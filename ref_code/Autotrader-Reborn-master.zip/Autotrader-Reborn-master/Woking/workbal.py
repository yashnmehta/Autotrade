a='0'

b =float(0)
print(b)