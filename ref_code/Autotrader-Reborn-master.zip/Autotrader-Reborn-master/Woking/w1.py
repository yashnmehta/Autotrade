a='-25'


b = float(a)
print(b)