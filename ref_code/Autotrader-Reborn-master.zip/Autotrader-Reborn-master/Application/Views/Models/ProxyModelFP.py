from PyQt5.QtCore import *




class ProxyModel (QSortFilterProxyModel): #Custom Proxy Model
    def __init__(self):
        super(ProxyModel,self).__init__()
        self.FolioName=''
        self.ClientName=''

    # def filterAcceptsRow(self, row, parent):
    #     if(self.onlyPoss==False):
    #         return True
    #     else:
    #         if(self.sourceModel().index(row, 10, parent).data() != 0 or self.sourceModel().index(row, 11, parent).data()!= 0 or self.sourceModel().index(row, 6, parent).data() == ' '):
    #             return True
    #         else:
    #             return False

    def filterAcceptsRow(self, row, parent):
        # print('filter')
        if (self.ClientName == 'ALL' and self.FolioName == 'ALL'):
            return True

        elif (self.FolioName == 'ALL'):
            if (self.sourceModel().index(row, 1, parent).data() == self.ClientName):
                return True
            else:
                return False
        elif (self.ClientName == 'ALL'):
            if (self.sourceModel().index(row, 3, parent).data() == self.FolioName):
                return True
            else:
                return False

        else:
            if (self.sourceModel().index(row, 1, parent).data() == self.ClientName and self.sourceModel().index(row, 3,
                                                                                                                 parent).data() == self.FolioName):
                # print(self.cllientCode,self.symbol)
                return True
            else:
                return False


    def setFolioName(self, Fname):
        self.FolioName = Fname
    def setClientName(self, Cname):
        self.ClientName = Cname
