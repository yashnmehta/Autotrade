from PyQt5.QtCore import *




class ProxyModel (QSortFilterProxyModel): #Custom Proxy Model
    def __init__(self):
        super(ProxyModel,self).__init__()
        self.type = 'ALL'

    def filterAcceptsRow(self, row, parent):
        # print('filter')
        if (self.type == 'All' ):
            return True

        elif (self.type == 'Active'):
            if (self.sourceModel().index(row, 14, parent).data() == 'Activated' or self.sourceModel().index(row, 14, parent).data() == 'Started'):
                return True
            else:
                return False
        elif (self.type == 'Stop'):
            if (self.sourceModel().index(row, 14, parent).data() == 'Stopped'):
                return True
            else:
                return False

        elif(self.type == 'Delete'):
            if (self.sourceModel().index(row, 14, parent).data() == 'Deleted'):
                # print(self.cllientCode,self.symbol)
                return True
            else:
                return False

        else:
            return True

    def setFilterType(self, type):
        self.type = type

