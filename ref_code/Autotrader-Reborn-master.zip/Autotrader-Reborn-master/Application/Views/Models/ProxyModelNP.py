from PyQt5.QtCore import *




class ProxyModel (QSortFilterProxyModel): #Custom Proxy Model
    def __init__(self):
        super(ProxyModel,self).__init__()
        self.cllientCode = 'ALL'
        self.symbol = 'ALL'

    def filterAcceptsRow(self, row, parent):
        # print('filter')
        if (self.cllientCode == 'ALL' and self.symbol == 'ALL'):
            return True

        elif (self.symbol == 'ALL'):
            if (self.sourceModel().index(row, 1, parent).data() == self.cllientCode):
                return True
            else:
                return False
        elif (self.cllientCode == 'ALL'):
            if (self.sourceModel().index(row, 5, parent).data() ==self.symbol):
                return True
            else:
                return False

        else:
            if (self.sourceModel().index(row, 1,parent).data() == self.cllientCode and self.sourceModel().index(row, 5,parent).data() == self.symbol):
                # print(self.cllientCode,self.symbol)
                return True
            else:
                return False

    def setClientCode(self, code):
        self.cllientCode = code

    def setSymbol(self, symbol):
        self.symbol = symbol