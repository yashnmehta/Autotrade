from PyQt5.QtCore import QObject,QFile,pyqtSignal,pyqtSlot,Qt,QSortFilterProxyModel,QTimer
from PyQt5.QtGui import QIcon, QKeySequence
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5 import uic
from os import path, getcwd

from Application.Utils.configReader import readConfig_All,refresh
from Theme.dt2 import dt1

import traceback
import logging

import platform
from Application.Utils.createTables import tables_details_tb

class msgbox(QMainWindow):
    def __init__(self,parent=None):
        try:

            super(msgbox, self).__init__(parent=None)



            loc1 = getcwd().split('Application')
            ui_login = path.join(loc1[0] , 'Resourses','UI','sr.ui')
            uic.loadUi(ui_login, self)
            osType = platform.system()

            if (osType == 'Darwin'):
                flags = Qt.WindowFlags(Qt.FramelessWindowHint | Qt.WA_TranslucentBackground)
            else:
                flags = Qt.WindowFlags( Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.WA_TranslucentBackground)
            self.setWindowFlags(flags)

            self.setAttribute(Qt.WA_TranslucentBackground)
            self.bt_ok.clicked.connect(self.hide)
            self.bt_cancle.clicked.connect(self.hide)
            # self.pixmap = QPixmap(bgImg)
            # self.setStyleSheet(dt1)

        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info())


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    form = msgbox()
    form.show()
    sys.exit(app.exec_())
