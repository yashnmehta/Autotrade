import platform
import traceback
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import uic
from Application.Utils import *
# from Application.Utils.animations import *
from Application.Utils.animations import *
from Resourses.icons import icons_rc
from os import path, getcwd
import qdarkstyle
from Theme.dt2 import dt1
from Application.Views.titlebar import tBar
from Application.Utils.configReader import *
from Application.Views.PendingOrder.support import *

import logging

class payOffChart(QMainWindow):

    def __init__(self, parent=None):
        try:

            super(payOffChart, self).__init__(parent=None)
            self.list1 = []
            self.rcount = 0
            self.sortOrder = 0
            self.sortColumn = 0

            refresh(self)

            loc1 = getcwd().split('Application')
            ui_login = path.join(loc1[0], 'Resourses', 'UI', 'inputPayoffchart1.ui')
            uic.loadUi(ui_login, self)

            osType = platform.system()

            if (osType == 'Darwin'):
                flags = Qt.WindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
            else:
                flags = Qt.WindowFlags(Qt.SubWindow | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
            self.setWindowFlags(flags)
            self.title = tBar('PAYOFF CHART')
            self.headerFrame.layout().addWidget(self.title, 0, 1)
            self.title.sgPoss.connect(self.movWin)
            dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()

            self.setStyleSheet(dt1)
            # tables_details_tb(self)
            self.isPayChartOpen = False
            self.btnSttn.clicked.connect(self.showPayOffWindow)

            self.createShortcuts()
            self.connectAllSlots()
            self.createAnimations()
            self.showPayOffWindow()
            QSizeGrip(self.frameGrip)

        except:
            print(traceback.print_exc())

    def connectAllSlots(self):

        self.bt_min.clicked.connect(self.showMinimized)
        self.bt_max.clicked.connect(self.showMaximized)
        self.bt_close.clicked.connect(self.hide)


    def createShortcuts(self):
        self.quitSc = QShortcut(QKeySequence('Esc'), self)
        self.quitSc.activated.connect(self.hide)

    def movWin(self, x, y):
        self.move(self.pos().x() + x, self.pos().y() + y)

    def showPayOffWindow(self):
        if (self.isPayChartOpen == False):
            self.anim101.setDuration(30)
            self.anim101.setStartValue(0)
            self.anim101.setEndValue(400)
            self.anim101.start()
            self.isPayChartOpen = True
        else:
            self.anim102.setDuration(30)
            self.anim102.setStartValue(400)
            self.anim102.setEndValue(0)
            self.anim102.start()
            self.isPayChartOpen = False

    def createAnimations(self):
        self.anim101 = QPropertyAnimation(self.settingsMenu, b"minimumWidth")
        self.anim102 = QPropertyAnimation(self.settingsMenu, b"minimumWidth")


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = payOffChart()
    form.show()

    sys.exit(app.exec_())