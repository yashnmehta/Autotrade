import os
import sys
import time
import traceback
from os import path, getcwd
import logging
import platform
import requests
# import notifypy
import json

from PyQt5.QtCore import QObject,QFile,pyqtSignal,pyqtSlot,Qt,QSortFilterProxyModel,QTimer
from PyQt5.QtGui import QIcon, QKeySequence
from PyQt5.QtWidgets import *
from PyQt5 import uic
from py_vollib.black_scholes import black_scholes
# import payOffChart
import qtpy
import qdarkstyle

from Application.Services.Xts.Api.servicesIA import PlaceOrder
from Application.Utils.createTables import tables_details_np
import pandas as pd
import datatable as dt
import numpy  as np

from Application.Utils.configReader import readConfig_All,refresh
from Application.Views.titlebar import tBar
from Application.Views.Models.tableNP import ModelPosition

from Theme.dt2 import dt1

from Application.Views.NetPosition.payOffChart import payOffChart
from Application.Views.NetPosition.support import createShortcuts

import pyqtgraph as pg
# import plotly.express as px
from Application.Utils import supMethods


class ProxyModel (QSortFilterProxyModel): #Custom Proxy Model
    def __init__(self):
        super(ProxyModel,self).__init__()
        self.onlyPoss = False

    def filterAcceptsRow(self, row, parent):
        if(self.onlyPoss == True):
            if(self.sourceModel().index(row, 7, parent).data() != 0 ):
                return True
            else:
                return False
        else:
            return True

class NetPosition(QMainWindow):
    # sgTmSubd=pyqtSignal(dict)
    sgTMTM=pyqtSignal(str)
    sgCallPOrderBook = pyqtSignal(str)
    sgCallTB = pyqtSignal(int)

    def __init__(self,parent=None):
        super(NetPosition, self).__init__(parent=None)
        try:

            self.onlyPoss = False
            self.filterStr = ''
            self.DayNet = 'NET'
            refresh(self)
            #####################################################################

            loc1 = getcwd().split('Application')
            ui_login = path.join(loc1[0] , 'Resourses','UI','netPosition.ui')
            uic.loadUi(ui_login, self)


            osType = platform.system()
            if (osType == 'Darwin'):
                flags = Qt.WindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
            else:
                flags = Qt.WindowFlags(Qt.SubWindow | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
            self.setWindowFlags(flags)

            self.payoffW = payOffChart()


            self.lastSerialNo = 0
            dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()
            self.setStyleSheet(dt1)

            tables_details_np(self)
            # self.tables_details()
            # self.tableView.horizontalHeader().sectionMoved.connect(print)
            self.tableView.customContextMenuRequested.connect(self.tableRightClickMenu_np)
            createShortcuts(self)
            # self.CreateToolBar()

            self.title = tBar('NET POSITION')
            self.headerFrame.layout().addWidget(self.title, 0, 0)
            self.title.sgPoss.connect(self.movWin)
            dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()
            QSizeGrip(self.netposGrip)
            self.connectAllSlots()
            self.graphWidget = pg.PlotWidget()

            self.payoffW.mainFrame.layout().addWidget(self.graphWidget,0,1)

            ########################################################################################################################
        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info()[1])

    def movWin(self, x, y):
        self.move(self.pos().x() + x, self.pos().y() + y)

    def connectAllSlots(self):
        self.bt_close_3.clicked.connect(self.hide)
        self.bt_min_3.clicked.connect(self.hide)
        self.cbClient.currentIndexChanged.connect(self.setClient)
        self.cbSymbol.currentIndexChanged.connect(self.setSymbol)
        self.pbShow.clicked.connect(self.Show)
        self.pbClear.clicked.connect(self.clearFilter)

    def Show(self):
        self.smodelP.setFilterFixedString('')

    def clearFilter(self):
        self.smodelP.setClientCode('ALL')
        self.smodelP.setSymbol('ALL')
        self.cbClient.setCurrentIndex(0)
        self.cbSymbol.setCurrentIndex(0)
        self.smodelP.setFilterFixedString('')

    def setClient(self):
        self.smodelP.setClientCode(self.cbClient.currentText())

    def setSymbol(self):
        self.smodelP.setSymbol(self.cbSymbol.currentText())

    def saveDefaultColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            # print(settingsFilePath)

            f1 = open(settingsFilePath)

            pathDetails= json.load(f1)
            # print(pathDetails)
            f1.close()
            defaultFilePath1 = pathDetails['NetPosition']['defaultColumnProfile']


            binData = self.tableView.horizontalHeader().saveState()

            loc1 = getcwd().split('Application')
            defaultFilePath = os.path.join(loc1[0], defaultFilePath1)
            # save = QFileDialog.getSaveFileName(self, 'Save file', dirctry)[0]
            with open(defaultFilePath, 'wb') as f:
                f.write(binData)
            f.close()
        except:
            print(traceback.print_exc())


    def updateDefaultColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
        f1 = open(settingsFilePath)
        pathDetails = json.load(f1)
        f1.close()
        lastCPFilePath1 = pathDetails['NetPosition']['defaultColumnProfile']
        lastCPFilePath = os.path.join(loc, lastCPFilePath1)

        with open(lastCPFilePath, 'rb') as f:
            binData = f.read()
        f.close()
        self.tableView.horizontalHeader().restoreState(binData)




    def lastSavedColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            f1 = open(settingsFilePath)
            pathDetails = json.load(f1)
            f1.close()
            lastCPFilePath1 = pathDetails['NetPosition']['lastSavedColumnProfile']
            lastCPFilePath = os.path.join(loc, lastCPFilePath1)

            with open(lastCPFilePath, 'rb') as f:
                binData = f.read()
            f.close()
            self.tableView.horizontalHeader().restoreState(binData)

            self.srNOIndex = 18
            for i in range(18):
                if (self.tableView.horizontalHeader().isSectionHidden(i)):
                    self.srNOIndex -= 1
            print('srno',self.srNOIndex)


        except:
            print(traceback.print_exc())

    def saveColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            defaultDir = os.path.join(loc, 'Resourses', 'ColumnProfile')


            binData = self.tableView.horizontalHeader().saveState()
            save = QFileDialog.getSaveFileName(self, 'Save file', defaultDir)[0]
            # print('save NetPosition save column profile',save)

            with open(save, 'wb') as f:
                f.write(binData)
            f.close()



            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            f1 = open(settingsFilePath)
            pathDetails= json.load(f1)
            f1.close()
            pathDetails['NetPosition']['lastSavedColumnProfile'] = save

            pathDetails_new = json.dumps(pathDetails, indent=4)


            f2 = open(settingsFilePath,'w+')
            f2.write(pathDetails_new)
            # pathDetails= json.load(f1)
            f2.close()




        except:
            print(traceback.print_exc())

    def openColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        defaultDir = os.path.join(loc, 'Resourses', 'ColumnProfile')

        save = QFileDialog.getOpenFileName(self, 'Open file', defaultDir)[0]

        with open(save, 'rb') as f:
            binData = f.read()
        f.close()

        self.tableView.horizontalHeader().restoreState(binData)

    def headerRightClickMenu(self, position):
        try:
            # print()
            # a=(self.tableView.selectedIndexes()[0].data())
            menu = QMenu()

            saveColumnProfile = menu.addAction("save col profile")
            restoreColumnProfile = menu.addAction("open Col Profile")
            hideColumn = menu.addAction("hide")
            reset = menu.addAction("reset")


            # cancelAction = menu.addAction("Cancel")
            action = menu.exec_(self.tableView.horizontalHeader().mapToGlobal(position))
            if action == saveColumnProfile:
                self.saveColumnProfile()
            elif (action == restoreColumnProfile):
                self.openColumnProfile()
            elif (action == hideColumn):

                self.srNOIndex = 18

                x = (self.tableView.horizontalHeader().logicalIndexAt(position))
                print('srNOIndex', self.srNOIndex, x)
                if (x != self.srNOIndex):
                    self.tableView.horizontalHeader().hideSection(x)
                    self.srNOIndex-=1


            elif (action == reset):
                self.updateDefaultColumnProfile()

        except:
            print(sys.exc_info()[1])

    #
    # def requestPayoffChart(self):
    #     self.payOffChart.show()


    def tableRightClickMenu_np(self, position):
        try:
            menu = QMenu()

            squareAction = menu.addAction("Square Off")
            # squareAction1 = menu.addAction("PARTH")
            payOfChart = menu.addAction("PayOffChart")
            # cancelAction = menu.addAction("Cancel")
            action = menu.exec_(self.tableView.mapToGlobal(position))
            if action == squareAction:
                self.squareOffSelected()
            elif action == payOfChart:
                self.requestPayoffChart()
        except:
            print(sys.exc_info()[1])

        #################################### Ends Here #############################################

    def squareOffSelected(self):
        try:

            # print('in square')
            indexes = self.tableView.selectedIndexes()
            srNOIndex = 18

            cc = self.modelP.columnCount()
            for i in range(18):
                if (self.tableView.horizontalHeader().isSectionHidden(i)):
                    srNOIndex -= 1

            # print('srNOIndex',srNOIndex)
            noOfVisibleColumn = self.modelP.columnCount()

            for i in range(cc):
                if (self.tableView.horizontalHeader().isSectionHidden(i)):
                    noOfVisibleColumn -= 1

            noOfSelectedRecords = int(len(indexes) / noOfVisibleColumn)
            print(noOfSelectedRecords)

            squareList = []
            for i in range(noOfSelectedRecords):
                srNO = indexes[(i * noOfVisibleColumn) + srNOIndex].data()

                exchange = self.Apipos[srNO, 2]
                clintID = self.Apipos[srNO, 1]
                token = self.Apipos[srNO, 3]
                qty = self.Apipos[srNO, 9]
                MaxQty = self.Apipos[srNO, 16]
                print(token,exchange)

                squareList.append([exchange, token, qty, MaxQty, clintID])

            for ix in squareList:
                token = ix[1]
                quantity = ix[2]
                exchange = ix[0]
                freezeQty = ix[3]
                clientId = ix[4]
                # print("Clien id : ", clientId)
                # print('do square',token, qty)

                if (quantity == 0):
                    print("zero")
                    pass
                elif quantity > 0:
                    # print("quantity > 0")
                    absQuantity = abs(quantity)
                    while (absQuantity > freezeQty):
                        # print('if while')
                        PlaceOrder(self, exchange=exchange, clientID=clientId, token=token, orderSide='Sell',
                                   qty=freezeQty,
                                   limitPrice=0.0,
                                   validity='DAY', disQty=0, triggerPrice=0, uid='MANUAL', orderType='MARKET',
                                   productType='NRML')
                        time.sleep(0.1)
                        absQuantity -= freezeQty
                    # print("Punch SELL")
                    PlaceOrder(self, exchange=exchange, clientID=clientId, token=token, orderSide='Sell',
                               qty=absQuantity,
                               limitPrice=0.0,
                               validity='DAY', disQty=0, triggerPrice=0, uid='MANUAL', orderType='MARKET',
                               productType='NRML')
                    time.sleep(0.1)
                    # print("SELL")
                else:
                    # print("quantity < 0")
                    absQuantity = abs(quantity)
                    while (absQuantity > freezeQty):
                        # print('else while < 0')
                        PlaceOrder(self, exchange=exchange, clientID=clientId, token=token, orderSide='Buy',
                                   qty=freezeQty,
                                   limitPrice=0.0,
                                   validity='DAY', disQty=0, triggerPrice=0, uid='MANUAL', orderType='MARKET',
                                   productType='NRML')
                        time.sleep(0.1)
                        absQuantity -= freezeQty
                    # print("Placee")
                    PlaceOrder(self, exchange=exchange, clientID=clientId, token=token, orderSide='Buy',
                               qty=absQuantity,
                               limitPrice=0.0,
                               validity='DAY', disQty=0
                               , triggerPrice=0, uid='MANUAL', orderType='MARKET',
                               productType='NRML')

                    time.sleep(0.1)
                    # print("BUY")
        except:
            print(traceback.print_exc())

    def requestPayoffChart(self):
        try:
            self.payoffW.hide()
            self.payoffW.show()
        except:
            print(traceback.print_exc())

    def getPayOffChart(self):

        try:
            try:
                self.graphWidget.line1.clear()
            except:
                pass
            lowerPoint = float(self.payoffInput.leSP.text())
            upperPoint = float(self.payoffInput.leEP.text())
            gap = float(self.payoffInput.leGap.text())

            x = lowerPoint
            stlmP = []
            while x<upperPoint:
                stlmP.append(x)
                x += gap

            d = []
            for ix in stlmP:
                d.append(self.getPayOfAt(ix))
            # print(stlmP)
            # print(d)
            self.graphWidget.line1 = self.graphWidget.plot(x=stlmP, y=d)


            # self.graphWidget.plot(x=stlmP, y=d)

        except:
            print(traceback.print_exc())

    def getPayOfAt(self,S):
        totalMtm = 0
        for i in self.Apipos:
            if (i[5] == 'BANKNIFTY'):
                try:
                    K =  float(i[7])

                    flag = i[8][0].lower()
                    t=0
                    r=0.001
                    sigma = 0.0001
                    tp = black_scholes(flag, S, K, t, r, sigma)

                    # print(S,i[7],i[8],i[9], i[11],tp)
                    mtm = i[9] * (tp - i[11])
                    totalMtm += mtm
                except:
                    pass
        return totalMtm


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = NetPosition()
    form.show()
    sys.exit(app.exec_())
