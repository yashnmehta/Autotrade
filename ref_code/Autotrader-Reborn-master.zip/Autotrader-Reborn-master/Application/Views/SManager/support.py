import traceback
import datetime
import datatable as dt
import numpy as np


def updatePbBGColor_filter(self,pb):
    try:
        self.lastSelectedFilter.setStyleSheet('background-color: #000a14;color: #F0F0F0;')
        if(pb=='All'):
            self.pbFAll.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedFilter =self.pbFAll
        elif(pb=='Active'):
            self.pbFActive.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedFilter =self.pbFActive
        elif(pb=='Stop'):
            self.pbFStop.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedFilter =self.pbFStop
        elif (pb == 'Delete'):
            self.pbFDelete.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedFilter = self.pbFDelete

    except:
        print(traceback.print_tb())

def filterStretegy(self,type):
    # print('----filter----',self.lastSelectedFilter)
    if(type=='All'):


        self.smodel.setFilterType('All')
        self.smodel.setFilterFixedString('')
    elif(type=='Active'):


        self.smodel.setFilterType('Active')
        self.smodel.setFilterFixedString('Activated')
    elif(type=='Stop'):


        self.smodel.setFilterType('Stop')
        self.smodel.setFilterFixedString('Stopped')

    elif(type=='Delete'):


        self.smodel.setFilterType('Delete')
        self.smodel.setFilterFixedString('Deleted')

def updatePbBGColor_stretegies(self,pb):
    try:
        self.lastSelectedStretegy.setStyleSheet('background-color: #000a14;color: #F0F0F0;')
        if(pb=='Stradle'):
            self.pbStradle.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy =self.pbStradle
        elif(pb=='Box'):
            self.pbBox.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy =self.pbBox
        elif(pb=='Custom'):
            self.pbCustomSt.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy =self.pbCustomSt
        elif(pb=='PairSell'):
            self.pbPairSell.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy =self.pbPairSell
        elif(pb=='PairSellAdv'):
            self.pbPairSellAdv.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy =self.pbPairSellAdv
        elif(pb=='TSpecial'):
            self.pbTSpecial.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy =self.pbTSpecial
        elif(pb=='JodiATM'):
            self.pbJodiATM.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy =self.pbJodiATM
        elif (pb == 'EMASpecial'):
            self.pbEMASpecial.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy = self.pbEMASpecial
        elif(pb=='Momentum'):
            self.pbMomentum.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy =self.pbMomentum
        elif(pb=='Pyramid'):
            self.pbPyramid.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy =self.pbPyramid
        elif(pb=='ValSpread'):
            self.pbValSp.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy =self.pbValSp
        elif(pb=='VixMonkey'):
            self.pbVixMonkey.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy =self.pbVixMonkey
        elif(pb=='JTiger'):
            self.pbJTiger.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy =self.pbJTiger
        elif (pb == 'OCheetah'):
            self.pbOCheetah.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy = self.pbOCheetah
        elif (pb == 'JodiST'):
            self.pbJodiST.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy = self.pbJodiST
        elif (pb == 'JCat'):
            self.pbJCat.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy = self.pbJCat
        elif (pb == 'LevelSpecial'):
            self.pbLevelSpecial.setStyleSheet('background: #148CD2;color: #19232d;')
            self.lastSelectedStretegy = self.pbLevelSpecial
    except:
        print(traceback.print_exc())

