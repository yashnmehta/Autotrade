from PyQt5.QtCore import QObject,QFile,pyqtSignal,pyqtSlot,Qt,QSortFilterProxyModel,QTimer
from PyQt5.QtGui import QIcon, QKeySequence
from PyQt5.QtWidgets import *
from PyQt5 import uic
from os import path, getcwd
import qtpy
import qdarkstyle
import sys
import pandas as pd
import datatable as dt
import numpy as np
import requests
import json

from Application.Views.BuyWindow.buyWindow import Ui_BuyW
from Application.Views.SellWindow.sellWindow import Ui_SellW
from Application.Views.SnapQuote.snapQuote import Ui_snapQ
from Application.Utils.dbConnection import  *
from Application.Utils.configReader import readConfig_All
from Application.Views.Models.tableFP import ModelPosition
from Application.Views.Models.ProxyModelStretegyManager import ProxyModel
from Application.Views.SManager.support import updatePbBGColor_stretegies,updatePbBGColor_filter,filterStretegy
from Theme.dt2 import dt1
import logging

from Application.Stretegies.TSpecial import TSpecial

class Manager(QMainWindow):
    # sgTmSubd=pyqtSignal(dict)
    sgTMTM=pyqtSignal(str)
    sgCallPOrderBook = pyqtSignal(str)
    sgCallTB = pyqtSignal(int)

    def __init__(self):
        super(Manager, self).__init__()
        try:


            #####################################################################
            loc1 = getcwd().split('Application')
            ui_login = os.path.join(loc1[0] , 'Resourses','UI','sManager.ui')
            uic.loadUi(ui_login, self)
            dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()
            self.setStyleSheet(dt1)

            self.MDheaders, self.IAheaders, self.MDToken, self.IAToken, self.URL, self.userID, self.source,self.MDKey,self.MDSecret,self.IAKey,self.IASecret,self.client_list,DClient,broadcastMode = readConfig_All()
            self.tables_details()

            ########################################################################################################################


            self.lastSelectedStretegy = self.pbStradle
            self.lastSelectedFilter = self.pbFAll


            self.stretegyList = []
            self.stretegyList_temp = []
            self.All_stretegyList=[]

            self.pbStradle.clicked.connect(lambda :updatePbBGColor_stretegies(self,'Stradle'))
            self.pbCustomSt.clicked.connect(lambda :updatePbBGColor_stretegies(self,'Custom'))
            self.pbBox.clicked.connect(lambda :updatePbBGColor_stretegies(self,'Box'))
            self.pbPairSell.clicked.connect(lambda :updatePbBGColor_stretegies(self,'PairSell'))
            self.pbPairSellAdv.clicked.connect(lambda :updatePbBGColor_stretegies(self,'PairSellAdv'))
            self.pbTSpecial.clicked.connect(lambda :updatePbBGColor_stretegies(self,'TSpecial'))
            self.pbJodiATM.clicked.connect(lambda :updatePbBGColor_stretegies(self,'JodiATM'))
            self.pbMomentum.clicked.connect(lambda :updatePbBGColor_stretegies(self,'Momentum'))
            self.pbVixMonkey.clicked.connect(lambda :updatePbBGColor_stretegies(self,'VixMonkey'))
            self.pbValSp.clicked.connect(lambda :updatePbBGColor_stretegies(self,'ValSpread'))
            self.pbOCheetah.clicked.connect(lambda :updatePbBGColor_stretegies(self,'OCheetah'))
            self.pbEMASpecial.clicked.connect(lambda :updatePbBGColor_stretegies(self,'EMASpecial'))
            self.pbJodiST.clicked.connect(lambda :updatePbBGColor_stretegies(self,'JodiST'))
            self.pbPyramid.clicked.connect(lambda :updatePbBGColor_stretegies(self,'Pyramid'))
            self.pbJTiger.clicked.connect(lambda :updatePbBGColor_stretegies(self,'JTiger'))
            self.pbJCat.clicked.connect(lambda: updatePbBGColor_stretegies(self, 'JCat'))
            self.pbLevelSpecial.clicked.connect(lambda: updatePbBGColor_stretegies(self, 'LevelSpecial'))
            self.pbFAll.clicked.connect(lambda :updatePbBGColor_filter(self,'All'))
            self.pbFAll.clicked.connect(lambda :filterStretegy(self,'All'))

            self.pbFActive.clicked.connect(lambda :updatePbBGColor_filter(self,'Active'))
            self.pbFActive.clicked.connect(lambda: filterStretegy(self,'Active'))

            self.pbFStop.clicked.connect(lambda :updatePbBGColor_filter(self,'Stop'))
            self.pbFStop.clicked.connect(lambda: filterStretegy(self,'Stop'))

            self.pbFDelete.clicked.connect(lambda :updatePbBGColor_filter(self,'Delete'))
            self.pbFDelete.clicked.connect(lambda: filterStretegy(self,'Delete'))

            # defaultData = self.tableView.horizontalHeader().saveState()
            # with open('default.bin', 'wb') as f:
            #     f.write(defaultData)
            # f.close()
            #
            # with open('abc.bin', 'rb') as f:
            #     binData = f.read()
            # f.close()

            # self.tableView.horizontalHeader().restoreState(binData)

            ########################################################################################################################
        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info()[1])

    def changeDayNet(self):
        if(self.rb1.isChecked()):
            self.DayNet = 'DAY'
            self.tableView.setModel(self.smodelFPD)
        elif(self.rb2.isChecked()):
            self.DayNet = 'NET'
            self.tableView.setModel(self.smodelFP)
            self.rcount = self.Apipos.shape[0]

    def orderRaise(self):
        token = int(self.tableView.selectedIndexes()[3].data())
        self.sgCallPOrderBook.emit(str(token))
    def showTB(self):
        token = int(self.tableView.selectedIndexes()[3].data())
        self.sgCallTB.emit(token)

    def tables_details(self):
        try:
            #############################################################################################################

            self.heads = ['SerialNo',
                          'UserID','ClientID','FolioNo','Status','MTM',
                          'SL','TSL','Target', 'symbol','Trend',
                          'S_type','date','TOC'
                          ]
            self.lastSerialNo = 0
            self.table =  np.empty((20000, 14),dtype=object)
            #############################################################################################################
            #############################################
            self.model = ModelPosition(self.table,self.heads)
            self.smodel = ProxyModel()
            self.smodel.setSourceModel(self.model)

            self.smodel.setDynamicSortFilter(False)
            self.smodel.setFilterKeyColumn(4)
            self.smodel.setFilterCaseSensitivity(False)

            self.tableView.setModel(self.smodel)


            self.tableView.horizontalHeader().setSectionsMovable(True)
            self.tableView.verticalHeader().setSectionsMovable(True)
            self.tableView.setContextMenuPolicy(Qt.CustomContextMenu)
            self.tableView.horizontalHeader().setContextMenuPolicy(Qt.CustomContextMenu)
            # self.tableView.customContextMenuRequested.connect(self.tableRightClickMenu)
            self.tableView.horizontalHeader().customContextMenuRequested.connect(self.headerRightClickMenu)
            self.tableView.setDragDropMode(self.tableView.InternalMove)
            self.tableView.setDragDropOverwriteMode(False)

            self.saveDefaultColumnProfile()
            self.lastSavedColumnProfile()
            # self.updateDefaultColumnProfile()

        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info()[1])


    def saveDefaultColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            # print(settingsFilePath)

            f1 = open(settingsFilePath)

            pathDetails= json.load(f1)
            # print(pathDetails)
            f1.close()
            defaultFilePath1 = pathDetails['SManager']['defaultColumnProfile']


            binData = self.tableView.horizontalHeader().saveState()
            loc1 = getcwd().split('Application')
            defaultFilePath = os.path.join(loc1[0], defaultFilePath1)
            # save = QFileDialog.getSaveFileName(self, 'Save file', dirctry)[0]
            with open(defaultFilePath, 'wb') as f:
                f.write(binData)
            f.close()
        except:
            print(traceback.print_exc())


    def updateDefaultColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
        f1 = open(settingsFilePath)
        pathDetails = json.load(f1)
        f1.close()
        lastCPFilePath1 = pathDetails['SManager']['defaultColumnProfile']
        lastCPFilePath = os.path.join(loc, lastCPFilePath1)

        with open(lastCPFilePath, 'rb') as f:
            binData = f.read()
        f.close()
        self.tableView.horizontalHeader().restoreState(binData)




    def lastSavedColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
        f1 = open(settingsFilePath)
        pathDetails = json.load(f1)
        f1.close()
        lastCPFilePath1 = pathDetails['SManager']['lastSavedColumnProfile']
        lastCPFilePath = os.path.join(loc, lastCPFilePath1)
        with open(lastCPFilePath, 'rb') as f:
            binData = f.read()
        f.close()
        self.tableView.horizontalHeader().restoreState(binData)


    def saveColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            defaultDir = os.path.join(loc, 'Resourses', 'ColumnProfile')


            binData = self.tableView.horizontalHeader().saveState()
            save = QFileDialog.getSaveFileName(self, 'Save file', defaultDir)[0]
            print('save smanager save column profile',save)

            with open(save, 'wb') as f:
                f.write(binData)
            f.close()



            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            f1 = open(settingsFilePath)
            pathDetails= json.load(f1)
            f1.close()
            pathDetails['SManager']['lastSavedColumnProfile'] = save

            pathDetails_new = json.dumps(pathDetails, indent=4)


            f2 = open(settingsFilePath,'w+')
            f2.write(pathDetails_new)
            # pathDetails= json.load(f1)
            f2.close()




        except:
            print(traceback.print_exc())

    def openColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        defaultDir = os.path.join(loc, 'Resourses', 'ColumnProfile')

        save = QFileDialog.getOpenFileName(self, 'Open file', defaultDir)[0]

        with open(save, 'rb') as f:
            binData = f.read()
        f.close()

        self.tableView.horizontalHeader().restoreState(binData)




    def filtr(self):
        try:
            self.smodelFP.setFilterFixedString(self.listView.selectedIndexes()[0].data())
        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info()[1])

    def headerRightClickMenu(self, position):
        try:
            # print()
            # a=(self.tableView.selectedIndexes()[0].data())
            menu = QMenu()

            saveColumnProfile = menu.addAction("save col profile")
            restoreColumnProfile = menu.addAction("open Col Profile")
            hideColumn = menu.addAction("hide")
            reset = menu.addAction("reset")

            # cancelAction = menu.addAction("Cancel")
            # cancelAction = menu.addAction("Cancel")
            action = menu.exec_(self.tableView.horizontalHeader().mapToGlobal(position))
            if action == saveColumnProfile:
                binData = self.tableView.horizontalHeader().saveState()
                # print(binData)
                save = QFileDialog.getOpenFileName(self, 'Open file', 'c:\\')

                with open(save, 'wb') as f:
                    f.write(binData)
                f.close()
            elif (action == restoreColumnProfile):
                with open('restore.bin', 'rb') as f:
                    binData = f.read()
                f.close()

                self.tableView.horizontalHeader().restoreState(binData)
            elif (action == hideColumn):

                x = (self.tableView.horizontalHeader().logicalIndexAt(position))
                self.tableView.horizontalHeader().hideSection(x)
            elif (action == reset):

                with open('default.bin', 'rb') as f:
                    defaultData = f.read()
                f.close()
                self.tableView.horizontalHeader().restoreState(defaultData)
        except:
            print(sys.exc_info()[1])

    def DeleteTableRow(self):
        pass

    def DeleteAction(self, position):
        try:
            # a=(self.tableView.selectedIndexes()[0].data())
            menu = QMenu()
            DeleteAction = menu.addAction("Delete")
            UndoAction = menu.addAction("Undo")
            # cancelAction = menu.addAction("Cancel")
            action = menu.exec_(self.tableView.mapToGlobal(position))
            if action == DeleteAction:
                self.DeleteAction()
            elif (action == UndoAction):
                self.UndoAction()
        except:
            print(sys.exc_info()[1])

    #################################### Ends Here #############################################



    def refresh_config(self):
        try:
            self.MDheaders, self.IAheaders, self.MDToken, self.IAToken, self.URL, self.userID, self.source,self.MDKey,self.MDSecret,self.IAKey,self.IASecret,self.client_list,DClient,broadcastMode = readConfig_All()
        except:
            logging.error(sys.exc_info()[1])


    def llp(self,a):
        self.sortOrder = self.smodelFP.sortOrder()
        self.sortColumn =self.smodelFP.sortColumn()

        self.sortOrderD = self.smodelFPD.sortOrder()
        self.sortColumnD =self.smodelFPD.sortColumn()

        self.smodelFP.setFilterKeyColumn(self.sortColumn)
        self.smodelFPD.setFilterKeyColumn(self.sortColumnD)

    def filterData(self,a):
        self.filterStr = a
        self.smodelFP.setFilterFixedString(self.filterStr)
        self.smodelFPD.setFilterFixedString(self.filterStr)

    def clearFilter(self):
        self.filterStr = ''
        self.smodelFPD.setFilterFixedString('')



if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = Manager()
    form.show()
    sys.exit(app.exec_())
