import json
import time
import traceback
import sys
from os import path, getcwd
from PyQt5.QtCore import QObject,QFile,pyqtSignal,pyqtSlot,Qt,QSortFilterProxyModel,QTimer
from PyQt5.QtGui import QIcon, QKeySequence
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5 import uic
import qdarkstyle
import qtpy

import logging
import pandas as pd
import datatable as dt
import requests
import numpy as np
from Application.Utils.dbConnection import  *
from Application.Utils.configReader import readConfig_All
from Application.Views.Models.tableOrder import ModelOB
from Theme.dt2 import dt1
import logging
from Application.Views.titlebar import tBar
from Application.Utils.createTables import tables_details_ob

import platform

class OrderBook(QMainWindow):
    # sgTmSubd=pyqtSignal(dict)

    def __init__(self,parent=None):
        try:
            super(OrderBook, self).__init__(parent=None)

            self.rcount = 0
            self.lastSerialNo = 0
            self.MDheaders, self.IAheaders, self.MDToken, self.IAToken, self.URL, self.userID, self.source,self.MDKey,self.MDSecret,self.IAKey,self.IASecret,self.client_list,DClient,broadcastMode = readConfig_All()
            #####################################################################

            loc1 = getcwd().split('Application')
            ui_login = os.path.join(loc1[0] ,'Resourses','UI','orderBook.ui')
            uic.loadUi(ui_login, self)

            osType = platform.system()
            if (osType == 'Darwin'):
                flags = Qt.WindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
            else:
                flags = Qt.WindowFlags(Qt.SubWindow | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)

            self.setWindowFlags(flags)

            self.title = tBar('OrderBook')
            self.headerFrame.layout().addWidget(self.title, 0, 0)
            self.title.sgPoss.connect(self.movWin)
            dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()
            self.setStyleSheet(dt1)
            tables_details_ob(self)
            self.actionCSV.triggered.connect(self.create_trade_csv)
            # self.leSearch = QLineEdit()
            # self.leSearch.setPlaceholderText('Search')
            # self.leSearch.setFixedWidth(150)
            self.createShortcuts()
            self.connectAllSlots()
            self.FillcbHeads()
            QSizeGrip(self.frameGrip)
        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info())

    def connectAllSlots(self):
        self.bt_close.clicked.connect(self.hide)
        self.bt_min.clicked.connect(self.hide)
        self.pbClear.clicked.connect(self.clearFilter)
        self.leSearch.textChanged.connect(self.changeFilter)
        self.cbHeads.currentIndexChanged.connect(self.setfilterColumn)

    def FillcbHeads(self):
        self.cbHeads.addItems(self.heads)
        self.smodelO.setFilterKeyColumn(0)

    def setfilterColumn(self):
        self.smodelO.setFilterKeyColumn(self.cbHeads.currentIndex())

    def clearFilter(self):
        self.smodelO.setFilterFixedString('')
        self.smodelO.setFilterKeyColumn(0)
        self.cbHeads.setCurrentIndex(0)
        self.leSearch.setText('')

    def changeFilter(self, a):
        # print(a)
        # self.smodelO.setFilterKeyColumn(0)
        self.smodelO.setFilterFixedString(a)

    def createShortcuts(self):
        self.quitSc = QShortcut(QKeySequence('Esc'), self)
        self.quitSc.activated.connect(self.hide)

    def movWin(self, x, y):
        self.move(self.pos().x() + x, self.pos().y() + y)

    def filtr(self):
        try:
            self.smodelT.setFilterFixedString(self.listView.selectedIndexes()[0].data())
            # print(self.listView.selectedIndexes()[0].data())
        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info())

    def updateGetApi(self,data):
        try:
            self.ApiOrder = data
            self.modelO = ModelOB(self.ApiOrder,self.heads)
            self.smodelO.setSourceModel(self.modelO)
            self.tableView.setModel(self.smodelO)
            self.rcount = self.ApiOrder.shape[0]

        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info())



    def refresh_config(self):
        try:
            self.MDheaders, self.IAheaders, self.MDToken, self.IAToken, self.URL, self.userID, self.source ,self.MDKey,self.MDSecret,self.IAKey,self.IASecret,self.client_list,DClient,broadcastMode= readConfig_All()
        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info())

    def create_trade_csv(self):
        try:
            name = QFileDialog.getSaveFileName(self, 'Save File')
            self.ApiTrade.to_csv(name[0])
        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info())

    def saveDefaultColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            # print(settingsFilePath)

            f1 = open(settingsFilePath)

            pathDetails= json.load(f1)
            # print(pathDetails)
            f1.close()
            defaultFilePath1 = pathDetails['OrderBook']['defaultColumnProfile']


            binData = self.tableView.horizontalHeader().saveState()
            loc1 = getcwd().split('Application')
            defaultFilePath = os.path.join(loc1[0], defaultFilePath1)
            # save = QFileDialog.getSaveFileName(self, 'Save file', dirctry)[0]
            with open(defaultFilePath, 'wb') as f:
                f.write(binData)
            f.close()
        except:
            print(traceback.print_exc())


    def updateDefaultColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
        f1 = open(settingsFilePath)
        pathDetails = json.load(f1)
        f1.close()
        lastCPFilePath1 = pathDetails['OrderBook']['defaultColumnProfile']
        lastCPFilePath = os.path.join(loc, lastCPFilePath1)

        with open(lastCPFilePath, 'rb') as f:
            binData = f.read()
        f.close()
        self.tableView.horizontalHeader().restoreState(binData)




    def lastSavedColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
        f1 = open(settingsFilePath)
        pathDetails = json.load(f1)
        f1.close()
        lastCPFilePath = pathDetails['OrderBook']['lastSavedColumnProfile']
        with open(lastCPFilePath, 'rb') as f:
            binData = f.read()
        f.close()
        self.tableView.horizontalHeader().restoreState(binData)


    def saveColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            defaultDir = os.path.join(loc, 'Resourses', 'ColumnProfile')
            binData = self.tableView.horizontalHeader().saveState()
            save = QFileDialog.getSaveFileName(self, 'Save file', defaultDir)[0]
            print('save OrderBook save column profile',save)

            with open(save, 'wb') as f:
                f.write(binData)
            f.close()



            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            f1 = open(settingsFilePath)
            pathDetails= json.load(f1)
            f1.close()
            pathDetails['OrderBook']['lastSavedColumnProfile'] = save

            pathDetails_new = json.dumps(pathDetails, indent=4)


            f2 = open(settingsFilePath,'w+')
            f2.write(pathDetails_new)
            # pathDetails= json.load(f1)
            f2.close()




        except:
            print(traceback.print_exc())

    def openColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        defaultDir = os.path.join(loc, 'Resourses', 'ColumnProfile')

        save = QFileDialog.getOpenFileName(self, 'Open file', defaultDir)[0]

        with open(save, 'rb') as f:
            binData = f.read()
        f.close()

        self.tableView.horizontalHeader().restoreState(binData)

    def headerRightClickMenu(self, position):
        try:
            # print()
            # a=(self.tableView.selectedIndexes()[0].data())
            menu = QMenu()

            saveColumnProfile = menu.addAction("save col profile")
            restoreColumnProfile = menu.addAction("open Col Profile")
            hideColumn = menu.addAction("hide")
            reset = menu.addAction("reset")

            # cancelAction = menu.addAction("Cancel")
            action = menu.exec_(self.tableView.horizontalHeader().mapToGlobal(position))
            if action == saveColumnProfile:
                self.saveColumnProfile()
            elif (action == restoreColumnProfile):
                self.openColumnProfile()
            elif (action == hideColumn):

                x = (self.tableView.horizontalHeader().logicalIndexAt(position))
                self.tableView.horizontalHeader().hideSection(x)
            elif (action == reset):
                self.updateDefaultColumnProfile()
        except:
            print(sys.exc_info()[1])



    def tableRightClickMenu(self, position):
        try:
            # a=(self.tableView.selectedIndexes()[0].data())
            menu = QMenu()

            squareAction = menu.addAction("Square")
            squareAction1 = menu.addAction("PARTH")
            # cancelAction = menu.addAction("Cancel")
            action = menu.exec_(self.tableView.mapToGlobal(position))
            if action == squareAction:
                pass
        except:
            print(sys.exc_info()[1])


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    form = OrderBook()
    form.show()
    sys.exit(app.exec_())
