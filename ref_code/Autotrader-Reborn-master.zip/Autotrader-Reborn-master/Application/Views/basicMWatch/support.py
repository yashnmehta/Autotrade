import logging
import sys
import threading
import traceback

import numpy as np

from Application.Services.Xts.Api.servicesIA import cancle_order
# from Application.Views.Basic.support import getFolioNo


def getClientId(self,filterValue):
    return 0

def getSerialNumber(self,filterValue):
    fltr = np.asarray([filterValue])
    value = self.table[np.in1d(self.table[:, 22], fltr),2]
    return value[0]

def getToken(self,filterValue):
    fltr = np.asarray([filterValue])
    value = self.table[np.in1d(self.table[:, 22], fltr),0]
    return value[0]

def getInstrumentType(self,filterValue):
    fltr = np.asarray([filterValue])
    value = self.table[np.in1d(self.table[:, 22], fltr),2]
    return value[0]

def getLTP(self,filterValue):
    fltr = np.asarray([filterValue])
    value = self.table[np.in1d(self.table[:, 22], fltr),9]
    return value[0]

def getSymbol(self,filterValue):
    fltr = np.asarray([filterValue])
    value = self.table[np.in1d(self.table[:, 22], fltr),3]
    return value[0]

def getExchange(self,filterValue):
    fltr = np.asarray([filterValue])
    value = self.table[np.in1d(self.table[:, 22], fltr),1]
    # print('getExchange',filterValue,value)
    return value[0]

def getStrikePrice(self,filterValue):
    fltr = np.asarray([filterValue])
    value = self.table[np.in1d(self.table[:, 22], fltr),5]
    return value[0]


def getExpiry(self,filterValue):
    fltr = np.asarray([filterValue])
    value = self.table[np.in1d(self.table[:, 22], fltr),4]
    return value[0]

def getOptionType(self,filterValue):
    fltr = np.asarray([filterValue])
    value = self.table[np.in1d(self.table[:, 22], fltr),6]
    return value[0]

def getStockName(self,filterValue):
    fltr = np.asarray([filterValue])
    value = self.table[np.in1d(self.table[:, 22], fltr),23]
    return value[0]

def unsubscribeToken(main):
   # print(main.marketWB.deletedtoken)
   main.recv_fo.Unsubscribedlist('BasicMarketWatch',main.marketWB.exch,main.marketWB.deletedtoken)


def delScript(self):
    try:
        indexes = self.tableView.selectedIndexes()
        srNOIndex = 22
        # self.tableView.horizontalHeader().isSectionHidden(22,True).deleteRow()

        cc= self.model.columnCount()
        for i in range(22):
            if(self.tableView.horizontalHeader().isSectionHidden(i)):
                srNOIndex -=1

        # it gives result as ex : 1.00 which cant directly convert to int as thowing base 10 error
        # for quick fix it convert to float and then int
        srNOF = float(indexes[srNOIndex].data())
        #print('srNo', srNOF)
        srNO = int(srNOF)

        self.deletedtoken=self.table[srNO,0]
        self.exch=self.table[srNO,1]
        #print('srNo inty', srNO)


        self.table[srNO:500-1,:] = self.table[srNO+1:500,:]
        for j,i in enumerate(self.table):
            self.table[j,22] = j

        self.lastSerialNo -= 1
        self.model.DelRows()
        ind = self.model.index(0, 0)
        ind1 = self.model.index(0, 31)

        self.model.dataChanged.emit(ind, ind1)





    except:
        logging.error(sys.exc_info()[1])
        print(traceback.print_exc())

def deleteRow(self):
    pass
#
#
#
#
