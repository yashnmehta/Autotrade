import logging
import sys
import traceback

from os import path, getcwd
import threading
import time
import requests
import json



from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import uic

import qdarkstyle
import qtpy

# import numpy as np
# import datatable as dt
# import pandas as pd

# import dill
# import pickle

from Application.Utils.openRequstedWindow import multiOrdersRequested

from Application.Utils.configReader import *
from Theme.dt2 import  dt1


class MarketW(QMainWindow):
    # sgTmSubd=pyqtSignal(dict)
    sgSnapQuote=pyqtSignal(int,int,int)
    sgShowPending= pyqtSignal(str)
    def __init__(self):
        super(MarketW, self).__init__()
        self.setObjectName('MarketWatch')

        #####################################################################
        try:
            loc1 = getcwd().split('Application')
            ui_login = os.path.join(loc1[0] , 'Resourses','UI','MW.ui')
            uic.loadUi(ui_login, self)

            dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()
            self.setStyleSheet(dt1)
            self.setCentralWidget(self.tableView)

            self.lastSerialNo = 0
            self.onlyPoss =False
            #
            # self.tableView.horizontalHeader().customContextMenuRequested.connect(self.rightClickMenu1)
            # self.tableView.customContextMenuRequested.connect(self.rightClickMenu)

            self.tableView.horizontalHeader().sectionClicked.connect(self.changeFilterColumn)
            self.createToolBar()

        except:
            print(traceback.print_exc(),'mwatch')
            logging.error(sys.exc_info()[1])
        ########################################################################################################################

    def createToolBar(self):
        self.leSearch = QLineEdit()
        self.leSearch.setPlaceholderText('Search')
        self.leSearch.setFixedWidth(150)
        self.leSearch.textChanged.connect(self.filterData)

        self.pbClear = QPushButton()
        self.pbClear.setText('Clear')

        self.toolBar.addWidget(self.leSearch)
        self.toolBar.addSeparator()
        self.cxbMore = QCheckBox('More')
        self.toolBar.addWidget(self.pbClear)
        self.toolBar.addSeparator()
        self.toolBar.addWidget(self.cxbMore)
        self.pbClear.clicked.connect(self.clearFilter)

    def clearFilter(self):
        self.leSearch.setText('')
        self.smodel.setFilterKeyColumn(3)

    def filterData(self):
        self.smodel.setFilterFixedString(self.leSearch.text())


    def changeFilterColumn(self,columnNo):
        # print("columnNo",columnNo)
        self.smodel.setFilterKeyColumn(columnNo)

    def headerRightClickMenu_mw(self, position):
        try:
            print('abc',self)
            # a=(self.tableView.selectedIndexes()[0].data())
            menu = QMenu()

            saveColumnProfile = menu.addAction("save col profile")
            restoreColumnProfile = menu.addAction("open Col Profile")
            hideColumn = menu.addAction("hide")
            reset = menu.addAction("reset")

            # cancelAction = menu.addAction("Cancel")
            action = menu.exec_(self.tableView.horizontalHeader().mapToGlobal(position))
            if action == saveColumnProfile:
                self.saveColumnProfile()
            elif (action == restoreColumnProfile):
                self.openColumnProfile()
            elif (action == hideColumn):

                srNOIndex = 30
                # for i in range(len(self.heads)):
                #     if (self.tableView.horizontalHeader().isSectionHidden(i)):
                #         srNOIndex -= 1
                #

                x = (self.tableView.horizontalHeader().logicalIndexAt(position))
                # print('srNOIndex',srNOIndex,x)
                if (x != srNOIndex):
                    self.tableView.horizontalHeader().hideSection(x)

            elif (action == reset):
                self.updateDefaultColumnProfile()
        except:
            print(sys.exc_info()[1])

    def saveDefaultColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            # print(settingsFilePath)

            f1 = open(settingsFilePath)

            pathDetails= json.load(f1)
            # print(pathDetails)
            f1.close()
            defaultFilePath1 = pathDetails['MarketWatch']['defaultColumnProfile']


            binData = self.tableView.horizontalHeader().saveState()
            # save = QFileDialog.getSaveFileName(self, 'Save file', dirctry)[0]

            loc1 = getcwd().split('Application')
            defaultFilePath = os.path.join(loc1[0] , defaultFilePath1)

            with open(defaultFilePath, 'wb') as f:
                f.write(binData)
            f.close()
        except:
            print(traceback.print_exc())


    def updateDefaultColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
        f1 = open(settingsFilePath)
        pathDetails = json.load(f1)
        f1.close()
        lastCPFilePath1 = pathDetails['MarketWatch']['defaultColumnProfile']
        lastCPFilePath = os.path.join(loc, lastCPFilePath1)


        with open(lastCPFilePath, 'rb') as f:
            binData = f.read()
        f.close()
        self.tableView.horizontalHeader().restoreState(binData)
    def lastSavedColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
        f1 = open(settingsFilePath)
        pathDetails = json.load(f1)
        f1.close()
        lastCPFilePath1 = pathDetails['MarketWatch']['lastSavedColumnProfile']
        lastCPFilePath = os.path.join(loc, lastCPFilePath1)
        # print(lastCPFilePath)
        with open(lastCPFilePath, 'rb') as f:
            binData = f.read()
        f.close()
        self.tableView.horizontalHeader().restoreState(binData)
    def saveColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            defaultDir = os.path.join(loc, 'Resourses', 'ColumnProfile')
            binData = self.tableView.horizontalHeader().saveState()
            save = QFileDialog.getSaveFileName(self, 'Save file', defaultDir)[0]
            # print('save FolioBook save column profile',save)

            with open(save, 'wb') as f:
                f.write(binData)
            f.close()
            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            f1 = open(settingsFilePath)
            pathDetails= json.load(f1)
            f1.close()
            pathDetails['MarketWatch']['lastSavedColumnProfile'] = save
            pathDetails_new = json.dumps(pathDetails, indent=4)


            f2 = open(settingsFilePath,'w+')
            f2.write(pathDetails_new)
            # pathDetails= json.load(f1)
            f2.close()

        except:
            print(traceback.print_exc())

    def openColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        defaultDir = os.path.join(loc, 'Resourses', 'ColumnProfile')

        save = QFileDialog.getOpenFileName(self, 'Open file', defaultDir)[0]

        with open(save, 'rb') as f:
            binData = f.read()
        f.close()

        self.tableView.horizontalHeader().restoreState(binData)


    # def headerRightClickMenu(self, position):
    #     try:
    #         # print()
    #         # a=(self.tableView.selectedIndexes()[0].data())
    #         menu = QMenu()
    #
    #         saveColumnProfile = menu.addAction("save col profile")
    #         restoreColumnProfile = menu.addAction("open Col Profile")
    #         hideColumn = menu.addAction("hide")
    #         reset = menu.addAction("reset")
    #
    #         # cancelAction = menu.addAction("Cancel")
    #         action = menu.exec_(self.tableView.horizontalHeader().mapToGlobal(position))
    #         if action == saveColumnProfile:
    #             self.saveColumnProfile()
    #         elif (action == restoreColumnProfile):
    #             self.openColumnProfile()
    #         elif (action == hideColumn):
    #
    #             srNOIndex = 30
    #
    #             x = (self.tableView.horizontalHeader().logicalIndexAt(position))
    #             print('srNOIndex', srNOIndex, x)
    #             if (x != srNOIndex):
    #                 self.tableView.horizontalHeader().hideSection(x)
    #         elif (action == reset):
    #             self.updateDefaultColumnProfile()
    #     except:
    #         print(sys.exc_info()[1])



    # def tableRightClickMenu(self, position):
    #     try:
    #         # a=(self.tableView.selectedIndexes()[0].data())
    #         Menu = QMenu()
    #         # QuickT = Menu.addAction("QuickT")
    #         # action = self.Menu.exec_(self.tableView.mapToGlobal(position))
    #
    #         SubMenu = QMenu(Menu)
    #         SubMenu.setTitle('QuickT')
    #         Multi = SubMenu.addAction('MultiOrder')
    #         Swap = SubMenu.addAction('Swap')
    #         Spread = SubMenu.addAction('Spread')
    #         Menu.addMenu(SubMenu)
    #         action = Menu.exec_(self.tableView.mapToGlobal(position))
    #         if action == Multi:
    #             self.multiOrdersRequested('MarketWatch')
    #
    #     except:
    #         print(traceback.print_exc())
    #




if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = MarketW()
    form.show()
    sys.exit(app.exec_())






comment="""
contract master cd 
contract master in database




# # print(a['Token'])
# arrrr=np.where(self.table2 == a['Token'])[0][0]
# print(arrrr)
# for i in range(self.NOC):
#     ind = self.model.index(arrrr, i)
#     self.model.data(index=ind,role=0)
#     self.model.data(index=ind,role=7)
#     self.model.data(index=ind,role=8)

"""