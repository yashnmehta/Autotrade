import numpy as np
import traceback
import sys

def showFeedManagerWindow(self):
    print("showFeedManagerWindow")
    feedManager = self.feedManager
    print("showFeedManagerWindow")
    print("showFeedManagerWindow:", self.port_fo, self.port_cash)
    feedManager.leFOPort.setText(str(self.port_fo))

    # feedManager.leCDPort.setText(str(self.port_cd))
    # print("showFeedManagerWindow", self.port_cd)
    feedManager.leCMPort.setText(str(self.port_cash))
    print("showFeedManagerWindow",self.port_cash)
    feedManager.show()

def connectFeed(self):
    feedManager =  self.feedManager
    print(":::", feedManager.cbSelectFeed.currentText())
    if(feedManager.cbSelectFeed.currentText() == 'Rebroadcater'):
        # self.cancelAllMDAPIConnction()
        self.broadcastReader.join_grp()
    feedManager.hide()
