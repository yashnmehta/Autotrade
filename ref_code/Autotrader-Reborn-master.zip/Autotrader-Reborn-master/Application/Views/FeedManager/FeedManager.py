from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import uic
from os import path, getcwd
import numpy as np
from Application.Services.Xts.Api.servicesIA import modifyOrder
import qdarkstyle
from Theme.dt2 import dt1
import traceback
# from Resourses.icons import icons_rc
import platform
import datatable as dt
from Application.Views.MultiOrders import  support

class Ui_FeedManager(QWidget):

    sgFin=pyqtSignal()
    ################################# Intialization Here ##################################################
    def __init__(self,parent=None):
        super(Ui_FeedManager, self).__init__(parent=None)

        loc1 = getcwd().split('Application')
        # logDir = loc1[0] + '\\Logs\\%s'%today

        ui_login = path.join(loc1[0], 'Resourses','UI','feedManager.ui')
        uic.loadUi(ui_login, self)
        osType = platform.system()
        # if (osType == 'Darwin'):
        #     flags = Qt.WindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        # else:
        #     flags = Qt.WindowFlags(Qt.SubWindow | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        # if (osType == 'Darwin'):
        #     flags = Qt.WindowFlags( Qt.WindowStaysOnTopHint)
        # else:
        #     flags = Qt.WindowFlags(Qt.SubWindow | Qt.WindowStaysOnTopHint)
        #
        # self.setWindowFlags(flags)
        dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()
        self.setStyleSheet(dt1)
       # QSizeGrip(self.sGripFrame)

    def createShortcuts(self):
        self.quitSc = QShortcut(QKeySequence('Esc'), self)
        self.quitSc.activated.connect(self.hide)

    def hideWindow(self):
        self.hide()



if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = Ui_FeedManager()
    form.show()
    sys.exit(app.exec_())
