import json
import traceback

from PyQt5.QtWidgets import QMenu



settings_location = ""

def load_settings(self):
    load_Order(self)
    loadFeeds()
    loadGeneral()
    loadStatus()

def load_Order(self):
    f1 = open(settings_location)
    jConfig = json.load(f1)
    # print(jConfig)


def connect2selectedFeeds(main):
    try:
        print('connnnecccct')
        selectedFeed=main.PreferanceW.cbSelectFeed.currentText()

        if selectedFeed=='UDP Feeds':
            # main.LiveFeed.sgNPFrec.disconnect(main.on_new_feed_1501)
            main.recv_fo.sgData7202.connect(main.on_new_feed_7202)
            main.recv_fo.sgData7208.connect(main.on_new_feed_7208)

        elif selectedFeed == 'API socket':
            # main.recv_fo.sgData7202.disconnect(main.on_new_feed_7202)
            main.LiveFeed.sgNPFrec.connect(main.on_new_feed_1501)
    except:
        print(traceback.print_exc())

def disconnect2selectedFeeds(main):
    try:

        selectedFeed=main.PreferanceW.cbSelectFeed.currentText()

        if selectedFeed=='UDP Feeds':
            # main.LiveFeed.sgNPFrec.disconnect(main.on_new_feed_1501)
            main.recv_fo.sgData7202.disconnect(main.on_new_feed_7202)
            main.recv_fo.sgData7208.disconnect(main.on_new_feed_7208)

        elif selectedFeed == 'API socket':
            # main.recv_fo.sgData7202.disconnect(main.on_new_feed_7202)
            main.LiveFeed.sgNPFrec.disconnect(main.on_new_feed_1501)
    except:
        print(traceback.print_exc())


def loadFeeds(self):
    pass


def loadGeneral(self):
    pass


def loadStatus(self):
    pass
    # self.pbSttsApply.clicked.connect(main.changeStatusBarSettings)


#
# def headerRightClickMenu(self, position):
#     try:
#         print()
#
#
#         menu = QMenu()
#         action = menu.exec_(self.tableView.horizontalHeader().mapToGlobal(position))
#         DefaultFocus= menu.addAction("DefaultFocus")
#
#         if action == DefaultFocus1:
#             self.DefaultFocus()
#         elif (action == DefaultFocus2):
#             x = (self.tableView.horizontalHeader().logicalIndexAt(position))
#             self.tableView.horizontalHeader().hideSection(x)
#         elif (action == reset):
#             self.updateDefaultColumnProfile()
#     except:
#         print(sys.exc_info()[1])