import logging
import time

import numpy as np
import traceback
import sys

from PyQt5.QtWidgets import QMessageBox

from Application.Views.basicMWatch import support as basicMarketSupport
from Application.Views.MarketWatch import support as marketSupport
import datatable as dt
from Application.Services.Xts.Api.servicesIA import PlaceOrder
#
# def updateMultiOrderstable(self, data):
#     try:
#         j = 0
#         self.table[:, :] = ''
#         for i in data:
#             self.table[j, :] = i
#             print(self.model._data)
#             ind = self.model.index(0, 0)
#             ind1 = self.model.index(0, 31)
#
#             self.model.dataChanged.emit(ind, ind1)
#             j += 1
#
#     except:
#         print(traceback.print_exc(), sys.exc_info())
# def hideWindow(self):
#     self.isFresh = True
# #
def showWindow(self, superClass ):

    try:
        if (self.spreadOrder.isVisible()):
            self.spreadOrder.hideWindow()

        if (superClass == 'MarketWatch'):
            marketwatchSupportRef = marketSupport
            marketwatchRef = self.marketW

            indexes = self.marketW.tableView.selectedIndexes()
            srNOIndex = 30
            for i in range(30):
                if (self.marketW.tableView.horizontalHeader().isSectionHidden(i)):
                    srNOIndex -= 1
            noOfVisibleColumns = len(self.marketW.heads)
            for i in range(len(self.marketW.heads)):
                if (self.marketW.tableView.horizontalHeader().isSectionHidden(i)):
                    noOfVisibleColumns -= 1

            selectedLen = len(indexes)
            noOfSelectedRecord = int(selectedLen / noOfVisibleColumns)

            srNOIndex1 = srNOIndex
            srNOIndex2 = srNOIndex + noOfVisibleColumns

            srNO1 = int(float(indexes[srNOIndex1].data()))
            srNO2 = int(float(indexes[srNOIndex2].data()))

        elif (superClass == 'MarketWatch_basic'):
            marketwatchSupportRef =basicMarketSupport
            marketwatchRef = self.marketW

            indexes = self.marketWB.tableView.selectedIndexes()
            srNOIndex = 22
            for i in range(22):
                if (self.marketWB.tableView.horizontalHeader().isSectionHidden(i)):
                    srNOIndex -= 1

            noOfVisibleColumns = len(self.marketWB.heads)
            for i in range(len(self.marketWB.heads)):
                if (self.marketWB.tableView.horizontalHeader().isSectionHidden(i)):
                    noOfVisibleColumns -= 1



        if(noOfSelectedRecord == 2 ):
            print('testing',marketwatchSupportRef.getSymbol(marketwatchRef,srNO2))
            self.spreadOrder.exchangeBuy = marketwatchSupportRef.getExchange(marketwatchRef,srNO1)
            self.spreadOrder.exchangeSell = marketwatchSupportRef.getExchange(marketwatchRef,srNO2)

            symbolBuy = marketwatchSupportRef.getSymbol(marketwatchRef,srNO1)
            symbolSell = marketwatchSupportRef.getSymbol(marketwatchRef,srNO2)

            self.spreadOrder.cbSymbolBuy.setCurrentText(symbolBuy)
            self.spreadOrder.cbSymbolSell.setCurrentText(symbolSell)

            expiryBuy = marketwatchSupportRef.getExpiry(marketwatchRef, srNO1)
            expirySell= marketwatchSupportRef.getExpiry(marketwatchRef, srNO2)

            self.spreadOrder.cbExpBuy.setCurrentText(expiryBuy)
            self.spreadOrder.cbExpSell.setCurrentText(expirySell)

            strikePriceBuy = marketwatchSupportRef.getStrikePrice(marketwatchRef,srNO1)
            strikePriceSell = marketwatchSupportRef.getStrikePrice(marketwatchRef,srNO2)

            self.spreadOrder.cbStrikeBuy.setCurrentText(strikePriceBuy)
            self.spreadOrder.cbStrikeSell.setCurrentText(strikePriceSell)

            optionTypeBuy = marketwatchSupportRef.getOptionType(marketwatchRef,srNO1)
            optionTypeSell = marketwatchSupportRef.getOptionType(marketwatchRef,srNO2)

            self.spreadOrder.cbOptBuy.setCurrentText(optionTypeBuy)
            self.spreadOrder.cbOptSell.setCurrentText(optionTypeSell)

            ltpBuy = marketwatchSupportRef.getInstrumentType(marketwatchRef,srNO1)
            ltpSell = marketwatchSupportRef.getInstrumentType(marketwatchRef,srNO2)

            SNameBuy = marketwatchSupportRef.getStockName(marketwatchRef,srNO1)
            SNameSell = marketwatchSupportRef.getStockName(marketwatchRef,srNO2)

            ClientIDBuy = marketwatchSupportRef.getClientId(marketwatchRef,srNO1)
            ClientIDSell = marketwatchSupportRef.getClientId(marketwatchRef,srNO2)

            tokenBuy = marketwatchSupportRef.getToken(marketwatchRef, srNO1)
            tokenSell = marketwatchSupportRef.getToken(marketwatchRef, srNO2)

            ##############################################
            self.spreadOrder.cbClientID.clear()
            self.spreadOrder.cbClientID.addItem(ClientIDBuy)
            self.spreadOrder.clientBuy = ClientIDBuy
            self.spreadOrder.clientSell = ClientIDSell
            ##############################################

            self.spreadOrder.tokenBuy = marketwatchSupportRef.getToken(marketwatchRef,srNO1)
            self.spreadOrder.tokenSell = marketwatchSupportRef.getToken(marketwatchRef,srNO2)

            self.spreadOrder.ex1 = marketwatchSupportRef.getExchange(marketwatchRef,srNO1)
            self.spreadOrder.ex2 = marketwatchSupportRef.getExchange(marketwatchRef,srNO2)

            self.spreadOrder.show()


        else:
            self.messageBox = QMessageBox(self)
            self.messageBox.setIcon(QMessageBox.Information)
            self.messageBox.setText("Selected record should be 2!!!")
            self.messageBox.show()



    except:
        print(traceback.print_exc(), sys.exc_info())

def alternateSymbol(self):
    tempSymbol = self.cbSymbolBuy.currentText()
    tempSymbol2 = self.cbSymbolSell.currentText()

    tempExp = self.cbExpBuy.currentText()
    tempExp2 = self.cbExpSell.currentText()

    tempStrike = self.cbStrikeBuy.currentText()
    tempStrike2 = self.cbStrikeSell.currentText()

    tempOpt = self.cbOptBuy.currentText()
    tempOpt2 = self.cbOptSell.currentText()

    self.cbSymbolBuy.setCurrentText(tempSymbol2)
    self.cbSymbolSell.setCurrentText(tempSymbol)

    time.sleep(0.02)
    alternateExp(self,tempExp,tempExp2,tempStrike,tempStrike2,tempOpt,tempOpt2)
    time.sleep(0.02)
    alternateStrike (self,tempExp,tempExp2,tempStrike,tempStrike2,tempOpt,tempOpt2)
def alternateExp(self,tempExp,tempExp2,tempStrike,tempStrike2,tempOpt,tempOpt2):
    try:
        self.cbExpBuy.setCurrentText(tempExp2)
        self.cbExpSell.setCurrentText(tempExp)

    except:
        print(traceback.print_exc())

def alternateStrike(self,tempExp,tempExp2,tempStrike,tempStrike2,tempOpt,tempOpt2):
    self.cbStrikeBuy.setCurrentText(tempStrike2)
    self.cbStrikeSell.setCurrentText(tempStrike)
    print('l1')

    self.cbOptBuy.setCurrentText(tempOpt2)
    self.cbOptSell.setCurrentText(tempOpt)

    tempToken = self.tokenBuy
    self.tokenBuy = self.tokenSell
    self.tokenSell = tempToken

    tempLtp = self.lbLTPBuy.text()
    tempLtp2 = self.lbLTPSell.text()
    self.lbLTPBuy.setText(tempLtp2)
    self.lbLTPSell.setText(tempLtp)


def executeSpreadOrders(self):
    leQtyBuy = int(float(self.spreadOrder.leQtyBuy.text()))
    leQtySell = int(float(self.spreadOrder.leQtySell.text()))
    if (leQtyBuy <=0 ):
        self.spreadOrder.messageBox.setText('Please Enter Valid Qty!!!')
        self.spreadOrder.messageBox.show()
    else:
        if (self.spreadOrder.exchangeBuy == 'NSEFO'):
            ins_details_buy = self.fo_contract[self.spreadOrder.tokenBuy - 35000]
        else:
            ins_details_buy = self.fo_contract[self.spreadOrder.tokenBuy - 35000]
        if (self.spreadOrder.exchangeSell == 'NSEFO'):
            ins_details_sell = self.fo_contract[self.spreadOrder.tokenSell - 35000]
        else:
            ins_details_sell = self.fo_contract[self.spreadOrder.tokenSell - 35000]
        lotSizeBuy = int(ins_details_buy[11])
        lotSizeSell = int(ins_details_sell[11])
        spreadOrder = self.spreadOrder
        print(spreadOrder.exchangeBuy, spreadOrder.clientBuy, self.spreadOrder.tokenBuy, leQtyBuy, lotSizeBuy, 0,)
        #placeorder for buyÏ
        PlaceOrder(self, spreadOrder.exchangeBuy, spreadOrder.clientBuy, self.spreadOrder.tokenBuy,'BUY', leQtyBuy,0, 'DAY', 0, 0, "A0119", 'MARKET')

        # placeorder for sell
        PlaceOrder(self, spreadOrder.exchangeSell, spreadOrder.clientSell, self.spreadOrder.tokenSell,'SELL', leQtySell,  0,'DAY', 0, 0, "A0119", 'MARKET')
        print(spreadOrder.exchangeSell, spreadOrder.clientSell, self.spreadOrder.tokenSell, leQtySell, lotSizeSell)
        self.spreadOrder.hideWindow()


def updateLTP(self, token,ltp):
    try:
        self.table[np.where(self.table[:,1]==token),6] =ltp
        ind = self.model.index(0, 0)
        ind1 = self.model.index(0, 31)
        self.model.dataChanged.emit(ind, ind1)

    except:
        print(traceback.print_exc(), sys.exc_info())


def symchange(self):
    try:
        a = self.cbSymbolBuy.currentText()
        fltr = np.asarray([a])
        self.t2 = self.contract[np.in1d(self.contract[:, 3], fltr)]
        self.t2_tp = self.t2.transpose()
        lsExp = np.unique(self.t2_tp[6])
        self.cbExpBuy.clear()
        self.cbExpBuy.addItems(lsExp)
    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])


def expchange(self):
    try:
        a = self.cbExpBuy.currentText()
        fltr = np.asarray([a])
        self.t3 = self.t2[np.in1d(self.t2[:, 6], fltr)]
        self.t3_tp = self.contract.transpose()
        # if ('FUT' in self.cbIns.currentText()):
        #     self.cbStrikeBuy.clear()
        #     self.cbStrikeSell.addItem(' ')
        # else:
        lsstrk = np.unique(self.t3_tp[7])
        self.cbStrikeBuy.clear()
        self.cbStrikeBuy.addItems(lsstrk)
    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])


def changesrtike(self):
    try:
        a = self.cbStrikeBuy.currentText()
        # if ('FUT' in self.cbIns.currentText()):
        #     self.cbOtype.clear()
        #     self.cbOtype.addItem(' ')
        #
        # elif ('OPT' in self.cbIns.currentText()):
        if (self.cbOptBuy.currentText() not in ['CE', 'PE']):
            self.cbOptBuy.clear()
            self.cbOptBuy.addItems(['CE', 'PE'])
        # else:
        #     changeOtype(self)

    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])


def changeOtype(self):
    try:
        # print("scriptbar : socket", self)
        a = self.cbOptBuy.currentText()
        if (self.cbSymbolBuy.currentText() != '' and self.cbExpBuy.currentText() != ''):
            if (a != ''):
                fltr = np.asarray([a])
                self.t4 = self.t3[np.in1d(self.t3[:, 8], fltr)]
                # if ('FUT' in self.cbIns.currentText()):
                #     self.t5 = self.t4
                # else:
                fltr1 = np.asarray([self.cbStrikeBuy.currentText()])
                self.t5 = self.t4[np.in1d(self.t4[:, 7], fltr1)]
                # self.LeToken.setText(str(self.t5[0][2]))
                # self.unSubscription_feed(self.Token)
                # self.Token = self.t5[0][2]
                # print('change token in snapQuote ', self.Token)
                # self.subscription_feed(self.Token)
    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])
def symchange1(self):
    try:
        a = self.cbSymbolSell.currentText()
        fltr = np.asarray([a])
        self.t21 = self.contract[np.in1d(self.contract[:, 3], fltr)]
        self.t21_tp = self.t21.transpose()
        lsExp = np.unique(self.t21_tp[6])
        self.cbExpSell.clear()
        self.cbExpSell.addItems(lsExp)
    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])


def expchange1(self):
    try:
        a = self.cbExpSell.currentText()
        fltr = np.asarray([a])
        self.t31 = self.t21[np.in1d(self.t21[:, 6], fltr)]
        self.t31_tp = self.contract.transpose()
        # if ('FUT' in self.cbIns.currentText()):
        #     self.cbStrikeBuy.clear()
        #     self.cbStrikeSell.addItem(' ')
        # else:
        lsstrk = np.unique(self.t31_tp[7])
        self.cbStrikeSell.clear()
        self.cbStrikeSell.addItems(lsstrk)
    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])


def changesrtike1(self):
    try:
        a = self.cbStrikeSell.currentText()
        # if ('FUT' in self.cbIns.currentText()):
        #     self.cbOtype.clear()
        #     self.cbOtype.addItem(' ')
        #
        # elif ('OPT' in self.cbIns.currentText()):
        if (self.cbOptSell.currentText() not in ['CE', 'PE']):
            self.cbOptSell.clear()
            self.cbOptSell.addItems(['CE', 'PE'])
        # else:
        #     changeOtype(self)

    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])


def changeOtype1(self):
    try:
        # print("scriptbar : socket", self)
        a = self.cbOptSell.currentText()
        if (self.cbSymbolSell.currentText() != '' and self.cbExpSell.currentText() != ''):
            if (a != ''):
                fltr = np.asarray([a])
                self.t41 = self.t31[np.in1d(self.t31[:, 8], fltr)]
                # if ('FUT' in self.cbIns.currentText()):
                #     self.t5 = self.t4
                # else:
                fltr1 = np.asarray([self.cbStrikeSell.currentText()])
                self.t51 = self.t41[np.in1d(self.t41[:, 7], fltr1)]
                # self.LeToken.setText(str(self.t5[0][2]))
                # self.unSubscription_feed(self.Token)
                # self.Token = self.t5[0][2]
                # print('change token in snapQuote ', self.Token)
                # self.subscription_feed(self.Token)
    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])
