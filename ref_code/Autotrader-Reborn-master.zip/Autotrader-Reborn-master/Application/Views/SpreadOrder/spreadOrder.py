from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import uic
from os import path, getcwd
import numpy as np
from Application.Services.Xts.Api.servicesIA import modifyOrder
import qdarkstyle
from Application.Views.SnapQuote.scriptbar import *
from Application.Views.titlebar import tBar
from Application.Views.SpreadOrder.support import *

from Theme.dt2 import dt1
import traceback
# from Resourses.icons import icons_rc
import platform
import datatable as dt
from Application.Views.MultiOrders import  support

class Ui_SpreadOrder(QMainWindow):

    sgFin=pyqtSignal()
    ################################# Intialization Here ##################################################
    def __init__(self,parent=None):
        super(Ui_SpreadOrder, self).__init__(parent=None)

        loc1 = getcwd().split('Application')
        # logDir = loc1[0] + '\\Logs\\%s'%today

        ui_login = path.join(loc1[0], 'Resourses','UI','spreadOrder.ui')
        uic.loadUi(ui_login, self)
        osType = platform.system()
        if (osType == 'Darwin'):
            flags = Qt.WindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        else:
            flags = Qt.WindowFlags(Qt.SubWindow | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)

        self.setWindowFlags(flags)

        self.title = tBar('SpreadOrder')
        self.headerFrame.layout().addWidget(self.title, 0, 0)
        self.title.sgPoss.connect(self.movWin)
        dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()
        self.setStyleSheet(dt1)
        self.createShortcuts()
        self.connectAllSlots()
        self.folionamechange()
        # self.leQtyBuy.textChanged.connect(self.updateQtySell)
        self.pbCancel.clicked.connect(self.hide)
        self.rbNewFolio.toggled.connect(self.folionamechange)
        self.rbTypeB.toggled.connect(print)
        QSizeGrip(self.sGripFrame)
        self.messageBox = QMessageBox(self)
        self.messageBox.setIcon(QMessageBox.Critical)
        self.messageBox.setWindowTitle("SpreadOrder")


    # def updateQtySell(self):
    #     if(self.cxbSameQty.isChecked()):
    #         self.leQtySell.setText(self.leQtyBuy.text())

    def folionamechange(self):
        if(self.rbNewFolio.isChecked()):
            # self.leFolioName.setText(self.folioname)
            self.leFolioName.setEnabled(True)
            self.cbFolio.setEnabled(False)
            # print("newfolio ")
        elif(self.rbExistingFolio.isChecked()):
            self.leFolioName.setEnabled(False)
            self.cbFolio.setEnabled(True)
            # print("ext")

    def showWindow(self, SName1, SName2):
        if (self.isVisible()):
            self.hideWindow()
        orderType = SName1[0][4]
        # print("orderType swap:", orderType)
        if(orderType == 'StopLimit'):
            self.leModifiedTriggerPrice.setEnabled(True)
        else:
            self.leModifiedTriggerPrice.setEnabled(False)
        self.SName1 = SName1
        self.SName2 = SName2
        self.show(SName1,SName2)


    def movWin(self, x, y):
        self.move(self.pos().x() + x, self.pos().y() + y)


    def connectAllSlots(self):
        self.bt_close.clicked.connect(self.hide)
        self.bt_min.clicked.connect(self.hide)
        self.cbSymbolBuy.currentIndexChanged.connect(lambda: symchange(self))
        self.cbExpBuy.currentIndexChanged.connect(lambda: expchange(self))
        self.cbStrikeBuy.currentIndexChanged.connect(lambda: changesrtike(self))
        self.cbOptBuy.currentIndexChanged.connect(lambda: changeOtype(self))

        self.cbSymbolSell.currentIndexChanged.connect(lambda: symchange1(self))
        self.cbExpSell.currentIndexChanged.connect(lambda: expchange1(self))
        self.cbStrikeSell.currentIndexChanged.connect(lambda: changesrtike1(self))
        self.cbOptSell.currentIndexChanged.connect(lambda: changeOtype1(self))
        self.pbAlternate.clicked.connect(lambda: alternateSymbol(self))
        self.pbAlternate.clicked.connect(lambda: print('abc'))

    def createShortcuts(self):
        self.quitSc = QShortcut(QKeySequence('Esc'), self)
        self.quitSc.activated.connect(self.hide)

    def hideWindow(self):
        self.hide()


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = Ui_SpreadOrder()
    form.show()
    sys.exit(app.exec_())
