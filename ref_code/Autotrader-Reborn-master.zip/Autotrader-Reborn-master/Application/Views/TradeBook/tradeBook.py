import os

from PyQt5.QtCore import QObject,QFile,pyqtSignal,pyqtSlot,Qt,QSortFilterProxyModel,QTimer
from PyQt5.QtGui import QIcon, QKeySequence
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5 import uic
from os import path, getcwd
from Application.Views.TradeBook.support import *
import qtpy
import qdarkstyle

from Application.Utils.configReader import readConfig_All,refresh
from Application.Views.Models.tableTB import ModelTB
from Theme.dt2 import dt1
from Application.Views.titlebar import tBar
# from ENTRY.buyWindow import Ui_BuyW
# from ENTRY.sellWindow import Ui_SellW

import traceback
import logging
import time
import json
import sys
import pandas as pd
import datatable as dt
import numpy as np
import requests
import platform
from Application.Utils.createTables import tables_details_tb
from Application.Utils.updation import updateGetTradeApi

class TradeBook(QMainWindow):
    def __init__(self,parent=None):
        try:

            super(TradeBook, self).__init__(parent=None)
            self.list1 = []
            self.rcount = 0
            self.sortColumn = 0
            self.sortOrder = 0

            refresh(self)

            loc1 = getcwd().split('Application')
            ui_login = path.join(loc1[0] , 'Resourses','UI','Tradebook.ui')
            uic.loadUi(ui_login, self)

            self.csvPath = path.join(loc1[0], 'Resourses','Trades.txt')

            osType = platform.system()

            if (osType == 'Darwin'):
                flags = Qt.WindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
            else:
                flags = Qt.WindowFlags(Qt.SubWindow | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
            self.setWindowFlags(flags)
            self.title = tBar('TradeBook')
            self.headerFrame.layout().addWidget(self.title, 0, 0)
            self.title.sgPoss.connect(self.movWin)
            dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()

            self.setStyleSheet(dt1)
            tables_details_tb(self)

            self.createShortcuts()
            self.connectAllSlots()
            self.FillcbHeads()
            QSizeGrip(self.frameGrip)

        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info())

    def connectAllSlots(self):
        self.pbCsv.clicked.connect(lambda:create_trade_csv(self))
        self.bt_min.clicked.connect(self.hide)
        self.bt_close.clicked.connect(self.hide)
        self.pbClear.clicked.connect(self.clearFilter)
        # self.pbGetTrade.clicked.connect(self.get_Trades)
        # self.tableView.horizontalHeader().sectionClicked.connect(self.getSortClues)
        self.leSearch.textChanged.connect(self.changeFilter)
        self.cbHeads.currentIndexChanged.connect(self.setfilterColumn)

    def FillcbHeads(self):
        self.cbHeads.addItems(self.heads)
        self.smodelT.setFilterKeyColumn(0)

    def setfilterColumn(self):
        self.smodelT.setFilterKeyColumn(self.cbHeads.currentIndex())

    def clearFilter(self):
        self.smodelT.setFilterFixedString('')
        self.smodelT.setFilterKeyColumn(0)
        self.cbHeads.setCurrentIndex(0)
        self.leSearch.setText('')


    # def clearFilter(self):
    #     self.smodelT.setFilterFixedString('')

    def createShortcuts(self):
        self.quitSc = QShortcut(QKeySequence('Esc'), self)
        self.quitSc.activated.connect(self.hide)


    def movWin(self, x, y):
        self.move(self.pos().x() + x, self.pos().y() + y)

    def changeFilter(self, a):
        # print(a)
        self.smodelT.setFilterFixedString(a)

    def saveDefaultColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            # print(settingsFilePath)

            f1 = open(settingsFilePath)

            pathDetails= json.load(f1)
            # print(pathDetails)
            f1.close()
            defaultFilePath1 = pathDetails['TradeBook']['defaultColumnProfile']


            binData = self.tableView.horizontalHeader().saveState()
            loc1 = getcwd().split('Application')
            defaultFilePath = os.path.join(loc1[0], defaultFilePath1)
            # save = QFileDialog.getSaveFileName(self, 'Save file', dirctry)[0]
            with open(defaultFilePath, 'wb') as f:
                f.write(binData)
            f.close()
        except:
            print(traceback.print_exc())


    def updateDefaultColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
        f1 = open(settingsFilePath)
        pathDetails = json.load(f1)
        f1.close()
        lastCPFilePath1 = pathDetails['TradeBook']['defaultColumnProfile']
        lastCPFilePath = os.path.join(loc, lastCPFilePath1)

        with open(lastCPFilePath, 'rb') as f:
            binData = f.read()
        f.close()
        self.tableView.horizontalHeader().restoreState(binData)


    def lastSavedColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
        f1 = open(settingsFilePath)
        pathDetails = json.load(f1)
        f1.close()
        lastCPFilePath1 = pathDetails['TradeBook']['lastSavedColumnProfile']
        lastCPFilePath = os.path.join(loc, lastCPFilePath1)

        with open(lastCPFilePath, 'rb') as f:
            binData = f.read()


        f.close()
        self.tableView.horizontalHeader().restoreState(binData)


    def saveColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            defaultDir = os.path.join(loc, 'Resourses', 'ColumnProfile')
            binData = self.tableView.horizontalHeader().saveState()
            save = QFileDialog.getSaveFileName(self, 'Save file', defaultDir)[0]
            # print('save smanager save column profile',save)

            with open(save, 'wb') as f:
                f.write(binData)
            f.close()

            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            f1 = open(settingsFilePath)
            pathDetails= json.load(f1)
            f1.close()
            pathDetails['TradeBook']['lastSavedColumnProfile'] = save.split('Application')[0]

            pathDetails_new = json.dumps(pathDetails, indent=4)


            f2 = open(settingsFilePath,'w+')
            f2.write(pathDetails_new)
            # pathDetails= json.load(f1)
            f2.close()




        except:
            print(traceback.print_exc())

    def openColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        defaultDir = os.path.join(loc, 'Resourses', 'ColumnProfile')

        save = QFileDialog.getOpenFileName(self, 'Open file', defaultDir)[0]

        with open(save, 'rb') as f:
            binData = f.read()
        f.close()

        self.tableView.horizontalHeader().restoreState(binData)

    def headerRightClickMenu(self, position):
        try:
            # print()
            # a=(self.tableView.selectedIndexes()[0].data())
            menu = QMenu()

            saveColumnProfile = menu.addAction("save col profile")
            restoreColumnProfile = menu.addAction("open Col Profile")
            hideColumn = menu.addAction("hide")
            reset = menu.addAction("reset")

            # cancelAction = menu.addAction("Cancel")
            action = menu.exec_(self.tableView.horizontalHeader().mapToGlobal(position))
            if action == saveColumnProfile:
                self.saveColumnProfile()
            elif (action == restoreColumnProfile):
                self.openColumnProfile()
            elif (action == hideColumn):

                x = (self.tableView.horizontalHeader().logicalIndexAt(position))
                self.tableView.horizontalHeader().hideSection(x)
            elif (action == reset):
                self.updateDefaultColumnProfile()
        except:
            print(sys.exc_info()[1])


    def tableRightClickMenu(self, position):
        try:
            # a=(self.tableView.selectedIndexes()[0].data())
            menu = QMenu()

            squareAction = menu.addAction("Square")
            # squareAction1 = menu.addAction("PARTH")
            # cancelAction = menu.addAction("Cancel")
            action = menu.exec_(self.tableView.mapToGlobal(position))
            if action == squareAction:
                pass
        except:
            print(sys.exc_info()[1])


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    form = TradeBook()
    form.show()
    sys.exit(app.exec_())
