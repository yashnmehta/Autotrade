import json
import os

from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import uic
from os import path, getcwd
import numpy as np
from Application.Services.Xts.Api.servicesIA import modifyOrder
import qdarkstyle

from Application.Views.titlebar import tBar
from Theme.dt2 import dt1
import traceback
# from Resourses.icons import icons_rc
import platform
import datatable as dt
from Application.Views.MultiOrders import  support

class Ui_MultiOrders(QWidget):

    sgFin=pyqtSignal()
    ################################# Intialization Here ##################################################
    def __init__(self,parent=None):
        super(Ui_MultiOrders, self).__init__(parent=None)

        loc1 = getcwd().split('Application')
        # logDir = loc1[0] + '\\Logs\\%s'%today

        ui_login = path.join(loc1[0], 'Resourses','UI','multiOrder.ui')
        uic.loadUi(ui_login, self)
        osType = platform.system()
        if (osType == 'Darwin'):
            flags = Qt.WindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        else:
            flags = Qt.WindowFlags(Qt.SubWindow | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)

        self.setWindowFlags(flags)
        self.title = tBar('MultiOrder')
        self.headerFrame.layout().addWidget(self.title, 0, 0)
        self.title.sgPoss.connect(self.movWin)
        dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()
        self.setStyleSheet(dt1)
        self.connectAllSlots()
        self.createShortcuts()

        self.messageBox = QMessageBox(self)
        self.messageBox.setIcon(QMessageBox.Critical)
        QSizeGrip(self.sGripFrame)

    def createShortcuts(self):
        self.quitSc = QShortcut(QKeySequence('Esc'), self)
        self.quitSc.activated.connect(self.hide)

    def hideWindow(self):
        self.hide()

    def connectAllSlots(self):
        self.bt_close.clicked.connect(self.hide)
        self.bt_min.clicked.connect(self.hide)

    def movWin(self, x, y):
        self.move(self.pos().x() + x, self.pos().y() + y)

    def saveDefaultColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            # print(settingsFilePath)

            f1 = open(settingsFilePath)

            pathDetails= json.load(f1)
            # print(pathDetails)
            f1.close()
            defaultFilePath = pathDetails['MultiOrder']['defaultColumnProfile']


            binData = self.tableView.horizontalHeader().saveState()
            # save = QFileDialog.getSaveFileName(self, 'Save file', dirctry)[0]
            with open(defaultFilePath, 'wb') as f:
                f.write(binData)
            f.close()
        except:
            print(traceback.print_exc())


    def updateDefaultColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
        f1 = open(settingsFilePath)
        pathDetails = json.load(f1)
        f1.close()
        lastCPFilePath1 = pathDetails['MultiOrder']['defaultColumnProfile']
        lastCPFilePath = os.path.join(loc, lastCPFilePath1)

        with open(lastCPFilePath, 'rb') as f:
            binData = f.read()
        f.close()
        self.tableView.horizontalHeader().restoreState(binData)




    def lastSavedColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            f1 = open(settingsFilePath)
            pathDetails = json.load(f1)
            f1.close()
            lastCPFilePath1 = pathDetails['MultiOrder']['lastSavedColumnProfile']
            lastCPFilePath = os.path.join(loc, lastCPFilePath1)

            with open(lastCPFilePath, 'rb') as f:
                binData = f.read()
            f.close()
            self.tableView.horizontalHeader().restoreState(binData)
        except:
            print(traceback.print_exc())

    def saveColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            defaultDir = os.path.join(loc, 'Resourses', 'ColumnProfile')
            binData = self.tableView.horizontalHeader().saveState()
            save = QFileDialog.getSaveFileName(self, 'Save file', defaultDir)[0]
            # print('save BasicMarketWatch save column profile',save)

            with open(save, 'wb') as f:
                f.write(binData)
            f.close()


            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            f1 = open(settingsFilePath)
            pathDetails= json.load(f1)
            f1.close()
            pathDetails['MultiOrder']['lastSavedColumnProfile'] = save

            pathDetails_new = json.dumps(pathDetails, indent=4)


            f2 = open(settingsFilePath,'w+')
            f2.write(pathDetails_new)
            # pathDetails= json.load(f1)
            f2.close()


        except:
            print(traceback.print_exc())

    def openColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        defaultDir = os.path.join(loc, 'Resourses', 'ColumnProfile')

        save = QFileDialog.getOpenFileName(self, 'Open file', defaultDir)[0]

        with open(save, 'rb') as f:
            binData = f.read()
        f.close()

        self.tableView.horizontalHeader().restoreState(binData)

    def headerRightClickMenu(self, position):
        try:
            print()
            # a=(self.tableView.selectedIndexes()[0].data())
            menu = QMenu()

            saveColumnProfile = menu.addAction("save col profile")
            restoreColumnProfile = menu.addAction("open Col Profile")
            hideColumn = menu.addAction("hide")
            reset = menu.addAction("reset")

            # cancelAction = menu.addAction("Cancel")
            action = menu.exec_(self.tableView.horizontalHeader().mapToGlobal(position))
            if action == saveColumnProfile:
                self.saveColumnProfile()
            elif (action == restoreColumnProfile):
                self.openColumnProfile()
            elif (action == hideColumn):

                x = (self.tableView.horizontalHeader().logicalIndexAt(position))
                self.tableView.horizontalHeader().hideSection(x)
            elif (action == reset):
                self.updateDefaultColumnProfile()
        except:
            print(sys.exc_info()[1])


    def tableRightClickMenu(self, position):
        try:
            # a=(self.tableView.selectedIndexes()[0].data())
            menu = QMenu()

            squareAction = menu.addAction("Square")
            # squareAction1 = menu.addAction("PARTH")
            # cancelAction = menu.addAction("Cancel")
            action = menu.exec_(self.tableView.mapToGlobal(position))
            if action == squareAction:
                pass
        except:
            print(sys.exc_info()[1])


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = Ui_MultiOrders()
    form.show()
    sys.exit(app.exec_())
