import os

from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import uic

import sys
import logging
import qdarkstyle
import requests
import time
import traceback
from threading import Thread
from os import path, getcwd
import platform

# from Application.configReader import *
from Application.Views.titlebar import tBar
from Theme.dt2 import dt1
from Application.Views.BuyWindow.support import *
from Application.Utils.openRequstedWindow import requestBuyWindow,requestSellWindow



class Ui_BuyW(QMainWindow):
    sgTmSubd = pyqtSignal(dict)
    sgTmUnSubd = pyqtSignal(dict)
    sgAppOrderID =  pyqtSignal(int)
    sgMsg = pyqtSignal(str)

    #################################### All Initialization Functions Are Here ################################
    def __init__(self,parent=None):
        super(Ui_BuyW, self).__init__(parent=None)
        try:

            loc1 = getcwd().split('Application')
            ui_login = os.path.join(loc1[0] , 'Resourses','UI','buyWindow.ui')
            uic.loadUi(ui_login, self)
            osType = platform.system()
            if (osType == 'Darwin'):
                flags = Qt.WindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
            else:
                flags = Qt.WindowFlags(Qt.SubWindow | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
            self.setWindowFlags(flags)
            self.title = tBar('')
            self.headerFrame.layout().addWidget(self.title, 0, 0)
            self.title.setStyleSheet('  border-radius: 4px;')

            ############## Set StyleSheet ######################
            dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()
            self.setStyleSheet(dt1)

            self.setWindowFlags(flags)
            self.title = tBar('BUY WINDOW')
            self.headerFrame.layout().addWidget(self.title, 0, 0)
            ################### End Section Here ###############
            self.title.sgPoss.connect(self.movWin)
            ####################################################
            self.initVariables()
            self.appOrderIdFprModification = 0



            self.messageBox = QMessageBox(self)
            self.messageBox .setIcon(QMessageBox.Critical)


            # self.buttonBox = QDialogButtonBox(self)
            # self.buttonBox = QMessageBox(self)
            # self.buttonBox .setText("Are You Sure?")
            # self.buttonBox .setStandardButtons(QMessageBox.Yes | QMessageBox.No)
            # self.buttonBox .setIcon(QMessageBox.Question)

            setAllShortcuts(self)
            self.leMLT.textChanged.connect(self.chackMaxMlt)
            self.leQty.textChanged.connect(self.checkForPMQty)
            self.leRate.textChanged.connect(self.checkForPMRate)



        except:
            print(traceback.print_exc())
    #################################### Ends Here #############################################
    def movWin(self,x,y):
        self.move(self.pos().x()+x,self.pos().y()+y)

    def checkForPMQty(self, data):

        if('-' in data):
            self.leQty.undo()
            self.callSellW1.activated.emit()
        elif('+' in data):
            self.leQty.undo()
            self.callBuyW.activated.emit()


    def checkForPMRate(self,data):
        if('-' in data):
            self.leRate.undo()
            self.callSellW1.activated.emit()

        elif('+' in data):
            self.leRate.undo()
            self.callBuyW.activated.emit()

    def chackMaxMlt(self,data):
        if('-' in data):
            self.leRate.undo()
            self.callSellW1.activated.emit()
        elif('+' in data):
            self.leRate.undo()
            self.callBuyW.activated.emit()


        if (int(self.leMLT.text()) > 10):
            self.leMLT.setText('10')


    def initVariables(self):
        self.isFresh = True
        self.modifyOIDList = []
        self.leQty.setFocus(True)
        self.mltplr = 1
        self.ticksize = 0.05
        self.lotsize = 0
        self.clist = []
        self.settings = {
        "NSEFO": {"F": {"Focus": "Qty","Lots": 1,"Multiplier": 1},
                  "O": {"Focus": "Qty","Lots": 1,"Multiplier": 1}},
        "NSECM": {"E": {"Focus": "Qty","Lots": 1,"Multiplier": 1}}}



    # def msgBox(self):
    #     self.buyW.leQty.clicked.connect(self.msg.show)


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = Ui_BuyW()
    form.show()
    sys.exit(app.exec_())