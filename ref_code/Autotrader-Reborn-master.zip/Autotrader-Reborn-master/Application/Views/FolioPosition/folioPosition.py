import time

from PyQt5.QtCore import QObject,QFile,pyqtSignal,pyqtSlot,Qt,QSortFilterProxyModel,QTimer
from PyQt5.QtGui import QIcon, QKeySequence
from PyQt5.QtWidgets import *
from PyQt5 import uic
from os import path, getcwd
import qtpy
import qdarkstyle
# import sys
from Application.Views.Models import tableFP
# import pandas as pd
# import datatable as dt
# import numpy  as np
# import requests
import json
import platform

from Application.Services.Xts.Api.servicesIA import PlaceOrder
from Application.Views.BuyWindow.buyWindow import Ui_BuyW
from Application.Views.SellWindow.sellWindow import Ui_SellW
from Application.Views.SnapQuote.snapQuote import Ui_snapQ

from Application.Utils.dbConnection import  *
from Application.Utils.configReader import readConfig_All
from Application.Views.Models.tableFP import ModelPosition
from Application.Utils.createTables import tables_details_fp
from Application.Views.titlebar import tBar

from Theme.dt2 import dt1
import logging

from Application.Views.FolioPosition.support import *


from Application.Views.FolioPosition import *

#

class FolioPosition(QMainWindow):
    sgTmSubd=pyqtSignal(dict)
    sgrecvfosubscribe=pyqtSignal(str,str,int)
    # sgTMTM=pyqtSignal(str)
    sgCallPOrderBook = pyqtSignal(str)
    sgCallTB = pyqtSignal(int)

    def __init__(self,parent=None):
        super(FolioPosition, self).__init__(parent=None)
        try:

            self.filterStr = ''
            self.clientFolios = {}
            self.folioList = ['MANUAL']

            self.MDheaders, self.IAheaders, self.MDToken, self.IAToken, self.URL, self.userID, self.source,self.MDKey,self.MDSecret,self.IAKey,self.IASecret,self.client_list,DClient,broadcastMode = readConfig_All()
            #####################################################################

            loc1 = getcwd().split('Application')
            ui_login = os.path.join(loc1[0] , 'Resourses','UI','folioPosition.ui')
            uic.loadUi(ui_login, self)
            dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()
            self.setStyleSheet(dt1)
            ########################## ###########################################


            osType = platform.system()
            if (osType == 'Darwin'):
                flags = Qt.WindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
            else:
                flags = Qt.WindowFlags(Qt.SubWindow | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)

            self.setWindowFlags(flags)

            self.title = tBar('FOLIO POSITION')
            self.headerFrame.layout().addWidget(self.title, 0, 0)
            self.title.sgPoss.connect(self.movWin)
            dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()
            QSizeGrip(self.gripFolio)

            #####################################################################
            tables_details_fp(self)

            # self.cbClient.currentIndexChanged.connect(lambda: cbClientChange(self))
            # createShortcuts(self)
            self.connectAllSlots()
            self.createShortcuts()
            self.selectedFolio = ''

            # self.movWin()

        except:
            print(traceback.print_exc())


    def movWin(self, x, y):
        self.move(self.pos().x() + x, self.pos().y() + y)

    def connectAllSlots(self):
        self.bt_close_3.clicked.connect(self.hide)
        self.bt_min_3.clicked.connect(self.hide)
        self.tableView.customContextMenuRequested.connect(self.tableRightClickMenu_fp)
        self.pbShow.clicked.connect(lambda: filterData(self))

        self.pbClear.clicked.connect(self.clearFilter)

    def clearFilter(self):
        self.smodelFP.setFolioName('ALL')
        self.smodelFP.setClientName('ALL')
        self.smodelFP.setFilterFixedString('')

    def createShortcuts(self):
        self.quitSc = QShortcut(QKeySequence('Esc'), self)
        self.quitSc.activated.connect(self.hide)

    def initVariablles(self):
        self.selectedFolio = ''
    #################################### Ends Here #############################################


    def saveDefaultColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            # print(settingsFilePath)

            f1 = open(settingsFilePath)

            pathDetails= json.load(f1)
            # print(pathDetails)
            f1.close()
            defaultFilePath1 = pathDetails['FolioBook']['defaultColumnProfile']


            binData = self.tableView.horizontalHeader().saveState()

            loc1 = getcwd().split('Application')
            defaultFilePath = os.path.join(loc1[0], defaultFilePath1)
            # save = QFileDialog.getSaveFileName(self, 'Save file', dirctry)[0]
            with open(defaultFilePath, 'wb') as f:
                f.write(binData)
            f.close()
        except:
            print(traceback.print_exc())


    def updateDefaultColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
        f1 = open(settingsFilePath)
        pathDetails = json.load(f1)
        f1.close()
        lastCPFilePath = pathDetails['FolioBook']['defaultColumnProfile']
        with open(lastCPFilePath, 'rb') as f:
            binData = f.read()
        f.close()
        self.tableView.horizontalHeader().restoreState(binData)


    def lastSavedColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
        f1 = open(settingsFilePath)
        pathDetails = json.load(f1)
        f1.close()
        lastCPFilePath1 = pathDetails['FolioBook']['lastSavedColumnProfile']
        lastCPFilePath = os.path.join(loc, lastCPFilePath1)

        with open(lastCPFilePath, 'rb') as f:
            binData = f.read()
        f.close()
        self.tableView.horizontalHeader().restoreState(binData)


    def saveColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            defaultDir = os.path.join(loc, 'Resourses', 'ColumnProfile')
            binData = self.tableView.horizontalHeader().saveState()
            save = QFileDialog.getSaveFileName(self, 'Save file', defaultDir)[0]
            print('save FolioBook save column profile',save)

            with open(save, 'wb') as f:
                f.write(binData)
            f.close()



            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            f1 = open(settingsFilePath)
            pathDetails= json.load(f1)
            f1.close()
            pathDetails['FolioBook']['lastSavedColumnProfile'] = save

            pathDetails_new = json.dumps(pathDetails, indent=4)


            f2 = open(settingsFilePath,'w+')
            f2.write(pathDetails_new)
            # pathDetails= json.load(f1)
            f2.close()




        except:
            print(traceback.print_exc())

    def openColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        defaultDir = os.path.join(loc, 'Resourses', 'ColumnProfile')

        save = QFileDialog.getOpenFileName(self, 'Open file', defaultDir)[0]

        with open(save, 'rb') as f:
            binData = f.read()
        f.close()

        self.tableView.horizontalHeader().restoreState(binData)

    def headerRightClickMenu(self, position):
        try:
            # print()
            # a=(self.tableView.selectedIndexes()[0].data())
            menu = QMenu()

            saveColumnProfile = menu.addAction("save col profile")
            restoreColumnProfile = menu.addAction("open Col Profile")
            hideColumn = menu.addAction("hide")
            reset = menu.addAction("reset")

            # cancelAction = menu.addAction("Cancel")
            action = menu.exec_(self.tableView.horizontalHeader().mapToGlobal(position))
            if action == saveColumnProfile:
                self.saveColumnProfile()
            elif (action == restoreColumnProfile):
                self.openColumnProfile()
            elif (action == hideColumn):

             srNOIndex = 25

            x = (self.tableView.horizontalHeader().logicalIndexAt(position))
            print('srNOIndex', srNOIndex, x)
            if (x != srNOIndex):
                self.tableView.horizontalHeader().hideSection(x)

            elif (action == reset):
                    self.updateDefaultColumnProfile()
        except:
            print(sys.exc_info()[1])

    def tableRightClickMenu_fp(self, position):
        try:
            menu = QMenu()

            squareAction = menu.addAction("Square Off")
            # squareAction1 = menu.addAction("PARTH")
            payOfChart = menu.addAction("PayOffChart")
            # cancelAction = menu.addAction("Cancel")
            action = menu.exec_(self.tableView.mapToGlobal(position))
            if action == squareAction:
                self.squareOffSelected()
            elif action == payOfChart:
                self.requestPayoffChart()
        except:
            print(sys.exc_info()[1])

##############################################################################################################################


    def squareOffSelected(self):
        try:

            print('in square')
            indexes = self.tableView.selectedIndexes()
            srNOIndex = 25

            cc = self.modelFP.columnCount('')
            for i in range(25):
                if (self.tableView.horizontalHeader().isSectionHidden(i)):
                    srNOIndex -= 1

            print('srNOIndex',srNOIndex)
            noOfVisibleColumn = self.modelFP.columnCount('')

            for i in range(cc):
                if (self.tableView.horizontalHeader().isSectionHidden(i)):
                    noOfVisibleColumn -= 1

            noOfSelectedRecords = int(len(indexes) / noOfVisibleColumn)
            print(noOfSelectedRecords)

            squareList = []
            for i in range(noOfSelectedRecords):
                srNO = indexes[(i * noOfVisibleColumn) + srNOIndex].data()

                exchange = self.table[srNO, 4]
                clintID = self.table[srNO, 1]
                token = self.table[srNO, 5]
                qty = self.table[srNO, 13]
                MaxQty = self.table[srNO, 23]
                folioname=self.table[srNO,3]
                print(token,exchange)

                squareList.append([exchange, token, qty, MaxQty, clintID])

            for ix in squareList:
                token = ix[1]
                quantity = ix[2]
                exchange = ix[0]
                freezeQty = ix[3]
                clientId = ix[4]
                # print("Clien id : ", clientId)
                # print('do square',token, qty)

                if (quantity == 0):
                    # print("zero")
                    pass
                elif quantity > 0:
                    # print("quantity > 0")
                    absQuantity = abs(quantity)
                    while (absQuantity > freezeQty):


                        PlaceOrder(self, exchange=exchange, clientID=clientId, token=token, orderSide='Sell',
                                   qty=freezeQty,
                                   limitPrice=0.0,
                                   validity='DAY', disQty=0, triggerPrice=0, uid=folioname, orderType='MARKET',
                                   productType='NRML')
                        time.sleep(0.1)
                        absQuantity -= freezeQty
                    print("Punch SELL")
                    PlaceOrder(self, exchange=exchange, clientID=clientId, token=token, orderSide='Sell',
                               qty=absQuantity,
                               limitPrice=0.0,
                               validity='DAY', disQty=0, triggerPrice=0, uid=folioname, orderType='MARKET',
                               productType='NRML')
                    time.sleep(0.1)
                    print("SELL")
                else:
                    print("quantity < 0")
                    absQuantity = abs(quantity)
                    while (absQuantity > freezeQty):
                        print('else while < 0')
                        PlaceOrder(self, exchange=exchange, clientID=clientId, token=token, orderSide='Buy',
                                   qty=freezeQty,
                                   limitPrice=0.0,
                                   validity='DAY', disQty=0, triggerPrice=0, uid=folioname, orderType='MARKET',
                                   productType='NRML')
                        time.sleep(0.1)
                        absQuantity -= freezeQty
                    print("Placee")
                    PlaceOrder(self, exchange=exchange, clientID=clientId, token=token, orderSide='Buy',
                               qty=absQuantity,
                               limitPrice=0.0,
                               validity='DAY', disQty=0
                               , triggerPrice=0, uid=folioname, orderType='MARKET',
                               productType='NRML')

                    time.sleep(0.1)
                    print("BUY")
        except:
            print(sys.exc_info()[1])



if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = FolioPosition()
    form.show()
    sys.exit(app.exec_())
