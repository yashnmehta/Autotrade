from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import uic
from os import path, getcwd
import numpy as np
from PyQt5.uic.properties import QtCore

from Application.Services.Xts.Api.servicesIA import modifyOrder
import qdarkstyle

from Application.Views.titlebar import tBar
from Theme.dt2 import dt1
import traceback
# from Resourses.icons import icons_rc
import platform
import datatable as dt
from Application.Views.MultiOrders import  support

class Ui_OptSelect(QMainWindow):

    sgFin=pyqtSignal()
    ################################# Intialization Here ##################################################
    def __init__(self,parent=None):
        super(Ui_OptSelect, self).__init__(parent=None)

        loc1 = getcwd().split('Application')
        # logDir = loc1[0] + '\\Logs\\%s'%today

        ui_login = path.join(loc1[0], 'Resourses','UI','optionChainSelection.ui')

        uic.loadUi(ui_login, self)
        osType = platform.system()
        if (osType == 'Darwin'):
            flags = Qt.WindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        else:
            flags = Qt.WindowFlags(Qt.SubWindow | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)

        self.setWindowFlags(flags)
        # self.setWindowFlags(QtCore.Qt.FramelessWindowHint)

        self.ceToken = 0
        self.peToken = 0
        self.cePrice = 0.0
        self.pePrice = 0.0
        self.optionType = 'CE'
        self.optionType = 'PE'


        # self.title = tBar('SwapOrder')
        # self.headerFrame.layout().addWidget(self.title, 0, 0)
        # self.title.sgPoss.connect(self.movWin)
        dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()
        self.setStyleSheet(dt1)
        self.createShortcuts()
        # self.connectAllSlots()

    def createShortcuts(self):
        self.quitSc = QShortcut(QKeySequence('Esc'), self)
        self.quitSc.activated.connect(self.hide)

    def hideWindow(self):
        self.hide()

    def setOptionType(self,type1):
        self.optionType = type1


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = Ui_OptSelect()
    form.show()
    sys.exit(app.exec_())
