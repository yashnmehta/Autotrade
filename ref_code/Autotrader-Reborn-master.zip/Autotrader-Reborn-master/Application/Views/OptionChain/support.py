import numpy as np
import traceback
import sys
import logging

from Application.Views.Models.tableOC import ModelTB
from PyQt5.QtCore import QObject,QFile,pyqtSignal,pyqtSlot,Qt,QSortFilterProxyModel,QTimer






def polpulateCbSymbol(self):
    # print("inside polpulateCbSymbol")
    uniqueSymbol = np.unique(self.contract_fo1[:, 3])
    self.cbSymbol.addItems(uniqueSymbol.tolist()[1:])

    self.cbSymbol.setCurrentText('NIFTY')
    self.symbol = 'NIFTY'
    populateCbExp(self)



def populateCbExp(self):
    fltr = np.asarray([self.cbSymbol.currentText()])
    filteredArray = self.contract_fo[np.in1d(self.contract_fo[:, 3], fltr)]
    uniqeExp = np.unique(filteredArray[:, 6])

    # print('uniqeExp', uniqeExp)
    self.cbExp.clear()
    self.cbExp.addItems(uniqeExp.tolist())
    self.futureToken = filteredArray[0][17]


def getClosingOI(main):
    main.OptionChain.symbol = main.OptionChain.cbSymbol.currentText()
    main.OptionChain.exp = main.OptionChain.cbExp.currentText()

    fltr=main.fo_contract[np.where((main.fo_contract[:,3]==main.OptionChain.symbol) & (main.fo_contract[:,6]==main.OptionChain.exp))]


    # CEfltr=fltr[np.where(fltr[:,8]=='CE')]
    main.OptionChain.CEOIsum=np.sum(fltr[np.where(fltr[:,8]=='CE'),[22]][0])

    main.OptionChain.PEOIsum=np.sum(fltr[np.where(fltr[:,8]=='PE'),[22]][0])
    # print('CEfltr', main.OptionChain.CEOIsum,main.OptionChain.PEOIsum)

def updatePCR(OptionChain):

    if OptionChain.lastSerialNo!=0:
        CEcurrentOIsum=np.sum(OptionChain.table_Cons[:,5])
        PEcurrentOIsum=np.sum(OptionChain.table_Cons[:,38])

        CETotalOI=CEcurrentOIsum - OptionChain.CEOIsum
        PETotalOI=PEcurrentOIsum - OptionChain.PEOIsum

        # print('PCR',OptionChain.CEOIsum,OptionChain.PEOIsum,CETotalOI,PETotalOI,PETotalOI/CETotalOI)
        # print('dkdf',PETotalOI,CETotalOI)
        PCR=PETotalOI / CETotalOI

        OptionChain.lb_PCR.setText(str(PCR))


def UpdateMaxpain(OptionChain):

    if OptionChain.lastSerialNo != 0:
        temp = np.zeros_like(OptionChain.table_Cons[:OptionChain.lastSerialNo])



        temp[:]=OptionChain.table_Cons[:OptionChain.lastSerialNo]

        temp[:, 11] = temp[:, 2] + temp[:, 41]

        maxval = np.min(temp[:, 11])

        if(maxval!=0):


            # print(temp)
            strike=temp[np.where(temp[:,11]==maxval),[22]][0]
            # print('tt',temp[:,22])
            # print('OO',OptionChain.table_Cons[:,22])
            print(strike,maxval)
            # res = np.where(arr == np.amax(arr))










        # temp = np.zeros_like(OptionChain.table_Cons[:OptionChain.lastSerialNo])
        #
        #
        #
        # temp[:]=OptionChain.table_Cons[:OptionChain.lastSerialNo]
        #
        # fltr = np.asarray([OptionChain.symbol])
        # filteredArray = OptionChain.contract_fo[np.in1d(OptionChain.contract_fo[:, 3], fltr)]
        #
        # futureToken = filteredArray[0][17]
        # futureprice = OptionChain.contract_fo[futureToken - 35000, 19]
        # # print('furureprice',futureprice)
        #
        # temp[:, 22] = temp[:, 22].astype('float64')
        #
        # temp[:, 9] = futureprice-temp[:, 22]
        # temp[:,10]=temp[:, 5]*temp[:, 9]
        # temp[:,11]=temp[:, 38]*temp[:, 9]
        #
        # temp[:,12]=temp[:, 10]+temp[:, 11]
        #
        # maxval=np.max(temp[:,12])
        #
        # # print(temp)
        # strike=temp[np.where(temp[:,12]==maxval),[22]][0]
        # # print('tt',temp[:,22])
        # # print('OO',OptionChain.table_Cons[:,22])
        # print(strike,maxval)
        # # res = np.where(arr == np.amax(arr))










def changeOptionChainwithNoofstrike(main):
    ################### Flush prev Data ################################




    main.OptionChain.lastSerialNo = 0
    main.OptionChain.modelT.lastSerialNo = 0
    main.OptionChain.modelT.rowCount()
    main.OptionChain.modelT.DelAllRows()
    main.OptionChain.modelT.modelReset.emit()

    if(main.OptionChain.cbStrike.currentText()=='All'):
        changeOptionChain(main)


        # num = 0
        # for i in self.table:
        #     try:
        #         self.table_Cons[num, :] = i
        #         num +=1
        #         self.lastSerialNo += 1
        #         self.modelT.lastSerialNo += 1
        #         self.modelT.insertRows()
        #         self.modelT.rowCount()
        #
        #     except:
        #         print(traceback.print_exc())
        # ind = self.modelT.index(0, 0)
        # ind1 = self.modelT.index(0, 1)
        # self.modelT.dataChanged.emit(ind, ind1)

    else:
        # main.recv_fo.classWiseList["OptionChain"]["NSEFO"]=[]

        # subscriibedTokens = main.recv_fo.classWiseList["OptionChain"]["NSEFO"]
        # print('b',main.recv_fo.classWiseList, 'ff', main.recv_fo.FinalList)

        main.recv_fo.classWiseList["OptionChain"]["NSEFO"] = []
        # print(type(subscriibedTokens))
        # for i in list(subscriibedTokens):
        #     # print('i',i)
        #     main.recv_fo.Unsubscribedlist("OptionChain", "NSEFO", i)

        main.recv_fo.UpdateFinalList('NSEFO')

        # print('A', main.recv_fo.classWiseList, 'ff', main.recv_fo.FinalList)

        ATMstrike = ATMWork(main.OptionChain)
        ATMstrike = format(ATMstrike, '.2f')
        rowIndex = np.where(main.OptionChain.table[:, 22] == str(ATMstrike))[0][0]
        print('ATM strike Index', rowIndex)
        noOfStrike = (int(main.OptionChain.cbStrike.currentText())*2) + 1
        noOfStrike1 = int(main.OptionChain.cbStrike.currentText())
        sPoint = rowIndex-noOfStrike1
        for i in range(noOfStrike):
            try:
                data=main.OptionChain.table[(sPoint + i), :]
                main.OptionChain.table_Cons[i, :] = main.OptionChain.table[(sPoint+i),:]

                main.recv_fo.subscribedlist("OptionChain", "NSEFO", data[0])
                main.recv_fo.subscribedlist("OptionChain", "NSEFO", data[1])

                main.OptionChain.lastSerialNo += 1
                main.OptionChain.modelT.lastSerialNo += 1
                main.OptionChain.modelT.insertRows()
                main.OptionChain.modelT.rowCount()

            except:
                print(traceback.print_exc())
        ind = main.OptionChain.modelT.index(0, 0)
        ind1 = main.OptionChain.modelT.index(0, 1)
        main.OptionChain.modelT.dataChanged.emit(ind, ind1)

    # print('ADD',main.recv_fo.classWiseList,'ff',main.recv_fo.FinalList)


    #     num = 0
    #     for i in self.table_Cons:
    #         # print(i)
    #
    #         self.table[num, :] = i
    #         self.table_Cons[num, :] = i
    #         num += 1
    #         self.lastSerialNo += 1
    #         self.modelT.lastSerialNo += 1
    #         self.modelT.insertRows()
    #         self.modelT.rowCount()
    # else:
    #     Sno=int(self.cbStrike.currentText())
    #     print(Sno)
    #     tv=self.table_Cons[rowIndex-Sno:rowIndex+Sno+1,:]
    #     # print(tv)
    #
    #
    #
    #
    #     num = 0
    #     for i in tv:
    #         # print(i)
    #
    #         self.table_Cons[num, :] = i
    #         num += 1
    #         self.lastSerialNo += 1
    #         self.modelT.lastSerialNo += 1
    #         self.modelT.insertRows()
    #         self.modelT.rowCount()
    #
    #
    #
    #


def createBaseOptionChain(self):
    print("inside : createBaseOptionChain")
    fltr = np.asarray([self.cbSymbol.currentText()])
    filteredArray = self.contract_fo[np.in1d(self.contract_fo[:, 3], fltr)]
    self.exp = self.cbExp.currentText()
    # uniqeExp = np.unique(filteredArray[:, 6])
    #
    #
    # self.cbExp.clear()
    # self.cbExp.addItems(uniqeExp.tolist())

    fltr1 = np.asarray([self.cbExp.currentText()])
    filteredArray1 = filteredArray[np.in1d(filteredArray[:, 6], fltr1)]

    fltr2 = np.asarray(['CE'])
    filteredArray2 = filteredArray1[np.in1d(filteredArray1[:, 8], fltr2)]
    filteredArray4 = filteredArray2[filteredArray2[:, 12].argsort()]
    filteredArray3 = filteredArray4[:, [2, 38, 7]]
    filteredArray3[:,  1] =  filteredArray3[:,  1].astype('int32')
    # print(filteredArray3)

    bdf = np.zeros((filteredArray3.shape[0], 40))
    table1 = np.hstack([filteredArray3, bdf])
    table1[:, 22] = table1[:, 2]
    table1[:, 2] = 0.0

    # print(table1[:,[0,1,17]])

    num = 0
    for i in table1:
        # print(i)

        self.table[num, :] = i
        self.table_Cons[num, :] = i
        num += 1
        self.lastSerialNo += 1
        self.modelT.lastSerialNo += 1
        self.modelT.insertRows()
        self.modelT.rowCount()


def updateTokenList(main):
    if main.OptionChain.lastSerialNo !=0:
        cetoken=main.OptionChain.table_Cons[:main.OptionChain.lastSerialNo,0]
        petoken=main.OptionChain.table_Cons[:main.OptionChain.lastSerialNo,1]
        # print(cetoken,petoken)

        finallist=list(cetoken)+list(petoken)
        # print(type(finallist),finallist)
        main.recv_fo.classWiseList["OptionChain"]["NSEFO"]=finallist
        main.recv_fo.UpdateFinalList('NSEFO')

def updateTokenListCloseW(main):
    if main.OptionChain.lastSerialNo!=0:
        main.recv_fo.classWiseList["OptionChain"]["NSEFO"] = []
        main.recv_fo.UpdateFinalList('NSEFO')

        # print(main.recv_fo.classWiseList,main.recv_fo.FinalList)




def changeOptionChain(main):
    subscriibedTokens = main.recv_fo.classWiseList.get("OptionChain")
    if subscriibedTokens is not None:
        main.recv_fo.classWiseList["OptionChain"]["NSEFO"]=[]
        # subscriibedTokens = main.recv_fo.classWiseList["OptionChain"]["NSEFO"]
        # print('b',main.recv_fo.classWiseList, 'ff', main.recv_fo.FinalList)

        # for i in list(subscriibedTokens):
        #     # print('i',i)
        #     main.recv_fo.Unsubscribedlist("OptionChain", "NSEFO", i)

        main.recv_fo.UpdateFinalList('NSEFO')

        # print('A',main.recv_fo.classWiseList,'ff',main.recv_fo.FinalList)

    ################### Flush prev Data ################################
    main.OptionChain.symbol = main.OptionChain.cbSymbol.currentText()
    main.OptionChain.exp = main.OptionChain.cbExp.currentText()

    # table = np.empty((500, 41), dtype=object)
    #
    # main.OptionChain.table[:,:] = table[:,:]
    # main.OptionChain.table_Cons[:,:] = table[:,:]

    # self.table = np.zeros((500, 43), dtype=object)
    # self.table_Cons = np.zeros((500, 43), dtype=object)

    main.OptionChain.lastSerialNo = 0
    main.OptionChain.modelT.lastSerialNo = 0
    main.OptionChain.modelT.rowCount()
    main.OptionChain.modelT.DelAllRows()
    main.OptionChain.modelT.modelReset.emit()


    ######################################################################


    fltr = np.asarray([main.OptionChain.cbSymbol.currentText()])
    filteredArray = main.OptionChain.contract_fo[np.in1d(main.OptionChain.contract_fo[:, 3], fltr)]

    # uniqeExp = np.unique(filteredArray[:, 6])
    # main.OptionChain.cbExp.addItems(uniqeExp.tolist())

    fltr1 = np.asarray([main.OptionChain.cbExp.currentText()])
    filteredArray1 = filteredArray[np.in1d(filteredArray[:, 6], fltr1)]

    fltr2 = np.asarray(['CE'])
    filteredArray2 = filteredArray1[np.in1d(filteredArray1[:, 8], fltr2)]

    filteredArray4 = filteredArray2[filteredArray2[:, 12].argsort()]
    filteredArray3 = filteredArray4[:, [2, 38, 7,22]]
    filteredArray3[:,  1] =  filteredArray3[:,  1].astype('int32')

    # print(filteredArray3)

    bdf = np.zeros((filteredArray3.shape[0], 39))
    table1 = np.hstack([filteredArray3, bdf])
    table1[:, 22] = table1[:, 2]
    table1[:, 2] = 0.0
    table1[:,5]=table1[:,3]
    table1[:, 3] = 0.0




    # print(table1[:,[0,1,17]])

    # main.recv_fo.FinalList['NSEFO'].clear()

    num =0
    for i in table1:
        # print('i[0] test',i[0])



        peTokenIndex = i[1] -35000
        peOI = main.OptionChain.contract_fo[peTokenIndex, 22]
        i[38]=peOI



        main.OptionChain.table[num, :] = i

        main.OptionChain.table_Cons[num, :] = i

        main.recv_fo.subscribedlist("OptionChain","NSEFO",i[0])
        main.recv_fo.subscribedlist("OptionChain", "NSEFO", i[1])

        num += 1
        main.OptionChain.lastSerialNo += 1
        main.OptionChain.modelT.lastSerialNo += 1
        main.OptionChain.modelT.insertRows()
        main.OptionChain.modelT.rowCount()

    # print('Add',main.recv_fo.classWiseList,'ff',main.recv_fo.FinalList)




def tables_details(self):
    try:
        #############################################################################################################
        self.heads = ['CEToken',
                      'PEToken', 'CEpain', 'CEScenarios', 'NetPremiu', 'OI',
                      'OIRunningBal','Volume', 'Open', 'High', 'Low',
                       'Close','LTP', 'IV','Delta','Gamma',
                      'Theta','Vega', 'Bid', 'Bid_IV', 'Ask',
                      'Ask_IV','StrikeP', 'LTP', 'IV','Delta',
                       'Gamma','Theta','Vega', 'Bid','Bid_IV',
                       'Ask','Ask_IV', 'Open', 'High','Low',
                       'Close','Volume', 'OI','OIRunningBal', 'NetPremium',
                       'PEScenario','PE_pain'

                      ]
        self.table = np.zeros((500, 43), dtype=object)
        self.table_Cons = np.zeros((500, 43), dtype=object)
        self.lastSerialNo = 0

        #############################################################################################################
        #############################################
        self.modelT = ModelTB(self.table_Cons, self.heads)
        self.smodelT = QSortFilterProxyModel()
        self.smodelT.setSourceModel(self.modelT)
        self.smodelT.setDynamicSortFilter(False)
        self.smodelT.setFilterKeyColumn(2)
        self.smodelT.setFilterCaseSensitivity(False)
        self.tableView.setModel(self.smodelT)

        self.tableView.horizontalHeader().setSectionsMovable(True)
        self.tableView.verticalHeader().setSectionsMovable(True)

        self.tableView.setDragDropMode(self.tableView.InternalMove)
        self.tableView.setDragDropOverwriteMode(False)
        #
        self.tableView.horizontalHeader().setContextMenuPolicy(Qt.CustomContextMenu)
        self.tableView.customContextMenuRequested.connect(self.tableRightClickMenu)
        self.tableView.horizontalHeader().customContextMenuRequested.connect(self.headerRightClickMenu)
        #
        # # self.tableView.horizontalHeader().customContextMenuRequested.connect(self.headerRightClickMenu)
        #
        self.saveDefaultColumnProfile()
        self.lastSavedColumnProfile()

        # self.tableView.setColumnWidth(0, 0)
        # self.tableView.setColumnWidth(3, 0)
        # self.tableView.setColumnWidth(4, 0)
        # self.tableView.setColumnWidth(5, 0)
        # self.tableView.setColumnWidth(9, 0)
        # self.tableView.setColumnWidth(10, 0)
        # self.tableView.setColumnWidth(11, 0)
        # self.tableView.setColumnWidth(15, 0)

    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info())








def updateIV(self,data,ins_details):
    opt = ins_details[8]
    # print(ins_details,data)
    if(opt=='CE'):

        rowIndexArray = np.where(self.table[:, 0] == data['Token'])[0]
        rowIndexArray1 = np.where(self.table_Cons[:, 0] == data['Token'])[0]
        editList = [13]
        if (rowIndexArray.size != 0):
            rowIndex = rowIndexArray[0]
            self.table[rowIndex, editList] = data['iv']

        if (rowIndexArray1.size != 0):
            rowIndex1 = rowIndexArray1[0]
            self.table_Cons[rowIndex1,editList] = data['iv']
            for i in editList:
                ind = self.modelT.index(rowIndex1, i)
                self.modelT.dataChanged.emit(ind, ind)

    elif(opt=='PE'):
        rowIndexArray = np.where(self.table[:, 1] == data['Token'])[0]
        rowIndexArray1 = np.where(self.table_Cons[:, 1] == data['Token'])[0]
        editList = [24]
        if (rowIndexArray.size != 0):
            rowIndex = rowIndexArray[0]
            self.table[rowIndex, editList] = data['iv']

        if (rowIndexArray1.size != 0):
            rowIndex1 = rowIndexArray1[0]
            self.table_Cons[rowIndex1, editList] = data['iv']

            for i in editList:
                ind = self.modelT.index(rowIndex1, i)
                self.modelT.dataChanged.emit(ind, ind)


def updateGreeks(self,data,ins_details):
    opt = ins_details[8]
    # print(ins_details,data)
    if(opt=='CE'):

        rowIndexArray = np.where(self.table[:, 0] == data['Token'])[0]
        rowIndexArray1 = np.where(self.table_Cons[:, 0] == data['Token'])[0]
        editList = [14,15,16,17]
        if (rowIndexArray.size != 0):
            rowIndex = rowIndexArray[0]
            self.table[rowIndex,editList] =[data['Delta'],data['Gamma'],data['Theta'],data['Vega']]

        if (rowIndexArray1.size != 0):
            rowIndex1 = rowIndexArray1[0]
            self.table_Cons[rowIndex1, editList] = [data['Delta'], data['Gamma'], data['Theta'], data['Vega']]
            for i in editList:
                ind = self.modelT.index(rowIndex1, i)
                self.modelT.dataChanged.emit(ind, ind)

    elif(opt=='PE'):
        rowIndexArray = np.where(self.table[:, 1] == data['Token'])[0]
        rowIndexArray1 = np.where(self.table_Cons[:, 1] == data['Token'])[0]
        editList = [25,26,27,28]
        if (rowIndexArray.size != 0):
            rowIndex = rowIndexArray[0]
            self.table[rowIndex, editList] = [data['Delta'],data['Gamma'],data['Theta'],data['Vega']]

        if (rowIndexArray1.size != 0):
            rowIndex1 = rowIndexArray1[0]
            self.table_Cons[rowIndex1, editList] = [data['Delta'], data['Gamma'], data['Theta'], data['Vega']]

            for i in editList:
                ind = self.modelT.index(rowIndex1, i)
                self.modelT.dataChanged.emit(ind, ind)

def update7202(self,data,ins_details):
    opt = ins_details[8]

    # print(ins_details,data)
    if(opt=='CE'):

        rowIndexArray = np.where(self.table[:, 0] == data['Token'])[0]
        rowIndexArray1 = np.where(self.table_Cons[:, 0] == data['Token'])[0]


        editList = [5,7,12,4]
        if(rowIndexArray.size != 0):
            rowIndex = rowIndexArray[0]
            prevData = self.table[rowIndex, :]
            prevVolume = prevData[7]
            newVolume = prevVolume + data['FillVolume']

            self.table[rowIndex,editList] = [data['OpenInterest'],newVolume,data['LTP'],data['OpenInterest'] * data['LTP']]



        if(rowIndexArray1.size != 0):
            rowIndex1 = rowIndexArray1[0]
            # prevData = self.table_Cons[rowIndex1, :]
            # prevVolume = prevData[6]
            # newVolume = prevVolume + data['FillVolume']
            self.table_Cons[rowIndex1, editList] = [data['OpenInterest'], newVolume, data['LTP'],data['OpenInterest'] * data['LTP']]



            for i in editList:
                ind = self.modelT.index(rowIndex1, i)
                self.modelT.dataChanged.emit(ind, ind)





    elif(opt=='PE'):
        rowIndexArray = np.where(self.table[:, 1] == data['Token'])[0]
        rowIndexArray1 = np.where(self.table_Cons[:, 1] == data['Token'])[0]


        editList = [37,38,23,40]
        if (rowIndexArray.size != 0):
            rowIndex = rowIndexArray[0]
            prevData = self.table[rowIndex, :]
            prevVolume = prevData[37]
            newVolume = prevVolume + data['FillVolume']

            self.table[rowIndex,editList ] = [newVolume,data['OpenInterest'],data['LTP'],data['OpenInterest'] * data['LTP']]

        if (rowIndexArray1.size != 0):
            rowIndex1 = rowIndexArray1[0]
            # prevData = self.table_Cons[rowIndex1, :]
            # prevVolume = prevData[36]
            # newVolume = prevVolume + data['FillVolume']
            self.table_Cons[rowIndex1, editList] = [newVolume, data['OpenInterest'], data['LTP'],data['OpenInterest'] * data['LTP']]

            for i in editList:
                ind = self.modelT.index(rowIndex1, i)
                self.modelT.dataChanged.emit(ind, ind)

def update1501(self,data,ins_details):
    opt = ins_details[8]
    # print(ins_details,data)
    if(opt=='CE'):
        rowIndexArray = np.where(self.table[:, 0] == data['Token'])[0]
        rowIndexArray1 = np.where(self.table_Cons[:, 0] == data['Token'])[0]
        editList = [7,8,9,10,11,12,18,20,4]
        if (rowIndexArray.size != 0):
            rowIndex = rowIndexArray[0]
            prevData = self.table[rowIndex, :]
            prevOI = prevData[5]
            self.table[rowIndex,editList] = [data['Volume'],data['OPEN'],data['HIGH'],data['LOW']
                                                                                    ,data['CLOSE'],data['LTP'],data['Bid'],data['Ask'],prevOI*data['LTP']]

        if (rowIndexArray1.size != 0):
            rowIndex1 = rowIndexArray1[0]
            self.table_Cons[rowIndex1, editList] = [data['Volume'], data['OPEN'], data['HIGH'], data['LOW']
                                                                    , data['CLOSE'], data['LTP'], data['Bid'], data['Ask'],prevOI*data['LTP']]
            for i in editList:
                ind = self.modelT.index(rowIndex1, i)
                self.modelT.dataChanged.emit(ind, ind)
    elif(opt=='PE'):
        rowIndexArray = np.where(self.table[:, 1] == data['Token'])[0]
        rowIndexArray1 = np.where(self.table_Cons[:, 1] == data['Token'])[0]
        editList = [37,33,34,35,36,23,29,31,40]
        if (rowIndexArray.size != 0):
            rowIndex = rowIndexArray[0]
            prevData = self.table[rowIndex, :]
            prevOI = prevData[38]
            self.table[rowIndex, editList] = [data['Volume'],data['OPEN'],data['HIGH'],data['LOW'],data['CLOSE'],data['LTP'],data['Bid'],data['Ask'],prevOI*data['LTP']]

        if (rowIndexArray1.size != 0):
            rowIndex1 = rowIndexArray1[0]

            self.table_Cons[rowIndex1, editList] = [data['Volume'], data['OPEN'], data['HIGH'], data['LOW'], data['CLOSE'],data['LTP'], data['Bid'], data['Ask'],prevOI*data['LTP']]



            for i in editList:
                ind = self.modelT.index(rowIndex1, i)
                self.modelT.dataChanged.emit(ind, ind)


def updateBidAskIV(self,data,ins_details):
    opt = ins_details[8]
    # print(ins_details,data)
    if(opt=='CE'):

        rowIndexArray = np.where(self.table[:, 0] == data['Token'])[0]
        rowIndexArray1 = np.where(self.table_Cons[:, 0] == data['Token'])[0]

        editList = [19,21]
        if (rowIndexArray.size != 0):
            rowIndex = rowIndexArray[0]
            self.table[rowIndex,editList] = data['Bid_iv'],data['Ask_iv']

        if (rowIndexArray1.size != 0):
            rowIndex1 = rowIndexArray1[0]
            self.table_Cons[rowIndex1, editList] = data['Bid_iv'], data['Ask_iv']

            for i in editList:
                ind = self.modelT.index(rowIndex1, i)
                self.modelT.dataChanged.emit(ind, ind)
    elif(opt=='PE'):

        rowIndexArray = np.where(self.table[:, 1] == data['Token'])[0]
        rowIndexArray1 = np.where(self.table_Cons[:, 1] == data['Token'])[0]
        editList = [30,32]
        if (rowIndexArray.size != 0):
            rowIndex = rowIndexArray[0]
            self.table[rowIndex, editList] = data['Bid_iv'],data['Ask_iv']

        if (rowIndexArray1.size != 0):
            rowIndex1 = rowIndexArray1[0]
            self.table_Cons[rowIndex1, editList] = data['Bid_iv'], data['Ask_iv']

            for i in editList:
                ind = self.modelT.index(rowIndex1, i)
                self.modelT.dataChanged.emit(ind, ind)


def ATMWork(self):

    fltr = np.asarray([self.symbol])
    filteredArray = self.contract_fo[np.in1d(self.contract_fo[:, 3], fltr)]

    futureToken = filteredArray[0][17]

    # futureToken=filteredArray[np.in1d(filteredArray[:, 3], fltr),17]

    # futureprice, stikediff = filteredArray[0][19], filteredArray[0][36]
    futureprice = self.contract_fo[futureToken-35000,19]
    stikediff= self.contract_fo[futureToken-35000,36]


    ATMstrike = int(futureprice / stikediff) * stikediff
    # print(futureToken, futureprice, stikediff,ATMstrike)
    return ATMstrike

def changeOIRunningBalance(self):

    # #call OI Running
    #
    # for j,i in enumerate(self.table_Cons):
    #     if(i[0]==None):
    #         pass
    #     else:
    #         if (j == 0):
    #             i[6] = i[5]
    #             CpreOIRunn = i[5]
    #
    #
    #             CpreScen=i[3]
    #
    #
    #
    #         else:
    #             i[6]=i[5]+CpreOIRunn
    #
    #
    #             i[3]=CpreScen+(CpreOIRunn*100)
    #             CpreOIRunn = i[6]
    #             CpreScen = i[3]
    #
    #
    #
    #
    #
    #
    #     ind = self.modelT.index(j, 6)
    #     self.modelT.dataChanged.emit(ind, ind)
    #
    # #Put OIRunning reverse
    #
    # for i in range(self.lastSerialNo):
    #     try:
    #         rowIndex = self.lastSerialNo - i - 1
    #         if(i==0):
    #             self.table[rowIndex,39] = self.table[rowIndex,38]
    #         else:
    #             newPeROI = self.table[rowIndex+1,39]
    #             peOI = self.table[rowIndex,38]
    #             self.table[rowIndex,39] = newPeROI+peOI
    #             self.table_Cons[rowIndex,39] = newPeROI+peOI
    #     except:
    #         print('error lastSR',self.lastSerialNo,i,rowIndex,self.table[158:163,:])
    #
    #     ind = self.modelT.index(rowIndex, 39)
    #     self.modelT.dataChanged.emit(ind, ind)

    editList = [2, 3, 6]

    for j, i in enumerate(self.table_Cons):
        if (i[0] == None):
            pass
        else:
            if (j == 0):
                i[6] = i[5]  # oiRunn=OI
                i[3] = i[5]  # CEScen=OiRunn

                CpreOIRunn = i[6]  # callPreOIRunn=OIRunning
                CpreScen = i[3]  # callPrescen=CEScen



            else:
                # OIRunning=OI+PrevRowOIRunning
                i[6] = i[5] + CpreOIRunn

                # CEScenarios=prevRowCEScenarios + (prevrowOIRunn * 100)
                i[3] = CpreScen + (CpreOIRunn * 100)

                # CEpain= CEScenarios + NetPrem
                i[2] = i[3] + i[4]

                CpreOIRunn = i[6]
                CpreScen = i[3]

        for i in editList:
            ind = self.modelT.index(j, i)
            self.modelT.dataChanged.emit(ind, ind)

    # Put OIRunning reverse

    editList = [39, 41, 42]
    for i in range(self.lastSerialNo):
        try:
            rowIndex = self.lastSerialNo - i - 1
            if (i == 0):
                self.table_Cons[rowIndex, 39] = self.table[rowIndex, 38]
                self.table_Cons[rowIndex, 41] = self.table[rowIndex, 39]
            else:
                newPeROI = self.table[rowIndex + 1, 39]
                peOI = self.table[rowIndex, 38]

                nxtPEScen = self.table[rowIndex + 1, 41]

                # OIRunning=OI+nxtRowOIRunning
                self.table[rowIndex, 39] = newPeROI + peOI
                self.table_Cons[rowIndex, 39] = newPeROI + peOI

                # PEScenarios=nxtRowPEScenarios + (nxtrowOIRunn * 100)
                self.table[rowIndex, 41] = nxtPEScen + (newPeROI * 100)
                self.table_Cons[rowIndex, 41] = nxtPEScen + (newPeROI * 100)

                # PEpain= PEScenarios + NetPrem
                self.table[rowIndex, 42] = self.table[rowIndex, 41] + self.table[rowIndex, 40]
                self.table_Cons[rowIndex, 42] = self.table_Cons[rowIndex, 41] + self.table_Cons[rowIndex, 40]

        except:
            print('error lastSR', self.lastSerialNo, i, rowIndex, self.table[158:163, :])

        for i in editList:
            ind = self.modelT.index(rowIndex, i)
            self.modelT.dataChanged.emit(ind, ind)
















