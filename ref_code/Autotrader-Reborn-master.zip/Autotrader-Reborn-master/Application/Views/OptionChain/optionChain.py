import json
import os

from PyQt5.QtCore import QObject,QFile,pyqtSignal,pyqtSlot,Qt,QSortFilterProxyModel,QTimer
from PyQt5.QtGui import QIcon, QKeySequence
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5 import uic
# from Application.MODEL.tableOC import ModelTB
from Application.Views.titlebar import tBar
from Theme.dt2 import dt1
from Application.Views.OptionChain.support import *
# from Application.Utils.createTables import tables_details

import traceback
import logging
import platform
import sys
from os import getcwd,path


import numpy as np

from Application.Views.OptionChain.optionSelection import Ui_OptSelect


class OptionChain(QMainWindow):
    def __init__(self):
        try:
            super(OptionChain, self).__init__(parent=None)

            self.list1 = []
            self.rcount = 0
            self.sortColumn = 0
            self.sortOrder = 0
            self.lastSerialNo = 0

            #############################################################################
            loc1 = getcwd().split('Application')
            ui_login = path.join(loc1[0], 'Resourses','UI', 'OptionChain1.ui')

            uic.loadUi(ui_login, self)
            osType = platform.system()
            if(osType=='Darwin'):
                flags = Qt.WindowFlags( Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint |Qt.WindowStaysOnTopHint )
            else:
                # flags = Qt.WindowFlags(Qt.SubWindow | Qt.FramelessWindowHint )
                flags = Qt.WindowFlags( Qt.FramelessWindowHint |Qt.WindowStaysOnTopHint  )
            self.setWindowFlags(flags)
            self.setStyleSheet(dt1)
            self.title = tBar('Option Chain')
            self.headerFrame.layout().addWidget(self.title, 0, 0)
            self.title.sgPoss.connect(self.movWin)

            #############################################################################
            # self.tables_details(self)
            tables_details(self)

            self.createShortcuts()
            self.connectAllSlots()
            QSizeGrip(self.frameGrip)

            self.exp = ''
            self.createTimers()
            self.symbol = 'NIFTY'

            # polpulateCbSymbol(self)
            # createBaseOptionChain(self)
            self.optSelect = Ui_OptSelect()
            self.lb_PCR.setText(str(0.0))

        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info())



    def updateIV(self,data):
        pass
    def updateGreeks(self,data):
        pass



    def updateValues(self, data):

        # exch
        # check id
        # print(data)
        if (data['Exch'] == 2):

            abc = 1
            ins_details = self.contract_fo[data['Token'] - 35000, :]
            # sym
            # exp
            # strike ' '

            symbol = ins_details[3]
            # print(1,symbol,self.cbSymbol.currentText())
            if (symbol == self.symbol):

                # print(2, symbol, self.cbSymbol.currentText())
                exp = ins_details[6]
                if (exp == self.exp):
                    strike = ins_details[7]

                    if (strike != ' '):
                        if (data['ID'] == 'IV'):
                            updateIV(self, data, ins_details)
                        elif (data['ID'] == 7202):
                            update7202(self, data, ins_details)
                        elif (data['ID'] == 1501):
                            update1501(self, data, ins_details)
                        elif (data['ID'] == 'Greeks'):
                            updateGreeks(self, data, ins_details)
                        elif (data['ID'] == 'Bid_Ask'):
                            updateBidAskIV(self, data, ins_details)


    def connectAllSlots(self):
        self.tableView.horizontalHeader().sectionClicked.connect(self.getSortClues)
        self.bt_close.clicked.connect(self.hide)
        # self.bt_min.clicked.connect(self.hide)

    def movWin(self, x, y):
        self.move(self.pos().x() + x, self.pos().y() + y)

    def createShortcuts(self):
        self.quitSc = QShortcut(QKeySequence('Esc'), self)
        self.quitSc.activated.connect(self.hide)

    def changeFilter(self,a):

        self.smodelT.setFilterFixedString(a)

    def getSortClues(self,a):
        self.sortOrder = self.smodelT.sortOrder()
        self.sortColumn =self.smodelT.sortColumn()

    def movWin(self, x, y):
        self.move(self.pos().x() + x, self.pos().y() + y)

    def filtr(self):
        try:
            self.smodelT.setFilterFixedString(self.listView.selectedIndexes()[0].data())
        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info())


    def refresh_config(self):

        try:
            self.MDheaders, self.IAheaders, self.MDToken, self.IAToken, self.URL, self.userID, self.source = readConfig1()
        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info())


    def createTimers(self):
        self.timerATM  = QTimer()
        self.timerATM.setInterval(30000)
        self.timerATM.timeout.connect(lambda :ATMWork(self))
        self.timerATM.start()

        self.timerCHOI = QTimer()
        self.timerCHOI.setInterval(5000)
        self.timerCHOI.timeout.connect(lambda: changeOIRunningBalance(self))

        self.timerCHOI.start()

        self.timerPCR = QTimer()
        self.timerPCR.setInterval(6000)
        self.timerPCR.timeout.connect(lambda: updatePCR(self))
        self.timerPCR.start()

        self.timerMpain = QTimer()
        self.timerMpain.setInterval(10000)
        self.timerMpain.timeout.connect(lambda: UpdateMaxpain(self))
        self.timerMpain.start()

    def connectAllSlots(self):
        self.tableView.horizontalHeader().sectionClicked.connect(self.getSortClues)
        self.bt_close.clicked.connect(self.hide)
        self.bt_min.clicked.connect(self.showMinimized)
        self.bt_max.clicked.connect(self.showMaximized)
        self.cbSymbol.currentIndexChanged.connect(lambda: populateCbExp(self))

        # self.pbApply.clicked.connect(lambda: changeOptionChainwithNoofstrike(self))

    def movWin(self, x, y):
        self.move(self.pos().x() + x, self.pos().y() + y)

    def createShortcuts(self):
        self.quitSc = QShortcut(QKeySequence('Esc'), self)
        self.quitSc.activated.connect(self.hide)

    def changeFilter(self,a):
        self.smodelT.setFilterFixedString(a)

    def getSortClues(self,a):
        self.sortOrder = self.smodelT.sortOrder()
        self.sortColumn =self.smodelT.sortColumn()

    # def movWin(self, x, y):
    #     self.move(self.pos().x() + x, self.pos().y() + y)

    def filtr(self):
        try:
            self.smodelT.setFilterFixedString(self.listView.selectedIndexes()[0].data())
        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info())


    # def refresh_config(self):
    #     try:
    #         self.MDheaders, self.IAheaders, self.MDToken, self.IAToken, self.URL, self.userID, self.source = readConfig1()
    #     except:
    #         print(traceback.print_exc())
    #         logging.error(sys.exc_info())


    def saveDefaultColumnProfile(self):
        try:
            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            # print(settingsFilePath)

            f1 = open(settingsFilePath)

            pathDetails= json.load(f1)
            # print(pathDetails)
            f1.close()
            defaultFilePath1 = pathDetails['optionChain']['defaultColumnProfile']


            binData = self.tableView.horizontalHeader().saveState()
            loc1 = getcwd().split('Application')
            defaultFilePath = os.path.join(loc1[0], defaultFilePath1)
            # save = QFileDialog.getSaveFileName(self, 'Save file', dirctry)[0]
            with open(defaultFilePath, 'wb') as f:
                f.write(binData)
            f.close()
        except:
            print(traceback.print_exc())
    def updateDefaultColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
        f1 = open(settingsFilePath)
        pathDetails = json.load(f1)
        f1.close()
        lastCPFilePath = pathDetails['optionChain']['defaultColumnProfile']
        with open(lastCPFilePath, 'rb') as f:
            binData = f.read()
        f.close()
        self.tableView.horizontalHeader().restoreState(binData)
    def lastSavedColumnProfile(self):
        loc = os.getcwd().split('Application')[0]
        settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
        f1 = open(settingsFilePath)
        pathDetails = json.load(f1)
        f1.close()
        lastCPFilePath1 = pathDetails['optionChain']['lastSavedColumnProfile']
        lastCPFilePath = os.path.join(loc, lastCPFilePath1)

        with open(lastCPFilePath, 'rb') as f:
            binData = f.read()
        f.close()
        self.tableView.horizontalHeader().restoreState(binData)
    def saveColumnProfile(self):
        try:
            # loc = os.getcwd().split('Application')[0]
            defaultDir = os.path.join( 'ColumnProfile')
            binData = self.tableView.horizontalHeader().saveState()
            save = QFileDialog.getSaveFileName(self, 'Save file', defaultDir)[0]
            print('save optionChain save column profile',save)

            with open(save, 'wb') as f:
                f.write(binData)
            f.close()



            loc = os.getcwd().split('Application')[0]
            settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
            f1 = open(settingsFilePath)
            pathDetails= json.load(f1)
            f1.close()
            pathDetails['optionChain']['lastSavedColumnProfile'] = save

            pathDetails_new = json.dumps(pathDetails, indent=4)


            f2 = open(settingsFilePath,'w+')
            f2.write(pathDetails_new)
            # pathDetails= json.load(f1)
            f2.close()
        except:
            print(traceback.print_exc())
    def openColumnProfile(self):
        # loc = os.getcwd().split('Application')[0]
        defaultDir = os.path.join('ColumnProfile')

        save = QFileDialog.getOpenFileName(self, 'Open file', defaultDir)[0]

        with open(save, 'rb') as f:
            binData = f.read()
        f.close()

        self.tableView.horizontalHeader().restoreState(binData)

    def headerRightClickMenu(self, position):
        try:
            # print()
            # a=(self.tableView.selectedIndexes()[0].data())
            menu = QMenu()

            saveColumnProfile = menu.addAction("save col profile")
            restoreColumnProfile = menu.addAction("open Col Profile")
            hideColumn = menu.addAction("hide")
            reset = menu.addAction("reset")

            # cancelAction = menu.addAction("Cancel")
            action = menu.exec_(self.tableView.horizontalHeader().mapToGlobal(position))
            if action == saveColumnProfile:
                self.saveColumnProfile()
            elif (action == restoreColumnProfile):
                self.openColumnProfile()
            elif (action == hideColumn):

                x = (self.tableView.horizontalHeader().logicalIndexAt(position))
                self.tableView.horizontalHeader().hideSection(x)
            elif (action == reset):
                self.updateDefaultColumnProfile()
        except:
            print(sys.exc_info()[1])
    def tableRightClickMenu(self, position):
        try:
            # a=(self.tableView.selectedIndexes()[0].data())
            menu = QMenu()

            squareAction = menu.addAction("Square")
            # squareAction1 = menu.addAction("PARTH")
            # cancelAction = menu.addAction("Cancel")
            action = menu.exec_(self.tableView.mapToGlobal(position))
            if action == squareAction:
                pass
        except:
            print(sys.exc_info()[1])


    @pyqtSlot(dict)
    def update(self,data):
        self.updateValues(self, data)




if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    form = OptionChain()
    form.show()
    sys.exit(app.exec_())



    # def saveDefaultColumnProfile(self):
    #     try:
    #         loc = os.getcwd().split('Application')[0]
    #         settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
    #         print(settingsFilePath)
    #
    #         f1 = open(settingsFilePath)
    #
    #         pathDetails= json.load(f1)
    #         print(pathDetails)
    #         f1.close()
    #         defaultFilePath = pathDetails['optionChain']['defaultColumnProfile']
    #
    #
    #         binData = self.tableView.horizontalHeader().saveState()
    #         # save = QFileDialog.getSaveFileName(self, 'Save file', dirctry)[0]
    #         with open(defaultFilePath, 'wb') as f:
    #             f.write(binData)
    #         f.close()
    #     except:
    #         print(traceback.print_exc())
    # def updateDefaultColumnProfile(self):
    #     loc = os.getcwd().split('Application')[0]
    #     settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
    #     f1 = open(settingsFilePath)
    #     pathDetails = json.load(f1)
    #     f1.close()
    #     lastCPFilePath = pathDetails['optionChain']['defaultColumnProfile']
    #     with open(lastCPFilePath, 'rb') as f:
    #         binData = f.read()
    #     f.close()
    #     self.tableView.horizontalHeader().restoreState(binData)
    # def lastSavedColumnProfile(self):
    #     loc = os.getcwd().split('Application')[0]
    #     settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
    #     f1 = open(settingsFilePath)
    #     pathDetails = json.load(f1)
    #     f1.close()
    #     lastCPFilePath = pathDetails['optionChain']['lastSavedColumnProfile']
    #     with open(lastCPFilePath, 'rb') as f:
    #         binData = f.read()
    #     f.close()
    #     self.tableView.horizontalHeader().restoreState(binData)
    # def saveColumnProfile(self):
    #     try:
    #         loc = os.getcwd().split('Application')[0]
    #         defaultDir = os.path.join(loc, 'Resourses', 'ColumnProfile')
    #         binData = self.tableView.horizontalHeader().saveState()
    #         save = QFileDialog.getSaveFileName(self, 'Save file', defaultDir)[0]
    #         print('save optionChain save column profile',save)
    #
    #         with open(save, 'wb') as f:
    #             f.write(binData)
    #         f.close()
    #
    #
    #
    #         loc = os.getcwd().split('Application')[0]
    #         settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')
    #         f1 = open(settingsFilePath)
    #         pathDetails= json.load(f1)
    #         f1.close()
    #         pathDetails['optionChain']['lastSavedColumnProfile'] = save
    #
    #         pathDetails_new = json.dumps(pathDetails, indent=4)
    #
    #
    #         f2 = open(settingsFilePath,'w+')
    #         f2.write(pathDetails_new)
    #         # pathDetails= json.load(f1)
    #         f2.close()
    #
    #
    #
    #
    #     except:
    #         print(traceback.print_exc())
    # def openColumnProfile(self):
    #     loc = os.getcwd().split('Application')[0]
    #     defaultDir = os.path.join(loc, 'Resourses', 'ColumnProfile')
    #
    #     save = QFileDialog.getOpenFileName(self, 'Open file', defaultDir)[0]
    #
    #     with open(save, 'rb') as f:
    #         binData = f.read()
    #     f.close()
    #
    #     self.tableView.horizontalHeader().restoreState(binData)
    # def headerRightClickMenu(self, position):
    #     try:
    #         print()
    #         # a=(self.tableView.selectedIndexes()[0].data())
    #         menu = QMenu()
    #
    #         saveColumnProfile = menu.addAction("save col profile")
    #         restoreColumnProfile = menu.addAction("open Col Profile")
    #         hideColumn = menu.addAction("hide")
    #         reset = menu.addAction("reset")
    #
    #         # cancelAction = menu.addAction("Cancel")
    #         action = menu.exec_(self.tableView.horizontalHeader().mapToGlobal(position))
    #         if action == saveColumnProfile:
    #             self.saveColumnProfile()
    #         elif (action == restoreColumnProfile):
    #             self.openColumnProfile()
    #         elif (action == hideColumn):
    #
    #             x = (self.tableView.horizontalHeader().logicalIndexAt(position))
    #             self.tableView.horizontalHeader().hideSection(x)
    #         elif (action == reset):
    #             self.updateDefaultColumnProfile()
    #     except:
    #         print(sys.exc_info()[1])
    # def tableRightClickMenu(self, position):
    #     try:
    #         # a=(self.tableView.selectedIndexes()[0].data())
    #         menu = QMenu()
    #
    #         squareAction = menu.addAction("Square")
    #         squareAction1 = menu.addAction("PARTH")
    #         # cancelAction = menu.addAction("Cancel")
    #         action = menu.exec_(self.tableView.mapToGlobal(position))
    #         if action == squareAction:
    #             pass
    #     except:
    #         print(sys.exc_info()[1])