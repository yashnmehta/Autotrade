import logging
import traceback
import sys
import requests
from PyQt5.QtCore import pyqtSlot,pyqtSignal
import numpy as np
import datatable as dt
import time
import threading
from Application.Views.Models.tableOrder import ModelOB
from Application.Utils.configReader import readDefaultClient,writeITR,refresh,all_refresh_config
from Application.Utils.getMasters import get_ins_details
# from Application.Utils.createTables import ta
from Application.Utils.updation import *
from Application.Services.Xts.Api import servicesMD


API_logger = logging.getLogger('API')

ORDER_logger = logging.getLogger('ORDER')

def getOrderPayloadWEBApi(exchange,clientID, token,orderSide, qty,limitPrice,validity, disQty, triggerPrice,uid,
                          orderType,productType):
    payload_order_place = {
        "exchangeSegment": exchange,
        "exchangeInstrumentID": token,
        "productType": productType,
        "orderType": orderType,
        "orderSide": orderSide,
        "timeInForce": validity,
        "disclosedQuantity": disQty,
        "orderQuantity": qty,
        "limitPrice": limitPrice,
        "stopPrice": triggerPrice,
        "orderUniqueIdentifier": uid
    }
    return payload_order_place


def getOrderPayloadTWSApi(exchange, clientID, token,  orderSide, qty,limitPrice,  validity, disQty, triggerPrice,uid,
                          orderType,productType):
    payload_order_place = {
        "clientID": clientID,
        "exchangeSegment": exchange,
        "exchangeInstrumentID": token,
        "productType": productType,
        "orderType": orderType,
        "orderSide": orderSide,
        "timeInForce": validity,
        "disclosedQuantity": disQty,
        "orderQuantity": qty,
        "limitPrice": limitPrice,
        "stopPrice": triggerPrice,
        "orderUniqueIdentifier": uid
    }
    return payload_order_place

def getOrderModifyPayloadWEBApi(apporderid, productType,orderType, qty,limitPrice, MStopPrice, disQty, validity, OrderUniqueID):

    payload_order_place = {
        "appOrderID": apporderid,
        "modifiedProductType": productType,
        "modifiedOrderType": orderType,
        "modifiedOrderQuantity": qty,
        "modifiedDisclosedQuantity": disQty,
        "modifiedLimitPrice": limitPrice,
        "modifiedStopPrice": MStopPrice,
        "modifiedTimeInForce": validity,
        "orderUniqueIdentifier": OrderUniqueID
    }
    return payload_order_place


def getOrderModifyPayloadTWSApi(clientID,apporderid, productType,orderType, qty,limitPrice, MStopPrice, disQty, validity, OrderUniqueID):
    payload_order_place = {
        "clientID": clientID,
        "appOrderID": apporderid,
        "modifiedProductType": productType,
        "modifiedOrderType": orderType,
        "modifiedOrderQuantity": qty,
        "modifiedDisclosedQuantity": disQty,
        "modifiedLimitPrice": limitPrice,
        "modifiedStopPrice": MStopPrice,
        "modifiedTimeInForce": validity,
        "orderUniqueIdentifier": OrderUniqueID
    }
    return payload_order_place

def PlaceOrder( self,exchange, clientID, token,  orderSide, qty, limitPrice,  validity,
               disQty, triggerPrice,uid,orderType="LIMIT", productType="NRML",):
    resJson = {}
    try:
        if(self.Source == 'TWSAPI'):
            if(uid == 'MANUAL'):
                uid = 'MANUAL'+'_'+clientID
            payload = getOrderPayloadTWSApi(exchange, clientID, token, orderSide, qty, limitPrice,  validity,
               disQty, triggerPrice,uid,orderType,productType)

        else:
            payload = getOrderPayloadWEBApi(exchange, clientID, token, orderSide, qty, limitPrice,  validity,
               disQty, triggerPrice,uid,orderType,productType)

        a =time.time()
        print('clientID',clientID)
        orderRes = requests.post(self.URL+'/interactive/orders', json=payload,
                                        headers=self.IAheaders)


        resJson = orderRes.json()
        # print('rrrrrrrr',resJson)
        appOrderId = resJson['result']['AppOrderID']
        # print('place_order_url', )
        b =time.time()


        logging.info("delay : %s,%s"%(b-a,orderRes.text))

        ORDER_logger.info("delay : %s,%s"%(b-a,orderRes.text))

        if(uid=='MANUAL'):
            pass
        elif(self.__class__.__name__ =='Ui_Main'):
            for i in self.Manager.All_stretegyList:
                if (i.folioName == uid):
                    i.Slogger.info("delay : %s,%s" % (b - a, orderRes.text))
        else:
            self.Slogger.info("delay : %s,%s"%(b-a,orderRes.text))


        return appOrderId

    except:
        print(traceback.print_exc(),resJson)
        #logging.error(traceback.print_exc(),'pppError',place_order_url.text)

##############################################################################################################
def modifyOrder( self,appOrderId,exchange, clientID, token,  orderSide, qty, limitPrice,
               disQty, triggerPrice,uid,orderType="LIMIT", productType="NRML",validity='DAY'):


    try:
        if(self.Source == 'TWSAPI'):
            payload = getOrderModifyPayloadTWSApi(clientID,appOrderId,productType,orderType,qty,limitPrice,triggerPrice,disQty,validity,uid)
        else:
            payload = getOrderModifyPayloadWEBApi(appOrderId,productType,orderType,qty,limitPrice,triggerPrice,disQty,validity,uid)
        # print("======modify:",payload)
        place_order_url = requests.put(self.URL + '/interactive/orders', json=payload,
                                       headers=self.IAheaders)
        data_p_order = place_order_url.json()
        # print('Order Modification request', data_p_order)

        logging.info(place_order_url.text)
    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])
#############################################################################################################################################################################################

def getOpenPosition(self):
    try:
        # print('in get_open_pos')
        if (self.Source == 'TWSAPI'):
            url = self.URL + '/interactive/portfolio/dealerpositions?dayOrNet=DayWise'
        elif (self.Source == 'WEBAPI'):
            url = self.URL + '/interactive/portfolio/positions?dayOrNet=DayWise'
        req = requests.request("GET", url, headers=self.IAheaders)
        data_p = req.json()
        # print('data_p--------------',data_p)
        dailyPos = data_p['result']['positionList']
        # print('dailyPos',dailyPos)
        if (self.Source == 'TWSAPI'):
            Neturl = self.URL + '/interactive/portfolio/dealerpositions?dayOrNet=NetWise'
        elif (self.Source == 'WEBAPI'):
            Neturl = self.URL + '/interactive/portfolio/positions?dayOrNet=NetWise'

        Netreq = requests.request("GET", Neturl, headers=self.IAheaders)
        Netdata_p = Netreq.json()
        NetPos = Netdata_p['result']['positionList']

        if(NetPos != []):

            self.openPossA = np.empty((0, 6))
            dpos = np.empty((0, 6))
            npos = np.empty((0, 6))

            if (dailyPos == []):
                for i2, i1 in enumerate(NetPos):
                    rmtm = float((i1['RealizedMTM']))
                    nv1 = float((i1['NetAmount']))
                    nv = rmtm if (nv1 == 0) else nv1

                    qty = int((i1['Quantity']).replace(',', ''))
                    token = int(i1['ExchangeInstrumentId'])
                    clientId = '*****'  if ('PRO' in i1['AccountID']) else i1['AccountID']


                    if(clientId not in self.openPosDict.keys()):
                        self.openPosDict[clientId]={}

                    pos1 = dt.Frame([[clientId], [token], [qty], [nv],[i2],[i1['ExchangeSegment']]])
                    self.openPosDict[clientId][token] = [qty,nv]

                    self.openPossA = np.vstack([self.openPossA, pos1])
            else:

                for i2, i1 in enumerate(dailyPos):

                    rmtm = float((i1['RealizedMTM']).replace(',', ''))
                    nv1 = float((i1['NetAmount']).replace(',', ''))
                    nv = rmtm if (nv1 == 0) else nv1
                    qty = int((i1['Quantity']).replace(',', ''))
                    token = int(i1['ExchangeInstrumentId'])
                    clientId = '*****'  if ('PRO' in i1['AccountID']) else i1['AccountID']

                    dpos1 = dt.Frame([[clientId], [token], [qty], [nv],[i2],[i1['ExchangeSegment']]])
                    dpos = np.vstack([dpos, dpos1])


                # print('dpos',dpos)
                for i2, i1 in enumerate(NetPos):
                    # print('i1',i1)
                    rmtm = float((i1['RealizedMTM']).replace(',', ''))
                    nv1 = float((i1['NetAmount']).replace(',', ''))
                    nv = rmtm if (nv1 == 0) else nv1
                    qty = int((i1['Quantity']).replace(',', ''))
                    token = int(i1['ExchangeInstrumentId'])
                    clientId = '*****'  if ('PRO' in i1['AccountID']) else i1['AccountID']


                    if(clientId not in self.openPosDict.keys()):
                        self.openPosDict[clientId]={}
                    if (token in dpos[:,1]):
                        fltr = np.asarray([token])
                        filteredArry  = dpos[np.in1d(dpos[:, 1], fltr)]
                        if(filteredArry.size >0):
                            fltr1 = np.asarray([i1['AccountID']])
                            filteredArry1 = filteredArry[np.in1d(filteredArry[:, 0], fltr1)]

                            if (filteredArry1.size > 0):
                                serialNo = filteredArry1[0,4]
                                # print(clientId,'filteredArry1',filteredArry1,'qty',qty,'serialNo',serialNo)
                                fnv = nv - dpos[serialNo,3]
                                Open_Quantity = qty - dpos[serialNo,2]
                            else:
                                fnv = nv
                                Open_Quantity = qty
                        else:
                            fnv = nv
                            Open_Quantity = qty
                    else:
                        fnv = nv
                        Open_Quantity = qty
                    self.openPosDict[clientId][token] = [Open_Quantity,fnv]
                    pos1 = dt.Frame([[clientId], [token], [Open_Quantity], [fnv],[i2],[i1['ExchangeSegment']]])
                    self.openPossA = np.vstack([self.openPossA, pos1])
        else:
            pass

        # for ixc in self.openPossA:
        #     print(ixc)
    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])
        API_logger.error(sys.exc_info()[1])

def getPositionBook(self):
    try:
        getOpenPosition(self)
        self.IAS.openPosDict = self.openPosDict
        # print("open pos disk", self.openPosDict)
        self.NetPos.lastSerialNo = 0
        if(self.Source=='TWSAPI'):
            url = self.URL + '/interactive/portfolio/dealerpositions?dayOrNet=NetWise'
        elif(self.Source=='WEBAPI'):
            url = self.URL + '/interactive/portfolio/positions?dayOrNet=NetWise'
        req = requests.request("GET", url, headers=self.IAheaders)
        data_p = req.json()

        # API_logger.info(req.text)

        aaa = data_p['result']['positionList']
        # print(aaa)
        if(aaa!=[]):

            for j,i in enumerate(aaa):
                try:
                    token  = int(i['ExchangeInstrumentId'])
                    clientId = '*****' if ('PRO' in i['AccountID']) else i['AccountID']

                    ins_details = get_ins_details(self,i['ExchangeSegment'],token)
                    qty = int(i['Quantity'])
                    amt =  float(i['NetAmount'])
                    avgp =  amt/qty if (qty != 0) else 0.0
                    openQty = self.openPosDict[clientId][token][0]
                    openAmount = self.openPosDict[clientId][token][1]
                    dayQty = qty - openQty
                    dayAmount = amt - openAmount

                    pos = dt.Frame([
                        [self.userID],
                        [clientId], [i['ExchangeSegment']],[int(i['ExchangeInstrumentId'])],[ins_details[4]],[ins_details[3]],
                        [ins_details[6]],[ins_details[7]],[ins_details[8]],[int(i['Quantity'])],[float(i['MTM'])],
                        [0],[float(i['RealizedMTM'])],[float(i['NetAmount'])],[avgp],[ins_details [11]],
                        [ins_details[14]],[ins_details[9]],[j],[openQty],[openAmount],
                        [dayQty],[dayAmount] ]).to_numpy()


                    updateGetPosition_NP(self, pos, j )
                    updateGetPosition_AMW(self, pos[0])

                except:
                    print(traceback.print_exc(),'error in getPOs i',i)

           # PosionW_datachanged_full(self)
         #   return pos[:ser_no+1,:]
    except:
        print(traceback.print_exc())

def getOrderBook(self,requestClass = 'main'):
    try:
        if(self.Source=='WEBAPI'):
            url = self.URL + '/interactive/orders'
            req = requests.request("GET", url, headers=self.IAheaders)
            data_p = req.json()
            noOfPendingOrder = 0


            ApiOrder = np.empty((15000, 23), dtype=object)
            PendingOrder = np.empty((15000, 26), dtype=object)
            if(data_p['result']!=[]):
                for j,i in enumerate(data_p['result']):
                    ########################
                    # if(j==0):
                        # print('get_order',i)
                    #######################


                    exchange = i["ExchangeSegment"]
                    token = i["ExchangeInstrumentID"]
                    ######################################## contract working ##########################################
                    ins_details = get_ins_details(self, exchange, token )
                    Qty1 = i['LeavesQuantity'] if(i['OrderSide'].upper()=='BUY') else -i['LeavesQuantity']
                    orderSide = i['OrderSide'].replace('BUY','Buy').replace('SELL','Sell')
                    order =dt.Frame([[(i['AppOrderID'])],
                            [i['ClientID']],[i['ExchangeInstrumentID']], [ ins_details[4]], [ins_details[3]],[ins_details[6]],
                            [ins_details[7]],[ins_details[8]],[orderSide],[i['OrderType']], [i['OrderStatus']],
                                                             [i['OrderQuantity']],[i['LeavesQuantity']],[i['OrderPrice']],[i['OrderStopPrice']], [i['OrderUniqueIdentifier']],
                            [i['OrderGeneratedDateTime']],[i['ExchangeTransactTime']],[i['CancelRejectReason']],[ins_details[0]],[ins_details[5]],
                            [i['OrderAverageTradedPrice']],[Qty1],[i['ProductType']],[i['TimeInForce']],[self.userID]]).to_numpy()

                    if(requestClass=='main'):
                        pass
                        # updateGetOrder_OB(self,order,j)


                    #############################################################################################

                    if(i['OrderStatus'] in ['PartiallyFilled','New','Replaced'] ):              #and i['OrderUniqueIdentifier']==self.FolioNo

                        PendingOrder[noOfPendingOrder,:] = order
                        #############################################################
                        if(requestClass=='main'):
                            # print(i['OrderStatus'])
                            updateGetOrder_POB(self,order,noOfPendingOrder)
                        #############################################################
                        noOfPendingOrder += 1


        else:
            jk = 0

            PendingOrder = np.empty((15000, 26), dtype=object)
            for kl in self.client_list:
                url = self.URL + '/interactive/orders?clientID=' + kl
                req = requests.request("GET", url, headers=self.IAheaders)
                data_p = req.json()
                noOfPendingOrder = 0

                if (data_p['result'] != []):
                    for j, i in enumerate(data_p['result']):
                        # print("ORDERBOOOKKK : ", i['LoginID'], ": ", self.userID)
                        if (i['LoginID'] == self.userID):

                            # print(" RRR   : ORDERBOOOKKK : ", i['LoginID'], ": ", self.userID)
                            exchange = i["ExchangeSegment"]
                            token = i["ExchangeInstrumentID"]
                            ######################################## contract working ##########################################
                            ins_details = get_ins_details(self, exchange, token)
                            ######################################## contract working ##########################################
                            Qty1 = i['LeavesQuantity'] if (i['OrderSide'].upper() == 'BUY') else -i['LeavesQuantity']
                            orderSide = i['OrderSide'].replace('BUY', 'Buy').replace('SELL', 'Sell')

                            order = dt.Frame([[(i['AppOrderID'])],
                                              [i['ClientID']], [i['ExchangeInstrumentID']], [ins_details[4]], [ins_details[3]], [ins_details[6]],
                                              [ins_details[7]], [ins_details[8]], [orderSide], [i['OrderType']], [i['OrderStatus']],
                                              [i['OrderQuantity']], [i['LeavesQuantity']], [i['OrderPrice']],[i['OrderStopPrice']], [i['OrderUniqueIdentifier']],
                                              [i['OrderGeneratedDateTime']], [i['ExchangeTransactTime']], [i['CancelRejectReason']], [ins_details[0]], [ins_details[5]],
                                              [i['OrderAverageTradedPrice']], [Qty1], [i['ProductType']], [i['TimeInForce']],[self.userID]]).to_numpy()
                            #############################################################################################
                            jk += 1

                            # print("1:", requestClass)
                            if (requestClass == 'main'):

                                pass
                                # updateGetOrder_OB(self, order, jk-1)

                                #############################################################################################

                            if (i['OrderStatus'] in ['PartiallyFilled', 'New', 'Replaced']):  # and i['OrderUniqueIdentifier']==self.FolioNo

                                PendingOrder[noOfPendingOrder, :] = order
                                #############################################################

                                if (requestClass == 'main'):
                                    # print("1")
                                    # print(i['OrderStatus'])
                                    updateGetOrder_POB(self, order, noOfPendingOrder)
                                #############################################################
                                noOfPendingOrder += 1


        pendingW_datachanged_full(self)
        orderW_datachanged_full(self)
    ####################################################
    except:
        print(traceback.print_exc())

def get_Trades(self,requestClass):
    try:
        if(self.Source=='WEBAPI'):
            url = self.URL + '/interactive/orders/trades'
            req = requests.request("GET", url, headers=self.IAheaders)
            data_p = req.json()

            if(data_p['result'] != []):
                if (requestClass == 'main'):
                    for i in self.Manager.stretegyList:
                        i.flushTradeData()

                # print('data_p getTrade',data_p)
                for j,i in enumerate(data_p['result']):
                    # print(i['OrderUniqueIdentifier'])

                    exchange = i['ExchangeSegment']
                    token = i['ExchangeInstrumentID']
                    ins_details = get_ins_details(self,exchange,token)
                    orderSide = i['OrderSide'].replace('BUY','Buy').replace('SELL','Sell')
                    tradedQty = i['LastTradedQuantity']
                    qty = tradedQty if (orderSide == 'Buy') else -tradedQty
                    netValue =  - qty *  i['LastTradedPrice']
                    trades = np.zeros((0,24),dtype=object)
                    trade = dt.Frame([
                        [i['LoginID']],
                        [i['ClientID']], [i['ExchangeInstrumentID']],[ins_details[4]],[ins_details[3]], [ins_details[6]],
                        [ins_details[7]], [ins_details[8]],[orderSide],[i['AppOrderID']],[i['OrderType']],
                        [tradedQty], [i['OrderStatus']],[i['OrderAverageTradedPrice']],[i['ExchangeTransactTime']], [i['OrderUniqueIdentifier']],
                        [i['ExchangeOrderID']],[i['LastTradedPrice']],[qty],[netValue],[ins_details[0]],
                        [ins_details[11]],[ins_details[14]],['openValue']
                        ]).to_numpy()
                    trades = np.vstack([trades,trade])
                    # print('trades.shape',trades.shape,trades)
                    if(requestClass=='main'):
                        # updateGetTrade_TB(self,trade,j)
                        updateGetTrade_FP(self.FolioPos,trade)
                        # print()
                        for x in self.Manager.All_stretegyList:
                            if (x.folioName == i['OrderUniqueIdentifier']):
                                print(x.folioName)
                                x.updateTrade(trade)

        else:
            # print("Client list : ", self.client_list)
            jk = 0
            trades = np.zeros((0, 24), dtype=object)

            for kl in self.client_list:
                url = self.URL + '/interactive/orders/trades?clientID=' + kl
                req = requests.request("GET", url, headers=self.IAheaders)
                data_p = req.json()



                if (data_p['result'] != []):
                    for i in self.Manager.stretegyList:
                        i.flushTradeData()

                    for j, i in enumerate(data_p['result']):
                        # print("inside get_Trades : ", i['LoginID'],":", i['ClientID'],":", self.userID,"abc")

                        if(i['LoginID']==self.userID):
                            # print('in get Trade',j,i)
                            exchange = i['ExchangeSegment']
                            token = i['ExchangeInstrumentID']
                            ins_details = get_ins_details(self, exchange, token)
                            orderSide = i['OrderSide'].replace('BUY', 'Buy').replace('SELL', 'Sell')
                            tradedQty = i['LastTradedQuantity']
                            qty = tradedQty if (orderSide == 'Buy') else -tradedQty
                            netValue = - qty * i['LastTradedPrice']

                            trade = dt.Frame([
                            [i['LoginID']],
                            [i['ClientID']], [i['ExchangeInstrumentID']], [ins_details[4]],[ins_details[3]], [ins_details[6]],
                            [ins_details[7]], [ins_details[8]],[orderSide],[i['AppOrderID']], [i['OrderType']],
                            [tradedQty],[i['OrderStatus']],[i['OrderAverageTradedPrice']], [i['ExchangeTransactTime']],[i['OrderUniqueIdentifier']],
                            [i['ExchangeOrderID']],[i['LastTradedPrice']],[qty],[netValue],[ins_details[0]],
                            [ins_details[11]],[ins_details[14]],['openValue']]).to_numpy()

                            jk+=1

                            trades = np.vstack([trades,trade])

                            if(requestClass=='main'):
                                # updateGetTrade_TB(self,trade,jk-1)
                                updateGetTrade_FP(self.FolioPos,trade)
                                for x in self.Manager.All_stretegyList:
                                    if(x.folioName==i['OrderUniqueIdentifier']):
                                        x.updateTrade(trade)


        tradeW_datachanged_full(self)
    except:
        print('get trade error',traceback.print_exc())


def get_bal_data(self):
    try:
        if (self.defaultClient == '*****'):
            url = self.URL + '/interactive/user/balance?clientID=' + self.defaultClient4mrg
        else:
            url = self.URL + '/interactive/user/balance?clientID=' + self.defaultClient

        # print('xxx',time.time())
        req = requests.request("GET", url, headers=self.IAheaders)
        data_p = req.json()
        # print('aaaaa',time.time())
        try:
            # pass
            cashAvailable=data_p['result']['BalanceList'][self.Mrglvl]['limitObject']['RMSSubLimits']['cashAvailable']
            collateral=data_p['result']['BalanceList'][self.Mrglvl]['limitObject']['RMSSubLimits']['collateral']
            marginUtilized=data_p['result']['BalanceList'][self.Mrglvl]['limitObject']['RMSSubLimits']['marginUtilized']

            print('marginUtilized',marginUtilized,type(marginUtilized),'\n',
                  'cashAvailable',cashAvailable,type(cashAvailable),'\n',
                  'collateral', marginUtilized, type(collateral)
                  )
            netMarginAvailable=data_p['result']['BalanceList'][self.Mrglvl]['limitObject']['RMSSubLimits']['netMarginAvailable']

            total = float(cashAvailable) + float(collateral)
            self.lbTMargin.setText('%.2f'%total)
            self.lbUMargin.setText(marginUtilized)
            self.lbFMargin.setText(netMarginAvailable)
        except:
            print('sdkfj')

        # except IndexError:
        #     cashAvailable = 0.00
        #     collateral = 0.00
        #     marginUtilized = 0.00
        #     netMarginAvailable = 0.0
        #
        #     self.lbTMargin.setText('%.2f' % (float(cashAvailable) + float(collateral)))
        #     self.lbUMargin.setText('%.2f' % float(marginUtilized))
        #     self.lbFMargin.setText('%.2f' % float(netMarginAvailable))


    except:
        print(traceback.print_exc())


def get_balance(self):
    try:
        get_bal_data(self)
        # print('timerbalance called')
        # th = threading.Thread(target=get_bal_data,args=(self,))
        # th.start()

    except:
        print(traceback.print_exc())

def login(self):
    try:
        refresh(self)

        payload = {"secretKey": self.IASecret, "appKey": self.IAKey, "source": self.Source}
        login_url = self.URL + '/interactive/user/session'
        login_access = requests.post(login_url, json=payload)

        # print(login_url, login_access.text,'\n',payload)

        if login_access.status_code == 200:
            data = login_access.json()
            result = data['result']

            if data['type'] == 'success':
                token = result['token']
                self.login.label.append('Interactive API Logged In')
                #####################################  clist  ###########################################################
                client_codes_r = result['clientCodes']


                # print('client_codes_r',client_codes_r)


                self.loggedInUser = result['userID']
                self.lbLoginId.setText(self.loggedInUser)

                self.client_list = []
                self.clientFolios = {}
                # self.FolioPos.clientFolios = {}
                # self.FolioPos.cbClient.addItem()

                for i in client_codes_r:
                    if (i[:3] == 'PRO'):
                        proclient = i
                        self.client_list.append('*****')
                        self.FolioPos.clientFolios['*****'] = ['MANUAL_*****']

                        self.FolioPos.cbClient.addItem('*****')

                    else:
                        # print("client_list.append:", i)
                        self.client_list.append(i)

                        if (i not in self.FolioPos.clientFolios.keys()):
                            self.FolioPos.clientFolios[i] = []


                        self.FolioPos.clientFolios[i].append('MANUAL_'+i)

                        # self.FolioPos.clientFolios[i] = ['MANUAL_'+i]
                        self.FolioPos.cbClient.addItem(i)

                dclient = readDefaultClient()
                self.defaultClient = dclient
                # print(dclient,'client_list',self.client_list)

                if (dclient in self.client_list):
                    # print("33333333333333")
                    self.defaultClient = dclient

                    self.buyW.leClient.setText(self.defaultClient)
                    self.sellW.leClient.setText(self.defaultClient)
                    self.swapOrder.cbClientID.addItem(self.defaultClient)

                    self.spreadOrder.cbClientID.addItem(self.defaultClient)



                    if(self.defaultClient == '*****'):
                        self.defaultClient4mrg = proclient


                self.multiOrders.cbClient.addItems(client_codes_r)
                writeITR(token, self.userID, self.client_list)
                self.login.updateIAstatus(data['type'])


                refresh(self)


                servicesMD.subscribeToken(self, 26000, 'NSECM')
                servicesMD.subscribeToken(self, 26001, 'NSECM')
                servicesMD.subscribeToken(self, 26002, 'NSECM')
                servicesMD.subscribeToken(self, 26034, 'NSECM')


                th3 = threading.Thread(target=getPositionBook, args=(self,))
                th3.start()
                th1 = threading.Thread(target=get_Trades, args=(self,'main'))
                self.IAS.start_socket_io()
                #
                th2 = threading.Thread(target=getOrderBook, args=(self,'main' ))
                #
                #
                th1.start()
                th2.start()




                all_refresh_config(self)




                # self.login.pbNext.show()


            else:
                a = 'Check API Details'
                self.login.updateIAstatus(a)
            # try:
            # API_logger.info('log In')
            # except:
            #     print(traceback.print_exc())

        else:
            logging.info(str(login_access.text).replace('\n', '\t\t\t\t'))
            API_logger.info(str(login_access.text).replace('\n', '\t\t\t\t'))
            ################# check if success ############
        refresh(self)
    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info())
        API_logger.error(sys.exc_info())

def cancle_order(self,cancledOrderist):
    try:

        for i in cancledOrderist:
            cancle_url = self.URL + "/interactive/orders?appOrderID=" + str(
                i['AppOrderId']) + "&orderUniqueIdentifier=" + str(i['FolioNO']) + "&clientID=" + i['clientId']

            cancle_order_r = requests.delete(cancle_url, headers=self.IAheaders)
            print(cancle_order_r.text)
    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])
        API_logger.error(sys.exc_info()[1])

