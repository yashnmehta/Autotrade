import traceback
import sys
import logging
import json
import datetime
import time


from Application.Utils.getMasters import getMaster, shareContract
import  requests

from Application.Utils.configReader import writeMD,refresh,readConfig_All
import numpy as np
import talib as ta



def subscribeToken(self, token, seg, streamType=1501):
    try:
        segment= 0
        if (seg == 'NSEFO'):
            segment = 2
        elif (seg == 'NSECM'):
            segment = 1
        ## ****** CD PENDING
        # print('segment',segment)
        sub_url = self.URL + '/marketdata/instruments/subscription'
        payloadsub = {"instruments": [{"exchangeSegment": segment, "exchangeInstrumentID": token}],
                      "xtsMessageCode": streamType}

        payloadsubjson = json.dumps(payloadsub)

        # print(payloadsubjson)
        req = requests.request("POST", sub_url, data=payloadsubjson, headers=self.MDheaders)
        # print(req.text)





        if ('subscribed successfully' in req.text or 'Already Subscribed' in req.text):
            if('subscribed successfully' in req.text):
                data = req.json()
                    # data2 = json.loads(data['result']['listQuotes'])
                # print('in sub',data2)
                if(data['result']['listQuotes'] != []):
                    try:
                        data2 = json.loads(data['result']['listQuotes'][0])
                    except:
                        print(traceback.print_exc(), data)

                    EXCH = data2['ExchangeSegment']
                    token = data2['ExchangeInstrumentID']
                    bid = data2['AskInfo']['Price']
                    bidQ = data2['BidInfo']['Size']
                    ask = data2['AskInfo']['Price']
                    askQ = data2['BidInfo']['Size']
                    LTP = data2['LastTradedPrice']
                    pc1 = '0.0'
                    pc = data2['PercentChange']
                    OPEN = data2['Open']
                    HIGH = data2['High']
                    LOW = data2['Low']
                    CLOSE = data2['Close']
                    Volume = data2['TotalValueTraded']

                    d1 = {"Exch": EXCH, "Token": int(token), "Bid": bid, "BQ": bidQ, "Ask": ask, "AQ": askQ,
                          "LTP": LTP, "%CH": pc, "OPEN": OPEN, "HIGH": HIGH, "LOW": LOW, "CLOSE": CLOSE, 'Volume': Volume}




                    try:
                        self.LiveFeed.sgNPFSub.emit(d1)
                    except:
                        pass
                        # print('error ,self.LiveFeed.sgNPFrec.emit', self)

        else:
            logging.error(req.text)

        ####################### database working passage deleted if required retrive from backup ##################
    except:
        logging.error(sys.exc_info()[1])
        print(traceback.print_exc())


def unSubscription_feed(self, token, seg, streamType=1501):
    try:
        if (seg == 'NSEFO'):
            segment = 2
        elif (seg == 'NSECM'):
            segment = 1
        ## ****** CD PENDING
        sub_url = self.URL + '/marketdata/instruments/subscription'
        payloadsub = {"instruments": [{"exchangeSegment": segment, "exchangeInstrumentID": token}],
                      "xtsMessageCode": streamType}
        payloadsubjson = json.dumps(payloadsub)
        req = requests.request("PUT", sub_url, data=payloadsubjson, headers=self.MDheaders)

        logging.info(req.text)
        # print(req.text)

        if ('subscribed successfully' in req.text or 'Already Subscribed' in req.text):
            pass

        else:
            logging.error(req.text)

        ####################### database working passage deleted if required retrive from backup ##################
    except:
        logging.error(sys.exc_info()[1])
        print(traceback.print_exc())

def login(self):
    try:

        self.login.pbLogin.setEnabled(False)
        self.login.label.append('Logging in to Marketdata API..')
        refresh(self)
        payload = {
            "secretKey": self.MDSecret,
            "appKey": self.MDKey,
            "source": self.Source
        }
        login_url = self.URL + '/marketdata/auth/login'
        print("login_url:", login_url)
        print("payload : ", payload)
        login_access = requests.post(login_url, json=payload)
        logging.info(login_access.text)
        print(login_access.text)


        if login_access.status_code == 200:
            data = login_access.json()
            result = data['result']
            if data['type'] == 'success':
                a = 'successfull'
                result = data['result']

                token = result['token']
                userID = result['userID']
                writeMD(token, userID)
                self.login.updateMDstatus(data['type'])
                self.login.label.append('MARKETDATA API Logged In.\nDownloadin contract masters...')
                # print('tgggdfgdfgdfg',self.login.cbCmaster.isChecked())
                self.fo_contract, self.eq_contract, self.cd_contract, self.contract_heads = getMaster(self,self.login.cbCmaster.isChecked())
                self.login.updateIAstatus(data['type'])
                shareContract(self)
                self.login.label.append('ContractMaster_fo downloaded.\nLogging in to Interactive API..')

            else:
                self.login.pbLogin.setEnable(True)

        else:
            self.login.pbLogin.setEnabled(True)
            logging.info(str(login_access.text).replace('\n', '\t\t\t\t'))
    except:
        logging.error(sys.exc_info()[1])
        print(traceback.print_exc())

def getQuote(self, token, seg, streamType):
    try:
        if (seg == 'NSEFO'):
            segment = 2
        elif (seg == 'NSECM'):
            segment = 1
        quote_url = self.URL + '/marketdata/instruments/quotes'
        payload_quote = {"instruments": [{"exchangeSegment": segment,"exchangeInstrumentID": token}],"xtsMessageCode": streamType,"publishFormat": "JSON"}
        quote_json = json.dumps(payload_quote)
        data = requests.request("POST", quote_url, data=quote_json, headers=self.MDheaders)
        # print('dataaaaaaaaaaa',token,data.text,)


        # if(token==26001):
        #     print(data.text)

        data1 = data.json()
        d = data1['result']['listQuotes'][0]
        data2 = json.loads(d)
        # print("data2222",data2)
        return data2

    except:
        print(sys.exc_info(),'get Quote error',data)
        data2 = {}
        return data2

def getOHLCData(self,token,segment,compression_val):
    print('Token : ',token)
    URL = 'http://192.168.102.9:3000'
    MDheaders = {
        "authorization": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySUQiOiJBMDA0NF82NmUzY2QyYzJhZjk1NWRjNGIxYjUyIiwicHVibGljS2V5IjoiNjZlM2NkMmMyYWY5NTVkYzRiMWI1MiIsImlhdCI6MTY4MzAwMDY1NSwiZXhwIjoxNjgzMDg3MDU1fQ.vWs8MW2eP55Iq5sqYFT6Wy6wnM-BETjCv4FeNrUv5QQ",
        'Content-Type': 'application/json'
    }

    startdate = datetime.datetime.today().strftime('%b %d %Y 091500')
    enddate = datetime.datetime.today().strftime('%b %d %Y 153000')
    date_format = '%b %d %Y %H%M%S'

    enddate = datetime.datetime.strptime(enddate, date_format)
    startdate = datetime.datetime.strptime(startdate, date_format)


    self.MDheaders, self.IAheaders, self.MDtoken, self.IAToken, self.URL, self.userID, self.Source, \
        self.MDKey, self.MDSecret, self.IAKey, self.IASecret, self.clist, self.DClient, self.broadcastMode = readConfig_All()
    # time.sleep(0.01)
    list1 = []
    while len(list1) < self.candleLength:
        print('strat-end', startdate, enddate)
    # st=time.time()
    # dt = datetime.combine(datetime.date.today(), time(hour, mins)) + datetime.timedelta(minutes=dura)
        url = '%s/marketdata/instruments/ohlc?exchangeSegment=%s&exchangeInstrumentID=%s&startTime=%s&endTime=%s&compressionValue=%s' %\
              (
            URL, segment,
            token, startdate.strftime('%b %d %Y %H%M%S'), enddate.strftime('%b %d %Y %H%M%S'), compression_val)
        # print(url)
        res = requests.get(url, headers=MDheaders)
        # print(res.json())
        # print( (res.json()['result']))
        data = (res.json()['result']['dataReponse'])
        data = data.split(',')        # et = time.time()
        # print('time', et - st)
        data.reverse()
        # print('data',data)
        if len(data)>1:
            list1 += data
            # print("list1:", list1)
        if(len(list1)<self.candleLength):
            enddate = enddate - datetime.timedelta(days=1)
            startdate = startdate - datetime.timedelta(days=1)


    close = []
    # build close array
    print(self.candleLength)
    list1 = list1[:self.candleLength]
    # print("list1:", list1)
    print("Length:", len(list1))
    return list1




