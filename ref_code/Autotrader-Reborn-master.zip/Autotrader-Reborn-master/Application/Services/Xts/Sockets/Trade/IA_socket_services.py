import json
import logging
import os

import numpy as np
import sys
import traceback
import datatable as dt
from PyQt5.QtWidgets import QMessageBox
from PyQt5.uic.properties import QtCore

from Application.Utils.getMasters import get_ins_details
import sqlite3


def update_on_position(self, data):
    try:
        data1 = json.loads(data)
        # print("update_on_position:", data1)
        exchange = data1['ExchangeSegment']
        token = int(data1['ExchangeInstrumentID'])
        ins_details = get_ins_details(self,exchange,token)

        if('ClientID' not in data1.keys()):
            data1['ClientID'] = data1['AccountID']



        rmtm = float((data1['RealizedMTM']).replace(',', ''))
        nv = float(data1['NetValue'].replace(',', ''))
        nv = rmtm if (nv == 0) else nv
        qty = int(data1['NetPosition'])
        amt = nv
        mtm = float((data1['MTM']).replace(',', ''))
        # print("data1")
        #print('l1')


        clientId = '*****' if ('PRO' in data1['ClientID']) else data1['ClientID']

        if (clientId not in self.openPosDict.keys()):
            self.openPosDict[clientId] = {}

        if (token not in self.openPosDict[clientId].keys()):
            self.openPosDict[clientId][token] = [0, 0.0]


        if('IsDayWiseNetWise' in data1.keys()):
            if(data1['IsDayWiseNetWise']=='NetWise'):
                openQty = self.openPosDict[clientId][token][0]
                openAmt = self.openPosDict[clientId][token][1]
                dayQty = qty - openQty
                dayAmount = amt - openAmt

                if (qty != 0):
                    avgp = amt / qty
                else:
                    avgp = 0.0

                pos = dt.Frame(
                    [[data1['LoginID']],
                    [clientId], [data1['ExchangeSegment']], [token],[ins_details[4]],[ins_details[3]],
                    [ins_details[6]],[ins_details[7]],[ins_details[8]],[qty], [mtm],
                    [0], [rmtm], [nv],[avgp],[ins_details [11]],
                    [ins_details[14]],[ins_details[9]],[1000],[openQty],[openAmt],
                    [dayQty],[dayAmount]]).to_numpy()

                self.sgAPIpos.emit(pos,data1['IsDayWiseNetWise'])

        else:
            openQty = self.openPosDict[clientId][token][0]
            openAmt = self.openPosDict[clientId][token][1]
            dayQty = qty - openQty
            dayAmount = amt - openAmt

            if (qty != 0):
                avgp = amt / qty
            else:
                avgp = 0.0

            pos = dt.Frame(
                [[data1['LoginID']],
                [clientId], [data1['ExchangeSegment']], [token],[ins_details[4]],[ins_details[3]],
                [ins_details[6]],[ins_details[7]],[ins_details[8]],[qty], [mtm],
                [0], [rmtm], [nv],[avgp],[ins_details [11]],
                [ins_details[14]],[ins_details[9]],[1000],[openQty],[openAmt],
                [dayQty],[dayAmount]]).to_numpy()

            self.sgAPIpos.emit(pos,'')

    except:
        print(sys.exc_info(), 'on_position')
        print(traceback.print_exc())


def update_on_order(self, data):
    try:
        data1 = json.loads(data)
        logging.info(data)
        exchange = data1['ExchangeSegment']
        token = int(data1['ExchangeInstrumentID'])
        ins_details = get_ins_details(self,exchange,token)

        orderSide = data1['OrderSide'].replace('BUY', 'Buy').replace('SELL', 'Sell')
        qty1 =data1['OrderQuantity'] if orderSide == "Buy" else  -data1['OrderQuantity']
        n2darray =dt.Frame( [[data1['AppOrderID']],
                            [data1['ClientID']],[data1['ExchangeInstrumentID']], [ins_details[4]],[ins_details[3]], [ins_details[6]],
                            [ins_details[7]],[ins_details[8]],[orderSide], [data1['OrderType']], [data1['OrderStatus']],
                            [data1['OrderQuantity']],[data1['LeavesQuantity']], [data1['OrderPrice']], [data1['OrderStopPrice']],[data1['OrderUniqueIdentifier']],
                            [data1['OrderGeneratedDateTime']],[data1['ExchangeTransactTime']],[data1['CancelRejectReason']], [ins_details[0]], [ins_details[5]],
                            [data1['OrderAverageTradedPrice']],[qty1],[data1['ProductType']],[data1['TimeInForce']],[self.userID]]).to_numpy()
        self.sgPendSoc.emit(n2darray, data1)



        if (data1['OrderStatus'] == 'Filled'):
            self.sgComplOrd.emit([int(data1['ExchangeInstrumentID']), data1['OrderSide'], data1['OrderQuantity'],
                                  float(data1['OrderAverageTradedPrice'].replace(',', '')), data1['AppOrderID'],
                                  data1['OrderUniqueIdentifier'], data1['OrderType']])


            # self.sgStatusUp.emit(data,'order')
        elif (data1['OrderStatus'] == 'Rejected'):
            self.sgStatusUp.emit(data,'Rejection')

            self.sgRejection.emit()

        else:

            self.sgStatusUp.emit(data,'order')


        # self.sgStatusUp.emit(data,'order')
    except:
        logging.error(sys.exc_info()[1])
        print(traceback.print_exc())


def update_on_trade(self, data):
    try:
        # print("UPDATE ON TRADE")
        data1 = json.loads(data)
        logging.info(data)
        # passing new trade to trade table#########################################################################

        exchange = data1['ExchangeSegment']
        token = int(data1['ExchangeInstrumentID'])
        ins_details =get_ins_details(self,exchange,token)

        orderSide = data1['OrderSide'].replace('BUY', 'Buy').replace('SELL', 'Sell')
        tradedQty = data1['LastTradedQuantity']
        qty = tradedQty if (orderSide == 'Buy') else -tradedQty
        netValue = -qty * data1['LastTradedPrice']
        #####################################################################################################################
        trades = dt.Frame([
            [data1['LoginID']],
            [data1['ClientID']], [data1['ExchangeInstrumentID']], [ins_details[4]], [ins_details[3]], [ins_details[6]],
            [ins_details[7]], [ins_details[8]], [orderSide], [data1['AppOrderID']], [data1['OrderType']],
            [tradedQty], [data1['OrderStatus']], [data1['OrderAverageTradedPrice']], [data1['ExchangeTransactTime']],[data1['OrderUniqueIdentifier']],
            [data1['ExchangeOrderID']], [data1['LastTradedPrice']], [qty], [netValue], [ins_details[0]],
            [ins_details[11]], [ins_details[14]], ['openValue']]).to_numpy()

        self.sgTrdSoc.emit(trades)
        self.sgStatusUp.emit(data,'Trade')


    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])


def saveTradestoDatabase(self,trade):
    loc=os.getcwd().split('Application')
    DBpath=os.path.join(loc[0],'Database','mainDB.db')
    conn = sqlite3.connect(DBpath)
    self.trdno+=1

    # conn.execute("INSERT INTO AllTrades (1, 'Paul', 32, 'California', 20000.00 )")

    # conn.execute("INSERT INTO AllTrades VALUES('{trade[0]}', '{trade[1]}', '{trade[2]}')")
    conn.execute("INSERT INTO AllTrades VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                 (trade[9],trade[0],trade[1],trade[2],trade[3],trade[4],
                  trade[5], trade[6], trade[7], trade[8],
                  trade[10],trade[11],trade[12],trade[13],trade[14],
                  trade[15],trade[16],trade[17],trade[18],trade[19],
                   trade[20],trade[21],trade[22],trade[23]))

    conn.commit()

    conn.close()

def saveOrder2Database(self,order):
    loc=os.getcwd().split('Application')
    DBpath=os.path.join(loc[0],'Database','mainDB.db')
    conn = sqlite3.connect(DBpath)
    self.Ordno+=1

    conn.execute("INSERT INTO AllOrder VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                 (order[0],order[25],order[1],order[2],order[3],order[4],
                  order[5], order[6], order[7], order[8], order[9],
                  order[10],order[11],order[12],order[13],order[14],
                  order[15],order[16],order[17],order[18],order[19],
                   order[20],order[21],order[22],order[23],order[24]))

    conn.commit()

    conn.close()













#####################################################################################################################################################
