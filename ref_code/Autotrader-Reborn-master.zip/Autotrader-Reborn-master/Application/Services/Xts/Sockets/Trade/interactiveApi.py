import time


import traceback
from PyQt5.QtCore import QObject,pyqtSlot,pyqtSignal,QTimer
import sys
import datatable as dt
import socketio
import os
import requests
import json
import logging
from threading import Thread
# import time
import pandas as pd
import datatable as dt

from Application.Utils.dbConnection import *
from Application.Utils.configReader import readConfig_All,readDefaultClient,writeITR,refresh
import numpy as np
from Application.Services.Xts.Sockets.Trade.IA_socket_services import  *

API_logger = logging.getLogger('API')

class Interactive(QObject):
    sgLoginS = pyqtSignal(str)
    sgSocketConn = pyqtSignal()
    sgSocConn = pyqtSignal(int)

    sgGetAPIpos = pyqtSignal(object)
    sgGetAPIposD = pyqtSignal(object)
    sgAPIpos = pyqtSignal(object,str)

    sgOpenPos = pyqtSignal(object)
    sgGetOrder = pyqtSignal(object)
    sgGetPOrder = pyqtSignal(object)
    sgPendSoc = pyqtSignal(object,object)
    sgRejection = pyqtSignal()
    sgAPQ =pyqtSignal(list)

    sgGetTrd =pyqtSignal(object)
    sgGTrdSoc =pyqtSignal(object)
    sgTrdSoc =pyqtSignal(object)

    sgAddScrp = pyqtSignal(int, int)
    sgComplOrd = pyqtSignal(list)
    sgClist = pyqtSignal(list)
    sgDClient = pyqtSignal(str)
    sgTrdC =pyqtSignal(list)
    sgBalance = pyqtSignal(list)
    sgRemainingDetail = pyqtSignal(list)
    sgStatusUp = pyqtSignal(str,str)
    sgLoggedinUser = pyqtSignal(str)



    def __init__(self):
        super(Interactive, self).__init__()
        self.ApiOrderSummary = np.empty(shape=[0,2],dtype='int')
        self.ApiOrderList = np.empty(shape=[0,3],dtype='int')
        self.openPosDict = {}
        self.trdno=0
        self.Ordno=0



    def start_socket_io(self):
        try:
            refresh(self)
            self.interactiveEmitters(self.IAToken,self.userID)
            Thread(target=self.connectIA).start()
        except:
            print(traceback.print_exc())
            API_logger.error(sys.exc_info()[1])
            logging.error(sys.exc_info()[1])

    def connectIA(self, headers={}, transports='websocket', namespaces=None, socketio_path='/interactive/socket.io',
                  verify=False):
        try:
            url = self.connection_url
            self.sid.connect(url, headers, transports, namespaces, socketio_path)
            self.sid.wait()
        except:
            print(traceback.print_exc())
            API_logger.error(sys.exc_info()[1])
            logging.error(sys.exc_info()[1])

    def interactiveEmitters(self, token, userID, reconnection=True, reconnection_attempts=0, reconnection_delay=1,
                            reconnection_delay_max=5, randomization_factor=0.5, logger=False, binary=False, json=None, **kwargs):
        try:
            refresh(self)
            self.sid = socketio.Client()
            self.eventlistener = self.sid
            self.sid.on('connect',self.on_connect)

            self.sid.on('message',self.on_message)
            self.sid.on('joined',self.on_joined)
            self.sid.on('position',self.on_position)
            self.sid.on('error',self.on_error)
            self.sid.on('trade',self.on_trade)
            self.sid.on('order',self.on_order)
            self.sid.on('logout',self.on_messagelogout)
            self.sid.on('disconnect',self.on_disconnect)

            self.userID = userID
            self.token = token
            port = f'{self.URL}/?token='
            self.connection_url = port + self.token + '&userID=' + self.userID + "&apiType=INTERACTIVE"
        except:
            logging.error(sys.exc_info()[1])
            API_logger.error(sys.exc_info()[1])
            print(traceback.print_exc())


    def on_trade(self,data):
        # print('on_trade')
        update_on_trade(self,data)
    def on_order(self,data):
        # print('on_order',data)
        update_on_order(self,data)
    def on_position(self,data):
        # print('on_pos:::',data)
        update_on_position(self,data)

    def get_emitter(self):
        return self.eventlistener

    def on_connect(self):

        logging.info('Interactive socket connected successfully!1111111')
        API_logger.info('Interactive socket connected successfully!1111111')
        self.sgSocketConn.emit()

    def on_disconnect(self):
        self.sgSocConn.emit(1)
        API_logger.info('Interactive Socket disconnected!')
        logging.info('Interactive Socket disconnected!')

    def on_message(self, data):

        API_logger.info('received a message! : ' + data)
        logging.info('received a message! : ' + data)
        self.sgStatusUp.emit(data,'msg')
    def on_joined(self, data):
        logging.info('%s' % data)
        API_logger.info('%s' % data)

    def on_error(self, data):
        logging.error('Interactive socket error!' + data)
        API_logger.error('Interactive socket error!' + data)

    def on_messagelogout(self, data):
        logging.info("User logged out!" + data)
        API_logger.info("User logged out!" + data)



###################################################  Concerns  ####################################################################
"""
auto Reconnect
client list
contract dict
connection status
path for config parser 
path for get log
use of pop ups
Q&A dailogs
if possible dont maintain table at both place


openPos and IntradayPos
all possible error scenarios for openPos calculation

minimize use of python list


where to use slot decorator
user id from config reader and login response telly




stress test json working with [ np array / ujson / orjson]
https://stackoverflow.com/questions/41068942/fastest-way-to-parse-json-strings-into-numpy-arrays


reworking folio pos from scratch no s off from folio pos cb cur index == 0
s off button inactive mean time 2 sec from s off executiom

review replace commas remove if not required


**********not all data comes in trades and order window


changed are made in except condition ins apply in get tarde and get order please check there 


regorous name changes
 
"""


##################################################################################################################################
