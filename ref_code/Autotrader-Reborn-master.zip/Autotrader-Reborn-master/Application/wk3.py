import os
import traceback

lisFinal = []



cwd = os.getcwd()

cwd= ('D:\Autotrader-Reborn\Resourses')

a=os.listdir(cwd)
print(a)


for i in a :
    if(os.path.isdir(os.path.join(cwd,i))):
        newPath  = os.path.join(cwd,i)
        print('newPath',newPath)
        newList = os.listdir(newPath)
        for ij in newList:

            newPath1 = os.path.join(newPath, ij)

            if(ij == '__pycache__'):
                pass
            elif (os.path.isdir(newPath1)):
                newList1 = os.listdir(newPath1)
                for ix in newList1:
                    newPath2 = os.path.join(newPath1, ix)

                    if (ix == '__pycache__'):

                        pass

                    elif (os.path.isdir(newPath2)):
                        newList2 = os.listdir(newPath2)
                        for iz in newList2:
                            print(iz)
                    else:

                        xx2 = newPath2.replace('D:\Autotrader-Reborn\\', '').replace(r'\\','/').replace('\\','/')
                        xx1 = xx2.replace('/'+ix, '')
                        po = (xx2,xx1)
                        lisFinal.append(po)
            else:
                xx2 = newPath1.replace('D:\Autotrader-Reborn\\', '').replace(r'\\', '/').replace('\\', '/')
                xx1 = xx2.replace('/' + ij, '')
                po = (xx2, xx1)
                lisFinal.append(po)
    else:
        path1= os.path.join(cwd,i)
        xx2 = path1.replace('D:\Autotrader-Reborn\\', '').replace(r'\\', '/').replace('\\', '/')
        xx1 = xx2.replace('/' + i, '')
        po = (xx2, xx1)
        lisFinal.append(po)

print(lisFinal)