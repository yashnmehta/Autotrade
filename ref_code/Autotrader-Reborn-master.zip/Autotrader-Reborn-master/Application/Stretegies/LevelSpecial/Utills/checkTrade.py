from datetime import datetime

from Application.Stretegies.LevelSpecial.Utills.keyParameters import saveJson
from Application.Stretegies.LevelSpecial.Utills.orderSupport import makeOrder


def checkTrade(self, priceFeed):
    priceToken = priceFeed['Token']
    if self.isStart:
        if self.isFirstOrderPunch:
            if self.cashToken == priceToken:
                self.cashPrice = priceFeed['LTP']
                if self.orderSide == 'Buy':
                    if self.changePoint < self.cashPrice and self.optionType == 'Put' and self.inModifyOrder == False:
                        self.inCheckTradeOrder = True
                        makeOrder(self, self.peToken, self.baseQty, self.revOrderSide)
                        makeOrder(self, self.ceToken, self.baseQty, self.orderSide)
                        self.optionType = 'Call'
                        if self.cagtch:
                            self.SlTimes -= 1
                            if self.SlTimes == 0:
                                self.changePoint += self.incrementSl
                                print('changePoint', self.changePoint, self.incrementSl)
                                self.sgParamModify.emit()
                        saveJson(self)
                        self.Slogger.info(f"Call {self.orderSide}")
                        self.inCheckTradeOrder = False

                    elif self.changePoint > self.cashPrice and self.optionType == 'Call' and self.inModifyOrder == False:
                        self.inCheckTradeOrder = True
                        makeOrder(self, self.ceToken, self.baseQty, self.revOrderSide)
                        makeOrder(self, self.peToken, self.baseQty, self.orderSide)
                        self.optionType = 'Put'
                        if self.cagtch == False:
                            self.SlTimes -= 1
                            if self.SlTimes == 0:
                                self.changePoint += self.incrementSl
                                print('changePoint', self.changePoint, self.incrementSl)
                                self.sgParamModify.emit()
                        saveJson(self)
                        self.Slogger.info(f"Put {self.orderSide}")
                        self.inCheckTradeOrder = False

                elif self.orderSide == 'Sell':
                    if self.changePoint < self.cashPrice and self.optionType == 'Call' and self.inModifyOrder == False:
                        self.inCheckTradeOrder = True
                        makeOrder(self, self.ceToken, self.baseQty, self.revOrderSide)
                        makeOrder(self, self.peToken, self.baseQty, self.orderSide)
                        self.optionType = 'Put'
                        if self.cagtch:
                            self.SlTimes -= 1
                            if self.SlTimes == 0:
                                self.changePoint += self.incrementSl
                                print('changePoint', self.changePoint, self.incrementSl)
                                self.sgParamModify.emit()
                        saveJson(self)
                        self.Slogger.info(f"Put {self.orderSide}")
                        self.inCheckTradeOrder = False

                    elif self.changePoint > self.cashPrice and self.optionType == 'Put' and self.inModifyOrder == False:
                        self.inCheckTradeOrder = True
                        makeOrder(self, self.peToken, self.baseQty, self.revOrderSide)
                        makeOrder(self, self.ceToken, self.baseQty, self.orderSide)
                        self.optionType = 'Call'
                        if self.cagtch == False:
                            self.SlTimes -= 1
                            if self.SlTimes == 0:
                                self.changePoint += self.incrementSl
                                print('changePoint',self.changePoint,self.incrementSl)
                                self.sgParamModify.emit()
                        saveJson(self)
                        self.Slogger.info(f"Call {self.orderSide}")
                        self.inCheckTradeOrder = False

            elif self.ceToken == priceToken:
                self.cePrice = priceFeed['LTP']

            elif self.peToken == priceToken:
                self.pePrice = priceFeed['LTP']
