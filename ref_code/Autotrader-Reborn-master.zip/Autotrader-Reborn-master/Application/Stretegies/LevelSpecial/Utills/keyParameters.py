import datetime
'''
To save key parameters to json file
'''
import json
import traceback
import numpy as np
from Application.Stretegies.LevelSpecial.Utills.executionSupport import checkIsAnyPosition, setParametersModify, \
    getCETable, getPETable


def saveJson(self,cf=False):
    getKeyParameterFile(self,self.folioName)
    createKeyParameterJson(self,cf)
    file = open(self.keyParameterFile, 'w')
    jInfo_new = json.dumps(self.keyParameterJson, indent=4)
    file.write(jInfo_new)
    file.close()

'''
create key parameters
'''
def createKeyParameterJson(self,cf):
    if (cf):
        open_pos =self.position[:self.lastSerialNo, :].tolist()
        DOI=self.DOI
    else:
        open_pos = []
        DOI = datetime.datetime.today().strftime('%d%m%Y')
    self.keyParameterJson = {


    'folioName' : self.folioName,
    'clientId':self.clientId,
    "stype": self.stype,
    'symbol':self.symbol,
    'expiry':self.expiry,
    'lotsize':self.lotsize,

    'isFirstOrderPunch': self.isFirstOrderPunch,
    'DateOfInitialization': DOI,
    "lastOrderSerialNo": self.lastOrderSerialNo,
    'open_position': open_pos,

    'baseToken':self.baseToken,
    'basePrice':self.basePrice,
    'cashToken':self.cashToken,
    'futToken':self.futToken,
    'cashPrice':self.cashPrice,
    'futPrice':self.futPrice,
    'strikeDiff':self.strikeDiff,
    'ATM':self.ATM,
    'ATMCEToken':self.ATMCEToken,
    'atmcePrice':self.atmcePrice,
    'atmpePrice':self.atmpePrice,
    'ceToken':self.ceToken,
    'peToken':self.peToken,
    'ceStrike':self.ceStrike,
    'peStrike':self.peStrike,
    'cePrice':self.cePrice,
    'pePrice':self.pePrice,
    'atmIdx':self.atmIdx,
    'ceIdx':self.ceIdx,
    'peIdx':self.peIdx,
    'baseQty':self.baseQty,
    'orderSide': self.orderSide,
    'revOrderSide': self.revOrderSide,
    'freezeQty':self.freezeQty,

    'isTrigger': self.isTrigger,
    'triggerPoint': self.triggerPoint,
    'changePoint': self.changePoint,
    "IncrementSl": self.incrementSl,
    'SlTimes': self.SlTimes,
    'SlAmount': self.SlAmount,
    'targetAmount': self.targetAmount,
    }
'''
fetch key parameters
'''
import os

def getKeyParameterFile(self,folioName):
    todate = datetime.datetime.today().strftime('%Y%m%d')
    loc = os.getcwd().split('Application')
    self.keyParameterFile = os.path.join(loc[0], 'Application', 'DB', 'Stretegy_data', todate,'%s.json' % folioName)
'''
reload key parameters from file
'''
def reloadKeyParameter(self):
    try:
        file = open(self.keyParameterFile)
        self.keyParameterJson = json.load(file)
        file.close()

        self.lastOrderSerialNo = self.keyParameterJson["lastOrderSerialNo"]
        self.isFirstOrderPunch = self.keyParameterJson['isFirstOrderPunch']
        self.folioName = self.keyParameterJson['folioName']
        self.clientId = self.keyParameterJson['clientId']
        self.stype = self.keyParameterJson['stype']
        self.symbol = self.keyParameterJson['symbol']
        self.expiry = self.keyParameterJson['expiry']

        self.ceTable = getCETable(self, self.symbol, self.expiry)
        self.peTable = getPETable(self, self.symbol, self.expiry)

        self.lotsize = self.keyParameterJson['lotsize']

        self.baseToken = self.keyParameterJson['baseToken']
        self.basePrice = self.keyParameterJson['basePrice']
        self.cashToken = self.keyParameterJson['cashToken']
        self.futToken = self.keyParameterJson['futToken']

        if (self.keyParameterJson['open_position'] != []):
            self.open_position = np.asarray(self.keyParameterJson['open_position'], dtype=object)
            updateOpenPos(self)

        self.cashPrice = self.keyParameterJson['cashPrice']
        self.futPrice = self.keyParameterJson['futPrice']
        self.strikeDiff = self.keyParameterJson['strikeDiff']
        self.ATM = self.keyParameterJson['ATM']
        self.ATMCEToken = self.keyParameterJson['ATMCEToken']
        self.atmcePrice = self.keyParameterJson['atmcePrice']
        self.atmpePrice = self.keyParameterJson['atmpePrice']
        self.ceToken = self.keyParameterJson['ceToken']
        self.peToken = self.keyParameterJson['peToken']
        self.ceStrike = self.keyParameterJson['ceStrike']
        self.peStrike = self.keyParameterJson['peStrike']
        self.cePrice = self.keyParameterJson['cePrice']
        self.pePrice = self.keyParameterJson['pePrice']
        self.atmIdx = self.keyParameterJson['atmIdx']
        self.ceIdx = self.keyParameterJson['ceIdx']
        self.peIdx = self.keyParameterJson['peIdx']
        self.freezeQty = self.keyParameterJson['freezeQty']

        self.baseQty = self.keyParameterJson['baseQty']

        self.orderSide = self.keyParameterJson['orderSide']
        self.revOrderSide = self.keyParameterJson['revOrderSide']

        self.incrementSl = self.keyParameterJson['IncrementSl']
        self.SlTimes = self.keyParameterJson['SlTimes']

        self.isTrigger = self.keyParameterJson['isTrigger']
        self.triggerPoint = self.keyParameterJson['triggerPoint']
        self.changePoint = self.keyParameterJson['changePoint']
        self.SlAmount = self.keyParameterJson['SlAmount']
        self.targetAmount = self.keyParameterJson['targetAmount']
        setParametersModify(self,self.modifyW)

    except:
        print(traceback.print_exc())

def updateOpenPos(self):
    for i in self.open_position:
        rowarray = np.where(self.position[:self.lastSerialNo, 1]== i[1])[0]
        if(rowarray.size!=0):

            rowNO=rowarray[0]

            filteredArray = self.position[np.where(self.position[:self.lastSerialNo, 1] == i[1])][0]

            openQty=i[5] + filteredArray[5]
            openamt=i[8] +filteredArray[8]

            editList=[5,8,11,12,13,14]
            self.position[rowNO, editList] = [openQty,openamt,openQty,openamt,0.0,0.0]

        else:
            self.position[self.lastSerialNo]=[i[0],i[1],i[2],i[3],i[4],i[5],i[6],i[7],i[8],i[9],i[10],i[5],i[8],0.0,0.0]
            self.lastSerialNo+=1

        checkIsAnyPosition(self)
        print("i[5]:", i[5], type(i[5]))
        if(i[5]>0):
            sellQ=i[5]
            buyQ=0
        else:
            sellQ = 0
            buyQ = i[5]
        data=[self.userID,self.clientId, self.stype,self.folioName,i[0],i[1],'stockname',i[2],self.expiry,i[3],i[4],i[5],0.0,
              i[5],i[8],0.0,buyQ,0.0,sellQ,0.0,0.0,0.0, self.lotsize,self.freezeQty,i[8],0,0.0]

        self.sgFolioOpenPos.emit(data)