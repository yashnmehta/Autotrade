import logging
import sys
import threading
import traceback
from Application.Services.Xts.Api.servicesMD import getQuote, subscribeToken
import numpy as np


def getBaseInfo(self,window):
    # print('getBaseInfo')
    window.symbol = window.cbSymbol.currentText()
    window.expiry = window.cbExp.currentText()
    window.cashToken = getCashToken(self,window.symbol)
    self.tokenList[0] =  window.cashToken
    subscribeToken(self,window.cashToken,'NSECM')
    window.cashFut = window.cbCF.currentText()

    window.futToken = getfutToken(self,window.symbol)
    self.tokenList[1] = window.futToken
    subscribeToken(self,window.futToken,'NSEFO')

    data = getQuote(self, window.cashToken, 'NSECM', 1501)
    window.cashPrice = data['LastTradedPrice']
    data = getQuote(self, window.futToken, 'NSEFO', 1501)
    window.futPrice = data['LastTradedPrice']

    if(window.cashFut == 'CASH'):
        window.baseToken = window.cashToken
        window.basePrice = window.cashPrice
    else:
        window.baseToken = window.futToken
        window.basePrice = window.futPrice

    window.strikeDiff = getStrikeDiff(self,window.futToken)
    window.lotsize = getLotSize(self,window.futToken)
    self.lotsize = window.lotsize
    window.ATM = getATM(self,window.basePrice, window.strikeDiff)

    window.ceTable = getCETable(self,window.symbol, window.expiry)
    window.peTable = getPETable(self,window.symbol, window.expiry)
    window.lb_ltp.setText(str(window.basePrice))
    window.lb_atm.setText(str(window.ATM))

    window.ATMCEToken = getATM_CE_Token(self,window.ATM, window.ceTable)
    window.ATMPEToken = getATM_PE_Token(self,window.ATM, window.peTable)
    subscribeToken(self,window.ATMCEToken,'NSEFO')
    subscribeToken(self,window.ATMPEToken,'NSEFO')

    self.tokenList[2] = window.ATMCEToken
    self.tokenList[3] = window.ATMPEToken


    data = getQuote(self, window.ATMCEToken, 'NSEFO', 1501)
    window.atmcePrice = data['LastTradedPrice']

    data1 = getQuote(self, window.ATMPEToken, 'NSEFO', 1501)
    window.atmpePrice = data1['LastTradedPrice']

    window.lbATMCE.setText('%.2f' % window.atmcePrice)
    window.lbATMPE.setText('%.2f' % window.atmpePrice)

    window.atmIdx = window.cbStrike_CE.findText('ATM')
    window.cbStrike_CE.setCurrentText('ATM')
    window.cbStrike_PE.setCurrentText('ATM')

    window.ceStrike = window.ATM
    window.peStrike = window.ATM

    window.ceToken = window.ATMCEToken
    window.peToken = window.ATMPEToken

    self.tokenList[4] = window.ceToken
    self.tokenList[5] = window.peToken

    window.lbcePrice.setText('%.2f' % window.atmcePrice)
    window.lbpePrice.setText('%.2f' % window.atmpePrice)

    window.isParachange = False


def symchange(self,window):
    try:
        # print('symchange')
        symbol = window.cbSymbol.currentText()
        fltr = np.asarray([symbol])
        filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
        uniqueExp = np.unique(filteredarray[:, 6])
        window.cbExp.clear()
        window.cbExp.addItems(uniqueExp)
        self.getBaseInfo(window)
        window.isParachange = True
    except:
        print(traceback.print_exc())

def baseChange(self,window):
    window.cashFut = window.cbCF.currentText()
    window.isParachange = True

def expchange(self,window):
    try:
        window.expiry = window.cbExp.currentText()
        window.isParachange = True
    except:
        print(traceback.print_exc())

def changesrtike(self,window):
    try:
        a = window.cbStrikePrice.currentText()
        if ('FUT' in window.cbInstrumentType.currentText()):
            window.cbOptType.clear()
            window.cbOptType.addItem(' ')

        elif ('OPT' in window.cbInstrumentType.currentText()):
            if (window.cbOptType.currentText() not in ['CE', 'PE']):
                window.cbOptType.clear()
                window.cbOptType.addItems(['CE', 'PE'])
            else:
                pass

    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])


def updateATMCEToken(self,window):

    window.ceStrike = window.ATM + (window.strikeDiff * (window.cbStrike_CE.currentIndex() - window.atmIdx))
    window.ceToken = getATM_CE_Token(window,window.ceStrike,window.ceTable)
    self.tokenList[4] =window.ceToken
    data1 = getQuote(self, window.ceToken, 'NSEFO', 1501)
    window.cePrice = data1['LastTradedPrice']
    window.lbcePrice.setText('%.2f'%window.cePrice)
    subscribeToken(self, window.ceToken, 'NSECM')
    # recalculateATMQtyONSC(self,window)


def updateATMPEToken(self,window):
    window.peStrike = window.ATM - (window.strikeDiff * (window.cbStrike_PE.currentIndex() - window.atmIdx))
    window.peToken = getATM_PE_Token(window,window.peStrike,window.peTable)
    self.tokenList[5] =window.peToken
    data1 = getQuote(self, window.peToken, 'NSEFO', 1501)
    window.pePrice = data1['LastTradedPrice']
    window.lbpePrice.setText('%.2f'%window.pePrice)
    subscribeToken(self, window.peToken, 'NSECM')

def updateSl1Amt(self,window):
    try:
        window.pairPrice = window.cePrice + window.pePrice
        window.Sl1pr = float(window.leSl1pr.text())
        window.Sl1Amt = window.pairPrice * window.Sl1pr/100
        window.lbSl1Amt.setText(str('%.2f'%window.Sl1Amt))
    except:
        print(traceback.print_exc())

def updateSl2Amt(self, window):
    try:
        window.pairPrice = window.cePrice + window.pePrice
        window.Sl2pr = float(window.leSl2pr.text())
        window.Sl2Amt = window.pairPrice * window.Sl2pr / 100
        window.lbSl2Amt.setText(str('%.2f' % window.Sl2Amt))
    except:
        print(traceback.print_exc())


def updateModifyInfo(self,window):
    print('updateModifyInfo')
    window.leFolioName.setText(self.folioName)
    window.cbClient.setCurrentText(self.clientId)
    window.cbSymbol.addItem(self.symbol)
    window.cbSymbol.setCurrentText(self.symbol)
    window.cbCF.setCurrentText(self.Base)
    window.cbExp.addItem(self.expiry)
    window.cbExp.setCurrentText(self.expiry)

    window.ceTable = self.ceTable
    window.peTable = self.peTable

    window.strikeDiff = self.strikeDiff
    window.lotsize = self.lotsize

    window.ATM = self.ATM

    window.symbol = self.symbol
    window.expiry = self.expiry
    window.cashFut = self.Base

    window.cashToken = self.cashToken
    window.futToken = self.futToken

    window.baseToken = self.baseToken
    window.cashPrice =self.cashPrice
    window.futPrice =self.futPrice
    window.basePrice =self.basePrice

    window.atmIdx = self.atmIdx

    window.cbSymbol.setCurrentText(self.symbol)
    window.cbCF.setCurrentText(self.Base)

    window.cbExp.addItem(self.expiry)
    window.leFolioName.setText(self.folioName)
    window.cbClient.addItem(self.clientId)
    window.lb_ltp.setText(str(self.basePrice))

    window.lb_atm.setText(str(self.ATM))

    window.lbATMCE.setText(str(self.atmcePrice))
    window.lbATMPE.setText(str(self.atmpePrice))

    window.cbStrike_CE.setCurrentIndex(self.ceIdx)
    window.cbStrike_PE.setCurrentIndex(self.peIdx)

    window.lbcePrice.setText(str(self.cePrice))
    window.lbpePrice.setText(str(self.pePrice))

    window.leQty.setText(str(self.baseQty))
    window.cbOrderSide.setCurrentText(self.orderSide)

    window.leChangePoint.setText(str(self.changePoint))

def getCETable(self,symbol,exp):

    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    fltr1 = np.asarray([exp])
    filteredarray2 = filteredarray[np.in1d(filteredarray[:, 6], fltr1)]

    filteredarray1 = filteredarray2[filteredarray2[:, 12].argsort()]
    fltr2 = np.asarray(['CE'])
    ceTable= filteredarray1[np.in1d(filteredarray1[:, 8], fltr2)]

    return ceTable

def getPETable(self,symbol,exp):
    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    fltr1 = np.asarray([exp])
    filteredarray2 = filteredarray[np.in1d(filteredarray[:, 6], fltr1)]
    filteredarray1 = filteredarray2[filteredarray2[:, 12].argsort()][::-1]
    fltr2 = np.asarray(['PE'])
    peTable= filteredarray1[np.in1d(filteredarray1[:, 8], fltr2)]
    return peTable

def getATM_CE_Token(self,atm,ceTable):
    ATM_CE_Token = ceTable[np.where(ceTable[:,12]==atm),2][0][0]
    return ATM_CE_Token

def getATM_PE_Token(self,atm,peTable):
    ATM_PE_Token = peTable[np.where(peTable[:,12]==atm),2][0][0]
    return ATM_PE_Token

def dec_v(self,window):
    if (window.leQty.text() != '0'):
        newQ = int(window.leQty.text()) - window.lotsize
        window.leQty.setText(str(newQ))

def inc_v(self,window):
    newQ = int(window.leQty.text()) + window.lotsize
    window.leQty.setText(str(newQ))

def getfutToken(self,symbol=''):
    futToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 17]
    return futToken


def getCashToken(self,symbol=''):
    assetToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 9]
    return assetToken

def checkIsAnyPosition(self):
    isAnyOpenPos = False
    for i in self.position[:self.lastSerialNo,5]:
        if(i != 0):
            isAnyOpenPos = True
            self.isAnyOpenPos = isAnyOpenPos
            return
    self.isAnyOpenPos = isAnyOpenPos

def updateValues(self):
    try:
        if(self.isFirstOrderPunch):
            window = self.modifyW

        elif(self.isParameterSet):
            window = self.modifyW

        else:
            window= self.addW

        window.lb_ltp.setText(str(window.cashPrice))
        window.lb_atm.setText(str(window.ATM))

        window.lbATMCE.setText('%.2f' % window.atmcePrice)
        window.lbATMPE.setText('%.2f' % window.atmpePrice)

        window.lbcePrice.setText('%.2f' % window.atmcePrice)
        window.lbpePrice.setText('%.2f' % window.atmpePrice)


    except:
        print(traceback.print_exc())

def getLotSize(self,futToken):
    lotsize = self.fo_contract[futToken-35000,11]
    return lotsize

def getCEpePrice(self):
    try:
        if (self.isFirstOrderPunch):
            window = self.modifyW
            a='modify'
        elif (self.isParameterSet):
            window = self.modifyW
            a='modify'

        else:
            window = self.addW
            a='add'

        if (window.visibleRegion().isEmpty() == False):
            window.cashPrice = getPrice(self=self, token=window.cashToken, seg='NSECM', streamType=1501)['ltp']
            window.futPrice = getPrice(self=self, token=window.futToken, seg='NSEFO', streamType=1501)['ltp']
            window.ATM = getATM(self, window.cashPrice, window.strikeDiff)

            data = getQuote(self,window.ATM_CE_Token, 'NSEFO', 1501)
            window.atmcePrice = data['LastTradedPrice']

            data1 = getQuote(self, window.ATM_PE_Token, 'NSEFO', 1501)
            window.atmpePrice = data1['LastTradedPrice']
    except:
        print(traceback.print_exc())

def getStrikeDiff(self,futToken):
    strikeDiff = self.fo_contract[futToken-35000,36]
    return strikeDiff

def getATM(self,cashPrice,strikeDiff):
    ATM1 = (cashPrice / strikeDiff)
    frac = ATM1 % 1
    strikeDecisionPoint = 0.5 #float(self.addW.leLowerPoint.text())
    if(frac > strikeDecisionPoint):
        ATM = int(ATM1+1) * strikeDiff
    else:
        ATM= int(ATM1)  * strikeDiff
    return ATM

def getPrice(self, token, seg, streamType):
    data = getQuote(self, token, seg, streamType)
    ltp = data['LastTradedPrice']
    try:
        bid = data['AskInfo']['Price']
        ask = data['BidInfo']['Price']
    except:
        bid = 0.00
        ask = 0.00
    return {"bid": bid, "ask": ask, "ltp": ltp}

def getPrices(self):
    try:
        th = threading.Thread(target=getCEpePrice,args=(self,))
        th.start()
    except:
        print(traceback.print_exc())

def setParametersModify(self,window):
    try:
        window.folioName = self.folioName
        window.clientId = self.clientId
        window.cbSymbol.addItem(self.symbol)
        window.symbol = self.symbol
        window.expiry = self.expiry
#
        window.cashToken = self.cashToken
        window.futToken = self.futToken
        window.strikeDiff = self.strikeDiff
        window.freezeQty = self.freezeQty

        window.cePrice= self.cePrice
        window.pePrice= self.pePrice

        window.targetAmt = self.TargetAmt
        window.ceTable = getCETable(self, self.symbol, self.expiry)
        window.peTable = getPETable(self, self.symbol, self.expiry)
        window.cashPrice = getPrice(self, token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
        window.futPrice = getPrice(self, token=self.futToken, seg='NSEFO', streamType=1501)['ltp']
        window.ATM = getATM(self, self.cashPrice, self.strikeDiff)
        window.atmIdx = self.atmIdx

        window.cbExp.addItem(self.expiry)
        window.leFolioName.setText(self.folioName)
        window.cbClient.addItem(self.clientId)
        window.lb_ltp.setText(str(self.basePrice))

        window.lb_atm.setText(str(self.ATM))

        window.lbATMCE.setText(str(self.atmcePrice))
        window.lbATMPE.setText(str(self.atmpePrice))

        window.cbStrike_CE.setCurrentIndex(self.ceIdx)
        window.cbStrike_PE.setCurrentIndex(self.peIdx)

        window.lbcePrice.setText(str(self.cePrice))
        window.lbpePrice.setText(str(self.pePrice))

        window.leQty.setText(str(self.baseQty))
        window.cbOrderSide.setCurrentText(self.orderSide)

        window.leIncrementSl.setText(str(self.incrementSl))
        window.leSlTimes.setText(str(self.SlTimes))

        window.leTriggerPoint.setText(str(self.triggerPoint))
        if self.isTrigger:
            window.leTriggerPoint.setEnabled(True)
            window.cbIsTrigger.setChecked(True)
        window.leChangePoint.setText(str(self.changePoint ))

        window.leSLAmount.setText(str(self.SlAmount))
        window.leTargetAmount.setText(str(self.targetAmount))

    except:
        print(traceback.print_exc())





