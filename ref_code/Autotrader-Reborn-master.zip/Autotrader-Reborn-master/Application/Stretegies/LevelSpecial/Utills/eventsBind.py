'''
bind events
'''

from Application.Stretegies.LevelSpecial.Utills.executionSupport import baseChange, symchange, expchange, \
    updateATMCEToken, updateATMPEToken, updateModifyInfo


def eventsBind(self):

    self.sgParamModify.connect(lambda: updateModifyInfo(self,self.modifyW))

    self.addW.pbApply.clicked.connect(self.setParameters)
    # self.addW.cbSymbol.currentIndexChanged.connect(lambda: self.addW.getOptionExpiryList(self.fo_contract))
    self.addW.cbSymbol.currentTextChanged.connect(lambda: symchange(self, self.addW))
    self.addW.cbCF.currentIndexChanged.connect(lambda: baseChange(self, self.addW))
    self.addW.cbExp.currentTextChanged.connect(lambda:expchange(self,self.addW))
    self.addW.pbGet.clicked.connect(lambda : self.getBaseInfo(self.addW))

    self.addW.cbStrike_CE.currentIndexChanged.connect(lambda: updateATMCEToken(self, self.addW))
    self.addW.cbStrike_PE.currentIndexChanged.connect(lambda: updateATMPEToken(self, self.addW))
    self.addW.cbIsTrigger.stateChanged.connect(self.toggleLineEdit)

    self.modifyW.cbStrike_CE.currentIndexChanged.connect(lambda: updateATMCEToken(self, self.modifyW))
    self.modifyW.cbStrike_PE.currentIndexChanged.connect(lambda: updateATMPEToken(self, self.modifyW))
    self.modifyW.pbApply.clicked.connect(lambda : self.modifyParameter(self.modifyW))
