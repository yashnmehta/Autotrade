import time as ttime
import traceback

import numpy as np

from Application.Services.Xts.Api.servicesIA import PlaceOrder
from Application.Stretegies.LevelSpecial.Utills.executionSupport import setParametersModify
from Application.Stretegies.LevelSpecial.Utills.keyParameters import saveJson
from Application.Utils.log import insertLogRow


def makeOrder(self,token,qty,orderSide = 'Sell', orderType  = 'MARKET', limitPrice = 0.0, triggerPrice = 0 ):
    try:
        tQty =qty
        appOrderIdList = []
        while qty > self.freezeQty:
            appOrderId = PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=token, orderSide=orderSide,
                       qty=self.freezeQty,
                       limitPrice=limitPrice,
                       validity='DAY', disQty=0, triggerPrice=triggerPrice, uid=self.folioName, orderType=orderType,
                       productType='NRML')

            # need to add in OMS
            appOrderIdList.append(appOrderId)
            ttime.sleep(0.1)
            qty -= self.freezeQty
        appOrderId = PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=token, orderSide=orderSide,
                   qty=qty,
                   limitPrice=limitPrice,
                   validity='DAY', disQty=0, triggerPrice=triggerPrice, uid=self.folioName, orderType=orderType,
                   productType='NRML')
        # need to add in OMS
        appOrderIdList.append(appOrderId)
        insertLogRow(self, tQty, token, orderSide)
        ttime.sleep(0.1)
        return appOrderIdList
    except:
        print(traceback.print_exc())

def makeFirstOrder(self):
    print('makeFirstOrder')
    try:
        if self.isFirstOrderPunch == False:
            self.cashPrice = self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
            if self.isTrigger:
                if self.cashPrice < self.triggerPoint:
                    self.cashlttr = True
                else:
                    self.cashlttr = False
                self.timerTriggerFirstOrder.start()

            else:
                placeFirstOrder(self)
        else:
            if self.position[np.where(self.position[:, 5] != 0), 4] == 'PE':
                self.optionType = 'Put'
            else:
                self.optionType = 'Call'
            self.isStart = True

    except:
        print(traceback.print_exc())

def triggerFirstOrder(self):
    self.cashPrice = self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
    if self.cashlttr:
        if self.cashPrice > self.triggerPoint:
            placeFirstOrder(self)
    else:
        if self.cashPrice < self.triggerPoint:
            placeFirstOrder(self)

def placeFirstOrder(self):
    if self.orderSide == 'Buy':
        if self.cashPrice > self.changePoint:
            # Call Buy
            self.timerTriggerFirstOrder.stop()
            makeOrder(self, self.ceToken, self.baseQty, self.orderSide)
            self.optionType = 'Call'
            saveJson(self)
            self.cagtch = True
        elif self.cashPrice < self.changePoint:
            # Put Buy
            self.timerTriggerFirstOrder.stop()
            makeOrder(self, self.peToken, self.baseQty, self.orderSide)
            self.optionType = 'Put'
            self.cagtch = False
    elif self.orderSide == 'Sell':
        if self.cashPrice > self.changePoint:
            # put sell
            self.timerTriggerFirstOrder.stop()
            makeOrder(self, self.peToken, self.baseQty, self.orderSide)
            self.optionType = 'Put'
            saveJson(self)
            self.cagtch = True
        elif self.cashPrice < self.changePoint:
            # call sell
            self.timerTriggerFirstOrder.stop()
            makeOrder(self, self.ceToken, self.baseQty, self.orderSide)
            self.optionType = 'Call'
            self.cagtch = False
    self.isFirstOrderPunch = True
    self.isStart = True
    saveJson(self)





