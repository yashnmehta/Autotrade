from PyQt5.QtCore import QTimer
from Application.Stretegies.LevelSpecial.Utills.executionSupport import updateValues,getPrices
#
# '''
# configure timers
# '''
from Application.Stretegies.LevelSpecial.Utills.orderSupport import makeFirstOrder, triggerFirstOrder


def createTimer(self):
    self.timerUpdateWindows = QTimer()
    self.timerUpdateWindows.setInterval(500)
    self.timerUpdateWindows.timeout.connect(lambda : updateValues(self))
    self.timerUpdateWindows.timeout.connect(self.modifyW.updateValues)

    self.timerGetPrices = QTimer()
    self.timerGetPrices.setInterval(500)
    self.timerGetPrices.timeout.connect(lambda : getPrices(self))
    self.timerUpdateWindows.timeout.connect(self.addW.getNewPriceData)

    # self.timerExecution = QTimer()
    # self.timerExecution.setInterval(1000)
    # self.timerExecution.timeout.connect(lambda:makeFirstOrder(self))
    # self.timerExecution.setSingleShot(True)

    self.timerTriggerFirstOrder = QTimer()
    self.timerTriggerFirstOrder.setInterval(1000)
    self.timerTriggerFirstOrder.timeout.connect(lambda: triggerFirstOrder(self))