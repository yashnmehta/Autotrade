import logging
import sys
import traceback
from os import path, getcwd
import threading
import time
import requests
import json
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import uic
import qdarkstyle
import qtpy
from Application.Utils.configReader import *
from Application.Views.titlebar import tBar
from Theme.dt2 import  dt1
import numpy as np
from Application.Services.Xts.Api.servicesMD import getQuote
import platform
class addW(QMainWindow):
    def __init__(self, parent=None):
        super(addW, self).__init__(parent=None)
        self.setObjectName('addParameter')
        #####################################################################
        loc1 = getcwd().split('Application')
        ui_login = os.path.join(loc1[0] ,'Application','Stretegies','Momentum','UI','inputParameter.ui')
        uic.loadUi(ui_login, self)
        dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()
        self.setStyleSheet(dt1)
        osType = platform.system()

        if (osType == 'Darwin'):
            flags = Qt.WindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        else:
            flags = Qt.WindowFlags(Qt.SubWindow | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setWindowFlags(flags)
        self.pbCancel.clicked.connect(self.hide)
        self.title = tBar('ADD PARAMETER')
        # self.title.setStyleSheet(self.headerFrame.styleSheet())
        self.headerFrame.layout().addWidget(self.title, 0, 0)
        self.title.sgPoss.connect(self.movWin)
        dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()
        # QSizeGrip(self.gripFolio)
        # self.movWin()
        self.createShortcuts()
        self.connectAllSlots()
        QSizeGrip(self.irGrip)


    def movWin(self, x, y):
        self.move(self.pos().x() + x, self.pos().y() + y)

    def connectAllSlots(self):
        self.bt_close.clicked.connect(self.hide)
        self.bt_min.clicked.connect(self.hide)

    def createShortcuts(self):
        self.quitSc = QShortcut(QKeySequence('Esc'), self)
        self.quitSc.activated.connect(self.hide)


    def getSymbolList(self,fo_contract):
        fo_contract1 = fo_contract[np.where(fo_contract[:, 1] != 'x')]
        uniqueSymbols = np.unique(fo_contract1[:,3])
        self.cbSymbol.addItems(uniqueSymbols)


    def getOptionExpiryList(self,fo_contract):
        symbol = self.cbSymbol.currentText()
        fltr = np.asarray([symbol])
        filteredarray = fo_contract[np.in1d(fo_contract[:, 3], fltr)]
        uniqueExp = np.unique(filteredarray[:,6])
        self.cbExp.addItems(uniqueExp)



    def getPairTotal(self):
        atmCeTOken = 0
        atmPeTOken = 0
        atmCePrice = 0
        atmPePrice = 0
        pairTotal = atmCePrice + atmPePrice
        return pairTotal

    # def createTimer(self):

    def getPrice(self,token,seg,streamType):

        data = getQuote(self,token,seg,streamType)
        bid = data['AskInfo']['Price']
        ask = data['BidInfo']['Price']
        ltp = data['LastTradedPrice']

        return {"bid":bid,"ask":ask ,"ltp":ltp}

    def getNewPriceData(self):

        self.cashPrice=self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
        self.futurePrice=self.getPrice(token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
        self.ATM = self.getATM(self.cashPrice,self.strikeDiff)


    def getATM(self,cashPrice,strikeDiff):
        ATM1 = (cashPrice / strikeDiff)
        frac = ATM1 % 1

        strikeDecisionPoint = float(self.leLowerPoint.text())
        # print(frac)
        if(frac > strikeDecisionPoint):
            ATM = int(ATM1+1) * strikeDiff
        else:
            ATM= int(ATM1)  * strikeDiff
        # ATM1 = (cashPrice / strikeDiff) * strikeDiff
        return ATM



if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = addW()
    form.show()
    sys.exit(app.exec_())