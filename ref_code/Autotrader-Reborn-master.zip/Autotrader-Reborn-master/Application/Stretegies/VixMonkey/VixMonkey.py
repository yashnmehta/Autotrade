import os
import threading
import traceback

import json
from PyQt5.QtGui import *
from PyQt5.QtCore import QObject,QTimer,pyqtSignal,Qt
from PyQt5.QtWidgets import QMessageBox,QShortcut

from Application.Stretegies.VixMonkey.Utills.executionSupport import getBaseInfo
from Application.Stretegies.VixMonkey.Views.addW import addW
from Application.Stretegies.VixMonkey.Views.modifyW import modifyW
import numpy as np
import datatable as dt
from Application.Services.Xts.Api.servicesIA import PlaceOrder
import datetime
import time
from Application.Services.Xts.Api.servicesMD import getQuote
from Application.Utils.configReader import refresh

from Application.Stretegies.VixMonkey.Utills.executionSupport import *
from Application.Stretegies.VixMonkey.Utills.keyParameters import *
from Application.Stretegies.VixMonkey.Utills.uiSupport import *
from Application.Stretegies.VixMonkey.Utills.square import *
from Application.Stretegies.VixMonkey.Utills.orderSupport import *


class logic(QObject):
    sgMTM = pyqtSignal(str,float)
    sgAlert = pyqtSignal(str)
    sgParamSet = pyqtSignal()
    sgParamModified = pyqtSignal()
    sgStart = pyqtSignal()
    sgSL = pyqtSignal(str,float)
    sgTSL = pyqtSignal(str,float)
    sgTarget = pyqtSignal(str,float)

    sgActivate =pyqtSignal()
    sgStop = pyqtSignal()
    sgClose =pyqtSignal()
    sgFolioOpenPos = pyqtSignal(list)
    ################################# Intialization Here ##################################################
    def __init__(self):
        super(logic, self).__init__()

        self.position = np.zeros((100, 15), dtype=object)
        # print('positionnnn',self.position)
        self.posHeads = ['exch',
                         'token', 'symbol', 'strike', 'c/p', 'netqty',
                         'requestedOrder', 'openOrder', 'netamt', 'ltp', 'mtm',
                         'OpenQty', 'OpenAmt', 'DQty', 'Damt']

        self.addW = addW(self)
        self.modifyW = modifyW(self)
        self.setAllShortCut()

        self.initVaribles()


    def initVaribles(self):
        self.stype = 'Vix_Monkey'
        self.vixToken = 26002

        self.isStart = False
        self.isClose = False
        self.isFirstOrderPunch = False
        self.isParameterSet = False
        self.isSlHitOnce = False
        self.fullPos = False

        self.mtm = 0
        self.SlAmount = 0.0
        self.targetAmt = 0.0
        self.tsl = 0.0
        self.lastSerialNo = 0
        self.isAnyOpenPos = False
        self.lotsize = 0
        self.DOI = datetime.today().strftime('%d%m%Y')



        self.tokenList = [0,0,0,0,0,0,0,0,0,0,0]
        """        # tokenlist  
                                0 cashToken  
                                1 futureToken
                                2 VixToken
                                3 Actual ATM CE
                                4 Actual ATM PE
                                5 OTM CE Token
                                6 OTM PE Token
                                7 ATM CE Token
                                8 ATM PE Token                                
                                9 hedge Token CE
                                10 hedge Token PE
                                
                            
        """


    def createObject(self, fo_contract):

        try:

            self.fo_contract = fo_contract

            refresh(self)
            refresh(self.addW)
            refresh(self.modifyW)

            fltr = np.asarray(['OPTSTK','OPTIDX'])
            self.addW.t = self.fo_contract[np.in1d(self.fo_contract[:, 5], fltr)]
            self.modifyW.t = self.fo_contract[np.in1d(self.fo_contract[:, 5], fltr)]
            lsSymbol = np.unique(self.addW.t[:, 3])
            self.addW.cbSymbol.addItems(lsSymbol)
            self.addW.cbSymbol.setCurrentText('BANKNIFTY')
            self.modifyW.cbSymbol.addItems(lsSymbol)
            self.modifyW.cbSymbol.setCurrentText('BANKNIFTY')

            symchange(self,self.addW)
            symchange(self,self.modifyW)
            expchange(self,self.addW)
            expchange(self,self.modifyW)
            getOptionExpiryList(self,self.addW)
            getOptionExpiryList(self,self.modifyW)

            self.createTimer()
        except:
            print(traceback.print_exc())

    def connect2slots(self):
        self.addW.cbCF.currentIndexChanged.connect(lambda: baseChange(self, self.addW))
        self.addW.cbSymbol.currentTextChanged.connect(lambda: symchange(self, self.addW))
        self.addW.cbExp.currentTextChanged.connect(lambda:expchange(self,self.addW))
        self.addW.pbGetInfo.clicked.connect(lambda :getBaseInfo(self,self.addW))
        self.addW.cbTrend.currentIndexChanged.connect(lambda:trendChanged(self,self.addW))

        self.addW.cbStrikeATMCE.currentIndexChanged.connect(lambda: updateATMCEToken(self, self.addW))
        self.addW.cbStrikeATMPE.currentIndexChanged.connect(lambda: updateATMPEToken(self, self.addW))
        self.addW.cbStrikeOTMCE.currentIndexChanged.connect(lambda: updateOTMCEToken(self, self.addW))
        self.addW.cbStrikeOTMPE.currentIndexChanged.connect(lambda: updateOTMPEToken(self, self.addW))

        self.addW.pbGetPrices.clicked.connect(lambda :updateAllToken(self,self.addW))

        # self.addW.cbOptType.currentIndexChanged.connect(lambda:recalOTMStrike(self))
        self.addW.leQty_O.textChanged.connect(lambda :recalculateATMQty(self,self.addW))
        self.addW.pbApply.clicked.connect(lambda:self.setParameters(self.addW))
        # print('done')
        self.addW.pbVixCh.clicked.connect(lambda: self.changeBaseVix(self.addW))
        self.modifyW.pbVixCh.clicked.connect(lambda: self.changeBaseVix(self.modifyW))


        self.modifyW.pbAdjApply.clicked.connect(lambda: self.changeAdjPts(self.modifyW))
        self.addW.pbAdjApply.clicked.connect(lambda: self.changeAdjPts(self.addW))
        self.modifyW.pbApply.clicked.connect(lambda:self.setParametersModify(self.modifyW))

    def setParameters(self,window):
        try:

            print('set paramete', window)
            self.ATMqty = int(window.leQty_A.text())
            self.OTMqty = int(window.leQty_O.text())

            if(self.OTMqty <= 0  and self.ATMqty <= 0):
                self.messageBox = QMessageBox()
                self.messageBox.setIcon(QMessageBox.Critical)
                self.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
                self.messageBox.setText('Quantity must be greater than zero!!')
                self.messageBox.show()
            else:
                self.symbol = window.cbSymbol.currentText()
                self.Base = window.cbCF.currentText()
                self.BaseVIX = float(window.lbBaseVix.text())
                # self.BaseVIX = float(window.leVIX.text())

                self.BaseToken = window.BaseToken
                self.folioName = window.leFolioName.text()
                self.adjPts = float(window.leAdjPts.text())

                self.cashToken = getCashToken(self,self.symbol)
                self.futureToken = getFutureToken(self,self.symbol)
                self.vixToken = 26002

                self.vix = float(window.lbBaseVix.text())

                self.clientId = window.cbClient.currentText()
                getKeyParameterFile(self,self.folioName)
                self.expiry = window.cbExp.currentText()
                self.trendPts = float(window.leTrendPts.text())
                # print("Trend Ptsuuuuuus",self.trendPts)


                self.revPts = float(window.leRevPts.text())
                isTradeOnReversal = window.cbRevTrade.currentIndex()
                self.isTradeOnReversal =  True if isTradeOnReversal==0 else False
                self.Trend = window.cbTrend.currentText()

                self.cashPrice = window.cashPrice
                self.futurePrice = window.futurePrice
                self.basePrice = window.basePrice
                self.ATM = window.ATM

                self.strikeDiff = getStrikeDiff(self,self.futureToken)
                self.freezeQty = int(self.fo_contract[self.futureToken-35000,14])
                self.lotsize = int(self.fo_contract[self.futureToken-35000,11])

                self.ceTable = getCETable(self, self.symbol, self.expiry)
                self.peTable = getPETable(self, self.symbol, self.expiry)

                self.ATM_CE_Token = window.ATM_CE_Token
                self.OTM_CE_Token = window.OTM_CE_Token
                self.ATM_PE_Token = window.ATM_PE_Token
                self.OTM_PE_Token = window.OTM_PE_Token


                self.hedgeToken_CE = window.hedgeToken_CE
                self.hedgeToken_PE = window.hedgeToken_PE


                self.strikeDecisionPoint = float(0.4)

                self.OTMqty = int(window.leQty_O.text())
                self.ATMqty = int(window.leQty_A.text())

                self.OTMStrikeIndex_CE = window.cbStrikeOTMCE.currentIndex()
                self.OTMStrikeIndex_PE = window.cbStrikeOTMPE.currentIndex()

                self.CE_Token_A = window.CE_Token_A
                self.PE_Token_A = window.PE_Token_A

                self.ATMStrikeIndex_CE = window.cbStrikeATMCE.currentIndex()
                self.ATMStrikeIndex_PE = window.cbStrikeATMPE.currentIndex()

                self.HedgeStrikeIndex_CE = window.cbStrikeATMCE.currentIndex()
                self.HedgeStrikeIndex_PE = window.cbStrikeATMPE.currentIndex()

                self.hedgeQty = self.OTMqty + self.ATMqty
                self.SlAmount = float(window.leSl.text())
                self.targetAmt = float(window.leTarget.text())

                updateModifyInfo(self)
                self.isParameterSet = True
                connectModifyWindowSlot(self)
                self.sgParamSet.emit()
                saveJson(self)
        except:
            print(traceback.print_exc())

    def setParametersModify(self,window):
        try:
            pass
            # print("paerameterrrrrrr settttt")
            self.OTMqty = int(window.leQty_O.text())
            self.ATMqty = int(window.leQty_A.text())

            if( self.ATMqty <= 0):
                self.messageBox = QMessageBox()
                self.messageBox.setIcon(QMessageBox.Critical)
                self.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
                self.messageBox.setText('Quantity must be greater than zero!!')
                self.messageBox.show()
            else:
                self.symbol = window.cbSymbol.currentText()
                self.Base = window.cbCF.currentText()
                self.BaseVIX = float(window.lbBaseVix.text())
                # self.BaseVIX = float(self.addW.leVIX.text())

                self.BaseToken = window.BaseToken
                self.folioName = window.leFolioName.text()
                self.adjPts = float(window.leAdjPts.text())

                self.cashToken = getCashToken(self,self.symbol)
                self.futureToken = getFutureToken(self,self.symbol)
                self.vixToken = 26002

                self.vix = float(window.lbBaseVix.text())

                self.clientId = window.cbClient.currentText()
                getKeyParameterFile(self,self.folioName)
                self.expiry = window.cbExp.currentText()
                self.trendPts = float(window.leTrendPts.text())
                print("Trend Pttttttss",self.trendPts)


                self.revPts = float(window.leRevPts.text())
                isTradeOnReversal = window.cbRevTrade.currentIndex()
                self.isTradeOnReversal =  True if isTradeOnReversal==0 else False
                self.Trend = window.cbTrend.currentText()

                self.cashPrice = window.cashPrice
                self.futurePrice = window.futurePrice
                self.basePrice = window.basePrice
                self.ATM = window.ATM

                self.strikeDiff = getStrikeDiff(self,self.futureToken)
                self.freezeQty = int(self.fo_contract[self.futureToken-35000,14])
                self.lotsize = int(self.fo_contract[self.futureToken-35000,11])

                self.ceTable = getCETable(self, self.symbol, self.expiry)
                self.peTable = getPETable(self, self.symbol, self.expiry)

                self.ATM_CE_Token = window.ATM_CE_Token
                self.OTM_CE_Token = window.OTM_CE_Token
                self.ATM_PE_Token = window.ATM_PE_Token
                self.OTM_PE_Token = window.OTM_PE_Token


                self.hedgeToken_CE = window.hedgeToken_CE
                self.hedgeToken_PE = window.hedgeToken_PE


                self.strikeDecisionPoint = float(0.4)

                self.OTMqty = int(window.leQty_O.text())
                self.ATMqty = int(window.leQty_A.text())

                self.OTMStrikeIndex_CE = window.cbStrikeOTMCE.currentIndex()
                self.OTMStrikeIndex_PE = window.cbStrikeOTMPE.currentIndex()

                self.CE_Token_A = window.CE_Token_A
                self.PE_Token_A = window.PE_Token_A

                self.ATMStrikeIndex_CE = window.cbStrikeATMCE.currentIndex()
                self.ATMStrikeIndex_PE = window.cbStrikeATMPE.currentIndex()

                self.HedgeStrikeIndex_CE = window.cbStrikeATMCE.currentIndex()
                self.HedgeStrikeIndex_PE = window.cbStrikeATMPE.currentIndex()

                self.hedgeQty = self.OTMqty + self.ATMqty
                self.SlAmount = float(window.leSl.text())
                self.targetAmt = float(window.leTarget.text())

                self.isParameterSet = True

                updateModifyInfo(self)
                connectModifyWindowSlot(self)
                # print("enter in looop")
                self.sgParamModified.emit()
                saveJson(self)

        except:
            print(traceback.print_exc())


    def squreOff(self):
        squreOff(self)

    def updateTrade(self, trade, source='on_trade'):
        # print('in update position stretegy')
        if (source == "on_trade"):
            trade1 = trade[0]
        else:
            trade1 = trade
        print(self.folioName, trade1)

        if (trade1[15] == self.folioName):

            exchange = trade1[20]
            token = trade1[2]
            fltr0 = np.asarray([token])
            filteredArray0 = self.position[np.in1d(self.position[:, 1], fltr0)]
            isRecordExist = False
            if (filteredArray0.size != 0):
                isRecordExist = True

            if (isRecordExist):
                array = self.position[np.where(self.position[:, 1] == token)]
                # print('in is record exist',array)
                prev_qty = array[0][5]
                prev_amt = array[0][8]

                Prev_Dqty = array[0][13]
                Prev_Damt = array[0][14]

                Dqty = Prev_Dqty + trade1[18]
                DAmt = Prev_Damt + trade1[19]

                newQty = prev_qty + trade1[18]
                newAmt = prev_amt + trade1[19]

                self.position[np.where(self.position[:, 1] == token), [5, 8, 13, 14]] = [newQty, newAmt, Dqty, DAmt]

                # print('updated position dekh lo',self.position)
            else:
                new = dt.Frame([[exchange],
                                [token], [trade1[4]], [float(trade1[6])], [trade1[7]], [trade1[18]],
                                [0], [0], [trade1[19]], [trade1[17]], [0.0],
                                [0.0], [0.0], [trade1[18]], [trade1[19]]
                                ]).to_numpy()

                # print('new position dekh lo',self.position,'\n\n\n\n',new,'\n\n\najsgd'
                #
                #       )
                self.position[self.lastSerialNo, :] = new
                self.lastSerialNo += 1
                # print('new position dekh lo',self.position)
            checkIsAnyPosition(self)


    def tradeVarification(self):
        pass

    def updateOrder(self,order,orderDict):
        pass

    def orderVarification(self):
        pass




    def getNewTokens(self):
        ATM = getATM(self,self.cashPrice,self.strikeDiff)

        OTMStrike_CE = ATM + (self.strikeDiff * self.OTMStrikeIndex_CE)
        OTMStrike_PE = ATM - (self.strikeDiff * self.OTMStrikeIndex_PE)
        ATMStrike_CE = ATM + (self.strikeDiff * self.ATMStrikeIndex_CE)
        ATMStrike_PE = ATM - (self.strikeDiff * self.ATMStrikeIndex_PE)

        self.OTM_CE_TOKEN  = get_ce_token(self,OTMStrike_CE)
        self.OTM_PE_TOKEN  = get_pe_token(self,OTMStrike_PE)
        self.ATM_CE_TOKEN  = get_ce_token(self,ATMStrike_CE)
        self.ATM_PE_TOKEN  = get_pe_token(self,ATMStrike_PE)



    def makeFirstOrder(self):
        try:
            if(self.isFirstOrderPunch==False):
                if(self.Trend == "Nutral"):
                    # print('Nutral')
                    self.isFirstOrderPunch = True
                elif(self.Trend == "Bullish"):

                    self.vix = getPrice(self,token=26002, seg='NSECM', streamType=1501)['ltp']
                    # print('bullish here')

                    self.getNewTokens()

                    print("ATM Qty",self.ATMqty,self.OTMqty)
                    makeOrder(self, self.ATM_CE_TOKEN, self.ATMqty, 'Sell')
                    makeOrder(self, self.ATM_PE_TOKEN, self.ATMqty, 'Sell')
                    makeOrder(self, self.OTM_CE_TOKEN, self.OTMqty, 'Buy')
                    makeOrder(self, self.OTM_PE_TOKEN, self.OTMqty, 'Buy')

                    self.BaseVIX = self.vix


                    self.sgStart.emit()
                    self.isStart = True
                    self.isFirstOrderPunch = True
                    self.saveJson()
                    self.Slogger.info('First Order Placed Successfully..')
                elif (self.Trend == "Bearish"):
                    self.vix = getPrice(self,token=26002, seg='NSECM', streamType=1501)['ltp']

                    # self.ATMqty = recalculateATMQty(self,self.addW)
                    self.getNewTokens()

                    print("ATM Qty",self.ATMqty,self.OTMqty)
                    makeOrder(self,self.OTM_CE_TOKEN,self.OTMqty,'Sell')
                    makeOrder(self,self.OTM_PE_TOKEN,self.OTMqty,'Sell')
                    makeOrder(self,self.ATM_CE_TOKEN,self.ATMqty,'Buy')
                    makeOrder(self,self.ATM_PE_TOKEN,self.ATMqty,'Buy')


                    self.BaseVIX = self.vix


                    self.sgStart.emit()
                    self.isStart = True
                    self.isFirstOrderPunch = True
                    self.saveJson()
                    self.Slogger.info('First Order Placed Successfully..')
        except:
            self.Slogger.error(sys.exc_info()[1])
            print('xxyyzz',self.isFirstOrderPunch,traceback.print_exc())



    def changeAdjPts(self, window):
        self.adjPts = float(window.leAdjPts.text())
        adjCashprice = float(window.lb_ltp.text()) + self.adjPts
        window.lbAdjCashP.setText('%.2f' % adjCashprice)
        # print("self.isStart",self.isParameterSet,self.isFirstOrderPunch )
        window.ATM =  getATM(window,adjCashprice,window.strikeDiff)

        print(window.ATM)
        window.lb_atm.setText('%.2f' % window.ATM )




    def checkTrade(self,priceFeed):
        self.updateWindows(priceFeed,self.modifyW)

        if(self.isStart):
            priceToken  = priceFeed['Token']

            if (self.cashToken == priceToken):
                self.cashPrice = priceFeed['LTP']

            elif(self.vixToken == priceToken):
                self.vix = priceFeed['LTP']
                if(self.Trend == 'Nutral'):

                    if (self.vix > (self.BaseVIX + self.trendPts)):

                        self.getNewTokens()
                        makeOrder(self, self.OTM_CE_TOKEN, self.OTMqty, 'Buy')
                        makeOrder(self, self.OTM_PE_TOKEN, self.OTMqty, 'Buy')
                        makeOrder(self, self.ATM_CE_TOKEN, self.ATMqty, 'Sell')
                        makeOrder(self, self.ATM_PE_TOKEN, self.ATMqty, 'Sell')
                        self.Trend = 'Bullish'
                        self.BaseVIX = self.vix
                        self.modifyW.lbBaseVix.setText('%.2f'%self.BaseVIX)
                        self.saveJson()

                        d = {'Trend': self.Trend, 'vix': self.vix, 'BaseVIX': self.BaseVIX,'trendPts':self.trendPts}
                        self.Slogger.info('checkTrade  Nutral(vix > (BaseVIX + trendPts)....', d)



                    elif(self.vix < (self.BaseVIX - self.trendPts)):
                        self.getNewTokens()

                        makeOrder(self, self.ATM_CE_TOKEN, self.ATMqty, 'Buy')
                        makeOrder(self, self.ATM_PE_TOKEN, self.ATMqty, 'Buy')
                        makeOrder(self, self.OTM_CE_TOKEN, self.OTMqty, 'Sell')
                        makeOrder(self, self.OTM_PE_TOKEN, self.OTMqty, 'Sell')
                        self.Trend = 'Bearish'
                        self.BaseVIX = self.vix
                        self.modifyW.lbBaseVix.setText('%.2f'%self.BaseVIX)

                        self.saveJson()
                        d = {'Trend': self.Trend, 'vix': self.vix, 'BaseVIX': self.BaseVIX, 'trendPts': self.trendPts}
                        self.Slogger.info('checkTrade  Nutral(vix < (BaseVIX - trendPts)....', d)

                elif(self.Trend == 'Bullish'):
                    if (self.vix > (self.BaseVIX + self.trendPts)):
                        self.getNewTokens()

                        makeOrder(self, self.OTM_CE_TOKEN, self.OTMqty, 'Buy')
                        makeOrder(self, self.OTM_PE_TOKEN, self.OTMqty, 'Buy')
                        makeOrder(self, self.ATM_CE_TOKEN, self.ATMqty, 'Sell')
                        makeOrder(self, self.ATM_PE_TOKEN, self.ATMqty, 'Sell')
                        self.Trend = 'Bullish'
                        self.BaseVIX = self.vix
                        self.modifyW.lbBaseVix.setText('%.2f'%self.BaseVIX)

                        self.saveJson()

                        d = {'Trend': self.Trend, 'vix': self.vix, 'BaseVIX': self.BaseVIX, 'trendPts': self.trendPts}
                        self.Slogger.info('checkTrade  Bullish(vix > (BaseVIX + trendPts)....', d)



                    elif(self.vix < (self.BaseVIX - self.revPts)):
                        self.squreOff()
                        self.Trend = 'Nutral'

                        if (self.isTradeOnReversal):
                            self.getNewTokens()

                            makeOrder(self, self.ATM_CE_TOKEN, self.ATMqty, 'Buy')
                            makeOrder(self, self.ATM_PE_TOKEN, self.ATMqty, 'Buy')
                            makeOrder(self, self.OTM_CE_TOKEN, self.OTMqty, 'Sell')
                            makeOrder(self, self.OTM_PE_TOKEN, self.OTMqty, 'Sell')
                            self.Trend = 'Bearish'
                        self.BaseVIX = self.vix
                        self.modifyW.lbBaseVix.setText('%.2f'%self.BaseVIX)

                        self.saveJson()
                        d = {'Trend': self.Trend, 'vix': self.vix, 'BaseVIX': self.BaseVIX, 'revPts': self.revPts}
                        self.Slogger.info('checkTrade  Bullish(vix < (BaseVIX - revPts)....', d)

                elif(self.Trend=='Bearish'):

                    if (self.vix < (self.BaseVIX - self.trendPts)):
                        self.getNewTokens()

                        makeOrder(self, self.ATM_CE_TOKEN, self.ATMqty, 'Buy')
                        makeOrder(self, self.ATM_PE_TOKEN, self.ATMqty, 'Buy')
                        makeOrder(self, self.OTM_CE_TOKEN, self.OTMqty, 'Sell')
                        makeOrder(self, self.OTM_PE_TOKEN, self.OTMqty, 'Sell')
                        self.Trend = 'Bearish'

                        self.BaseVIX = self.vix
                        self.modifyW.lbBaseVix.setText('%.2f' % self.BaseVIX)

                        self.saveJson()

                        d = {'Trend': self.Trend, 'vix': self.vix, 'BaseVIX': self.BaseVIX, 'trendPts': self.trendPts}
                        self.Slogger.info('checkTrade  Bullish(vix < (BaseVIX - trendPts)....', d)

                    elif (self.vix > (self.BaseVIX + self.revPts)):
                        self.squreOff()
                        self.Trend = 'Nutral'

                        if (self.isTradeOnReversal):
                            self.getNewTokens()

                            makeOrder(self, self.OTM_CE_TOKEN, self.OTMqty, 'Buy')
                            makeOrder(self, self.OTM_PE_TOKEN, self.OTMqty, 'Buy')
                            makeOrder(self, self.ATM_CE_TOKEN, self.ATMqty, 'Sell')
                            makeOrder(self, self.ATM_PE_TOKEN, self.ATMqty, 'Sell')
                            self.Trend = 'Bullish'
                        self.BaseVIX = self.vix
                        self.modifyW.lbBaseVix.setText('%.2f'%self.BaseVIX)
                        self.saveJson()

                        d = {'Trend': self.Trend, 'vix': self.vix, 'BaseVIX': self.BaseVIX, 'revPts': self.revPts}
                        self.Slogger.info('checkTrade  Bullish(vix > (BaseVIX + revPts)....', d)









    def updateMTM(self,data):
        # print('uuuuuuu')
        if(self.isAnyOpenPos == True):
            if (data['Token'] in self.position[:,1]):
                fltr0 = np.asarray([data['Token']])
                array = self.position[np.in1d(self.position[:, 1], fltr0)][0]
                # print(array)
                netAmt = array[8]
                ltp = data['LTP']
                qty = array[5]
                mtm = netAmt + (qty * ltp)
                self.position[np.in1d(self.position[:, 1], fltr0),[9,10]] = [ltp,mtm]
                # print(self.position[np.in1d(self.position[:, 1], fltr0)][0])
                total_mtm = np.sum(self.position[:,10])
                self.mtm = total_mtm
                # self.modifyW.leRMTM.setText('%.2f'%total_mtm)

                self.sgMTM.emit(self.folioName, total_mtm)
                # print('emited')
                self.modifyW.lbMTM.setText('%.2f' % total_mtm)
                self.checkSL()
                self.checkTarget()



    def hideAddW(self):
        try:
            self.addW.hide()
        except:
            print(traceback)

    def hideModifyW(self):
        self.modifyW.hide()

    def getBaseInfo(self,window):
        getBaseInfo(self,self.addW)

    def saveJson(self):
        saveJson(self)

    def getKeyParameterFile(self,folio):
        getKeyParameterFile(self,folio)

    def reloadKeyParameter(self):
        reloadKeyParameter(self)

    def flushTradeData(self):
        self.position = np.zeros((100,11),dtype=object)


    def modifyParameter(self):
        # print("hhhhhhyyyyyyyyyyyy"
        try:
            if(self.isFirstOrderPunch==False):
                self.setParametersModify(self.modifyW)
                # print("modify!!!!")
            else:
                print("MODIFY ORDER")
                if(self.modifyW.cxbSL.isChecked()):
                    self.SlAmount = float(self.modifyW.leSl.text())
                    self.sgSL.emit(self.folioName,self.SlAmount)
                    self.modifyW.lb_SlAmount.setText('%.2f'%self.SlAmount)

                if (self.modifyW.cxbTarget.isChecked()):
                    self.targetAmt = float(self.modifyW.leTarget.text())
                    self.modifyW.lb_Target.setText('%.2f'%self.targetAmt)
                    self.sgTarget.emit(self.folioName,self.targetAmt)
            self.hideModifyW()
        except:
            traceback.print_exc()

    def createTimer(self):
        self.timerUpdateWindows = QTimer()
        self.timerUpdateWindows.setInterval(500)
        self.timerUpdateWindows.timeout.connect(lambda:updateValues(self))


        self.timerGetPrices = QTimer()
        self.timerGetPrices.setInterval(500)
        self.timerGetPrices.timeout.connect(lambda:getPrices(self))





    def placeMarginHedgeOrder(self):
        pass
        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=peHedgeToken, orderSide='Buy', qty=self.qty,
        #            limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET', productType='NRML')

    #
    def checkSL(self):
        # print("ddddddddddddddddddd)

        if(self.isSlHitOnce==False and self.SlAmount != 0 and self.isStart==True):
            # if((self.tsl+self.trailP) <= (self.mtm + self.sl)):
            #     self.tsl = self.mtm + self.sl
            #     self.sgTSL.emit(self.folioName,self.tsl)
            ####################################################
            # if(self.mtm<=self.tsl):
            #     self.squreOff()
            # print('sl hit or nottttttttttttt')
            if(self.mtm<=self.SlAmount):
                # print("slHITTTTTTT")
                # print('trgger sl', self.mtm, self.SlAmount)
                self.isSlHitOnce = True
                self.squreOff()
                d={'MTM':self.mtm,'SlAmount':self.SlAmount}
                self.Slogger.info('SL Trigger (mtm>Slamt)....' ,d)
            ####################################################


    def setAllShortCut(self):
        # print("parthhhhhhhhhhhhh")
        self.addW.leQty_O.sc_up1 = QShortcut(QKeySequence('Up'),self.addW.leQty_O)
        self.addW.leQty_O.sc_up1.setContext(Qt.WidgetWithChildrenShortcut)
        self.addW.leQty_O.sc_up1.activated.connect(lambda:inc_v(self,self.addW))
        self.addW.leQty_O.sc_down11= QShortcut(QKeySequence('Down'), self.addW.leQty_O)
        self.addW.leQty_O.sc_down11.setContext(Qt.WidgetWithChildrenShortcut)
        self.addW.leQty_O.sc_down11.activated.connect(lambda :dec_v(self,self.addW))


        self.modifyW.leQty_O.sc_up2 = QShortcut(QKeySequence('Up'),self.modifyW.leQty_O)
        self.modifyW.leQty_O.sc_up2.setContext(Qt.WidgetWithChildrenShortcut)
        self.modifyW.leQty_O.sc_up2.activated.connect(lambda:inc_v(self,self.modifyW))
        self.modifyW.leQty_O.sc_down12= QShortcut(QKeySequence('Down'), self.modifyW.leQty_O)
        self.modifyW.leQty_O.sc_down12.setContext(Qt.WidgetWithChildrenShortcut)
        self.modifyW.leQty_O.sc_down12.activated.connect(lambda:dec_v(self,self.modifyW))

    def checkTarget(self):
        if (self.isSlHitOnce == False):

            if (self.mtm >= self.targetAmt and self.targetAmt != 0):
                self.isSlHitOnce = True
                squreOff(self)

                d = {'MTM': self.mtm, 'SlAmount': self.targetAmt}
                self.Slogger.info('Target Trigger (mtm>targetAmt)....', d)
    def updateWindows(self,feed,window):
        priceToken  = feed['Token']
        # print(self.tokenList,"priceTokennnn")
        try:

            if (window.visibleRegion().isEmpty() == False):
                if(window.isParachange==False):
                    if(priceToken==self.tokenList[0]):
                        if (window.cashFut == 'CASH'):
                            window.BaseToken = window.cashToken
                            window.cashPrice = feed['LTP']
                            window.basePrice = window.cashPrice
                            if(self.isFirstOrderPunch==False):
                                ATM = getATM(self, window.basePrice, window.strikeDiff)
                                # print("ATTTTTTMMMM",ATM)
                                if(ATM != window.ATM):
                                    window.ATM = ATM
                                    window.lb_atm.setText(str(window.ATM))
                                    window.ATM_CE_Token = get_ce_token(window, window.ATM)
                                    window.ATM_PE_Token = get_pe_token(window, window.ATM)
                                    self.tokenList[3] = window.CE_Token_A
                                    self.tokenList[4] = window.PE_Token_A

                            window.lb_ltp.setText(str(window.basePrice))

                    elif(priceToken==self.tokenList[1]):
                        if (window.cashFut != 'CASH'):
                            window.BaseToken = window.futureToken
                            window.futurePrice = feed['LTP']
                            window.basePrice = window.futurePrice
                            ATM = getATM(self, window.basePrice, window.strikeDiff)
                            if(self.isFirstOrderPunch==False):
                                if(ATM != window.ATM):
                                    window.ATM = ATM
                                    window.lb_atm.setText(str(window.ATM))
                                    window.CE_Token_A = get_ce_token(self, window.ATM)
                                    window.PE_Token_A = get_pe_token(self, window.ATM)
                                    self.tokenList[3] = window.CE_Token_A
                                    self.tokenList[4] = window.PE_Token_A

                            window.lb_ltp.setText(str(window.basePrice))

                    elif(priceToken==self.tokenList[2]):
                        # print('enterr!!!')
                        window.VIX = feed['LTP']
                        window.lbVIX.setText('%.2f' % window.VIX)


                    elif(priceToken==self.tokenList[3]):
                        # print('enterr!!!')
                        window.CEPrice = feed['LTP']
                        window.lb_CEP.setText('%.2f' % window.CEPrice)
                        if (priceToken == self.tokenList[7]):
                            window.ATMCEPrice = feed['LTP']
                            window.lbATMCE.setText('%.2f' % window.ATMCEPrice)
                        if (priceToken == self.tokenList[5]):
                            window.OTMCEPrice = feed['LTP']
                            window.lbOTMCE.setText('%.2f' % window.OTMCEPrice)


                    elif(priceToken==self.tokenList[4]):
                        window.PEPrice = feed['LTP']
                        window.lb_PEP.setText('%.2f' % window.PEPrice)
                        if (priceToken == self.tokenList[8]):
                            window.ATMPEPrice = feed['LTP']
                            window.lbATMPE.setText('%.2f' % window.ATMPEPrice)
                        if (priceToken == self.tokenList[6]):
                            window.OTMPEPrice = feed['LTP']
                            window.lbOTMPE.setText('%.2f' % window.OTMPEPrice)



                    elif(priceToken==self.tokenList[5]):
                        window.OTMCEPrice= feed['LTP']
                        window.lbOTMCE.setText('%.2f' % window.OTMCEPrice)
                    elif(priceToken==self.tokenList[6]):
                        window.OTMPEPrice= feed['LTP']
                        window.lbOTMPE.setText('%.2f' % window.OTMPEPrice)

                    elif(priceToken==self.tokenList[7]):
                        window.ATMCEPrice= feed['LTP']
                        window.lbATMCE.setText('%.2f' % window.ATMCEPrice)

                    elif(priceToken==self.tokenList[8]):
                        window.ATMPEPrice= feed['LTP']
                        window.lbATMPE.setText('%.2f' % window.ATMPEPrice)
        except:
            print(traceback.print_exc())


    def changeBaseVix(self,window):

        self.BaseVIX =float( window.leVIX.text())
        window.lbBaseVix.setText(window.leVIX.text())