import logging
import sys
import traceback
from os import path, getcwd
import threading
import time
import requests
import json
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import uic
import qdarkstyle
import qtpy
from Application.Utils.configReader import *
from Application.Views.titlebar import tBar
from Theme.dt2 import  dt1
import numpy as np
from Application.Services.Xts.Api.servicesMD import getQuote
import platform
class addW(QMainWindow):
    def __init__(self, parent=None):
        super(addW, self).__init__(parent=None)
        self.setObjectName('addParameter')
        #####################################################################
        loc1 = getcwd().split('Application')
        ui_login = os.path.join(loc1[0] ,'Application','Stretegies','VixMonkey','UI','inputParameter.ui')
        uic.loadUi(ui_login, self)
        dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()
        self.setStyleSheet(dt1)
        osType = platform.system()

        if (osType == 'Darwin'):
            flags = Qt.WindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        else:
            flags = Qt.WindowFlags(Qt.SubWindow | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setWindowFlags(flags)
        self.pbCancel.clicked.connect(self.hide)
        self.title = tBar('ADD PARAMETER')
        # self.title.setStyleSheet(self.headerFrame.styleSheet())
        self.headerFrame.layout().addWidget(self.title, 0, 0)
        self.title.sgPoss.connect(self.movWin)
        dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()
        # QSizeGrip(self.gripFolio)
        # self.movWin()

        # for i in range(40):
        #     a='ATM + ' + str(i)
        #     self.cbHedgeStrikeCE.addItem(a)

        self.cbStrikeOTMCE.setCurrentIndex(5)
        self.cbStrikeOTMPE.setCurrentIndex(5)

        self.cbHedgeStrikeCE.setCurrentIndex(25)
        self.cbHedgeStrikePE.setCurrentIndex(25)


        self.isParachange =False
        # self.createShortcuts()
        self.connectAllSlots()
        QSizeGrip(self.Grip)


    def movWin(self, x, y):
        self.move(self.pos().x() + x, self.pos().y() + y)

    def connectAllSlots(self):
        self.bt_close.clicked.connect(self.hide)
        self.bt_min.clicked.connect(self.hide)
    #
    # def createShortcuts(self):
    #     self.quitSc = QShortcut(QKeySequence('Esc'), self)
    #     self.quitSc.activated.connect(self.hide)



if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = addW()
    form.show()
    sys.exit(app.exec_())