import logging
import sys
import traceback
from os import path, getcwd
import threading
import time
import requests
import json
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import uic
import qdarkstyle
import qtpy
from Application.Utils.configReader import *
from Application.Views.titlebar import tBar
from Theme.dt2 import  dt1
import platform

class modifyW(QMainWindow):
    def __init__(self, parent= None):
        super(modifyW, self).__init__(parent=None)
        self.setObjectName('addParameter')

        #####################################################################

        loc1 = getcwd().split('Application')
        # print(loc1)
        ui_login = os.path.join(loc1[0] ,'Application','Stretegies','VixMonkey','UI','modify.ui')
        uic.loadUi(ui_login, self)
        dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()


        self.setStyleSheet(dt1)
        QSizeGrip(self.modifyGrip)
        osType = platform.system()

        if (osType == 'Darwin'):
            flags = Qt.WindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        else:
            flags = Qt.WindowFlags(Qt.SubWindow | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setWindowFlags(flags)
        self.pbCancel.clicked.connect(self.hide)

        self.title = tBar('MODIFY PARAMETER')
        self.headerFrame.layout().addWidget(self.title, 0, 0)
        self.title.sgPoss.connect(self.movWin)
        self.connectAllSlots()
        self.isParachange = False
        # self.movWin()
        # self.createShortcuts()

    def movWin(self, x, y):
        self.move(self.pos().x() + x, self.pos().y() + y)

    def connectAllSlots(self):
        self.bt_close.clicked.connect(self.hide)
        self.bt_min.clicked.connect(self.hide)
        self.cxbTrend.stateChanged.connect(self.enableTrend)
        self.cxbRevPts.stateChanged.connect(self.enableRevTrendPts)
        self.cxbTrendPts.stateChanged.connect(self.enableTrendPts)
        self.cxbOTMCEStrike.stateChanged.connect(self.enableOTMCEStrike)
        self.cxbOTMPEStrike.stateChanged.connect(self.enableOTMPEStrike)
        self.cxbATMCEStrike.stateChanged.connect(self.enableATMCEStrike)
        self.cxbATMPEStrike.stateChanged.connect(self.enableATMPEStrike)
        self.cxbOTMQty.stateChanged.connect(self.enableOTMQty)
        self.cxbATMQty.stateChanged.connect(self.enableATMQty)
        self.cxbHedgeStrikeCE.stateChanged.connect(self.enableHedgeStrikeStrikeCE)
        self.cxbHedgeStrikePE.stateChanged.connect(self.enableHedgeStrikeStrikePE)

    def enableTrend(self):
        try:
            if(self.cxbTrend.isChecked()):
                self.cbTrend.setEnabled(True)
            else:
                self.cbTrend.setEnabled(False)
        except:
            print(traceback.print_exc())

    def enableRevTrendPts(self):
        try:
            if(self.cxbRevPts.isChecked()):
                self.leRevPts.setEnabled(True)
            else:
                self.leRevPts.setEnabled(False)
        except:
            print(traceback.print_exc())

    def enableTrendPts(self):
        try:
            if(self.cxbOTMCEStrike.isChecked()):
                self.cbStrikeOTMCE.setEnabled(True)
            else:
                self.cbStrikeOTMCE.setEnabled(False)
        except:
            print(traceback.print_exc())

    def enableOTMCEStrike(self):
        try:
            if(self.cxbOTMPEStrike.isChecked()):
                self.cbStrikeOTMPE.setEnabled(True)
            else:
                self.cbStrikeOTMPE.setEnabled(False)
        except:
            print(traceback.print_exc())

    def enableOTMPEStrike(self):
        try:
            if(self.cxbTrend.isChecked()):
                self.cbTrend.setEnabled(True)
            else:
                self.cbTrend.setEnabled(False)
        except:
            print(traceback.print_exc())

    def enableATMCEStrike(self):
        try:
            if(self.cxbATMCEStrike.isChecked()):
                self.cbStrikeATMCE.setEnabled(True)
            else:
                self.cbStrikeATMCE.setEnabled(False)
        except:
            print(traceback.print_exc())

    def enableATMPEStrike(self):
        try:
            if(self.cxbATMPEStrike.isChecked()):
                self.cbStrikeATMPE.setEnabled(True)
            else:
                self.cbStrikeATMPE.setEnabled(False)
        except:
            print(traceback.print_exc())

    def enableOTMQty(self):
        try:
            if(self.cxbOTMQty.isChecked()):
                self.leQty_O.setEnabled(True)
            else:
                self.leQty_O.setEnabled(False)
        except:
            print(traceback.print_exc())

    def enableATMQty(self):
        try:
            if(self.cxbATMQty.isChecked()):
                self.leQty_A.setEnabled(True)
            else:
                self.leQty_A.setEnabled(False)
        except:
            print(traceback.print_exc())
    def enableHedgeStrikeStrikeCE(self):
        try:
            if(self.cxbHedgeStrikeCE.isChecked()):
                self.cbHedgeStrikeCE.setEnabled(True)
            else:
                self.cbHedgeStrikeCE.setEnabled(False)
        except:
            print(traceback.print_exc())

    def enableHedgeStrikeStrikePE(self):
        try:
            if(self.cxbHedgeStrikePE.isChecked()):
                self.cbHedgeStrikePE.setEnabled(True)
            else:
                self.cbHedgeStrikePE.setEnabled(False)
        except:
            print(traceback.print_exc())


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = modifyW()
    form.show()
    sys.exit(app.exec_())
