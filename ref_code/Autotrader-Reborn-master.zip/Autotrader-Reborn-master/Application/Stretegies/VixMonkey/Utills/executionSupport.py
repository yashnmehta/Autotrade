import threading
import traceback
from datetime import datetime, time

from Application.Services.Xts.Api.servicesMD import getQuote,subscribeToken
import logging
import sys
import numpy as np

from Application.Stretegies.VixMonkey.Utills.square import *

def getBaseInfo(self,window):

    try:
        window.symbol = window.cbSymbol.currentText()
        window.expiry = window.cbExp.currentText()

        window.vixToken = 26002
        self.vixToken = 26002
        self.tokenList[2] =  window.vixToken
        subscribeToken(self,26002,'NSECM')

        data = getQuote(self, window.vixToken, 'NSECM',1501)
        window.VIX = data['LastTradedPrice']


        window.lbVIX.setText(str(window.VIX))

        if(self.isParameterSet == False):
            window.lbBaseVix.setText(str(window.VIX))
            window.leVIX.setText(str(window.VIX))

        window.cashToken = getCashToken(self,window.symbol)

        self.tokenList[0] =  window.cashToken
        subscribeToken(self,window.cashToken,'NSECM')
        window.cashFut = window.cbCF.currentText()
        window.futureToken = getFutureToken(self,window.symbol)
        self.tokenList[1] = window.futureToken

        # print('window.futureToken',window.futureToken)

        subscribeToken(self,window.futureToken,'NSEFO')
        data = getQuote(self, window.cashToken, 'NSECM', 1501)
        window.cashPrice = data['LastTradedPrice']
        data = getQuote(self, window.futureToken, 'NSEFO', 1501)
        window.futurePrice = data['LastTradedPrice']

        if(window.cashFut == 'CASH'):
            window.BaseToken = window.cashToken
            window.basePrice = window.cashPrice
        else:
            window.BaseToken = window.futureToken
            window.basePrice = window.futurePrice


        # print('window.cashPrice',window.cashPrice,'window.futurePrice',window.futurePrice,'window.basePrice',window.basePrice)

        self.adjPts = float(window.leAdjPts.text())
        # print("adjs pts",self.adjPts)
        adjBaseprice = float(window.lb_ltp.text()) + self.adjPts
        window.lbAdjCashP.setText('%.2f' % adjBaseprice)


        window.strikeDiff = getStrikeDiff(self,window.futureToken)
        window.lotsize = getLotSize(self,window.futureToken)
        # print('window lotsize',window.lotsize)
        window.ATM = getATM(self,window.basePrice, window.strikeDiff)

        # print('window.ATM',window.ATM)


        # print()

        window.ceTable = getCETable(self,window.symbol, window.expiry)
        window.peTable = getPETable(self,window.symbol, window.expiry)


        window.lb_ltp.setText(str(window.basePrice))
        window.lb_atm.setText(str(window.ATM))

        # print('window.ceTable',window.ceTable)




        window.CE_Token_A = get_ce_token(window,window.ATM)
        window.PE_Token_A = get_pe_token(window,window.ATM)
        subscribeToken(self,window.CE_Token_A,'NSEFO')
        subscribeToken(self,window.PE_Token_A,'NSEFO')
        self.tokenList[3] = window.CE_Token_A
        self.tokenList[4] = window.PE_Token_A

        try:

            data = getQuote(self, window.CE_Token_A, 'NSEFO', 1501)
            window.ACEP = data['LastTradedPrice']

        except:
            print(traceback.print_exc())
            # print('window.CE_Token_A',window.CE_Token_A)

        # print('data',data)
        data1 = getQuote(self, window.PE_Token_A, 'NSEFO', 1501)
        window.APEP = data1['LastTradedPrice']


        window.lb_CEP.setText('%.2f' % window.ACEP)
        window.lb_PEP.setText('%.2f' % window.APEP)

        # print('window.cbStrikeATMCE.currentIndex()',window.cbStrikeATMCE.currentIndex())
        # print('window.cbStrikeOTMCE.currentIndex()',window.cbStrikeOTMCE.currentIndex())
        atm_ce_strike = window.ATM + (window.strikeDiff * window.cbStrikeATMCE.currentIndex())
        atm_pe_strike = window.ATM + (window.strikeDiff * window.cbStrikeATMPE.currentIndex())
        # print(window.ATM,atm_ce_strike,atm_pe_strike)

        window.ATM_CE_Token = get_ce_token(window,atm_ce_strike)
        window.ATM_PE_Token = get_pe_token(window,atm_pe_strike)

        subscribeToken(self,window.ATM_CE_Token,'NSEFO')
        subscribeToken(self,window.ATM_PE_Token,'NSEFO')

        self.tokenList[7] = window.ATM_CE_Token
        self.tokenList[8] = window.ATM_PE_Token

        data = getQuote(self, window.ATM_CE_Token, 'NSEFO', 1501)
        window.atmCEPrice = data['LastTradedPrice']

        data1 = getQuote(self, window.ATM_PE_Token, 'NSEFO', 1501)
        window.atmPEPrice = data1['LastTradedPrice']

        otm_ce_strike = window.ATM + (window.strikeDiff * window.cbStrikeOTMCE.currentIndex())
        otm_pe_strike = window.ATM - (window.strikeDiff * window.cbStrikeOTMPE.currentIndex())

        window.OTM_CE_Token = get_ce_token(window,otm_ce_strike)
        window.OTM_PE_Token = get_pe_token(window,otm_pe_strike)

        subscribeToken(self,window.OTM_CE_Token,'NSEFO')
        subscribeToken(self,window.OTM_PE_Token,'NSEFO')

        self.tokenList[5] = window.OTM_CE_Token
        self.tokenList[6] = window.OTM_PE_Token

        data = getQuote(self, window.OTM_CE_Token, 'NSEFO', 1501)
        window.otmCEPrice = data['LastTradedPrice']

        data1 = getQuote(self, window.OTM_PE_Token, 'NSEFO', 1501)
        window.otmPEPrice = data1['LastTradedPrice']

        self.hedgeStrike_CE = otm_ce_strike + (window.strikeDiff * 10)
        self.hedgeStrike_PE = otm_pe_strike + (window.strikeDiff * 10)

        window.hedgeStrike_CE = self.hedgeStrike_CE
        window.hedgeStrike_PE = self.hedgeStrike_PE


        window.hedgeToken_CE = get_ce_token(window,window.hedgeStrike_CE)
        window.hedgeToken_PE = get_pe_token(window,window.hedgeStrike_PE)

        subscribeToken(self,window.hedgeToken_CE,'NSEFO')
        subscribeToken(self,window.hedgeToken_PE,'NSEFO')

        self.tokenList[9] = window.hedgeToken_CE
        self.tokenList[10] = window.hedgeToken_PE



        window.isParachange = False
    except:
            traceback.print_exc()

def updateModifyInfo(self):
    try:
        connectModifyWindowSlot(self)

        self.modifyW.leFolioName.setText(self.folioName)
        self.modifyW.cbClient.addItem(self.clientId)
        self.modifyW.cbSymbol.setCurrentText(self.symbol)

        self.modifyW.cbCF.setCurrentText(self.Base)


        self.modifyW.cbExp.setCurrentText(self.expiry)


        # print("EXPPPPPPPP",self.modifyW.cbExp.setCurrentText(self.expiry))



        self.modifyW.ceTable = self.ceTable
        self.modifyW.peTable = self.peTable


        self.modifyW.strikeDiff = self.strikeDiff
        self.modifyW.lotsize = self.lotsize
        self.modifyW.freezeQty = self.freezeQty


        self.modifyW.symbol = self.symbol
        self.modifyW.expiry = self.expiry
        self.modifyW.cashFut = self.Base
        self.modifyW.BaseVIX = self.BaseVIX

        self.modifyW.cashToken = self.cashToken
        self.modifyW.futureToken = self.futureToken

        self.modifyW.BaseToken = self.BaseToken
        self.modifyW.basePrice =self.basePrice

        self.modifyW.cashPrice =self.cashPrice
        self.modifyW.futurePrice =self.futurePrice
        self.modifyW.adjPts = self.adjPts


        self.modifyW.ATM = self.ATM

        self.modifyW.hedgeStrike_CE = self.hedgeStrike_CE
        self.modifyW.hedgeStrike_PE = self.hedgeStrike_PE


        self.modifyW.leAdjPts.setText('%.2f'%self.adjPts)
        self.modifyW.lbBaseVix.setText('%.2f'%self.BaseVIX)
        self.modifyW.leVIX.setText('%.2f'%self.BaseVIX)


        self.modifyW.leTrendPts.setText('%.2f'%self.trendPts)
        self.modifyW.leRevPts.setText('%.2f'%self.revPts)


        if(self.isTradeOnReversal):
            self.modifyW.cbRevTrade.setCurrentIndex(0)
        else:
            self.modifyW.cbRevTrade.setCurrentIndex(1)

        self.modifyW.cbTrend.setCurrentText(self.Trend)

        self.modifyW.cbStrikeOTMCE.setCurrentIndex(self.OTMStrikeIndex_CE)
        self.modifyW.cbStrikeOTMPE.setCurrentIndex(self.OTMStrikeIndex_PE)

        self.modifyW.cbStrikeATMCE.setCurrentIndex(self.ATMStrikeIndex_CE)
        self.modifyW.cbStrikeATMPE.setCurrentIndex(self.ATMStrikeIndex_PE)

        self.modifyW.cbHedgeStrikeCE.setCurrentIndex(self.HedgeStrikeIndex_CE)
        self.modifyW.cbHedgeStrikePE.setCurrentIndex(self.HedgeStrikeIndex_PE)

        # self.modifyW.cbHedgeStrike.setCurrentText('%.2f'%self.hedgeStrike)
        # self.addW.cbTrend.setCurrentText(self.Trend)

        self.modifyW.ATM = self.ATM

        self.modifyW.lb_atm.setText('%.2f'%self.ATM)
        self.modifyW.lb_ltp.setText(self.addW.lb_ltp.text())

        self.modifyW.CE_Token_A = self.CE_Token_A
        self.modifyW.PE_Token_A = self.PE_Token_A

        self.modifyW.ATM_CE_Token = self.ATM_CE_Token
        self.modifyW.ATM_PE_Token = self.ATM_PE_Token

        self.modifyW.OTM_CE_Token = self.OTM_CE_Token
        self.modifyW.OTM_PE_Token = self.OTM_PE_Token

        self.modifyW.hedgeToken_CE = self.hedgeToken_CE
        self.modifyW.hedgeToken_PE = self.hedgeToken_PE


        # self.modifyW.lb_CEP.setText(self.addW.lb_CEP.text())
        # self.modifyW.lb_PEP.setText(self.addW.lb_PEP.text())
        #
        # self.modifyW.lbOTMCE.setText(self.addW.lbOTMCE.text())
        # self.modifyW.lbOTMPE.setText(self.addW.lbOTMPE.text())
        #
        # self.modifyW.lbATMCE.setText(self.addW.lbATMCE.text())
        # self.modifyW.lbATMPE.setText(self.addW.lbATMPE.text())

        self.modifyW.leQty_O.setText(str(self.OTMqty))
        self.modifyW.leQty_A.setText(str(self.ATMqty))

        self.modifyW.leQty_O.setText(str(self.OTMqty))
        self.modifyW.leQty_A.setText(str(self.ATMqty))
        self.modifyW.leSl.setText(str(self.SlAmount))
        self.modifyW.leTarget.setText(str(self.targetAmt))

        self.modifyW.ATM_CE_Token = get_ce_token(self.modifyW, self.ATM)
        self.modifyW.ATM_PE_Token = get_ce_token(self.modifyW, self.ATM)

        self.modifyW.leAdjPts.setText(str(self.adjPts))
        #
        # recalculateATMQty(self,self.modifyW)
        # recalculateATMQtyONSC(self,self.modifyW)
        # recalOTMStrike(self,self.modifyW)
    except:
        print('updateeeeeeeeeeeee')


def connectModifyWindowSlot(self):
    try:
        # print('in modifyconnectiom')
        self.modifyW.cbSymbol.currentTextChanged.connect(lambda: symchange(self, self.modifyW))
        self.modifyW.pbApply.clicked.connect(self.modifyParameter)
        self.modifyW.cbExp.currentTextChanged.connect(lambda: expchange(self, self.modifyW))
        self.modifyW.cbTrend.currentIndexChanged.connect(lambda: trendChanged(self, self.modifyW))
        self.modifyW.pbGetInfo.clicked.connect(lambda: getBaseInfo(self, self.modifyW))

        self.modifyW.cbHedgeStrikeCE.currentIndexChanged.connect(lambda: getHedgeToken(self))
        self.modifyW.cbHedgeStrikePE.currentIndexChanged.connect(lambda: getHedgeToken(self))
        # self.modifyW.leQty_O.textChanged.connect(lambda: recalculateATMQty(self, self.modifyW))

        self.modifyW.pb50.clicked.connect(lambda: profitBook50(self))
        self.modifyW.pbFull.clicked.connect(lambda: squreOff(self))
        self.modifyW.pbHedge.clicked.connect(lambda: hedgeorder(self))

    except:
        print('error in modify connections',traceback.print_exc())


def getHedgeToken(self):
    # print('kjdfhksdjhfjksdhfkjhsdkf')
    self.hedgeStrike_CE = self.addW.cbHedgeStrikeCE.currentText()
    self.hedgeStrike_PE = self.addW.cbHedgeStrikePE.currentText()

    self.hedgeToken_CE = get_ce_token(self,float(self.hedgeStrike_CE))
    self.hedgeToken_PE = get_pe_token(self,float(self.hedgeStrike_PE))


def trendChanged(self,window):
    if(window.cbTrend.currentText()=='Bullish'):
        window.cbOptType.setCurrentText('CE')
    elif(window.cbTrend.currentText()=='Bearish'):
        window.cbOptType.setCurrentText('PE')

def symchange(self,window):
    try:
        a = window.cbSymbol.currentText()
        fltr = np.asarray([a])
        window.t2 = window.t[np.in1d(window.t[:, 3], fltr)]
        window.t2_tp = window.t2.transpose()
        lsExp = np.unique(window.t2_tp[6])
        window.cbExp.clear()
        window.cbExp.addItems(lsExp)
        # self.getBaseInfo(window)
        window.isParachange = True


    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])

def expchange(self,window):
    try:
        a = window.cbExp.currentText()
        fltr = np.asarray([a])
        window.t3 = window.t2[np.in1d(window.t2[:, 6], fltr)]
        window.t3_tp = window.t3.transpose()
        window.lsstrk = np.unique(window.t3_tp[7])
        # window.cbStrikePrice.clear()
        # window.cbStrikePrice.addItems(window.lsstrk)
        # updateHedgeStrikes(self)
        window.isParachange = True

    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])



def baseChange(self,window):
    window.cashFut = window.cbCF.currentText()
    window.isParachange = True

def changesrtike(self,window):
    try:
        a = window.cbStrikePrice.currentText()
        if ('FUT' in window.cbInstrumentType.currentText()):
            window.cbOptType.clear()
            window.cbOptType.addItem(' ')

        elif ('OPT' in window.cbInstrumentType.currentText()):
            if (window.cbOptType.currentText() not in ['CE', 'PE']):
                window.cbOptType.clear()
                window.cbOptType.addItems(['CE', 'PE'])
            else:
                pass

    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])

def getStrikePriceList(self,window):
    symbol = window.cbSymbol.currentText()
    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    fltr1 = np.asarray(['OPTSTK','OPTIDX'])

    filteredarray1 = filteredarray[np.in1d(filteredarray[:, 5], fltr1)]
    exp = window.cbExp.currentText()

    fltr2 = np.asarray([exp])
    filteredarray2 = filteredarray1[np.in1d(filteredarray1[:, 6], fltr2)]

    uniqueStrike = np.unique(filteredarray2[:,7])
    window.cbStrikePrice.addItems(uniqueStrike)

def getOptionExpiryList(self,window):
    symbol = window.cbSymbol.currentText()
    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    uniqueExp = np.unique(filteredarray[:,6])
    window.cbExp.addItems(uniqueExp)

def updateHedgeStrikes(self):
    self.modifyW.cbHedgeStrike.clear()
    self.modifyW.cbHedgeStrike.addItems(self.addW.lsstrk.tolist())
    # self.hedgeStrike = self.modifyW.cbHedgeStrike.currentText()
    # self.modifyW.hedgeStrike = self.modifyW.cbHedgeStrike.currentText()
    if(self.isParameterSet):
        self.modifyW.cbHedgeStrike.setCurrentText(self.addW.hedgeStrike)
# def onExpChange(self,window):
#     window.ceTable = self.getCETable(window.symbol, window.expiry)
#     window.peTable = self.getPETable(window.symbol, window.expiry)
#
#
#     window.ATM_CE_Token = self.getATM_CE_Token(window.ATM, window.ceTable)
#     window.ATM_PE_Token = self.getATM_PE_Token(window.ATM, window.peTable)



def recalOTMStrike(self,window):

    if(window.cbOptType.currentText()=='CE'):
        OTMStrike=window.ATM  + (window.strikeDiff * 10)
    else:
        OTMStrike = window.ATM - (window.strikeDiff * 10)
    # print('pappapapap',OTMStrike)
    window.cbStrikePrice.setCurrentText('%.2f'%OTMStrike)

def recalculateATMQty(self,window):
    try:
        print('ATMwindow', window)

        OTMQty_CE = float(int(window.leQty_O.text()))
        OTMQty_PE = float(int(window.leQty_O.text()))
        OTMPrc_CE = float(window.lbOTMCE.text())
        OTMPrc_PE = float(window.lbOTMPE.text())
        OTMPrem_CE = OTMPrc_CE * OTMQty_CE
        OTMPrem_PE = OTMPrc_PE * OTMQty_PE

        total_OTM_Prem =OTMPrem_PE + OTMPrem_CE

        ATMPrc_CE = float(window.lbATMCE.text())
        ATMPrc_PE = float(window.lbATMPE.text())

        ATM_PAIR_TOTAL = ATMPrc_PE+ATMPrc_CE

        atmQty =  int(total_OTM_Prem / (ATM_PAIR_TOTAL * window.lotsize))*window.lotsize
        print("total_OTM_Prem",total_OTM_Prem)
        window.leQty_A.setText(str(atmQty))

    except:
        print(traceback.print_exc())


def recalculateATMQtyONSC(self,window):
    print('ONSCwindow',window)
    window.isParachange =True
    OTMQty = int(window.leQty_O.text())
    OTMPrc_CE = float(window.lbOTMCE.text())
    OTMPrc_PE = float(window.lbOTMPE.text())

    OTMPrc_Total = OTMPrc_CE + OTMPrc_PE
    # print("OTMPrc_Total ",OTMPrc_Total )

    OTMPrem = OTMPrc_Total * OTMQty
    # print("OTMPrem",OTMPrem)

    ATMPrc_CE = float(window.lbATMCE.text())
    ATMPrc_PE = float(window.lbATMPE.text())
    ATMPrc_Total = ATMPrc_CE + ATMPrc_PE
    # print('ATMPrc_Total',ATMPrc_Total)

    print("ATM QTY",OTMPrem,self.lotsize,ATMPrc_Total,OTMPrc_Total,window.leQty_O.text())
    atmQty =  int(OTMPrem / (ATMPrc_Total *window.lotsize))*window.lotsize
    window.leQty_A.setText(str(atmQty))

def updateATMCEToken(self,window):
    ATMStrike_CE = window.ATM +  (window.strikeDiff * window.cbStrikeATMCE.currentIndex())
    window.ATM_CE_Token = get_ce_token(window,ATMStrike_CE)
    self.tokenList[7] =window.ATM_CE_Token
    data1 = getQuote(self, window.ATM_CE_Token, 'NSEFO', 1501)
    window.ATMPrice_CE = data1['LastTradedPrice']
    window.lbATMCE.setText('%.2f'%window.ATMPrice_CE)
    print('window',window)
    recalculateATMQtyONSC(self,window)


def updateATMPEToken(self,window):
    ATMStrike_PE = window.ATM -  (window.strikeDiff * window.cbStrikeATMPE.currentIndex())
    window.ATM_PE_Token = get_pe_token(window,ATMStrike_PE)
    self.tokenList[8] =window.ATM_PE_Token
    data1 = getQuote(self, window.ATM_PE_Token, 'NSEFO', 1501)
    window.ATMPrice_PE = data1['LastTradedPrice']
    window.lbATMPE.setText('%.2f'%window.ATMPrice_PE)
    recalculateATMQtyONSC(self,window)


def updateOTMCEToken(self,window):
    OTMStrike_CE = window.ATM +  (window.strikeDiff * window.cbStrikeOTMCE.currentIndex())
    window.OTM_CE_Token = get_ce_token(window,OTMStrike_CE)
    self.tokenList[5] =window.OTM_CE_Token
    data1 = getQuote(self, window.OTM_CE_Token, 'NSEFO', 1501)
    window.OTMPrice_CE = data1['LastTradedPrice']
    window.lbOTMCE.setText('%.2f'%window.OTMPrice_CE)
    recalculateATMQtyONSC(self,window)


def updateOTMPEToken(self,window):
    OTMStrike_PE = window.ATM -  (window.strikeDiff * window.cbStrikeOTMPE.currentIndex())
    window.OTM_PE_Token = get_pe_token(window,OTMStrike_PE)
    self.tokenList[6] =window.OTM_PE_Token
    data1 = getQuote(self, window.OTM_PE_Token, 'NSEFO', 1501)
    window.OTMPrice_PE = data1['LastTradedPrice']
    window.lbOTMPE.setText('%.2f'%window.OTMPrice_PE)
    recalculateATMQtyONSC(self,window)









def updateAllToken(self,window):
    subscribeToken(self,window.OTM_CE_Token,'NSEFO')
    subscribeToken(self,window.OTM_PE_Token,'NSEFO')
    subscribeToken(self,window.ATM_CE_Token,'NSEFO')
    subscribeToken(self,window.ATM_PE_Token,'NSEFO')
    subscribeToken(self,window.hedgeToken_CE,'NSEFO')
    subscribeToken(self,window.hedgeToken_PE,'NSEFO')
    window.isParachange = False




def getCETable(self,symbol,exp):
    # print('in getCETable',symbol,exp)
    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    fltr1 = np.asarray([exp])
    filteredarray2 = filteredarray[np.in1d(filteredarray[:, 6], fltr1)]
    filteredarray1 = filteredarray2[filteredarray2[:, 12].argsort()]
    fltr2 = np.asarray(['CE'])
    ceTable= filteredarray1[np.in1d(filteredarray1[:, 8], fltr2)]
    # print('ceTableeee',ceTable)
    return ceTable

def getPETable(self,symbol,exp):
    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    fltr1 = np.asarray([exp])
    filteredarray2 = filteredarray[np.in1d(filteredarray[:, 6], fltr1)]
    filteredarray1 = filteredarray2[filteredarray2[:, 12].argsort()][::-1]
    fltr2 = np.asarray(['PE'])
    peTable= filteredarray1[np.in1d(filteredarray1[:, 8], fltr2)]
    return peTable



def checkIsAnyPosition(self):
    isAnyOpenPos = False
    for i in self.position[:self.lastSerialNo,5]:
        if(i != 0):
            isAnyOpenPos = True
            self.isAnyOpenPos = isAnyOpenPos

            return
    self.isAnyOpenPos = isAnyOpenPos


    # if(np.unique(self.position[:self.lastSerialNo,5])==[0]):
    #     self.isAnyOpenPos = False

    # print('isANYposition',self.isAnyOpenPos)


def tradeVarification(self):
    pass

def updateOrder(self):
    pass

def orderVarification(self):
    pass

def getPrice(self, token, seg, streamType):
    data = getQuote(self, token, seg, streamType)
    bid = data['AskInfo']['Price']
    ask = data['BidInfo']['Price']
    ltp = data['LastTradedPrice']
    return {"bid": bid, "ask": ask, "ltp": ltp}

def dec_v(self,window):
    if (window.leQty_O.text() != '0'):
        newQ = int(window.leQty_O.text()) - window.lotsize

        window.leQty_O.setText(str(newQ))

def inc_v(self,window):
    # print('in inc_v',window.lotsize)

    newQ = int(window.leQty_O.text()) + window.lotsize
    window.leQty_O.setText(str(newQ))


def getCEList(self,ATMStrike):
    lowerRange= ATMStrike - ((self.lowerRangeIndex+1) *self.strikeDiff)
    upperRange= ATMStrike + ((self.upperRangeIndex+1) *self.strikeDiff)
    array1 = self.ceTable[np.where(self.ceTable[:, 12] >= lowerRange)]
    array2 = array1[np.where(array1[:, 12] <= upperRange)]
    array3 = array2[:, [2, 8, 12]]
    return array3

def getPEList(self,ATMStrike):
    lowerRange= ATMStrike - ((self.lowerRangeIndex+1) *self.strikeDiff)
    upperRange= ATMStrike + ((self.upperRangeIndex+1) *self.strikeDiff)
    array1 = self.peTable[np.where(self.peTable[:, 12] >= lowerRange)]
    array2 = array1[np.where(array1[:, 12] <= upperRange)]
    array3 = array2[:, [2, 8, 12]]
    # print(array3)
    return array3

def getExecutionTime(self):
    now = datetime.datetime.today()
    date = now.strftime('%Y-%m-%d ')
    a915 = datetime.datetime.strptime(date + '09:15:00', '%Y-%m-%d %H:%M:%S')
    a920 = datetime.datetime.strptime(date + self.etime, '%Y-%m-%d %H:%M:%S')
    self.timeout1 = int(a920.timestamp()-time.time())*1000
    return self.timeout1

def getFutureToken(self,symbol):
    futureToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 17]
    return futureToken

def getCashToken(self,symbol):
    # print(self.fo_contract)
    assetToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 9]

    # print(symbol,self.symbol,'getCashToken',assetToken)
    return assetToken
# def getHedgeToken(self,symbol):
#
#     hedgeToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0,]

def getStrikeDiff(self,futureToken):
    # print(self.fo_contract[futureToken-35000,:])
    strikeDiff = self.fo_contract[futureToken-35000,36]
    return strikeDiff

def getLotSize(self,futureToken):
    lotsize = self.fo_contract[futureToken-35000,11]
    return lotsize
    # print("lotsize:",lotsize)



def getATM(self,cashPrice,strikeDiff):
    ATM1 = (cashPrice / strikeDiff)
    # print(ATM1)
    frac = ATM1 % 1

    strikeDecisionPoint = float(0.4)
    # print(frac)
    if(frac > strikeDecisionPoint):
        ATM = int(ATM1+1) * strikeDiff
        # print("AAAAAA",ATM)
    else:
        ATM= int(ATM1)  * strikeDiff
    # ATM1 = (cashPrice / strikeDiff) * strikeDiff
    return ATM



def getCEPEPrice(self,cm=[],fo=[] ):
    try:

        # print('ppuuu')
        if(self.isFirstOrderPunch):
            window = self.modifyW
            # print('hedgeToken hedgeToken',self.hedgeToken)
            data1 = getQuote(self, self.hedgeToken, 'NSEFO', 1501)
            window.hedgeOptPrc = data1['LastTradedPrice']


        elif(self.isParameterSet):
            window = self.modifyW
            # print('hedgeToken hedgeToken',self.hedgeToken)

            data1 = getQuote(self, self.hedgeToken, 'NSEFO', 1501)
            # window.hedgeOptPrc = data1['LastTradedPrice']



        else:
            window = self.addW
            a = 'add'

        # if(window.visibleRegion().isEmpty() == False):
        #
        #     for i in cm:
        #         if(i==window.cashToken)
        #
        #         window.cashPrice = getPrice(self=self, token=window.cashToken, seg='NSECM', streamType=1501)['ltp']


            # print(window,'llllll')
            # window.cashPrice = getPrice(self=self,token=window.cashToken, seg='NSECM', streamType=1501)['ltp']
            # window.futurePrice =getPrice(self=self,token=window.futureToken, seg='NSEFO', streamType=1501)['ltp']
            # window.ATM = getATM(self,window.cashPrice, window.strikeDiff)
            #
            # data = getQuote(self,window.ATM_CE_Token, 'NSEFO', 1501)
            # data1= getQuote(self,window.ATM_PE_Token, 'NSEFO', 1501)
            # try:
            #     window.OTMPrc_CE = data['LastTradedPrice']
            #     window.OTMPrc_PE = data1['LastTradedPrice']
            # except:
            #     print('error in getQuote getCEPEPrice ')
            #
            #
            #
            #
            # data1 = getQuote(self, window.ATMToken, 'NSEFO', 1501)
            # window.ATMPrice = data1['LastTradedPrice']
            #
            # data = getQuote(self, window.ATM_CE_Token, 'NSEFO', 1501)
            # window.atmCEPrice = data['LastTradedPrice']
            #
            # data1 = getQuote(self, window.ATM_PE_Token, 'NSEFO', 1501)
            # window.atmPEPrice = data1['LastTradedPrice']            # print('xyz2')

    except:
        print(traceback.print_exc())


def updateValues(self):
    try:
        if(self.isFirstOrderPunch):
            window = self.modifyW
            window.lb_hedge_prc.setText('%.2f' % window.hedgeOptPrc)

        elif(self.isParameterSet):
            window = self.modifyW
            window.lb_hedge_Prc.setText('%.2f' % window.hedgeOptPrc)

        else:
            window= self.addW

        window.lb_ltp.setText(str(window.basePrice))
        window.lb_atm.setText(str(window.ATM))

        window.lbOTMCE.setText('%.2f' % window.otmCEPrice)
        window.lbOTMPE.setText('%.2f' % window.otmPEPrice)

        window.lbATMCE.setText('%.2f' % window.atmCEPrice)
        window.lbATMPE.setText('%.2f' % window.atmPEPrice)

        window.lb_CEP.setText('%.2f' % window.atmCEPrice)
        window.lb_PEP.setText('%.2f' % window.atmPEPrice)

        adjCashprice = window.cashPrice + float(window.leAdjPts.text())
        window.lbAdjCashP.setText('%.2f' % adjCashprice)

        if(window.leQty_O.text() != '' and  window.leQty_A.text() != ''):
            OTMQty =float(int(window.leQty_O.text()))
            ATMQty = int(window.leQty_A.text())


            OTMPrem = window.OTMPrice * OTMQty
            ATMPrem = window.ATMPrice * ATMQty

            window.lbOTM_Prem.setText('%.2f' % OTMPrem)
            window.lbATM_Prem.setText('%.2f' % ATMPrem)


    except:
        print(traceback.print_exc())

def getPrices(self):
    try:
        th = threading.Thread(target=getCEPEPrice,args=(self,))
        th.start()
    except:
        print(traceback.print_exc())



def get_ce_token(self,strike):
    # print("strikeeeee",strike)
    try:
        ATM_CE_Token = self.ceTable[np.where(self.ceTable[:,12]==strike),2][0][0]
        return ATM_CE_Token
    except:
        print(traceback.print_exc(),'error \n###############\n','atm',strike,'ceTable',self.ceTable,'\n###############\n')
def get_pe_token(self,atm):
    try:
        ATM_PE_Token = self.peTable[np.where(self.peTable[:,12]==atm),2][0][0]
        return ATM_PE_Token
    except:
        print(traceback.print_exc(),'error \n###############\n','atm',atm,'ceTable',self.peTable,'\n###############\n')

