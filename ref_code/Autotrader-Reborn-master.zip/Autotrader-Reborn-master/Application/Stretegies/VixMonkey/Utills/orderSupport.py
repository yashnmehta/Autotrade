from Application.Services.Xts.Api.servicesIA import PlaceOrder
import time as ttime


def makeOrder(self,token,qty,orderSide):

    try:
        while qty > self.freezeQty:
            PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=token, orderSide=orderSide,
                       qty=self.freezeQty,
                       limitPrice=0.0,
                       validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                       productType='NRML')
            ttime.sleep(0.1)

            qty -= self.freezeQty
        PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=token, orderSide=orderSide,
                   qty=qty,
                   limitPrice=0.0,
                   validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                   productType='NRML')
        ttime.sleep(0.1)
    except:
        print('make order error',type(qty),qty)
