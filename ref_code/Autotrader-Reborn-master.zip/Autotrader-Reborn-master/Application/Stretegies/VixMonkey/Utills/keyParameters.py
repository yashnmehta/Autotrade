import datetime
import time
import json
import os
import traceback
import numpy as np

from Application.Stretegies.VixMonkey.Utills.executionSupport import *


def craeteKeyParameterJson(self,cf):
    if (cf):
        open_pos = self.position[:self.lastSerialNo, :].tolist()
        # DOI = self.DOI
    else:
        open_pos = []
        # DOI = datetime.datetime.today().strftime('%d%m%Y')

    self.keyParameterJson = {
        "folioName": self.folioName,
        'clientId': self.clientId,
        "stype": self.stype,
        "symbol": self.symbol,
        'adjPts':self.adjPts,
        "Base":self.Base,
        "BaseVIX":self.BaseVIX,
        "expiry": self.expiry,
        'ATM': self.ATM,
        'trendPts': self.trendPts,
        'revPts': self.revPts,
        'Trend': self.Trend,

        'OTMqty': self.OTMqty,
        'ATMqty': self.ATMqty,

        'isTradeOnReversal': self.isTradeOnReversal,
        'OTMStrikeIndex_CE': self.OTMStrikeIndex_CE,
        'OTMStrikeIndex_PE': self.OTMStrikeIndex_PE,
        'ATMStrikeIndex_CE': self.ATMStrikeIndex_CE,
        'ATMStrikeIndex_PE': self.ATMStrikeIndex_PE,
        'HedgeStrikeIndex_CE': self.HedgeStrikeIndex_CE,
        'HedgeStrikeIndex_PE': self.HedgeStrikeIndex_PE,

        'isFirstOrderPunch': self.isFirstOrderPunch,
        'ATM_CE_Token': self.ATM_CE_Token,
        'ATM_PE_Token': self.ATM_PE_Token,
        'OTM_CE_Token': self.OTM_CE_Token,
        'OTM_PE_Token': self.OTM_PE_Token,
        'hedgeToken_CE': self.hedgeToken_CE,
        'hedgeToken_PE': self.hedgeToken_PE,



        'CE_Token_A': self.CE_Token_A,
        'PE_Token_A': self.PE_Token_A,

        'lotSize':self.lotsize,
        'freezeQty':self.freezeQty,
        'cashToken':self.cashToken,
        'futureToken':self.futureToken,
        'hedgeQty':self.hedgeQty,
        'SlAmount': self.SlAmount,
        'targetAmt': self.targetAmt,
        'fullPos':self.fullPos,
        'strikeDecisionPoint': self.strikeDecisionPoint,
        'isParameterSet' : self.isParameterSet,
        'tokenList' : self.tokenList,

        'open_position': open_pos,
        'DateOfInitialization':self.DOI,
        'hedgeStrike_PE':self.hedgeStrike_PE,
        'hedgeStrike_CE':self.hedgeStrike_CE
    }


def reloadKeyParameter(self):
    try:
        f1 = open(self.keyParameterFile)
        self.keyParameterJson = json.load(f1)
        f1.close()
        self.clientId = self.keyParameterJson['clientId']
        self.symbol = self.keyParameterJson['symbol']
        self.stype = self.keyParameterJson['stype']
        self.expiry = self.keyParameterJson['expiry']
        self.strikeDecisionPoint = self.keyParameterJson['strikeDecisionPoint']
        self.Base = self.keyParameterJson['Base']
        self.BaseVIX = self.keyParameterJson['BaseVIX']


        self.adjPts = self.keyParameterJson['adjPts']
        # self.optType = self.keyParameterJson['optType']

        self.Trend = self.keyParameterJson['Trend']

        self.trendPts = self.keyParameterJson['trendPts']
        self.isTradeOnReversal = self.keyParameterJson['isTradeOnReversal']

        self.revPts = self.keyParameterJson['revPts']
        # self.ATMStrikeIndex = self.keyParameterJson['ATMStrikeIndex']

        self.ATM = self.keyParameterJson['ATM']
        self.OTMqty = self.keyParameterJson['OTMqty']
        self.ATMqty = self.keyParameterJson['ATMqty']

        # self.OTMStrike = self.keyParameterJson['OTMStrike']


        self.OTMStrikeIndex_CE = self.keyParameterJson['OTMStrikeIndex_CE']
        self.OTMStrikeIndex_PE = self.keyParameterJson['OTMStrikeIndex_PE']

        self.ATMStrikeIndex_CE = self.keyParameterJson['ATMStrikeIndex_CE']
        self.ATMStrikeIndex_PE = self.keyParameterJson['ATMStrikeIndex_PE']

        self.HedgeStrikeIndex_CE = self.keyParameterJson['HedgeStrikeIndex_CE']
        self.HedgeStrikeIndex_PE = self.keyParameterJson['HedgeStrikeIndex_PE']


        self.ATM_CE_Token = self.keyParameterJson['ATM_CE_Token']
        self.ATM_PE_Token = self.keyParameterJson['ATM_PE_Token']

        self.OTM_CE_Token = self.keyParameterJson['OTM_CE_Token']
        self.OTM_PE_Token = self.keyParameterJson['OTM_PE_Token']

        self.hedgeToken_CE = self.keyParameterJson['hedgeToken_CE']
        self.hedgeToken_PE = self.keyParameterJson['hedgeToken_PE']


        # self.PE_Token_A = self.keyParameterJson['PE_Token_A']
        # self.PE_Token_A = self.keyParameterJson['PE_Token_A']


        self.hedgeQty = self.keyParameterJson['hedgeQty']

        # self.hedgeStrike = self.keyParameterJson['hedgeStrike']

        self.SlAmount = self.keyParameterJson['SlAmount']

        self.targetAmt = self.keyParameterJson['targetAmt']
        self.fullPos = self.keyParameterJson['fullPos']

        self.isParameterSet = self.keyParameterJson['isParameterSet']

        self.tokenList= self.keyParameterJson['tokenList']
        self.hedgeStrike_CE= self.keyParameterJson['hedgeStrike_CE']
        self.hedgeStrike_PE= self.keyParameterJson['hedgeStrike_PE']

        # self.ATMToken= self.keyParameterJson['ATMToken']
        # self.OTMToken= self.keyParameterJson['OTMToken']

        self.freezeQty = self.keyParameterJson['freezeQty']
        self.DOI = self.keyParameterJson['DateOfInitialization']

        self.isFirstOrderPunch = self.keyParameterJson['isFirstOrderPunch']
        #
        self.cashToken =getCashToken(self,self.symbol)
        self.futureToken = getFutureToken(self,self.symbol)
        self.strikeDiff = getStrikeDiff(self,self.futureToken)
        if (self.keyParameterJson['open_position'] != []):
            self.open_position = np.asarray(self.keyParameterJson['open_position'])
            updateOpenPos(self)
        self.lotsize = getLotSize(self, self.futureToken)

        data = getQuote(self, self.cashToken, 'NSECM', 1501)
        self.cashPrice = data['LastTradedPrice']
        data = getQuote(self, self.futureToken, 'NSEFO', 1501)
        self.futurePrice = data['LastTradedPrice']



        if (self.Base == 'CASH'):
            self.BaseToken = self.cashToken
            self.basePrice = self.cashPrice
        else:
            self.BaseToken = self.futureToken
            self.basePrice = self.futurePrice





        self.ceTable = getCETable(self,self.symbol, self.expiry)
        self.peTable = getPETable(self,self.symbol, self.expiry)


        self.ATM = getATM(self,self.basePrice, self.strikeDiff)
        self.CE_Token_A = get_ce_token(self,self.ATM)
        self.PE_Token_A = get_pe_token(self,self.ATM)


        # print('stretegy parameter has been set, cashToken', self.cashToken)
        # print(self.folioName,self.modifyW)
        updateModifyInfo(self)
        connectModifyWindowSlot(self)

        self.modifyW.isParachange = False
        # print('freezeQty', self.freezeQty)
    except:
        print(traceback.print_exc())


def updateOpenPos(self):

    for i in self.open_position:
        # print(i)
        # fltr = [i[1]]
        rowarray = np.where(self.position[:self.lastSerialNo, 1]== i[1])[0]




        if(rowarray.size!=0):

            rowNO=rowarray[0]

            filteredArray = self.position[np.where(self.position[:self.lastSerialNo, 1] == i[1])][0]

            openQty=i[5] + filteredArray[5]
            openamt=i[8] +filteredArray[8]

            editList=[5,8,11,12,13,14]
            self.position[rowNO, editList] = [openQty,openamt,openQty,openamt,0.0,0.0]

        else:
            self.position[self.lastSerialNo]=[i[0],i[1],i[2],i[3],i[4],i[5],i[6],i[7],i[8],i[9],i[10],i[5],i[8],0.0,0.0]
            self.lastSerialNo+=1

        checkIsAnyPosition(self)

        if(i[5]>0):
            sellQ=i[5]
            buyQ=0
        else:
            sellQ = 0
            buyQ = i[5]
        data=[self.userID,self.clientId, self.stype,self.folioName,i[0],i[1],'stockname',i[2],self.expiry,i[3],i[4],i[5],0.0,
              i[5],i[8],0.0,buyQ,0.0,sellQ,0.0,0.0,0.0, self.lotsize,self.freezeQty,i[8],0,0.0]
        self.sgFolioOpenPos.emit(data)

def saveJson(self,cf=False):
    getKeyParameterFile(self,self.folioName)
    craeteKeyParameterJson(self,cf)
    f2 = open(self.keyParameterFile, 'w')
    jInfo_new = json.dumps(self.keyParameterJson, indent=4)
    f2.write(jInfo_new)
    f2.close()


# def getKeyParameterFile(self, folioName):
#     todate = datetime.datetime.today().strftime('%Y%m%d')
#     loc = os.getcwd().split('Application')
#     self.keyParameterFile = os.path.join(loc[0], 'Application', 'DB', 'Stretegy_data', todate,
#                                          '%s.json' % folioName)
def getKeyParameterFile(self,folioName):
    todate = datetime.today().strftime('%Y%m%d')
    loc = os.getcwd().split('Application')
    self.keyParameterFile = os.path.join(loc[0], 'Application', 'DB', 'Stretegy_data', todate,
                                         '%s.json' % folioName)
