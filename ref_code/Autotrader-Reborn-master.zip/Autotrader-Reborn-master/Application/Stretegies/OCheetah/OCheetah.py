import os
import threading
import traceback
import json
from PyQt5.QtCore import QObject,QTimer,pyqtSignal
from PyQt5.QtGui import QKeySequence
from Application.Stretegies.OCheetah.Utills.squareOff import squreOff
from Application.Stretegies.OCheetah.Views.addW import addW
from Application.Stretegies.OCheetah.Views.modifyW import modifyW
import numpy as np
import datatable as dt
from Application.Services.Xts.Api.servicesIA import PlaceOrder
import datetime
import time
from Application.Services.Xts.Api.servicesMD import getQuote
from Application.Utils.configReader import refresh
from Application.Stretegies.OCheetah.Utills.keyParameters import reloadKeyParameter, getKeyParameterFile, saveJson
from Application.Stretegies.OCheetah.Utills.eventsBind import eventsBind
from Application.Stretegies.OCheetah.Utills.timer import createTimer
from Application.Stretegies.OCheetah.Utills.positionSupport import *
from Application.Stretegies.OCheetah.Utills.orderSupport import *
from Application.Stretegies.OCheetah.Utills.executionSupport import *
from Application.Stretegies.OCheetah.Utills.checkTrade import *
from Application.Stretegies.OCheetah.Utills.setParameters import *
from Application.Stretegies.OCheetah.Utills.inactiveOMSSupport import *
from Application.Stretegies.OCheetah.Utills.strategyOp import addNew

class logic(QObject):
    sgMTM = pyqtSignal(str,float)
    sgSL = pyqtSignal(str, float)
    sgAlert = pyqtSignal(str)
    sgParamSet = pyqtSignal()
    sgParamModify = pyqtSignal()
    sgStart = pyqtSignal()
    sgActivate =pyqtSignal()
    sgStop = pyqtSignal()
    sgClose =pyqtSignal()
    sgFolioOpenPos = pyqtSignal(list)
    sgTarget = pyqtSignal(str, float)
    sgSlPts = pyqtSignal(str, float)
    sgtrendPts = pyqtSignal(str, float)
    sgRevPts = pyqtSignal(str, float)
    ################################# Intialization Here ##################################################
    def __init__(self):
        super(logic, self).__init__()

        self.position = np.zeros((100, 15), dtype=object)
        # print("ffffff",self.position )
        self.posHeads = ['exch',
                         'token', 'symbol', 'strike', 'c/p', 'netqty',
                         'requestedOrder', 'openOrder', 'netamt', 'ltp', 'mtm',
                         'OpenQty', 'OpenAmt', 'DQty', 'Damt']

        self.addW = addW(self)
        self.modifyW = modifyW(self)
        self.setAllShortCut()
        self.initVaribles()

    def flushTradeData(self):
        self.position = np.zeros((100,11),dtype=object)
    def initVaribles(self):
        # print("OCheetah ----")
        self.stype = 'OCheetah'
        self.isStart = False
        self.isClose = False
        self.isFirstOrderPunch = False
        self.isParameterSet = False
        self.executionRunning =False
        self.isAnyOpenPos = False
        self.lastSerialNo = 0

        self.lastOrderPoint = 0
        self.isSlHitOnce = False
        self.isAnyOpenPos = False

        self.preSl1PtsValCE = 0
        self.preSl2PtsValCE = 0
        self.preSl3PtsValCE = 0

        self.preSl1PtsValPE = 0
        self.preSl2PtsValPE = 0
        self.preSl3PtsValPE = 0

        self.cashPrice = 0.0
        self.futPrice = 0.0
        self.ATM = 0.0
        self.baseStrike = 0.0
        self.basePrice = 0.0
        self.strikeDiff = 0.0
        self.pairTotal = 0.0
        self.baseQty = 0
        self.tsl = 0.0
        self.SlAmount = 0
        self.targetAmt = 0
        self.mtm = 0.0
        self.lastOrderSerialNo = 0
        self.iomslastOrderSerialNo = 0
        self.OMS = []
        self.inactiveOMS = []

        self.isSLCE = False
        self.isSLPE = False

        self.lotsize = 0
        self.DOI = datetime.datetime.today().strftime('%d%m%Y')

        self.tokenList = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        self.incrementSl = 0.0

        """        # tokenlist  
                            0 cashToken  
                            1 futureToken
                            2 Actual ATM CE
                            3 Actual ATM PE
                            4 ATM CE Token
                            5 ATM PE Token                                
                            6 hedge Token CE
                            7 hedge Token PE


        """
    def setAllShortCut(self):
        # print("parthhhhhhhhhhhhh")
        self.addW.leQty.sc_up = QShortcut(QKeySequence('Up'),self.addW.leQty)
        self.addW.leQty.sc_up.setContext(Qt.WidgetWithChildrenShortcut)
        self.addW.leQty.sc_up.activated.connect(lambda:inc_v(self,self.addW))
        self.addW.leQty.sc_down = QShortcut(QKeySequence('Down'), self.addW.leQty)
        self.addW.leQty.sc_down.setContext(Qt.WidgetWithChildrenShortcut)
        self.addW.leQty.sc_down.activated.connect(lambda :dec_v(self,self.addW))


        self.modifyW.leQty.sc_up = QShortcut(QKeySequence('Up'),self.modifyW.leQty)
        self.modifyW.leQty.sc_up.setContext(Qt.WidgetWithChildrenShortcut)
        self.modifyW.leQty.sc_up.activated.connect(lambda:inc_v(self,self.modifyW))
        self.modifyW.leQty.sc_down = QShortcut(QKeySequence('Down'), self.modifyW.leQty)
        self.modifyW.leQty.sc_down.setContext(Qt.WidgetWithChildrenShortcut)
        self.modifyW.leQty.sc_down.activated.connect(lambda:dec_v(self,self.modifyW))
    #

    def createTimer(self):
        createTimer(self)


    def createObject(self,fo_contract):
        try:
            self.fo_contract=fo_contract

            refresh(self)
            refresh(self.addW)
            refresh(self.modifyW)

            self.addW.getSymbolList(self.fo_contract)
            self.addW.cbSymbol.setCurrentText('BANKNIFTY')
            self.symbol = self.addW.cbSymbol.currentText()
            self.addW.getOptionExpiryList(self.fo_contract)
            eventsBind(self)
            self.createTimer()
        except:
            print(traceback.print_exc())

    def reloadKeyParameter(self):
        try:
            reloadKeyParameter(self)
        except:
            print(traceback.print_exc())


    def checkSL(self):
        if(self.isSlHitOnce==False and self.SlAmount != 0 ):
            if(self.mtm<=self.SlAmount):
                print('trgger sl', self.mtm, self.SlAmount)
                self.isSlHitOnce = True
                self.squreOff()
                print("SQureOf Parthhhhhhh!!!! ")
                d = {'MTM': self.mtm, 'SlAmount': self.SlAmount}
                self.Slogger.info('SL Trigger (mtm>Slamt)....', d)

    def checkTarget(self):
        if (self.isSlHitOnce == False):
            if (self.mtm >= self.targetAmt):
                self.isSlHitOnce = True
                self.squreOff()
                d = {'MTM': self.mtm, 'SlAmount': self.targetAmount}
                self.Slogger.info('Target Trigger (mtm>targetAmt)....', d)

    def updateMTM(self,data):
        if(self.isAnyOpenPos == True):
            if (data['Token'] in self.position[:,1]):
                fltr0 = np.asarray([data['Token']])
                array = self.position[np.in1d(self.position[:, 1], fltr0)][0]
                # print(array)
                netAmt = array[8]
                ltp = data['LTP']
                qty = array[5]
                mtm = netAmt + (qty * ltp)
                self.position[np.in1d(self.position[:, 1], fltr0),[9,10]] = [ltp,mtm]
                # print(self.position[np.in1d(self.position[:, 1], fltr0)][0])
                total_mtm = np.sum(self.position[:,10])
                self.mtm = total_mtm
                self.sgMTM.emit(self.folioName,total_mtm)
                # print('emited')
                self.modifyW.leMTM.setText('%.2f'%total_mtm)
                self.checkSL()
                self.checkTarget()


    def setParameters( self):
        setParameters(self,self.addW)


    def setLTP(self, window):
        self.cashPrice = float(window.leLTP.text())
        self.cePrice = float(window.lbCEPrice.text())
        self.pePrice = float(window.lbPEPrice.text())
        # print("cashPrice:", self.cashPrice, "lst order point:", self.lastOrderPoint)

    def modifyParameter(self,window):
        print("hhhhhhyyyyyyyyyyyy")
        try:
            if (self.isFirstOrderPunch == False):
                self.setParametersModify(self.modifyW)
                print("modify OCheetah!!!!")
            else:
                print("MODIFY ORDER")

                self.S1QtyCE = float(window.leS1QtyCE.text())
                self.S2QtyCE = float(window.leS2QtyCE.text())
                self.S3QtyCE = float(window.leS3QtyCE.text())

                self.S1QtyPE = float(window.leS1QtyPE.text())
                self.S2QtyPE = float(window.leS2QtyPE.text())
                self.S3QtyPE = float(window.leS3QtyPE.text())

                window.S1PtsCE = float(window.leS1PtsCE.text())
                window.S2PtsCE = float(window.leS2PtsCE.text())
                window.S3PtsCE = float(window.leS3PtsCE.text())

                window.S1PtsPE = float(window.leS1PtsPE.text())
                window.S2PtsPE = float(window.leS2PtsPE.text())
                window.S3PtsPE = float(window.leS3PtsPE.text())

                if window.S1PtsCE != self.S1PtsCE:
                    self.S1PtsCE = window.S1PtsCE
                    self.Sl1TimesCE = self.SlTimes

                if window.S2PtsCE != self.S2PtsCE:
                    self.S2PtsCE = window.S2PtsCE
                    self.Sl2TimesCE = self.SlTimes

                if window.S3PtsCE != self.S3PtsCE:
                    self.S3PtsCE = window.S3PtsCE
                    self.Sl3TimesCE = self.SlTimes

                if window.S1PtsPE != self.S1PtsPE:
                    self.S1PtsPE = window.S1PtsPE
                    self.Sl1TimesPE = self.SlTimes

                if window.S2PtsPE != self.S2PtsPE:
                    self.S2PtsPE = window.S2PtsPE
                    self.Sl2TimesPE = self.SlTimes

                if window.S3PtsPE != self.S3PtsPE:
                    self.S3PtsPE = window.S3PtsPE
                    self.Sl3TimesPE = self.SlTimes


                self.slAgainPtsCE = window.leSLAgainPtsCE.text()
                self.slAgainPtsPE = window.leSLAgainPtsPE.text()

                self.Sl1PtsValCE = self.firstCEPrice + self.S1PtsCE
                self.Sl2PtsValCE = self.firstCEPrice + self.S2PtsCE
                self.Sl3PtsValCE = self.firstCEPrice + self.S3PtsCE

                self.Sl1PtsValPE = self.firstPEPrice + self.S1PtsPE
                self.Sl2PtsValPE = self.firstPEPrice + self.S2PtsPE
                self.Sl3PtsValPE = self.firstPEPrice + self.S3PtsPE

                self.SlAmount = float(window.leSLAmount.text())
                self.sgSL.emit(self.folioName, self.SlAmount)

                self.targetAmt = float(window.leTargetAmount.text())
                self.sgTarget.emit(self.folioName, self.targetAmt)

                self.sgParamModify.emit()
                saveJson(self)
                self.hideModifyW()
        except:
            traceback.print_exc()

    def setParametersModify(self,window):
        setParametersModify(self,window)

    def saveJson(self, cf = False):
        saveJson(self, cf)
    def getKeyParameterFile(self, folioName):
        getKeyParameterFile(self, folioName)

    def addNew(self, main):
        return addNew(self,main)

    def updateTrade(self, trade, source='on_trade'):

        # print('in update position stretegy,',trade)
        if (source == "on_trade"):
            trade1 = trade[0]
        else:
            trade1 = trade

        if (trade1[15] == self.folioName):

            exchange = trade1[20]
            token = trade1[2]
            fltr0 = np.asarray([token])
            filteredArray0 = self.position[np.in1d(self.position[:, 1], fltr0)]
            isRecordExist = False
            if (filteredArray0.size != 0):
                isRecordExist = True

            if (isRecordExist):
                array = self.position[np.where(self.position[:, 1] == token)]
                # print('in is record exist',array)
                prev_qty = array[0][5]
                prev_amt = array[0][8]

                Prev_Dqty = array[0][13]
                Prev_Damt = array[0][14]

                Dqty = Prev_Dqty + trade1[18]
                DAmt = Prev_Damt + trade1[19]

                newQty = prev_qty + trade1[18]
                newAmt = prev_amt + trade1[19]

                self.position[np.where(self.position[:, 1] == token), [5, 8, 13, 14]] = [newQty, newAmt, Dqty, DAmt]

            else:
                new = dt.Frame([[exchange],
                                [token], [trade1[4]], [float(trade1[6])], [trade1[7]], [trade1[18]],
                                [0], [0], [trade1[19]], [trade1[17]], [0.0],
                                [0.0], [0.0], [trade1[18]], [trade1[19]]
                                ]).to_numpy()


                self.position[self.lastSerialNo, :] = new
                self.lastSerialNo += 1

            checkIsAnyPosition(self)


    def makeFirstOrder(self):
        makeFirstOrder(self)

    def checkTrade(self,priceFeed):
        checkTrade(self,priceFeed)


    def getPrice(self, token, seg, streamType):
        data = getQuote(self, token, seg, streamType)
        bid = data['AskInfo']['Price']
        ask = data['BidInfo']['Price']
        ltp = data['LastTradedPrice']
        return {"bid": bid, "ask": ask, "ltp": ltp}


    def getExecutionTime(self):
        now = datetime.datetime.today()
        date = now.strftime('%Y-%m-%d ')
        a915 = datetime.datetime.strptime(date + '09:15:00', '%Y-%m-%d %H:%M:%S')
        a920 = datetime.datetime.strptime(date + self.etime, '%Y-%m-%d %H:%M:%S')
        self.timeout1 = int(a920.timestamp()-time.time())*1000
        return self.timeout1

    def updateOrder(self, order, orderDict):
        pass

    def getStrikeDiff(self,futureToken):
        # print(self.fo_contract[futureToken-35000,:])
        strikeDiff = self.fo_contract[futureToken-35000,36]
        return strikeDiff

    def hideAddW(self):
        try:
            self.timerUpdateWindows.stop()
            self.addW.hide()
        except:
            print(traceback)
    def hideModifyW(self):
        self.timerUpdateWindows.stop()
        self.modifyW.hide()

    def updateWindows(self, feed, window):
        priceToken = feed['Token']
        if (window.isParachange == False):
            if (window.visibleRegion().isEmpty() == False):

                if (priceToken == self.tokenList[0]):
                    if (window.cashFut == 'CASH'):
                        window.baseToken = window.cashToken
                        window.cashPrice = feed['LTP']
                        window.basePrice = window.cashPrice
                        if (self.isFirstOrderPunch == False):
                            ATM = getATM(self, window.basePrice, window.strikeDiff)
                            if (ATM != window.ATM):
                                window.ATM = ATM
                                window.lb_atm.setText(str(window.ATM))
                                window.ATMCEToken = getATM_CE_Token(self, window.ATM, window.ceTable)
                                window.ATMPEToken = getATM_PE_Token(self, window.ATM, window.peTable)
                                self.tokenList[2] = window.ATMCEToken
                                self.tokenList[3] = window.ATMPEToken

                        window.lb_ltp.setText(str(window.basePrice))



                elif (priceToken == self.tokenList[1]):
                    if (window.cashFut != 'CASH'):
                        window.baseToken = window.futureToken
                        window.futPrice = feed['LTP']
                        window.basePrice = window.futPrice
                        ATM = getATM(self, window.basePrice, window.strikeDiff)
                        if (self.isFirstOrderPunch == False):
                            if (ATM != window.ATM):
                                window.ATM = ATM
                                window.lb_atm.setText(str(window.ATM))
                                window.ATMCEToken = getATM_CE_Token(self, window.ATM, window.ceTable)
                                window.ATMPEToken = getATM_PE_Token(self, window.ATM, window.peTable)
                                self.tokenList[2] = window.ATMCEToken
                                self.tokenList[3] = window.ATMPEToken

                        window.lb_ltp.setText(str(window.basePrice))


                elif (priceToken == self.tokenList[2]):
                    window.atmcePrice = feed['LTP']
                    window.lbATMCE.setText('%.2f' % window.atmcePrice)
                    if (priceToken == self.tokenList[4]):
                        window.cePrice = feed['LTP']
                        window.lbcePrice.setText('%.2f' % window.cePrice)

                elif (priceToken == self.tokenList[3]):
                    window.atmpePrice = feed['LTP']
                    window.lbATMPE.setText('%.2f' % window.atmpePrice)

                    if (priceToken == self.tokenList[5]):
                        window.pePrice = feed['LTP']
                        window.lbpePrice.setText('%.2f' % window.pePrice)

                elif (priceToken == self.tokenList[4]):
                    window.ATMcePrice = feed['LTP']
                    window.lbcePrice.setText('%.2f' % window.ATMcePrice)

                elif (priceToken == self.tokenList[5]):
                    window.ATMpePrice = feed['LTP']
                    window.lbcePrice.setText('%.2f' % window.ATMpePrice)

    def getCEPEPrice(self):
        try:
            # print('xyz1')
            data = getQuote(self,self.addW.ATM_CE_Token, 'NSEFO', 1501)
            self.addW.atmCEPrice = data['LastTradedPrice']

            data1 = getQuote(self, self.addW.ATM_PE_Token, 'NSEFO', 1501)
            self.addW.atmPEPrice = data1['LastTradedPrice']
            # print('xyz2')
        except:
            print(traceback.print_exc())

    def updateValues(self):
        try:
            print('abc')
            self.addW.lb_ltp_cash.setText(str(self.addW.cashPrice))
            self.addW.lb_ltp_fo.setText(str(self.addW.futPrice))
            self.addW.lb_atm.setText(str(self.addW.ATM))
            self.addW.lbCEPrice.setText(str(self.addW.atm_ce_strike))
            self.addW.lbPEPrice.setText(str(self.addW.atm_pe_strike))

            self.addW.ATM_CE_Token=self.getATM_CE_Token(self.addW.ATM,self.addW.ceTable)
            self.addW.ATM_PE_Token=self.getATM_PE_Token(self.addW.ATM,self.addW.peTable)



        except:
            print(traceback.print_exc())

    def getPrices(self):
        try:
            th = threading.Thread(target=self.getCEPEPrice,args=())
            th.start()
        except:
            print(traceback.print_exc())

    def getBaseInfo(self, window):
        getBaseInfo(self, window)
        # getBaseInfo(self)

    def getBasePrices(self):
        try:
            data = getQuote(self, self.addW.cashToken, 'NSECM', 1501)
            self.addW.cashPrice=data['LastTradedPrice']
            data = getQuote(self, self.addW.futureToken, 'NSEFO', 1501)
            self.addW.futPrice=data['LastTradedPrice']

            self.addW.ATM = self.getATM(self.addW.cashPrice,self.addW.strikeDiff)

            self.addW.ceTable = self.getCETable(self.addW.symbol,self.addW.expiry)
            self.addW.peTable = self.getPETable(self.addW.symbol,self.addW.expiry)
            self.updateValues()
        except:
            print(traceback.print_exc())
    def flushTradeData(self):
        self.position = np.zeros((100,11),dtype=object)


    def checkShortPosExist(self,array):
        isPos =False
        # print('array',array)
        for i in array[0]:
            if(i < 0):
                isPos = True
                return isPos
        return isPos


    def squreOff(self):
        squreOff(self)

    def updateSl1CEP(self,window):
        updateSl1CEP(self,window)
    def updateSl2CEP(self,window):
        updateSl2CEP(self,window)
    def updateSl3CEP(self,window):
        updateSl3CEP(self,window)

    def updateSl1PEP(self,window):
        updateSl1PEP(self,window)
    def updateSl2PEP(self,window):
        updateSl2PEP(self,window)
    def updateSl3PEP(self,window):
        updateSl3PEP(self,window)

    def getStrikeOT(self,token):
        data=self.fo_contract[token-35000,:]
        return data[7],data[8]
