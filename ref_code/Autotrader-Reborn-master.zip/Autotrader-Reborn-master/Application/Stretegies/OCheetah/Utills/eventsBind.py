'''
bind events
'''
from Application.Stretegies.OCheetah.Utills.executionSupport import updateATMCEToken, updateAllToken, symchange, \
    baseChange, expchange, updateModifyInfo
from Application.Stretegies.OCheetah.Utills.executionSupport import updateATMPEToken

def eventsBind(self):

    self.sgParamModify.connect(lambda : updateModifyInfo(self))

    self.addW.pbApply.clicked.connect(self.setParameters)
    self.addW.cbSymbol.currentIndexChanged.connect(lambda: self.addW.getOptionExpiryList(self.fo_contract))
    self.addW.cbSymbol.currentTextChanged.connect(lambda: symchange(self, self.addW))
    self.addW.cbCF.currentIndexChanged.connect(lambda: baseChange(self, self.addW))
    self.addW.cbExp.currentTextChanged.connect(lambda:expchange(self,self.addW))
    self.addW.pbGet.clicked.connect(lambda : self.getBaseInfo(self.addW))
    self.addW.cbStrike_CE.currentIndexChanged.connect(lambda: updateATMCEToken(self, self.addW))
    self.addW.cbStrike_PE.currentIndexChanged.connect(lambda: updateATMPEToken(self, self.addW))
    self.addW.pbGetLive.clicked.connect(lambda: updateAllToken(self, self.addW))

    self.modifyW.pbApply.clicked.connect(lambda : self.modifyParameter(self.modifyW))
    self.modifyW.pbGet.clicked.connect(lambda: self.getBaseInfo(self.modifyW))
    self.modifyW.pbSetLTP.clicked.connect(lambda : self.setLTP(self.modifyW))

    self.modifyW.leS1PtsCE.textChanged.connect(lambda: self.updateSl1CEP(self.modifyW))
    self.modifyW.leS2PtsCE.textChanged.connect(lambda: self.updateSl2CEP(self.modifyW))
    self.modifyW.leS3PtsCE.textChanged.connect(lambda: self.updateSl3CEP(self.modifyW))

    self.modifyW.leS1PtsPE.textChanged.connect(lambda: self.updateSl1PEP(self.modifyW))
    self.modifyW.leS2PtsPE.textChanged.connect(lambda: self.updateSl2PEP(self.modifyW))
    self.modifyW.leS3PtsPE.textChanged.connect(lambda: self.updateSl3PEP(self.modifyW))


