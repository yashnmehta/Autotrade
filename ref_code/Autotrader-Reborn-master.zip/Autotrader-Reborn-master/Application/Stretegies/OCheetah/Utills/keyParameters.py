import json
import datetime
import os
import numpy as np
import traceback
from Application.Stretegies.OCheetah.Utills.executionSupport import *
from Application.Stretegies.OCheetah.Utills.executionSupport import getLotSize, updateModifyInfo

'''
To save key parameters to json file
'''
def saveJson(self,cf=False):
    getKeyParameterFile(self,self.folioName)
    createKeyParameterJson(self,cf)
    file = open(self.keyParameterFile, 'w')
    jInfo_new = json.dumps(self.keyParameterJson, indent=4)
    file.write(jInfo_new)
    file.close()

'''
create key parameters
'''
def createKeyParameterJson(self,cf):
    if (cf):
        open_pos =self.position[:self.lastSerialNo, :].tolist()
        # inactiveOMS = self.inactiveOMS[:self.lastSerialNo, :].tolist()
        DOI=self.DOI
    else:
        open_pos = []
        DOI = datetime.datetime.today().strftime('%d%m%Y')
        # inactiveOMS = self.inactiveOMS[:self.lastSerialNo, :].tolist()
    self.keyParameterJson = {
    'folioName' : self.folioName,
    'clientId':self.clientId,
    "stype": self.stype,
    'symbol':self.symbol,
    'expiry':self.expiry,
    'baseToken':self.baseToken,
    'basePrice':self.basePrice,
    'cashToken':self.cashToken,
    'futureToken':self.futureToken,
    'cashPrice':self.cashPrice,
    'futPrice':self.futPrice,
    'strikeDiff':self.strikeDiff,
    'ATM':self.ATM,
    'ATMCEToken':self.ATMCEToken,
    'atmcePrice':self.atmcePrice,
    'atmpePrice':self.atmpePrice,
    'ceToken':self.ceToken,
    'peToken':self.peToken,
    'ceStrike':self.ceStrike,
    'peStrike':self.peStrike,
    'cePrice':self.cePrice,
    'pePrice':self.pePrice,
    'atmIdx':self.atmIdx,
    'ceIdx':self.ceIdx,
    'peIdx':self.peIdx,
    'qty':self.qty,
    'freezeQty':self.freezeQty,

    "qty" : self.baseQty,
    "SlAmount" : self.SlAmount,
    "targetAmt" : self.targetAmt,
    "lastSerialNo" :  self.lastSerialNo,

    "ceHighPrice" :  self.ceHighPrice,
    "peHighPrice" :  self.peHighPrice,

    "IncrementSl" : self.incrementSl,
    'SlTimes': self.SlTimes,

    'Sl1TimesCE': self.Sl1TimesCE,
    'Sl2TimesCE': self.Sl2TimesCE,
    'Sl3TimesCE': self.Sl3TimesCE,

    'Sl1TimesPE': self.Sl1TimesPE,
    'Sl2TimesPE': self.Sl2TimesPE,
    'Sl3TimesPE': self.Sl3TimesPE,

    "Sl1PtsValCE": self.cePrice + self.S1PtsCE,
    "Sl2PtsValCE": self.cePrice + self.S2PtsCE,
    "Sl3PtsValCE": self.cePrice + self.S3PtsCE,

    "Sl1PtsValPE": self.pePrice + self.S1PtsPE,
    "Sl2PtsValPE": self.pePrice + self.S2PtsPE,
    "Sl3PtsValPE": self.pePrice + self.S3PtsPE,

    "S1QtyCE": self.S1QtyCE,
    "S2QtyCE": self.S2QtyCE,
    "S3QtyCE": self.S3QtyCE,

    "S1QtyPE": self.S1QtyPE,
    "S2QtyPE": self.S2QtyPE,
    "S3QtyPE": self.S3QtyPE,

    "S1PtsCE": self.S1PtsCE,
    "S2PtsCE": self.S2PtsCE,
    "S3PtsCE": self.S3PtsCE,

    "S1PtsPE": self.S1PtsPE,
    "S2PtsPE": self.S2PtsPE,
    "S3PtsPE": self.S3PtsPE,

    "ceQTY": self.ceQTY,
    "peQTY": self.peQTY,
    "ATM": self.ATM,
    "baseStrike" : self.baseStrike,
    "lastOrderPoint": self.lastOrderPoint,
    "Base" : self.Base,
    'open_position': open_pos,

    'ceLastOrderPunchPrice': self.ceLastOrderPunchPrice,
    'peLastOrderPunchPrice': self.peLastOrderPunchPrice,

    'flagS1CE' : self.flagS1CE,
    'flagS2CE':self.flagS2CE,
    'flagS3CE' : self.flagS3CE,
    'flagS1PE' : self.flagS1PE,
    'flagS2PE':self.flagS2PE,
    'flagS3PE': self.flagS3PE,
    'slAgainPtsCE' : self.slAgainPtsCE,
    'slAgainPtsPE': self.slAgainPtsPE,
    'isSLCE': self.isSLCE,
    'isSLPE': self.isSLPE,
    'DateOfInitialization': DOI,
    "lastOrderSerialNo" : self.lastOrderSerialNo,
    'isFirstOrderPunch': self.isFirstOrderPunch,
    'isAnyOpenPos':   self.isAnyOpenPos,
    "firstCEPrice": self.firstCEPrice,
    "firstPEPrice": self.firstPEPrice,

    }
 
'''
fetch key parameters
'''
def getKeyParameterFile(self,folioName):
    todate = datetime.datetime.today().strftime('%Y%m%d')
    loc = os.getcwd().split('Application')
    self.keyParameterFile = os.path.join(loc[0], 'Application', 'DB', 'Stretegy_data', todate,
                                         '%s.json' % folioName)
'''
reload key parameters from file
'''
def reloadKeyParameter(self):
    try:
        # fetch json object from  file
        file = open(self.keyParameterFile)
        self.keyParameterJson = json.load(file)
        file.close()
        # assign parameters
        self.stype = self.keyParameterJson['stype']
        self.symbol = self.keyParameterJson['symbol']
        self.expiry = self.keyParameterJson['expiry']
        self.clientId = self.keyParameterJson['clientId']
        self.folioName = self.keyParameterJson['folioName']
        self.isFirstOrderPunch = self.keyParameterJson['isFirstOrderPunch']
        self.isAnyOpenPos = self.keyParameterJson['isAnyOpenPos']

        self.baseToken = self.keyParameterJson['baseToken']
        self.basePrice = self.keyParameterJson['basePrice']

        self.cashToken = self.keyParameterJson['cashToken']
        self.futureToken = self.keyParameterJson['futureToken']
        self.strikeDiff = self.keyParameterJson['strikeDiff']

        self.ATM = self.keyParameterJson['ATM']
        self.atmIdx = self.keyParameterJson['atmIdx']
        self.ATMCEToken = self.keyParameterJson['ATMCEToken']
        self.atmcePrice = self.keyParameterJson['atmcePrice']
        self.atmpePrice = self.keyParameterJson['atmpePrice']

        self.ceStrike = self.keyParameterJson['ceStrike']
        self.peStrike = self.keyParameterJson['peStrike']
        self.ceToken = self.keyParameterJson['ceToken']
        self.peToken = self.keyParameterJson['peToken']
        self.cePrice = self.keyParameterJson['cePrice']
        self.firstCEPrice = self.keyParameterJson['firstCEPrice']
        self.pePrice = self.keyParameterJson['pePrice']
        self.firstPEPrice = self.keyParameterJson['firstPEPrice']

        self.ceIdx = self.keyParameterJson['ceIdx']
        self.peIdx = self.keyParameterJson['peIdx']

        self.slAgainPtsCE = self.keyParameterJson['slAgainPtsCE']
        self.slAgainPtsPE = self.keyParameterJson['slAgainPtsPE']
        self.freezeQty = self.keyParameterJson['freezeQty']
        self.qty = self.keyParameterJson['qty']
        self.baseQty = self.keyParameterJson['qty']
        self.SlAmount = self.keyParameterJson['SlAmount']
        self.targetAmt = self.keyParameterJson['targetAmt']

        self.ceHighPrice = self.keyParameterJson['ceHighPrice']
        self.peHighPrice = self.keyParameterJson['peHighPrice']
        self.lastSerialNo = self.keyParameterJson['lastSerialNo']
        self.lastOrderSerialNo = self.keyParameterJson['lastOrderSerialNo']

        self.incrementSl = self.keyParameterJson['IncrementSl']
        self.SlTimes = self.keyParameterJson['SlTimes']

        self.Sl1TimesCE = self.keyParameterJson['Sl1TimesCE']
        self.Sl2TimesCE = self.keyParameterJson['Sl2TimesCE']
        self.Sl3TimesCE = self.keyParameterJson['Sl3TimesCE']

        self.Sl1TimesPE = self.keyParameterJson['Sl1TimesPE']
        self.Sl2TimesPE = self.keyParameterJson['Sl2TimesPE']
        self.Sl3TimesPE = self.keyParameterJson['Sl3TimesPE']

        self.S1QtyCE = self.keyParameterJson['S1QtyCE']
        self.S2QtyCE = self.keyParameterJson['S2QtyCE']
        self.S3QtyCE = self.keyParameterJson['S3QtyCE']

        self.S1QtyPE = self.keyParameterJson['S1QtyPE']
        self.S2QtyPE = self.keyParameterJson['S2QtyPE']
        self.S3QtyPE = self.keyParameterJson['S3QtyPE']

        self.S1PtsCE = self.keyParameterJson['S1PtsCE']
        self.S2PtsCE = self.keyParameterJson['S2PtsCE']
        self.S3PtsCE = self.keyParameterJson['S3PtsCE']

        self.S1PtsPE = self.keyParameterJson['S1PtsPE']
        self.S2PtsPE = self.keyParameterJson['S2PtsPE']
        self.S3PtsPE = self.keyParameterJson['S3PtsPE']

        self.ceQTY = self.keyParameterJson['ceQTY']
        self.peQTY = self.keyParameterJson['peQTY']

        self.Sl1PtsValCE = self.keyParameterJson['Sl1PtsValCE']
        self.Sl2PtsValCE = self.keyParameterJson['Sl2PtsValCE']
        self.Sl3PtsValCE = self.keyParameterJson['Sl3PtsValCE']

        self.Sl1PtsValPE = self.keyParameterJson['Sl1PtsValPE']
        self.Sl2PtsValPE = self.keyParameterJson['Sl2PtsValPE']
        self.Sl3PtsValPE = self.keyParameterJson['Sl3PtsValPE']

        self.flagS1CE = self.keyParameterJson['flagS1CE']
        self.flagS2CE = self.keyParameterJson['flagS2CE']
        self.flagS3CE = self.keyParameterJson['flagS3CE']

        self.flagS1PE = self.keyParameterJson['flagS1PE']
        self.flagS2PE = self.keyParameterJson['flagS2PE']
        self.flagS3PE = self.keyParameterJson['flagS3PE']

        self.ceLastOrderPunchPrice = self.keyParameterJson['ceLastOrderPunchPrice']
        self.peLastOrderPunchPrice = self.keyParameterJson['peLastOrderPunchPrice']

        self.baseStrike = self.keyParameterJson['baseStrike']
        self.lastOrderPoint = self.keyParameterJson['lastOrderPoint']
        self.DOI = self.keyParameterJson['DateOfInitialization']
        self.Base = self.keyParameterJson['Base']
        self.cashToken = getCashToken(self, self.symbol)
        self.futureToken = getFutureToken(self, self.symbol)
        self.strikeDiff = getStrikeDiff(self, self.futureToken)
        self.freezeQty = int(self.fo_contract[self.futureToken - 35000, 14])
        self.ceTable = getCETable(self, self.symbol, self.expiry)
        self.peTable = getPETable(self, self.symbol, self.expiry)



        self.ceToken = self.ceTable[np.where(self.ceTable[:, 12] == self.ceStrike), 2][0][0]
        self.peToken = self.peTable[np.where(self.peTable[:, 12] == self.peStrike), 2][0][0]
        self.cashPrice = getPrice(self, token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
        self.futPrice = getPrice(self, token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
        if (self.keyParameterJson['open_position'] != []):
            self.open_position = np.asarray(self.keyParameterJson['open_position'], dtype=object)
            updateOpenPos(self)

        self.lotsize = getLotSize(self, self.futureToken)

        data = getQuote(self, self.cashToken, 'NSECM', 1501)
        self.cashPrice = data['LastTradedPrice']
        data = getQuote(self, self.futureToken, 'NSEFO', 1501)
        self.futPrice = data['LastTradedPrice']

        if (self.Base == 'CASH'):
            self.baseToken = self.cashToken
            self.basePrice = self.cashPrice
        else:
            self.baseToken = self.futureToken
            self.basePrice = self.futPrice

        self.ceTable = getCETable(self,self.symbol, self.expiry)
        self.peTable = getPETable(self,self.symbol, self.expiry)

        updateModifyInfo(self)

        self.modifyW.isParachange = False

        setParametersModifyW(self)

    except:
        print(traceback.print_exc())



def updateOpenPos(self):

    for i in self.open_position:
        rowarray = np.where(self.position[:self.lastSerialNo, 1]== i[1])[0]

        if(rowarray.size!=0):

            rowNO=rowarray[0]

            filteredArray = self.position[np.where(self.position[:self.lastSerialNo, 1] == i[1])][0]

            openQty=i[5] + filteredArray[5]
            openamt=i[8] +filteredArray[8]

            editList=[5,8,11,12,13,14]
            self.position[rowNO, editList] = [openQty,openamt,openQty,openamt,0.0,0.0]

        else:
            self.position[self.lastSerialNo]=[i[0],i[1],i[2],i[3],i[4],i[5],i[6],i[7],i[8],i[9],i[10],i[5],i[8],0.0,0.0]
            self.lastSerialNo+=1

        checkIsAnyPosition(self)
        print("i[5]:", i[5], type(i[5]))
        if(i[5]>0):
            sellQ=i[5]
            buyQ=0
        else:
            sellQ = 0
            buyQ = i[5]
        data=[self.userID,self.clientId, self.stype,self.folioName,i[0],i[1],'stockname',i[2],self.expiry,i[3],i[4],i[5],0.0,
              i[5],i[8],0.0,buyQ,0.0,sellQ,0.0,0.0,0.0, self.lotsize,self.freezeQty,i[8],0,0.0]
        self.sgFolioOpenPos.emit(data)