import logging
import sys
import numpy as np
import traceback
from Application.Services.Xts.Api.servicesMD import getQuote, subscribeToken
import datetime, time
import threading

def getBaseInfo(self,window):
    # print('getBaseInfo')
    window.symbol = window.cbSymbol.currentText()
    window.expiry = window.cbExp.currentText()
    window.cashToken = getCashToken(self,window.symbol)
    self.tokenList[0] =  window.cashToken
    subscribeToken(self,window.cashToken,'NSECM')
    window.cashFut = window.cbCF.currentText()

    window.futureToken = getFutureToken(self,window.symbol)
    self.tokenList[1] = window.futureToken
    subscribeToken(self,window.futureToken,'NSEFO')

    data = getQuote(self, window.cashToken, 'NSECM', 1501)
    window.cashPrice = data['LastTradedPrice']
    data = getQuote(self, window.futureToken, 'NSEFO', 1501)
    window.futPrice = data['LastTradedPrice']

    if(window.cashFut == 'CASH'):
        window.baseToken = window.cashToken
        window.basePrice = window.cashPrice
    else:
        window.baseToken = window.futureToken
        window.basePrice = window.futPrice

    window.strikeDiff = getStrikeDiff(self,window.futureToken)
    window.lotsize = getLotSize(self,window.futureToken)
    window.ATM = getATM(self,window.basePrice, window.strikeDiff)

    window.ceTable = getCETable(self,window.symbol, window.expiry)
    window.peTable = getPETable(self,window.symbol, window.expiry)

    window.lb_ltp.setText(str(window.basePrice))
    window.lb_atm.setText(str(window.ATM))

    window.ATMCEToken = getATM_CE_Token(self,window.ATM, window.ceTable)
    window.ATMPEToken = getATM_PE_Token(self,window.ATM, window.peTable)

    subscribeToken(self,window.ATMCEToken,'NSEFO')
    subscribeToken(self,window.ATMPEToken,'NSEFO')

    self.tokenList[2] = window.ATMCEToken
    self.tokenList[3] = window.ATMPEToken

    data = getQuote(self, window.ATMCEToken, 'NSEFO', 1501)
    window.atmcePrice = data['LastTradedPrice']

    data1 = getQuote(self, window.ATMPEToken, 'NSEFO', 1501)
    window.atmpePrice = data1['LastTradedPrice']

    window.lbATMCE.setText('%.2f' % window.atmcePrice)
    window.lbATMPE.setText('%.2f' % window.atmpePrice)

    window.atmIdx = window.cbStrike_CE.findText('ATM')
    window.cbStrike_CE.setCurrentText('ATM')
    window.cbStrike_PE.setCurrentText('ATM')

    window.ceStrike = window.ATM
    window.peStrike = window.ATM

    window.ceToken = window.ATMCEToken
    window.peToken = window.ATMPEToken

    self.tokenList[4] = window.ceToken
    self.tokenList[5] = window.peToken

    window.lbcePrice.setText('%.2f' % window.atmcePrice)
    window.lbpePrice.setText('%.2f' % window.atmpePrice)

    window.isParachange = False

def symchange(self,window):
    try:
        # print('symchange')
        symbol = window.cbSymbol.currentText()
        fltr = np.asarray([symbol])
        filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
        uniqueExp = np.unique(filteredarray[:, 6])
        window.cbExp.clear()
        window.cbExp.addItems(uniqueExp)
        self.getBaseInfo(window)
        window.isParachange = True
    except:
        print(traceback.print_exc())

def baseChange(self,window):
    window.cashFut = window.cbCF.currentText()
    window.isParachange = True

def expchange(self,window):
    try:
        window.expiry = window.cbExp.currentText()
        window.isParachange = True
    except:
        print(traceback.print_exc())

def updateATMCEToken(self,window):
    window.ceStrike = window.ATM + (window.strikeDiff * (window.cbStrike_CE.currentIndex() - window.atmIdx))
    window.ceToken = getATM_CE_Token(window,window.ceStrike,window.ceTable)
    self.tokenList[4] =window.ceToken
    data1 = getQuote(self, window.ceToken, 'NSEFO', 1501)
    window.cePrice = data1['LastTradedPrice']
    window.lbcePrice.setText('%.2f'%window.cePrice)
    subscribeToken(self, window.ceToken, 'NSECM')
    # recalculateATMQtyONSC(self,window)


def updateATMPEToken(self,window):
    window.peStrike = window.ATM - (window.strikeDiff * (window.cbStrike_PE.currentIndex() - window.atmIdx))
    window.peToken = getATM_PE_Token(window,window.peStrike,window.peTable)
    self.tokenList[5] =window.peToken
    data1 = getQuote(self, window.peToken, 'NSEFO', 1501)
    window.pePrice = data1['LastTradedPrice']
    window.lbpePrice.setText('%.2f'%window.pePrice)
    subscribeToken(self, window.peToken, 'NSECM')

def updateAllToken(self,window):
    # print("updateAll Token")
    subscribeToken(self,window.ATM_CE_Token,'NSEFO')
    subscribeToken(self,window.ATM_PE_Token,'NSEFO')
    window.isParachange = False

def updateModifyInfo(self):
    self.modifyW.leFolioName.setText(self.folioName)
    self.modifyW.cbClient.setCurrentText(self.clientId)
    self.modifyW.cbSymbol.addItem(self.symbol)
    self.modifyW.cbSymbol.setCurrentText(self.symbol)
    self.modifyW.cbCF.setCurrentText(self.Base)
    self.modifyW.cbExp.addItem(self.expiry)
    self.modifyW.cbExp.setCurrentText(self.expiry)

    self.modifyW.ceTable = self.ceTable
    self.modifyW.peTable = self.peTable

    self.modifyW.strikeDiff = self.strikeDiff
    self.modifyW.lotsize = self.lotsize
    self.modifyW.freezeQty = self.freezeQty

    self.modifyW.ATM = self.ATM

    self.modifyW.symbol = self.symbol
    self.modifyW.expiry = self.expiry
    self.modifyW.cashFut = self.Base

    self.modifyW.cashToken = self.cashToken
    self.modifyW.futureToken = self.futureToken

    self.modifyW.baseToken = self.baseToken
    self.modifyW.cashPrice = self.cashPrice
    self.modifyW.futPrice = self.futPrice
    self.modifyW.basePrice = self.basePrice

    self.modifyW.cbSymbol.setCurrentText(self.symbol)
    self.modifyW.cbCF.setCurrentText(self.Base)

    self.modifyW.lb_ltp.setText(str(self.basePrice))

    self.modifyW.lb_atm.setText(str(self.ATM))

    self.modifyW.cbStrike_CE.setCurrentIndex(self.ceIdx)
    self.modifyW.cbStrike_PE.setCurrentIndex(self.peIdx)

    self.modifyW.lbATMCE.setText(str(self.atmcePrice))
    self.modifyW.lbATMPE.setText(str(self.atmpePrice))

    self.modifyW.lbcePrice.setText(str(self.cePrice))
    self.modifyW.lbpePrice.setText(str(self.pePrice))

    self.modifyW.leS1QtyCE.setText(str(self.S1QtyCE))
    self.modifyW.leS2QtyCE.setText(str(self.S2QtyCE))
    self.modifyW.leS3QtyCE.setText(str(self.S3QtyCE))

    self.modifyW.leS1PtsCE.setText(str(self.S1PtsCE))
    self.modifyW.leS2PtsCE.setText(str(self.S2PtsCE))
    self.modifyW.leS3PtsCE.setText(str(self.S3PtsCE))

    self.modifyW.leS1QtyPE.setText(str(self.S1QtyPE))
    self.modifyW.leS2QtyPE.setText(str(self.S2QtyPE))
    self.modifyW.leS3QtyPE.setText(str(self.S3QtyPE))

    self.modifyW.leS1PtsPE.setText(str(self.S1PtsPE))
    self.modifyW.leS2PtsPE.setText(str(self.S2PtsPE))
    self.modifyW.leS3PtsPE.setText(str(self.S3PtsPE))

    self.modifyW.s1CEP.setText(str(self.Sl1PtsValCE))
    self.modifyW.s2CEP.setText(str(self.Sl2PtsValCE))
    self.modifyW.s3CEP.setText(str(self.Sl3PtsValCE))

    self.modifyW.s1CEF.setText(str(self.flagS1CE))
    self.modifyW.s2CEF.setText(str(self.flagS2CE))
    self.modifyW.s3CEF.setText(str(self.flagS3CE))

    self.modifyW.s1PEP.setText(str(self.Sl1PtsValPE))
    self.modifyW.s2PEP.setText(str(self.Sl2PtsValPE))
    self.modifyW.s3PEP.setText(str(self.Sl3PtsValPE))

    self.modifyW.s1PEF.setText(str(self.flagS1PE))
    self.modifyW.s2PEF.setText(str(self.flagS2PE))
    self.modifyW.s3PEF.setText(str(self.flagS3PE))

    self.modifyW.leSLAgainPtsCE.setText(str(self.slAgainPtsCE))
    self.modifyW.leSLAgainPtsPE.setText(str(self.slAgainPtsPE))

    self.modifyW.leIncrementSl.setText(str(self.incrementSl))
    self.modifyW.leSlTimes.setText(str(self.SlTimes))


def getCETable(self,symbol,exp):

    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    fltr1 = np.asarray([exp])
    filteredarray2 = filteredarray[np.in1d(filteredarray[:, 6], fltr1)]

    filteredarray1 = filteredarray2[filteredarray2[:, 12].argsort()]
    fltr2 = np.asarray(['CE'])
    ceTable= filteredarray1[np.in1d(filteredarray1[:, 8], fltr2)]

    return ceTable


def getPETable(self,symbol,exp):
    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    fltr1 = np.asarray([exp])
    filteredarray2 = filteredarray[np.in1d(filteredarray[:, 6], fltr1)]
    filteredarray1 = filteredarray2[filteredarray2[:, 12].argsort()][::-1]
    fltr2 = np.asarray(['PE'])
    peTable= filteredarray1[np.in1d(filteredarray1[:, 8], fltr2)]
    return peTable

def getATM_CE_Token(self,atm,ceTable):
    ATM_CE_Token = ceTable[np.where(ceTable[:,12]==atm),2][0][0]
    return ATM_CE_Token

def getATM_PE_Token(self,atm,peTable):
    ATM_PE_Token = peTable[np.where(peTable[:,12]==atm),2][0][0]
    return ATM_PE_Token


def dec_v(self,window):
    if (window.leQty.text() != '0'):
        newQ = int(window.leQty.text()) - window.lotsize

        window.leQty.setText(str(newQ))

def inc_v(self,window):
    # print('in inc_v',window.lotsize)

    newQ = int(window.leQty.text()) + window.lotsize
    window.leQty.setText(str(newQ))


def getCEList(self,ATMStrike):
    lowerRange= ATMStrike - ((self.lowerRangeIndex+1) *self.strikeDiff)
    upperRange= ATMStrike + ((self.upperRangeIndex+1) *self.strikeDiff)
    array1 = self.ceTable[np.where(self.ceTable[:, 12] >= lowerRange)]
    array2 = array1[np.where(array1[:, 12] <= upperRange)]
    array3 = array2[:, [2, 8, 12]]
    return array3

def getPEList(self,ATMStrike):
    lowerRange= ATMStrike - ((self.lowerRangeIndex+1) *self.strikeDiff)
    upperRange= ATMStrike + ((self.upperRangeIndex+1) *self.strikeDiff)
    array1 = self.peTable[np.where(self.peTable[:, 12] >= lowerRange)]
    array2 = array1[np.where(array1[:, 12] <= upperRange)]
    array3 = array2[:, [2, 8, 12]]
    # print(array3)
    return array3

def getExecutionTime(self):
    now = datetime.datetime.today()
    date = now.strftime('%Y-%m-%d ')
    a915 = datetime.datetime.strptime(date + '09:15:00', '%Y-%m-%d %H:%M:%S')
    a920 = datetime.datetime.strptime(date + self.etime, '%Y-%m-%d %H:%M:%S')
    self.timeout1 = int(a920.timestamp()- time.time())*1000
    return self.timeout1

def getFutureToken(self,symbol=''):
    futureToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 17]
    return futureToken


def getCashToken(self,symbol=''):
    # print('symbo',symbol)

    assetToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 9]
    # print('sss',assetToken)
    return assetToken

def checkIsAnyPosition(self):
    isAnyOpenPos = False
    for i in self.position[:self.lastSerialNo,5]:
        if(i != 0):
            isAnyOpenPos = True
            self.isAnyOpenPos = isAnyOpenPos

            return
    self.isAnyOpenPos = isAnyOpenPos

def updateValues(self):
    print('updateValues')
    try:
        if self.isFirstOrderPunch:
            window = self.modifyW

        elif(self.isParameterSet):
            window = self.mod
        else:
            window= self.addW

        window.lb_ltp.setText(str(window.cashPrice))
        window.lb_atm.setText(str(window.ATM))

        window.lbATMCE.setText('%.2f' % window.atmCEPrice)
        window.lbATMPE.setText('%.2f' % window.atmPEPrice)

        window.lbcePrice.setText('%.2f' % window.cePrice)
        window.lbpePrice.setText('%.2f' % window.pePrice)


    except:
        print(traceback.print_exc())
def getLotSize(self,futureToken):
    lotsize = self.fo_contract[futureToken-35000,11]
    return lotsize
    print("lotsize:",lotsize)


def getCEPEPrice(self):
    try:
        if (self.isFirstOrderPunch):
            window = self.modifyW
            a='modify'
        elif (self.isParameterSet):
            window = self.modifyW
            a='modify'

        else:
            window = self.addW
            a='add'

        if (window.visibleRegion().isEmpty() == False):

            window.cashPrice = getPrice(self=self, token=window.cashToken, seg='NSECM', streamType=1501)['ltp']
            window.futPrice = getPrice(self=self, token=window.futureToken, seg='NSEFO', streamType=1501)['ltp']
            window.ATM = getATM(self, window.cashPrice, window.strikeDiff)

            data = getQuote(self,window.ATM_CE_Token, 'NSEFO', 1501)
            window.atmCEPrice = data['LastTradedPrice']

            data1 = getQuote(self, window.ATM_PE_Token, 'NSEFO', 1501)
            window.atmPEPrice = data1['LastTradedPrice']
    except:
        print(traceback.print_exc())

def getStrikeDiff(self,futureToken):
    strikeDiff = self.fo_contract[futureToken-35000,36]
    return strikeDiff


def getATM(self,cashPrice,strikeDiff):
    # print("cAsh And StrDiff",cashPrice,strikeDiff)
    ATM1 = (cashPrice / strikeDiff)
    # print((cashPrice / strikeDiff))
    frac = ATM1 % 1
    # ** NOTE  : need to chge below
    strikeDecisionPoint = 0.5 #float(self.addW.leLowerPoint.text())
    # print(frac)
    if(frac > strikeDecisionPoint):
        ATM = int(ATM1+1) * strikeDiff
    else:
        ATM = int(ATM1) * strikeDiff
    # ATM1 = (cashPrice / strikeDiff) * strikeDiff
    return ATM

def getPrice(self, token, seg, streamType):

    data = getQuote(self, token, seg, streamType)
    # print('dataaaa:',data)
    ltp = data['LastTradedPrice']
    try:
        bid = data['AskInfo']['Price']
        ask = data['BidInfo']['Price']
    except:
        bid = 0.00
        ask = 0.00
    return {"bid": bid, "ask": ask, "ltp": ltp}
def getPrices(self):
    try:
        th = threading.Thread(target=getCEPEPrice,args=(self,))
        th.start()
    except:
        print(traceback.print_exc())

def setParametersModifyW(self):
    try:
        self.modifyW.folioName = self.folioName
        self.modifyW.clientId = self.clientId
        self.modifyW.symbol = self.symbol
        self.modifyW.expiry = self.expiry

        self.modifyW.strikeDiff = getStrikeDiff(self, self.futureToken)
        self.modifyW.freezeQty = int(self.fo_contract[self.futureToken - 35000, 14])

        self.modifyW.ceTable = getCETable(self, self.symbol, self.expiry)
        self.modifyW.peTable = getPETable(self, self.symbol, self.expiry)

        self.modifyW.ATM = getATM(self, self.cashPrice, self.strikeDiff)

        self.modifyW.ceToken = getATM_CE_Token(self, self.ATM, self.ceTable)
        self.modifyW.peToken = getATM_PE_Token(self, self.ATM, self.peTable)

        self.modifyW.cbSymbol.addItem(self.symbol)
        self.modifyW.cbExp.addItem(self.expiry)
        self.modifyW.leFolioName.setText(self.folioName)
        self.modifyW.cbClient.addItem(self.clientId)
        self.modifyW.leQty.setText(str(self.baseQty))

        self.modifyW.leIncrementSl.setText(str(self.incrementSl))
        self.modifyW.leSlTimes.setText(str(self.SlTimes))

        self.modifyW.leSLAmount.setText(str(self.SlAmount))
        self.modifyW.leTargetAmount.setText(str(self.targetAmt))

        self.modifyW.lb_atm.setText(str(self.ATM))

        self.modifyW.SlAmount = float(self.SlAmount)
        self.modifyW.targetAmt = float(self.targetAmt)

    except:
        print(traceback.print_exc())

def updateSl1CEP(self,window):
   newPoints = float(window.leS1PtsCE.text())
   window.s1CEP.setText(str(self.firstCEPrice +newPoints ))

def updateSl2CEP(self,window):
    newPoints = float(window.leS2PtsCE.text())
    window.s2CEP.setText(str(self.firstCEPrice + newPoints))

def updateSl3CEP(self,window):
    newPoints = float(window.leS3PtsCE.text())
    window.s3CEP.setText(str(self.firstCEPrice + newPoints))

def updateSl1PEP(self,window):
    newPoints = float(window.leS1PtsPE.text())
    window.s1PEP.setText(str(self.firstPEPrice + newPoints))

def updateSl2PEP(self,window):
    newPoints = float(window.leS2PtsPE.text())
    window.s2PEP.setText(str(self.firstPEPrice + newPoints))

def updateSl3PEP(self,window):
    newPoints = float(window.leS3PtsPE.text())
    window.s3PEP.setText(str(self.firstPEPrice + newPoints))
