import sys
from Application.Services.Xts.Api.servicesIA import PlaceOrder, modifyOrder
import time as ttime
from Application.Stretegies.OCheetah.Utills.keyParameters import  saveJson
from Application.Stretegies.OCheetah.Utills.executionSupport import *
# from Application.Stretegies.OCheetah.Utills.OMSSupport import *
from Application.Stretegies.OCheetah.Utills.inactiveOMSSupport import *
from Application.Utils.log import insertLogRow


def makeOrder(self,token,qty,orderSide = 'Sell', orderType  = 'MARKET', limitPrice = 0.0, triggerPrice = 0 ):
    try:
        tQty = qty
        # print("dfssssssssssssssssssssssssssssss")
        appOrderIdList = []
        # print('AppOrderList',appOrderIdList)
        while qty > self.freezeQty:
            appOrderId = PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=token, orderSide=orderSide,
                       qty=self.freezeQty,
                       limitPrice=limitPrice,
                       validity='DAY', disQty=0, triggerPrice=triggerPrice, uid=self.folioName, orderType=orderType,
                       productType='NRML')

            # need to add in OMS
            appOrderIdList.append(appOrderId)
            ttime.sleep(0.1)
            qty -= self.freezeQty
        appOrderId = PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=token, orderSide=orderSide,
                   qty=qty,
                   limitPrice=limitPrice,
                   validity='DAY', disQty=0, triggerPrice=triggerPrice, uid=self.folioName, orderType=orderType,
                   productType='NRML')
        # need to add in OMS
        appOrderIdList.append(appOrderId)
        insertLogRow(self, tQty, token, orderSide)
        ttime.sleep(0.1)
        # print("makeOrder Done")
        return appOrderIdList
    except:
        print(traceback.print_exc())
def makeFirstOrder(self):
    # print("djdsbjhggggggggHSHSDHSAHDASHD")
    try:

        print('self.isFirstOrderPunch',self.isFirstOrderPunch)
        if(self.isFirstOrderPunch==False):
            # print('self.isFirstOrderPunch 2', self.trend)

            makeOrder(self,self.ceToken,self.baseQty,'Sell')
            makeOrder(self,self.peToken,self.baseQty,'Sell')
            # print("dgshsfgfgdsfgsfgfdghsfhjdfs",self.peToken,self.baseQty,self.orderSide)

            # self.ceLastOrderPunchPrice = getPrice(self, token=self.ceToken, seg='NSECM', streamType=1501)['ltp']
            self.ceLastOrderPunchPrice = self.cePrice
            # print("First  order punched cePrice : ", self.cePrice)
            self.peLastOrderPunchPrice = self.pePrice
            # print("First  order punched pePrice : ", self.pePrice)
            # print("pePrice : ", self.pePrice)
            self.sgStart.emit()
            self.isStart = True
            self.isFirstOrderPunch = True
            self.baseStrike = self.ATM

            setParametersModifyW(self)
            saveJson(self)
    except:
        # print("Frst NOt Done")
        print(traceback.print_exc())
        # self.Slogger.error(sys.exc_info()[1])
# def updateOrder(self, order):
    # try:
    #     for x in range(len(self.OMS)):
    #         if(x <9):
    #             print("OMS data : ",self.OMS[x])
    #     print("JTiger : updateOrder", order)
    #     orderType = order['OrderType']
    #     appOrderId = order['AppOrderID']
    #     token = order['ExchangeInstrumentID']
    #     orderSide = order['OrderSide']
    #     orderTag = order['OrderUniqueIdentifier']
    #     orderStatus = order['OrderStatus']
    #     qty = order['OrderQuantity']
    #     print("appOrderId:",appOrderId)
    #     print("updateOrder isStart:", self.isStart)
    #     if(self.isStart == True):
    #         print("self.isStart 1", orderType, orderStatus)
    #         if(orderType == 'Market'):
    #             print("inside market")
    #             # check with apporder id and cporderId - 0 ,21
    #             fltr = np.asarray([appOrderId])
    #             print("OMSSSSS:", self.OMS)
    #             filteredArrayId = self.OMS[np.in1d(self.OMS[:, 1], fltr)]
    #             filteredArrayCEId = self.OMS[np.in1d(self.OMS[:, 21], fltr)]
    #             print("filteredArrayId:", filteredArrayId,filteredArrayCEId)
    #             if(filteredArrayId.size !=0 ):
    #                 # update in OMS
    #                 lastOrderSerialNo = filteredArrayId[0][0]
    #                 print("lastOrderSerialNo:", lastOrderSerialNo)
    #                 # check order Type
    #                 if(orderStatus == "PendingNew"):
    #                     updatePendingNewOrder(self,lastOrderSerialNo, order)
    #                 elif(orderStatus  == "New"):
    #                     updateNewOrder(self,lastOrderSerialNo)
    #                 elif(orderStatus == "Rejetcted"):
    #                     updateRejetctedOrder(self,lastOrderSerialNo,order)
    #                 elif(orderStatus == "Cancelled"):
    #                     updateCancelledNewOrder(self,lastOrderSerialNo,order)
    #                 elif (orderStatus == "PartiallyFilled"):
    #                     updatePartiallyFilledOrder(self, lastOrderSerialNo, order)
    #                 elif(orderStatus == "Filled"):
    #                     print("orderStatus:", orderStatus)
    #                     updateFilledOrder(self,lastOrderSerialNo,order,filteredArrayId[0])
    #
    #
    #
    #             elif(filteredArrayCEId.size !=0 ):
    #                 pass
    #             else:
    #                 # self.OMS[lastOrderSerialNo, [0, 1, 2, 3, 4, 5, 6, 7, 8, 21, 22]] = \
    #                 #     np.array([self.lastOrderSerialNo,
    #                 #               appOrder, orderTag, token,
    #                 #               optionType, orderSide,
    #                 #               strike, 'Placed', baseQty,
    #                 #               cpAOID, 'OPEN'
    #                 #               ])
    #                 # add record in OMS
    #                 pass
    #
    #         elif(orderType == 'StopLimit'):
    #             print("orderType== 'StopLimit")
    #             fltr = np.asarray([appOrderId])
    #             filteredArrayId = self.OMS[np.in1d(self.OMS[:, 1], fltr)]
    #             if (filteredArrayId.size != 0):
    #                 orderStatus = order['OrderStatus']
    #
    #         elif(orderType== 'Limit'):
    #             print("orderType== 'Limit' hit")
    #             fltr = np.asarray([appOrderId])
    #             filteredArrayId = self.OMS[np.in1d(self.OMS[:, 1], fltr)]
    #             if (filteredArrayId.size != 0):
    #
    #                 orderStatus = order['OrderStatus']
    #                 if (orderStatus == "Filled"):
    #                     type = filteredArrayId[0][2]
    #                     print("type : ", type)
    #                     if (type == "SL"):
    #                         print("inside : ", "SL")
    #                         slLastOrderSerialNo = filteredArrayId[0][0]
    #                         updateStopLimitOrder(self, slLastOrderSerialNo, order, filteredArrayId[0])
    #                     elif (type == "Target"):
    #                         print("inside : ", "Target")
    #                         targetLastOrderSerialNo = filteredArrayId[0][0]
    #                         updateTragetOrder(self, targetLastOrderSerialNo, order, filteredArrayId[0])
    #                 # print("updateStopLimitOrder :orderStatus ",orderStatus )
    #
    #
    #         print("self.isStart end")
    #         saveJson(self)
    #     # stratergy is inactive
    #     else:
    #         print("dddd else:",orderStatus)
    #         if (orderType == 'Market'):
    #             # exorderTag : 5_pairdell
    #             addOrderToInactiveOMS(self, [appOrderId], token, order['OrderQuantity'],order['LeavesQuantity'],order['CumulativeQuantity'], '', orderSide, '', '', orderTag,order['OrderAverageTradedPrice'],orderStatus)
    #         elif (orderType == 'StopLimit'):
    #             addSLOrderToInactiveOMS(self, [appOrderId], token, order['OrderQuantity'], order['LeavesQuantity'],
    #                                   order['CumulativeQuantity'], '', orderSide, '', '', orderTag,
    #                                   order['OrderAverageTradedPrice'], orderStatus)
    #
    #         elif (orderType == 'Limit'):
    #             addTargetOrderToInactiveinactiveOMS(self, [appOrderId], token, order['OrderQuantity'], order['LeavesQuantity'],
    #                                   order['CumulativeQuantity'], '', orderSide, '', '', orderTag,
    #                                   order['OrderAverageTradedPrice'], orderStatus)
    #
    #         saveJson(self)
    #         print("inactive OMS:",getinactiveOMSRecord(self,appOrderId))
    # except:
    #     print(traceback.print_exc())

# def updateTragetOrder(self, targetLastOrderSerialNo,order, orderInfo):
#     self.OMS[targetLastOrderSerialNo, [7]] = "Filled"
#     print(" ********** updateTragetOrder inside")
#     # ** step 2  fetch main appOrder id and update sl status = 'sl hit'
#     mainLastOrderSerialNo = orderInfo[15]
#     self.OMS[mainLastOrderSerialNo, [22]] = ["Target Hit"]
#
#     # ** step 3 place target order of respected CE/PE
#     fltrMain = np.asarray([mainLastOrderSerialNo])
#     filteredArrayMain = self.OMS[np.in1d(self.OMS[:, 1], fltrMain)]
#     # fetch respected CE/PE appOrder id
#     cpOrderId = mainLastOrderSerialNo[0][21]
#     # fetch respected CE/PE order info
#     fltrCP = np.asarray([cpOrderId])
#     filteredArrayCP = self.OMS[np.in1d(self.OMS[:, 1], fltrCP)]
#     # avgPrice
#     avgPrice = filteredArrayCP[0][11]
#     targetLeg = filteredArrayCP[0][18]
#
#     # calculate target price
#     leTargetLeg = 0
#     legDetail = ''
#     if (targetLeg == 1):
#         leTargetLeg = self.leTargetPts2
#         legDetail = 'Second'
#     elif (targetLeg == 2):
#         leTargetLeg = self.leTargetPts3
#         legDetail = 'Third'
#
#     targetPrice = avgPrice * (leTargetLeg + float(1))
#     targetTriggerPrice = targetPrice * float( 1 + 0.05)
#     # 50 % order quantity
#     targetQty = int(fltrMain[8] / 4)
#     # place target order
#     targetOrderIdList = makeOrder(self, filteredArrayCP[0][3], targetQty, 'Buy', 'Limit', targetPrice, targetTriggerPrice)
#
#     # target order
#     addTargetOrderToOMS(self, targetOrderIdList, filteredArrayCP[0][3], targetQty, filteredArrayCP[0][5], "Buy",
#                         filteredArrayCP[0][6], 'Target',
#                         mainLastOrderSerialNo, targetPrice, targetTriggerPrice,targetLeg+1)
#
#     # update in main AOID
#     self.OMS[mainLastOrderSerialNo, [17, 19]] = np.array([targetOrderIdList[0], legDetail+'Leg Placed'])
#
#     # calculate SL price (change to current LTP)
#     slPrice = avgPrice * (self.leSLPoint + float(1))
#     slTriggerPrice = slPrice * (self.slPts + float(1 - 0.05))
#     # 50 % order quantity
#     slQty = filteredArrayCP[0][8]
#
#     # place sl order
#     orderIdList = modifyOrder(self, cpOrderId, '', self.clientId, filteredArrayCP[0][3], 'Buy', (50-((filteredArrayMain[0][18]-1)*3)) ,
#                               slPrice,
#                               filteredArrayCP[0][8], slTriggerPrice, filteredArrayCP[0][15], 'StopLimit')
#
#     # sl order
#     addSLOrderToOMS(self, orderIdList, filteredArrayCP[3], targetQty, filteredArrayCP[5], "Buy",
#                         filteredArrayCP[6], 'Target',
#                         mainLastOrderSerialNo)
#
#     print("***************")
# def updateStopLimitOrder(self, slLastOrderSerialNo, order, orderInfo):
#         print(" ****************updateStopLimitOrder:", orderInfo)
#         #** step 1 update status to filled in sl order
#         self.OMS[slLastOrderSerialNo, [7]] = "Filled"
#
#         #** step 2  fetch main appOrder id and update sl status = 'sl hit'
#         mainAppId = orderInfo[15]
#         mainSerialNo = orderInfo[0]
#
#         #** step 3 place target order of respected CE/PE
#         fltrMain = np.asarray([mainAppId])
#         filteredArrayMain = self.OMS[np.in1d(self.OMS[:, 1], fltrMain)]
#         # fetch respected CE/PE appOrder id
#         cpOrderId = filteredArrayMain[0][21]
#         # fetch respected CE/PE order info
#         fltrCP = np.asarray([cpOrderId])
#         filteredArrayCP = self.OMS[np.in1d(self.OMS[:, 1], fltrCP)]
#         # avgPrice
#         avgPrice = float(filteredArrayCP[0][11])
#         # update SL hit order detail to main APP order id
#         self.OMS[mainSerialNo, [11, 16]] = np.array([avgPrice, 'SL Hit'])
#
#         print("avgPrice:", avgPrice)
#         # calculate target price
#         targetPrice = round(avgPrice * (self.targetPts1 + float(1)))
#         targetTriggerPrice = round(targetPrice * (float(1) + 0.05))
#         # 50 % order quantity
#         print("filteredArrayMain[0][8]: original qty:", filteredArrayMain[0][8])
#         targetQty = filteredArrayMain[0][8]/2
#         print("targetQty:", targetQty, targetPrice, targetTriggerPrice)
#         # place target order
#         targetOrderIdList = makeOrder(self, filteredArrayCP[0][3], targetQty, 'Buy', 'Limit', targetPrice, targetTriggerPrice)
#
#         # target order
#         addTargetOrderToOMS(self, targetOrderIdList, filteredArrayCP[0][3], targetQty, filteredArrayCP[0][5], "Buy", filteredArrayCP[0][6], 'Target',
#                         mainAppId, targetPrice, targetTriggerPrice,1) # 1 = target leg
#
#         # update in main AOID
#         self.OMS[mainSerialNo,[17,19]] = np.array([targetOrderIdList[0],'First Leg Placed'])
#         # calculate SL price (change to current LTP)
#         slPrice = round(avgPrice * (self.slPts + float(1)))
#         slTriggerPrice = round(slPrice * (self.slPts + float(1 - 0.05)))
#         print("slTriggerPrice : ", slTriggerPrice,slPrice)
#         # 50 % order quantity
#
#         # place sl order
#         orderIdList = modifyOrder(self, cpOrderId,'',self.clientId,filteredArrayCP[0][3], 'Buy',filteredArrayCP[0][8],slPrice ,
#                                   filteredArrayCP[0][8],slTriggerPrice,filteredArrayCP[0][15],'StopLimit')
#
#         # sl order
#         addSLOrderToOMS(self, [cpOrderId], filteredArrayCP[0][3], targetQty, filteredArrayCP[0][5], "Buy",
#                             filteredArrayCP[0][6], 'SL',
#                             mainAppId, slPrice,slTriggerPrice)
#
#         print("******************")
#         print(" Add in future, remove target orders")
#
#         # for x in self.OMS:
#             # print("XXX : ", x)
# def modifyAppOrder(self, appOrderId, exchange, clientID, token, orderSide, qty, limitPrice,
#                 disQty, triggerPrice, uid, orderType="LIMIT", productType="NRML", validity='DAY'):
#     modifyOrder(self, exchange='NSEFO', clientID=self.clientId, token=token, orderSide=orderSide,
#                             qty=self.freezeQty,
#                             limitPrice=limitPrice,
#                             validity='DAY', disQty=0, triggerPrice=triggerPrice, uid=self.folioName,
#                             orderType=orderType,
#                             productType='NRML')

# def updatePendingNewOrder(self,lastOrderSerialNo,order):
#     self.OMS[lastOrderSerialNo, [7,10]] = ['PendingNew',order['LeavesQuantity']]

# def updateNewOrder(self,lastOrderSerialNo):
    # self.OMS[lastOrderSerialNo, 7] = 'New'


# def updateRejetctedOrder(self,lastOrderSerialNo,order):
#     pass
#
# def updateCancelledNewOrder(self,lastOrderSerialNo,order):
#     pass
#
# def updatePartiallyFilledOrder(self,lastOrderSerialNo,order):
#     self.OMS[lastOrderSerialNo, [7,9,10]] = ["Filled",order['CumulativeQuantity'],order['LeavesQuantity']]
#
# def updateFilledOrder(self,lastOrderSerialNo,order,orderInfo):
#     #place sl
#     mainAppId = orderInfo[1]
#     avgTradedPrice = float(order['OrderAverageTradedPrice'])
#     print("self.slPts:", self.slPts, type(self.slPts),avgTradedPrice)
#     slPrice = round(avgTradedPrice * (self.slPts+float(1.00)) ) #description': 'Gateway:Price should be multiple of Tick Size which is0.05for this contract'}
#     slTargetPrice = round(avgTradedPrice * (self.slPts + float(1.00 - 0.05)))
#     print("Mak SL order:", orderInfo)
#     # sl place order
#     print("sl or  : ", orderInfo[3], order['OrderQuantity'], orderInfo[4], 'Buy','StopLimit',slPrice, slTargetPrice)
#     orderIdList = makeOrder(self, orderInfo[3], order['OrderQuantity'], 'Buy','StopLimit',slPrice, slTargetPrice)
#     print("after SL order:", orderIdList)
#     # sl order
#     addSLOrderToOMS(self, orderIdList,orderInfo[3] , order['OrderQuantity'], orderInfo[4] , 'Buy',orderInfo[5], 'SL', mainAppId,'Sl',slTargetPrice)
#     # update value
#     self.OMS[lastOrderSerialNo, [7,9,10,11,15,16]] = ['Filled', order['OrderQuantity'],0,
#                                                       order['OrderAverageTradedPrice'],orderIdList[0],'OPEN']
#     print("Self.OMS:", self.OMS[self.lastOrderSerialNo-1])
#
