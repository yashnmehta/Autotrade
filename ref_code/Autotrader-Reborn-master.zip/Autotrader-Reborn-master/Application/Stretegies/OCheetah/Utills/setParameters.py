import traceback

import numpy as np
from PyQt5.QtCore import *
from Application.Stretegies.OCheetah.Utills.keyParameters import reloadKeyParameter, getKeyParameterFile, saveJson
from Application.Stretegies.OCheetah.Utills.executionSupport import *
from PyQt5.QtWidgets import *


def setParameters(self, window):
    print('setParameters')
    try:
        self.baseQty = int(window.leQty.text())

        # print("QTY :::::::::::", self.baseQty)
        if (self.baseQty <= 0):
            self.messageBox = QMessageBox()
            self.messageBox.setIcon(QMessageBox.Critical)
            self.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
            self.messageBox.setText('Quantity must be greater than zero!!')
            self.messageBox.show()
        else:
            self.folioName = window.leFolioName.text()
            self.clientId = window.cbClient.currentText()

            self.symbol = window.cbSymbol.currentText()
            self.expiry = window.cbExp.currentText()

            self.Base = window.cbCF.currentText()
            self.baseToken = getCashToken(self, self.symbol)
            self.basePrice = self.getPrice(token=self.baseToken, seg='NSECM', streamType=1501)['ltp']

            self.cashToken = getCashToken(self, self.symbol)
            self.futureToken = getFutureToken(self, self.symbol)

            self.cashPrice = self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
            self.futPrice = self.getPrice(token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
            self.ATM = window.ATM
            self.ATMCEToken = window.ATMCEToken
            self.ATMPEToken = window.ATMPEToken

            self.atmcePrice = self.getPrice(token=self.ATMCEToken, seg='NSEFO', streamType=1501)['ltp']
            self.atmpePrice = self.getPrice(token=self.ATMPEToken, seg='NSEFO', streamType=1501)['ltp']

            self.ceToken = window.ceToken
            self.peToken = window.peToken
            self.ceStrike = window.ceStrike
            self.peStrike = window.peStrike
            self.cePrice = self.getPrice(token=self.ceToken, seg='NSEFO', streamType=1501)['ltp']
            self.pePrice = self.getPrice(token=self.peToken, seg='NSEFO', streamType=1501)['ltp']

            self.firstCEPrice = self.getPrice(token=self.ceToken, seg='NSEFO', streamType=1501)['ltp']
            self.firstPEPrice = self.getPrice(token=self.peToken, seg='NSEFO', streamType=1501)['ltp']

            self.pePrice = self.getPrice(token=self.peToken, seg='NSEFO', streamType=1501)['ltp']

            self.strikeDiff = getStrikeDiff(self, self.futureToken)

            self.atmIdx = window.atmIdx
            self.ceIdx = window.cbStrike_CE.currentIndex()
            self.peIdx = window.cbStrike_PE.currentIndex()
            self.freezeQty = int(self.fo_contract[self.futureToken - 35000, 14])



            self.SlAmount = float(window.leSLAmount.text())
            self.targetAmt = float(window.leTargetAmount.text())
            getKeyParameterFile(self, self.folioName)

            self.ceTable = getCETable(self, self.symbol, self.expiry)
            self.peTable = getPETable(self, self.symbol, self.expiry)

            self.qty = self.baseQty


            self.S1QtyCE = float(window.leS1QtyCE.text())
            self.S2QtyCE = float(window.leS2QtyCE.text())
            self.S3QtyCE = float(window.leS3QtyCE.text())

            self.S1PtsCE = float(window.leS1PtsCE.text())
            self.S2PtsCE = float(window.leS2PtsCE.text())
            self.S3PtsCE = float(window.leS3PtsCE.text())

            self.S1QtyPE = float(window.leS1QtyPE.text())
            self.S2QtyPE = float(window.leS2QtyPE.text())
            self.S3QtyPE = float(window.leS3QtyPE.text())

            self.S1PtsPE = float(window.leS1PtsPE.text())
            self.S2PtsPE = float(window.leS2PtsPE.text())
            self.S3PtsPE = float(window.leS3PtsPE.text())

            self.slAgainPtsCE = window.leSLAgainPtsCE.text()
            self.slAgainPtsPE = window.leSLAgainPtsPE.text()

            self.incrementSl = float(window.leIncrementSl.text())
            self.SlTimes = int(window.leSlTimes.text())

            self.Sl1TimesCE = self.SlTimes
            self.Sl2TimesCE = self.SlTimes
            self.Sl3TimesCE = self.SlTimes

            self.Sl1TimesPE = self.SlTimes
            self.Sl2TimesPE = self.SlTimes
            self.Sl3TimesPE = self.SlTimes

            self.Sl1PtsValCE = self.firstCEPrice + self.S1PtsCE
            self.Sl2PtsValCE = self.firstCEPrice + self.S2PtsCE
            self.Sl3PtsValCE = self.firstCEPrice + self.S3PtsCE

            self.Sl1PtsValPE = self.firstPEPrice + self.S1PtsPE
            self.Sl2PtsValPE = self.firstPEPrice + self.S2PtsPE
            self.Sl3PtsValPE = self.firstPEPrice + self.S3PtsPE

            self.ceQTY = self.qty
            self.peQTY = self.qty

            self.ceHighPrice = self.cePrice
            self.peHighPrice = self.pePrice

            self.flagS1CE = False
            self.flagS2CE = False
            self.flagS3CE = False
            self.flagS1PE = False
            self.flagS2PE = False
            self.flagS3PE = False
            self.isSLCE = False
            self.isSLPE = False

            self.ceLastOrderPunchPrice = 0
            self.peLastOrderPunchPrice = 0

            self.baseStrike = self.ATM
            self.heads = ['serialNo',
                          'appOrderId', 'orderTag', 'token', 'optionType', 'orderSide',
                          'strike', 'status', 'orderQty', 'fillQty', 'pendingQty',
                          'avgPrice', 'slPrice', 'tslPrice', 'targetPrice', 'slAOID',
                          'slStatus', 'targetAOID', 'targetLeg', 'targetStatus', 'targetQty',
                          'cpOrderId', 'cpStatus', 'primaryAOID'
                          ]
            # exchange
            self.lastOrderSerialNo = 0
            self.OMS = np.zeros((500, 24), dtype=object)

            self.inactiveOMS = np.zeros((500, 23), dtype=object)
            self.iomslastOrderSerialNo = 0

            self.isParameterSet = True
            updateModifyInfo(self)
            setParametersModifyW(self)
            self.sgParamSet.emit()
            saveJson(self)
    except:
        print(traceback.print_exc())


def setParametersModify(self, window):
    try:
        self.baseQty = int(window.leQty.text())
        if self.baseQty % self.lotsize != 0:
            self.messageBox = QMessageBox()
            self.messageBox.setIcon(QMessageBox.Critical)
            self.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
            self.messageBox.setText(f'Quantity must be multiple of lotsize {self.lotsize}')
            self.messageBox.show()

        elif (self.baseQty <= 0 ):
            self.messageBox = QMessageBox()
            self.messageBox.setIcon(QMessageBox.Critical)
            self.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
            self.messageBox.setText('Quantity must be greater than zero!!')
            self.messageBox.show()
        else:
            # assign values
            self.folioName = window.leFolioName.text()
            self.clientId = window.cbClient.currentText()
            self.symbol = window.cbSymbol.currentText()
            self.expiry = window.cbExp.currentText()
            self.Base = window.cbCF.currentText()
            self.cashToken = getCashToken(self, self.symbol)
            self.futureToken = getFutureToken(self, self.symbol)
            self.strikeDiff = getStrikeDiff(self, self.futureToken)
            self.freezeQty = int(self.fo_contract[self.futureToken - 35000, 14])

            self.slAgainPtsCE = window.leSLAgainPtsCE.text()
            self.slAgainPtsPE = window.leSLAgainPtsPE.text()

            self.CE_Token_A = window.CE_Token_A
            self.PE_Token_A = window.PE_Token_A

            self.ATM_CE_Token = window.ATM_CE_Token
            self.ATM_PE_Token = window.ATM_PE_Token

            self.lotsize = int(self.fo_contract[self.futureToken - 35000, 11])
            self.baseToken = window.baseToken
            self.cashPrice = getPrice(self, token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
            self.futPrice = getPrice(self, token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
            self.basePrice = window.basePrice

            self.ceStrikeIndex = window.cbStrike_CE.currentIndex()
            self.peStrikeIndex = window.cbStrike_PE.currentIndex()

            self.ATMPrc_CE = float(window.lbATMCE.text())
            self.ATMPrc_PE = float(window.lbATMPE.text())

            self.S1QtyCE = float(window.leS1QtyCE.text())
            self.S2QtyCE = float(window.leS2QtyCE.text())
            self.S3QtyCE = float(window.leS3QtyCE.text())

            self.S1QtyPE = float(window.leS1QtyPE.text())
            self.S2QtyPE = float(window.leS2QtyPE.text())
            self.S3QtyPE = float(window.leS3QtyPE.text())

            self.S1PtsCE = float(window.leS1PtsCE.text())
            self.S2PtsCE = float(window.leS2PtsCE.text())
            self.S3PtsCE = float(window.leS3PtsCE.text())

            self.S1PtsPE = float(window.leS1PtsPE.text())
            self.S2PtsPE = float(window.leS2PtsPE.text())
            self.S3PtsPE = float(window.leS3PtsPE.text())
            window.s1CEP.setText()
            self.Sl1PtsValCE = self.cePrice + self.S1PtsCE
            self.Sl2PtsValCE = self.cePrice + self.S2PtsCE
            self.Sl3PtsValCE = self.cePrice + self.S3PtsCE

            self.Sl1PtsValPE = self.pePrice + self.S1PtsPE
            self.Sl2PtsValPE = self.pePrice + self.S2PtsPE
            self.Sl3PtsValPE = self.pePrice + self.S3PtsPE


            self.qty = self.baseQty
            self.SlAmount = float(window.leSLAmount.text())
            self.targetAmt = float(window.leTargetAmount.text())
            getKeyParameterFile(self, self.folioName)
            self.lotsize = int(self.fo_contract[self.futureToken - 35000, 11])

            self.flagS1CE = False
            self.flagS2CE = False
            self.flagS3CE = False
            self.flagS1PE = False
            self.flagS2PE = False
            self.flagS3PE = False
            self.isSLCE = False
            self.isSLPE = False

            self.ceTable = getCETable(self, self.symbol, self.expiry)
            self.peTable = getPETable(self, self.symbol, self.expiry)
            # print(":", self.ceTable, self.peTable)
            self.ATM = getATM(self, self.cashPrice, self.strikeDiff)
            # print("ATM:", self.ATM)
            self.ceStrike = self.ATM + ((self.ceStrikeIndex) * self.strikeDiff)
            self.peStrike = self.ATM - ((self.peStrikeIndex) * self.strikeDiff)
            # print("strike:", self.ceStrike, self.peStrike)
            self.ceToken = self.ceTable[np.where(self.ceTable[:, 12] == self.ceStrike), 2][0][0]
            self.peToken = self.peTable[np.where(self.peTable[:, 12] == self.peStrike), 2][0][0]
            # print("token:", self.ceToken, self.peToken)
            self.trend = window.leTrend.text()

            self.cePrice = getPrice(self, token=self.ceToken, seg='NSEFO', streamType=1501)['ltp']
            # print("CePrice:",self.cePrice )
            self.pePrice = getPrice(self, token=self.peToken, seg='NSEFO', streamType=1501)['ltp']
            # print("PePrice:",self.pePrice )
            #
            self.ceHighPrice = self.cePrice
            self.peHighPrice = self.pePrice
            self.ceLastOrderPunchPrice = 0
            self.peLastOrderPunchPrice = 0

            self.baseStrike = self.ATM
            self.heads = ['serialNo',
                          'appOrderId', 'orderTag', 'token', 'optionType', 'orderSide',
                          'strike', 'status', 'orderQty', 'fillQty', 'pendingQty',
                          'avgPrice', 'slPrice', 'tslPrice', 'targetPrice', 'slAOID',
                          'slStatus', 'targetAOID', 'targetLeg', 'targetStatus', 'targetQty',
                          'cpOrderId', 'cpStatus', 'primaryAOID'
                          ]
            updateModifyInfo(self)
            self.sgParamModify.emit()
            saveJson(self)
    except:
        print(traceback.print_exc())