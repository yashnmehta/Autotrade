
from Application.Stretegies.OCheetah.Utills.keyParameters import reloadKeyParameter, getKeyParameterFile, saveJson
from Application.Stretegies.OCheetah.Utills.positionSupport import *
from Application.Stretegies.OCheetah.Utills.orderSupport import *
from Application.Stretegies.OCheetah.Utills.executionSupport import *
from Application.Stretegies.OCheetah.Utills.positionSupport import *
from Application.Services.Xts.Api.servicesIA import PlaceOrder, modifyOrder


def checkTrade(self, priceFeed):
    if self.isSlHitOnce == False:
    # self.updateWindows(priceFeed, self.modifyW)
        if (self.isStart):
            priceToken = priceFeed['Token']
            if (self.ceToken == priceToken):
                self.cePrice = priceFeed['LTP']
                try:
                    if (self.flagS1CE == False and (self.cePrice >= self.Sl1PtsValCE )):
                        # print("S1QTY",self.S1QtyCE,self.ceQTY, self.peQTY)
                        makeOrder(self, self.ceToken, self.S1QtyCE, 'Buy')
                        self.ceQTY = self.ceQTY - self.S1QtyCE
                        self.flagS1CE = True
                        self.isSLCE = True
                        self.sgParamModify.emit()
                        saveJson(self)
                    elif ( self.flagS2CE == False and (self.cePrice >= self.Sl2PtsValCE) ):
                        makeOrder(self, self.ceToken, self.S2QtyCE, 'Buy')
                        self.ceQTY = self.ceQTY - self.S2QtyCE
                        self.flagS2CE = True
                        self.isSLCE = True
                        self.sgParamModify.emit()
                        saveJson(self)
                    elif ( self.flagS3CE == False and (self.cePrice >= self.Sl3PtsValCE) ):
                        makeOrder(self, self.ceToken, self.S3QtyCE, 'Buy')
                        self.ceQTY = self.ceQTY - self.S3QtyCE
                        self.flagS3CE = True
                        self.isSLCE = True
                        self.sgParamModify.emit()
                        saveJson(self)

                    if (self.isSLCE == True):
                        if (self.flagS3CE == True and (self.cePrice <= self.Sl3PtsValCE)):
                            makeOrder(self, self.ceToken, self.S3QtyCE, 'Sell')
                            self.ceQTY = self.ceQTY + self.S3QtyCE
                            self.Sl3TimesCE -= 1
                            if self.Sl3TimesCE == 0:
                                self.Sl3PtsValCE += self.incrementSl
                                self.S3PtsCE += self.incrementSl
                            self.flagS3CE = False
                            self.sgParamModify.emit()
                            saveJson(self)
                        elif (self.flagS2CE == True and (self.cePrice <= self.Sl2PtsValCE)):
                            makeOrder(self, self.ceToken, self.S2QtyCE, 'Sell')
                            self.ceQTY = self.ceQTY + self.S2QtyCE
                            self.Sl2TimesCE -= 1
                            if self.Sl2TimesCE == 0:
                                self.Sl2PtsValCE += self.incrementSl
                                self.S2PtsCE += self.incrementSl
                            self.flagS2CE = False
                            self.sgParamModify.emit()
                            saveJson(self)
                        elif (self.flagS1CE == True and (self.cePrice <= self.Sl1PtsValCE)):
                            makeOrder(self, self.ceToken, self.S1QtyCE, 'Sell')
                            self.ceQTY = self.ceQTY + self.S1QtyCE
                            self.Sl1TimesCE -= 1
                            if self.Sl1TimesCE == 0:
                                self.Sl1PtsValCE += self.incrementSl
                                self.S1PtsCE += self.incrementSl
                            print('Sl1TimesCE', self.Sl1TimesCE)
                            self.flagS1CE = False
                            self.isSLCE = False
                            self.sgParamModify.emit()
                            saveJson(self)
                        if(self.flagS3CE == False and self.flagS2CE == False and self.flagS1CE == False):
                            self.isSLCE = False
                except:
                    print(traceback.print_exc())

            elif(self.peToken == priceToken):
                self.pePrice = priceFeed['LTP']


                if (self.flagS1PE == False  and (self.pePrice >= self.Sl1PtsValPE)):
                    makeOrder(self, self.peToken, self.S1QtyPE, 'Buy')
                    self.peQTY = self.peQTY - self.S1QtyPE
                    self.flagS1PE = True
                    self.isSLPE = True
                    self.sgParamModify.emit()
                    saveJson(self)

                elif (self.flagS2PE == False and (self.pePrice >= self.Sl2PtsValPE) ):
                    makeOrder(self, self.peToken, self.S2QtyPE, 'Buy')
                    self.peQTY = self.peQTY - self.S2QtyPE
                    self.flagS2PE = True
                    self.isSLPE = True
                    self.sgParamModify.emit()
                    saveJson(self)

                elif (self.flagS3PE == False and (self.pePrice >= self.Sl3PtsValPE) ):
                    makeOrder(self, self.peToken, self.S3QtyPE, 'Buy')
                    self.peQTY = self.peQTY - self.S3QtyPE
                    self.flagS3PE = True
                    self.isSLPE = True
                    self.sgParamModify.emit()
                    saveJson(self)

                if(self.isSLPE == True):
                    if (self.flagS3PE == True and (self.pePrice <= self.Sl3PtsValPE)):
                        makeOrder(self, self.peToken, self.S3QtyPE, 'Sell')
                        self.peQTY = self.peQTY + self.S3QtyPE
                        self.Sl3TimesPE -= 1
                        if self.Sl3TimesPE == 0:
                            self.Sl3PtsValPE += self.incrementSl
                            self.S3PtsCE += self.incrementSl
                        self.flagS3PE = False
                        self.isSLPE = False
                        self.sgParamModify.emit()
                        saveJson(self)

                    elif (self.flagS2PE == True and (self.pePrice <= self.Sl2PtsValPE)):
                        makeOrder(self, self.peToken, self.S2QtyPE, 'Sell')
                        self.peQTY = self.peQTY + self.S2QtyPE
                        self.Sl2TimesPE -= 1
                        if self.Sl2TimesPE == 0:
                            self.Sl2PtsValPE += self.incrementSl
                            self.S2PtsPE += self.incrementSl
                        self.flagS2PE = False
                        self.isSLPE = False
                        self.sgParamModify.emit()
                        saveJson(self)

                    elif (self.flagS1PE == True and (self.pePrice <= self.Sl1PtsValPE)):
                        makeOrder(self, self.peToken, self.S1QtyPE, 'Sell')
                        self.peQTY = self.peQTY + self.S1QtyPE
                        self.Sl1TimesPE -= 1
                        if self.Sl1TimesPE == 0:
                            self.Sl1PtsValPE += self.incrementSl
                            self.S1PtsPE += self.incrementSl
                        self.flagS1PE = False
                        self.isSLPE = False
                        self.sgParamModify.emit()
                        saveJson(self)

                    if (self.flagS3PE == False and self.flagS2PE == False and self.flagS1PE == False):
                        self.isSLPE = False
