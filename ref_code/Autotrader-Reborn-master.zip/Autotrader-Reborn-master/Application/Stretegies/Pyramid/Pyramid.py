import sys
import os
import threading
import traceback

import json
from PyQt5.QtCore import QObject,QTimer,pyqtSignal
from Application.Stretegies.Pyramid.Views.addW import addW
from Application.Stretegies.Pyramid.Views.modifyW import modifyW
import numpy as np
import datatable as dt
from Application.Services.Xts.Api.servicesIA import PlaceOrder
import datetime
import time
from Application.Services.Xts.Api.servicesMD import getQuote
from Application.Utils.configReader import refresh

# from Application.Stretegies.Pyramid.Utills.executionSupport import getBaseInfo


class logic(QObject):
    sgMTM = pyqtSignal(str,float)
    sgAlert = pyqtSignal(str)
    sgParamSet = pyqtSignal()
    sgStart = pyqtSignal()
    sgActivate =pyqtSignal()
    sgStop = pyqtSignal()
    sgClose =pyqtSignal()
    sgFolioOpenPos = pyqtSignal(list)
    ################################# Intialization Here ##################################################
    def __init__(self):
        super(logic, self).__init__()

        self.position = np.zeros((100, 15), dtype=object)
        self.posHeads = ['exch',
                         'token', 'symbol', 'strike', 'c/p', 'netqty',
                         'requestedOrder', 'openOrder', 'netamt', 'ltp', 'mtm',
                         'OpenQty', 'OpenAmt', 'DQty', 'Damt']

        self.addW = addW(self)
        self.modifyW = modifyW(self)

        self.initVaribles()
    def createTimer(self):
        self.timerUpdateWindows = QTimer()
        self.timerUpdateWindows.setInterval(500)
        # self.timerUpdateWindows.timeout.connect(self.updateValues)
        # self.timerUpdateWindows.timeout.connect(self.modifyW.updateValues)
        #

        self.timerGetPrices = QTimer()
        self.timerGetPrices.setInterval(500)
        # self.timerGetPrices.timeout.connect(self.getPrices)
        # self.timerUpdateWindows.timeout.connect(self.addW.getNewPriceData)

        self.timerExecution = QTimer()
        self.timerExecution.timeout.connect(self.makeFirstOrder)
        self.timerExecution.setSingleShot(True)





        # self.timerUpdateWindows.start()

    def createConnection(self):
        self.addW.pbApply.clicked.connect(self.setParameters)


        # self.addW.pbGet.clicked.connect(self.getBaseInfo)
        # self.addW.cbClient.

    def test1(self):
        print(getQuote(self, token=82425, seg='NSEFO', streamType=1501))


    def createObject(self,fo_contract):

        try:

            #print(self.folioName,'createObject has called')
            self.fo_contract=fo_contract



            refresh(self)
            refresh(self.addW)
            refresh(self.modifyW)

            self.addW.cbInstrumentType.currentIndexChanged.connect(self.addW.inschange)
            self.addW.cbSymbol.currentIndexChanged.connect(self.addW.symchange)
            self.addW.cbExp.currentIndexChanged.connect(self.addW.expchange)
            self.addW.cbStrikePrice.currentIndexChanged.connect(self.addW.changesrtike)


            self.addW.getContractFO(self.fo_contract)
            self.addW.cbSymbol.setCurrentText('BANKNIFTY')
            # self.symbol = self.addW.cbSymbol.currentText()

            # self.addW.getOptionExpiryList(self.fo_contract)
            # self.addW.getInstrumentTypeList(self.fo_contract)
            # self.addW.getStrikePriceList(self.fo_contract)
            # self.StrikePrice = self.addW.cbSrikePrice.currentText()

            # self.addW.getOPTTypeList(self.fo_contract)
            # self.addW.cbOptType.currentText()
            self.createConnection()
            self.createTimer()
        except:
            print(traceback.print_exc())



    def getCETable(self,symbol,exp):

        fltr = np.asarray([symbol])
        filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
        fltr1 = np.asarray([exp])
        filteredarray2 = filteredarray[np.in1d(filteredarray[:, 6], fltr1)]
        filteredarray1 = filteredarray2[filteredarray2[:, 12].argsort()]
        fltr2 = np.asarray(['CE'])
        ceTable= filteredarray1[np.in1d(filteredarray1[:, 8], fltr2)]

        return ceTable

    def getPETable(self,symbol,exp):
        fltr = np.asarray([symbol])
        filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
        fltr1 = np.asarray([exp])
        filteredarray2 = filteredarray[np.in1d(filteredarray[:, 6], fltr1)]
        filteredarray1 = filteredarray2[filteredarray2[:, 12].argsort()][::-1]
        fltr2 = np.asarray(['PE'])
        peTable= filteredarray1[np.in1d(filteredarray1[:, 8], fltr2)]
        return peTable



    def setParameters(self):
        try:
            self.qty = int(self.addW.leQty.text())
            if(self.qty <= 0 ):

                self.sgAlert.emit('Quantity must be greater than zero')
            else:

                self.folioName = self.addW.leFolioName.text()

                self.getKeyParameterFile(self.folioName)
                self.isExecuteOnTimer = self.addW.cxbPunchOnETime.isChecked()
                if (self.isExecuteOnTimer):
                    date = datetime.datetime.today().strftime('%Y-%m-%d ')

                    self.executionTime = datetime.datetime.strptime(
                        date + self.addW.lt1.text() + ":" + self.addW.lt2.text() + ":" + self.addW.lt3.text(),
                        '%Y-%m-%d %H:%M:%S')


                    checkTime = datetime.datetime.now() + datetime.timedelta(minutes=1)

                    self.timeout1 = int(self.executionTime.timestamp() - time.time()) * 1000
                    if(self.executionTime < checkTime):
                        return
                    else:
                        # print('in else')
                        self.timerExecution.setInterval(self.timeout1)
                        self.timerExecution.start()

                self.clientId = self.addW.cbClient.currentText()
                # self.instrumentType = self.addW.cbInstrumentType.currentText()



                self.srikePrice = self.addW.cbSrikePrice.currentText()
                self.optType = self.addW.cbOptType.currentText()
                self.symbol = self.addW.cbSymbol.currentText()
                self.expiry = self.addW.cbExp.currentText()
                self.upperRangeIndex = self.addW.cbUpperRange.currentIndex()
                self.lowerRangeIndex = self.addW.cbLowerRange.currentIndex()
                self.coverType = "Half" if self.addW.rbCHalf.isChecked() else "Full"
                self.strikeDecisionPoint = float(self.addW.leLowerPoint.text())

                self.cashToken = self.getCashToken(self.symbol)
                self.futureToken = self.getFutureToken(self.symbol)
                self.strikeDiff = self.getStrikeDiff(self.futureToken)
                self.freezeQty = int(self.fo_contract[self.futureToken-35000,14])
                # print('freezeQty',self.freezeQty)


                self.ceTable = self.getCETable(self.symbol, self.expiry)
                self.peTable = self.getPETable(self.symbol, self.expiry)
                self.saveJson()

                # print('stretegy parameter has been set, cashToken',self.cashToken)
                self.modifyW.cbSymbol.addItem(self.symbol)
                self.modifyW.cbExp.addItem(self.expiry)
                self.modifyW.leFolioName.setText(self.folioName)
                self.modifyW.cbClient.addItem(self.clientId)
                self.modifyW.leQty.setText(str(self.qty))
                self.modifyW.cbUpperRange.setCurrentIndex(self.upperRangeIndex)
                self.modifyW.cbLowerRange.setCurrentIndex(self.lowerRangeIndex)
                self.modifyW.leLowerPoint.setText('%.2f' % self.strikeDecisionPoint)
                print(" -*******-**----------")
                print(self.clientId, self.folioName)
                print(" -*******-**----------")

                # self.cashPrice = self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
                # self.futurePrice = self.getPrice(token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
                # self.ATM = self.getATM(self.cashPrice, self.strikeDiff)

                self.sgParamSet.emit()


        except:
            print(traceback.print_exc())

    def updateTrade(self, trade, source='on_trade'):
        # print('in update position stretegy')
        if (source == "on_trade"):
            trade1 = trade[0]
        else:
            trade1 = trade
        print(self.folioName, trade1)

        if (trade1[15] == self.folioName):

            exchange = trade1[20]
            token = trade1[2]
            fltr0 = np.asarray([token])
            filteredArray0 = self.position[np.in1d(self.position[:, 1], fltr0)]
            isRecordExist = False
            if (filteredArray0.size != 0):
                isRecordExist = True

            if (isRecordExist):
                array = self.position[np.where(self.position[:, 1] == token)]
                # print('in is record exist',array)
                prev_qty = array[0][5]
                prev_amt = array[0][8]

                Prev_Dqty = array[0][13]
                Prev_Damt = array[0][14]

                Dqty = Prev_Dqty + trade1[18]
                DAmt = Prev_Damt + trade1[19]

                newQty = prev_qty + trade1[18]
                newAmt = prev_amt + trade1[19]

                self.position[np.where(self.position[:, 1] == token), [5, 8, 13, 14]] = [newQty, newAmt, Dqty, DAmt]

                # print('updated position dekh lo',self.position)
            else:
                new = dt.Frame([[exchange],
                                [token], [trade1[4]], [float(trade1[6])], [trade1[7]], [trade1[18]],
                                [0], [0], [trade1[19]], [trade1[17]], [0.0],
                                [0.0], [0.0], [trade1[18]], [trade1[19]]
                                ]).to_numpy()

                # print('new position dekh lo',self.position,'\n\n\n\n',new,'\n\n\najsgd'
                #
                #       )
                self.position[self.lastSerialNo, :] = new
                self.lastSerialNo += 1
                # print('new position dekh lo',self.position)

            self.checkIsAnyPosition()

    def checkIsAnyPosition(self):
        isAnyOpenPos = False
        for i in self.position[:self.lastSerialNo,5]:
            if(i != 0):
                isAnyOpenPos = True
                self.isAnyOpenPos = isAnyOpenPos

                return
        self.isAnyOpenPos = isAnyOpenPos


        # if(np.unique(self.position[:self.lastSerialNo,5])==[0]):
        #     self.isAnyOpenPos = False

        # print('isANYposition',self.isAnyOpenPos)


    def tradeVarification(self):
        pass

    def updateOrder(self):
        pass

    def orderVarification(self):
        pass


    def makeFirstOrder(self):
        try:
            if(self.isFirstOrderPunch==False):

                # print('makefirst Order')
                self.cashPrice = self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
                self.futurePrice = self.getPrice(token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
                self.ATM = self.getATM(self.cashPrice, self.strikeDiff)

                ATM = self.getATM(self.cashPrice, self.strikeDiff)
                # print('in makefirstorder',ATM)
                ##################### get hedge qty ############################

                if(self.coverType=='Half'):
                    hedge_ce_Qty = self.qty * (self.lowerRangeIndex +1)
                    hedge_pe_Qty = self.qty * (self.upperRangeIndex + 1)
                else:
                    hedge_ce_Qty = self.qty * (self.lowerRangeIndex + self.upperRangeIndex +3)
                    hedge_pe_Qty = hedge_ce_Qty
                ###################################################################

                ##################### get hedge strike ############################

                peHedgeStrike = ATM - ((self.lowerRangeIndex + 2)* self.strikeDiff)
                ceHedgeStrike = ATM + ((self.upperRangeIndex + 2)* self.strikeDiff)


                # print('ceHedgeStrike',ceHedgeStrike,'peHedgeStrike',peHedgeStrike,'\n\n\n',self.ceTable,'\n\n\n',self.peTable)

                ceHedgeToken = self.ceTable[np.where(self.ceTable[:,12]==ceHedgeStrike),2][0][0]
                peHedgeToken = self.peTable[np.where(self.peTable[:,12]==peHedgeStrike),2][0][0]


                # print('ceHedgeToken',ceHedgeToken,'peHedgeToken',peHedgeToken,'peHedgeStrike',peHedgeStrike,'ceHedgeStrike',ceHedgeStrike)

                ###################################################################

                ###################### place order for hedge ######################


                while hedge_ce_Qty > self.freezeQty:
                    PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=ceHedgeToken, orderSide='Buy', qty=self.freezeQty,
                               limitPrice=0.0,
                               validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET', productType='NRML')
                    time.sleep(0.1)
                    hedge_ce_Qty -= self.freezeQty

                PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=ceHedgeToken, orderSide='Buy',qty=hedge_ce_Qty,
                           limitPrice=0.0,
                           validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET', productType='NRML')
                time.sleep(0.1)
                while hedge_pe_Qty > self.freezeQty:
                    PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=peHedgeToken, orderSide='Buy', qty=self.freezeQty,
                               limitPrice=0.0,
                               validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET', productType='NRML')
                    hedge_pe_Qty -= self.freezeQty
                    time.sleep(0.1)
                PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=peHedgeToken, orderSide='Buy', qty=hedge_pe_Qty,
                           limitPrice=0.0,
                           validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET', productType='NRML')
                time.sleep(0.1)


                ###################################################################

                ceList = self.getCEList(ATM)
                peList = self.getPEList(ATM)

                lis = ceList if (len(ceList) > len(peList) ) else peList
                for j,i in enumerate(lis):
                    ct = 0
                    pt = 0
                    if(j<len(ceList)):
                        ct = ceList[j,0]
                    if(j<len(peList)):
                        pt = peList[j,0]

                    ceQty = self.qty
                    peQty =self.qty
                    while ceQty > self.freezeQty:
                        PlaceOrder(self,exchange='NSEFO',clientID=self.clientId,token=ct,orderSide='Sell',qty=self.freezeQty,limitPrice=0.0,
                                   validity='DAY',disQty=0,triggerPrice=0,uid=self.folioName,orderType='MARKET',productType='NRML')
                        ceQty -= self.freezeQty
                        PlaceOrder(self,exchange='NSEFO',clientID=self.clientId,token=ct,orderSide='Sell',qty=self.freezeQty,limitPrice=0.0,
                                   validity='DAY',disQty=0,triggerPrice=0,uid=self.folioName,orderType='MARKET',productType='NRML')
                        peQty -= self.freezeQty
                        time.sleep(0.2)

                    PlaceOrder(self,exchange='NSEFO',clientID=self.clientId,token=ct,orderSide='Sell',qty=ceQty,limitPrice=0.0,
                               validity='DAY',disQty=0,triggerPrice=0,uid=self.folioName,orderType='MARKET',productType='NRML')

                    PlaceOrder(self,exchange='NSEFO',clientID=self.clientId,token=pt,orderSide='Sell',qty=peQty,limitPrice=0.0,
                               validity='DAY',disQty=0,triggerPrice=0,uid=self.folioName,orderType='MARKET',productType='NRML')
                    time.sleep(0.2)

                self.lastOrderPoint = self.cashPrice


                self.sgStart.emit()
                self.isStart = True
                self.isFirstOrderPunch =True
                self.saveJson()
                self.Slogger.info('First Order Placed Successfully..')
        except:
            self.Slogger.error(sys.exc_info()[1])

            print('lastOrderPoint',self.lastOrderPoint)

    def checkTrade(self,priceFeed):

        if(self.isStart):
            priceToken  = priceFeed['Token']
            if(self.cashToken == priceToken):
                cashPrice = priceFeed['LTP']
                self.cashPrice = cashPrice
                # print('cashPrice',cashPrice,'lastOrderPoint',self.lastOrderPoint)
                if(self.cashPrice > (self.lastOrderPoint + self.strikeDiff)):
                    # print('in if ')
                    atm = self.getATM(cashPrice,self.strikeDiff)
                    cornerStrikeBl = atm + ((self.upperRangeIndex +1) * self.strikeDiff)
                    array = self.position[np.where(self.position[:,3]==cornerStrikeBl),5]
                    isPosExist = self.checkShortPosExist(array)
                    ##################################
                    if(isPosExist != True):
                        self.placeHedgeOrder()

                        ceToken  =  self.ceTable[np.where(self.ceTable[:,12]==cornerStrikeBl),2][0][0]
                        peToken  =  self.peTable[np.where(self.peTable[:,12]==cornerStrikeBl),2][0][0]

                        PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=ceToken, orderSide='Sell',
                                   qty=self.qty,
                                   limitPrice=0.0,
                                   validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                                   productType='NRML')

                        PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=peToken, orderSide='Sell',
                                   qty=self.qty,
                                   limitPrice=0.0,
                                   validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                                   productType='NRML')
                        time.sleep(0.2)
                    ##################################
                    self.lastOrderPoint = cashPrice
                    self.saveJson()

                elif(self.cashPrice < (self.lastOrderPoint - self.strikeDiff)):
                    # print('in else',self.cashPrice,self.lastOrderPoint - 100.0,self.cashPrice < (self.lastOrderPoint - 100.0))
                    atm = self.getATM(cashPrice, self.strikeDiff)
                    cornerStrikeBr = atm - ((self.lowerRangeIndex +1)* self.strikeDiff)
                    array = self.position[np.where(self.position[:, 3] == cornerStrikeBr), 5]
                    isPosExist = self.checkShortPosExist(array)
                    ##################################
                    if (isPosExist != True):
                        self.placeHedgeOrder()

                        ####################### pledge hedge Qty #################################
                        ceToken = self.ceTable[np.where(self.ceTable[:, 12] == cornerStrikeBr), 2][0][0]
                        peToken = self.peTable[np.where(self.peTable[:, 12] == cornerStrikeBr), 2][0][0]



                        PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=ceToken, orderSide='Sell',
                                   qty=self.qty,
                                   limitPrice=0.0,
                                   validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                                   productType='NRML')
                        PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=peToken, orderSide='Sell',
                                   qty=self.qty,
                                   limitPrice=0.0,
                                   validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                                   productType='NRML')
                        time.sleep(0.2)
                    ##################################
                    self.lastOrderPoint = cashPrice
                    self.saveJson()

    def getPrice(self, token, seg, streamType):
        data = getQuote(self, token, seg, streamType)
        bid = data['AskInfo']['Price']
        ask = data['BidInfo']['Price']
        ltp = data['LastTradedPrice']
        return {"bid": bid, "ask": ask, "ltp": ltp}

    def placeHedgeOrder(self):
        ATM = self.getATM(self.cashPrice, self.strikeDiff)
        ##################### get hedge qty ############################

        peHedgeStrike = ATM - ((self.lowerRangeIndex + 2)* self.strikeDiff)
        ceHedgeStrike = ATM + ((self.upperRangeIndex + 2)* self.strikeDiff)


        ceHedgeToken = self.ceTable[np.where(self.ceTable[:,12]==ceHedgeStrike),2][0][0]
        peHedgeToken = self.peTable[np.where(self.peTable[:,12]==peHedgeStrike),2][0][0]

        ### while freeze qty

        PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=ceHedgeToken, orderSide='Buy', qty=self.qty,
                   limitPrice=0.0,
                   validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET', productType='NRML')
        PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=peHedgeToken, orderSide='Buy', qty=self.qty,
                   limitPrice=0.0,
                   validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET', productType='NRML')



    def updateMTM(self,data):
        if(self.isAnyOpenPos == True):
            if (data['Token'] in self.position[:,1]):
                fltr0 = np.asarray([data['Token']])
                array = self.position[np.in1d(self.position[:, 1], fltr0)][0]
                # print(array)
                netAmt = array[8]
                ltp = data['LTP']
                qty = array[5]
                mtm = netAmt + (qty * ltp)
                self.position[np.in1d(self.position[:, 1], fltr0),[9,10]] = [ltp,mtm]
                # print(self.position[np.in1d(self.position[:, 1], fltr0)][0])
                total_mtm = np.sum(self.position[:,10])
                self.sgMTM.emit(self.folioName,total_mtm)
                # print('emited')

    def initVaribles(self):
        self.stype = 'TSpecial'
        self.isStart = False
        self.isClose = False
        self.isFirstOrderPunch = False

        self.sl = 0.0
        self.tsl = 0.0
        self.cashPrice = 0.0
        self.futurePrice = 0.0
        self.ATM = 0.0
        self.strikeDiff = 0.0
        self.pairTotal = 0.0
        self.lastOrderPoint = 0

        self.isAnyOpenPos = False
        self.lastSerialNo = 0
        self.lotsize = 0
        self.DOI = datetime.datetime.today().strftime('%d%m%Y')





    def getCEList(self,ATMStrike):
        lowerRange= ATMStrike - ((self.lowerRangeIndex+1) *self.strikeDiff)
        upperRange= ATMStrike + ((self.upperRangeIndex+1) *self.strikeDiff)
        array1 = self.ceTable[np.where(self.ceTable[:, 12] >= lowerRange)]
        array2 = array1[np.where(array1[:, 12] <= upperRange)]
        array3 = array2[:, [2, 8, 12]]
        return array3

    def getPEList(self,ATMStrike):
        lowerRange= ATMStrike - ((self.lowerRangeIndex+1) *self.strikeDiff)
        upperRange= ATMStrike + ((self.upperRangeIndex+1) *self.strikeDiff)
        array1 = self.peTable[np.where(self.peTable[:, 12] >= lowerRange)]
        array2 = array1[np.where(array1[:, 12] <= upperRange)]
        array3 = array2[:, [2, 8, 12]]
        # print(array3)
        return array3

    def getExecutionTime(self):
        now = datetime.datetime.today()
        date = now.strftime('%Y-%m-%d ')
        a915 = datetime.datetime.strptime(date + '09:15:00', '%Y-%m-%d %H:%M:%S')
        a920 = datetime.datetime.strptime(date + self.etime, '%Y-%m-%d %H:%M:%S')
        self.timeout1 = int(a920.timestamp()-time.time())*1000
        return self.timeout1




    def getFutureToken(self,symbol=''):
        futureToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 17]
        return futureToken

    def getCashToken(self,symbol=''):
        # print(self.fo_contract)
        assetToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 9]

        # print(symbol,self.symbol,'getCashToken',assetToken)
        return assetToken

    def getStrikeDiff(self,futureToken):
        # print(self.fo_contract[futureToken-35000,:])
        strikeDiff = self.fo_contract[futureToken-35000,36]
        return strikeDiff

    def getATM(self,cashPrice,strikeDiff):
        ATM1 = (cashPrice / strikeDiff)
        frac = ATM1 % 1

        strikeDecisionPoint = float(self.addW.leLowerPoint.text())
        # print(frac)
        if(frac > strikeDecisionPoint):
            ATM = int(ATM1+1) * strikeDiff
        else:
            ATM= int(ATM1)  * strikeDiff
        # ATM1 = (cashPrice / strikeDiff) * strikeDiff
        return ATM

    # def getATM_CE_Token(self,atm,ceTable):
    #     ATM_CE_Token = ceTable[np.where(ceTable[:,12]==atm),2][0][0]
    #     return ATM_CE_Token

    # def getATM_PE_Token(self,atm,peTable):
    #     ATM_PE_Token = peTable[np.where(peTable[:,12]==atm),2][0][0]
    #     return ATM_PE_Token
    #

    def hideAddW(self):
        try:
            self.timerUpdateWindows.stop()
            self.addW.hide()
        except:
            print(traceback)
    def hideModifyW(self):
        self.timerUpdateWindows.stop()
        self.addW.hide()




    # def getCEPEPrice(self):
    #     try:
    #         # print('xyz1')
    #         data = getQuote(self,self.addW.ATM_CE_Token, 'NSEFO', 1501)
    #         self.addW.atmCEPrice = data['LastTradedPrice']
    #
    #         data1 = getQuote(self, self.addW.ATM_PE_Token, 'NSEFO', 1501)
    #         self.addW.atmPEPrice = data1['LastTradedPrice']
    #         # print('xyz2')
    #     except:
    #         print(traceback.print_exc())




    # def updateValues(self):
    #     try:
    #
    #         # print('abc')
    #
    #         self.addW.lb_ltp_cash.setText(str(self.addW.cashPrice))
    #         self.addW.lb_ltp_fo.setText(str(self.addW.futurePrice))
    #         self.addW.lb_atm.setText(str(self.addW.ATM))
    #
    #         self.addW.ATM_CE_Token=self.getATM_CE_Token(self.addW.ATM,self.addW.ceTable)
    #         self.addW.ATM_PE_Token=self.getATM_PE_Token(self.addW.ATM,self.addW.peTable)
    #
    #         pairTotal = self.addW.atmPEPrice + self.addW.atmCEPrice
    #         self.addW.lb_pTotal.setText('%.2f'%pairTotal)


        #
        # except:
        #     print(traceback.print_exc())

    # def getPrices(self):
    #     try:
    #         th = threading.Thread(target=self.getCEPEPrice,args=())
    #         th.start()
    #     except:
    #         print(traceback.print_exc())

    # def getBaseInfo(self):
    #     getBaseInfo(self)

    # def getBasePrices(self):
    #     try:
    #         data = getQuote(self, self.addW.cashToken, 'NSECM', 1501)
    #         self.addW.cashPrice=data['LastTradedPrice']
    #         data = getQuote(self, self.addW.futureToken, 'NSEFO', 1501)
    #         self.addW.futurePrice=data['LastTradedPrice']
    #
    #         self.addW.ATM = self.getATM(self.addW.cashPrice,self.addW.strikeDiff)
    #
    #         self.addW.ceTable = self.getCETable(self.addW.symbol,self.addW.expiry)
    #         self.addW.peTable = self.getPETable(self.addW.symbol,self.addW.expiry)
    #         self.updateValues()
    #     except:
    #         print(traceback.print_exc())
    def flushTradeData(self):
        self.position = np.zeros((100,11),dtype=object)


    def checkShortPosExist(self,array):
        isPos =False
        # print('array',array)
        for i in array[0]:
            if(i < 0):
                isPos = True
                return isPos
        return isPos

    def craeteKeyParameterJson(self,cf):
        if (cf):

            open_pos = self.position[:self.lastSerialNo, :].tolist()
            #self.DOI = self.DOI
            appOrderList = self.appOrderList[:self.lastSerialNo, :].tolist()
        else:

            open_pos = []
            appOrderList = []

        self.keyParameterJson = {
            "folioName": self.folioName,
            "stype": self.stype,
            "symbol": self.symbol,
            "lastOrderPoint": self.lastOrderPoint,
            "expiry": self.expiry,
            "upperRangeIndex":self.upperRangeIndex,
            "lowerRangeIndex": self.lowerRangeIndex,
            "coverType": self.coverType,
            "strikeDecisionPoint": self.strikeDecisionPoint,
            'clientId' : self.clientId ,
            'qty' : self.qty,
            'isFirstOrderPunch':self.isFirstOrderPunch,
            'open_position': open_pos,
            'DateOfInitialization': self.DOI

        }

    def reloadKeyParameter(self):
        try:
            f1 = open(self.keyParameterFile)
            self.keyParameterJson= json.load(f1)
            f1.close()
            self.stype = self.keyParameterJson['stype']
            self.symbol = self.keyParameterJson['symbol']
            self.expiry = self.keyParameterJson['expiry']
            self.clientId = self.keyParameterJson['clientId']
            self.upperRangeIndex = self.keyParameterJson['upperRangeIndex']
            self.lowerRangeIndex = self.keyParameterJson['lowerRangeIndex']
            self.coverType = self.keyParameterJson['coverType']
            self.strikeDecisionPoint = self.keyParameterJson['strikeDecisionPoint']
            self.lastOrderPoint = self.keyParameterJson['lastOrderPoint']
            self.qty  = self.keyParameterJson['qty']
            self.isFirstOrderPunch = self.keyParameterJson['isFirstOrderPunch']
            self.DOI = self.keyParameterJson['DateOfInitialization']

            if (self.keyParameterJson['open_position'] != []):
                self.open_position = np.asarray(self.keyParameterJson['open_position'])
                self.updateOpenPos()

            self.cashToken = self.getCashToken(self.symbol)
            self.futureToken = self.getFutureToken(self.symbol)
            self.strikeDiff = self.getStrikeDiff(self.futureToken)
            self.freezeQty = int(self.fo_contract[self.futureToken - 35000, 14])

            # self.position = np.asarray(self.keyParameterJson['position'])
            print(self.folioName,'position reload',type(self.position),self.position)

            # self.position = self.keyParameterJson['position']

            # print('ppp',self.symbol, self.expiry)

            self.ceTable = self.getCETable(self.symbol, self.expiry)
            self.peTable = self.getPETable(self.symbol, self.expiry)

            # print('stretegy parameter has been set, cashToken', self.cashToken)
            # print(self.folioName,self.modifyW)
            self.modifyW.leFolioName.setText(self.folioName)
            self.modifyW.cbSymbol.addItem(self.symbol)
            self.modifyW.cbExp.addItem(self.expiry)
            self.modifyW.leFolioName.setText(self.folioName)
            self.modifyW.cbClient.addItem(self.clientId)
            self.modifyW.leQty.setText(str(self.qty))
            self.modifyW.cbUpperRange.setCurrentIndex(self.upperRangeIndex)
            self.modifyW.cbLowerRange.setCurrentIndex(self.lowerRangeIndex)
            self.modifyW.leLowerPoint.setText('%.2f' % self.strikeDecisionPoint)

            # print('freezeQty', self.freezeQty)
        except:
            print(traceback.print_exc())
        # self.cashPrice = self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
        # self.futurePrice = self.getPrice(token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
        # self.ATM = self.getATM(self.cashPrice, self.strikeDiff)

    def updateOpenPos(self):

        for i in self.open_position:
            # print(i)
            # fltr = [i[1]]
            rowarray = np.where(self.position[:self.lastSerialNo, 1] == i[1])[0]

            if (rowarray.size != 0):

                rowNO = rowarray[0]

                filteredArray = self.position[np.where(self.position[:self.lastSerialNo, 1] == i[1])][0]

                openQty = i[5] + filteredArray[5]
                openamt = i[8] + filteredArray[8]

                editList = [5, 8, 11, 12, 13, 14]
                self.position[rowNO, editList] = [openQty, openamt, openQty, openamt, 0.0, 0.0]

            else:
                self.position[self.lastSerialNo] = [i[0], i[1], i[2], i[3], i[4], i[5], i[6], i[7], i[8], i[9], i[10],
                                                    i[5], i[8], 0.0, 0.0]
                self.lastSerialNo += 1

            self.checkIsAnyPosition()

            if (i[5] > 0):
                sellQ = i[5]
                buyQ = 0
            else:
                sellQ = 0
                buyQ = i[5]
            data = [self.userID, self.clientId, self.stype, self.folioName, i[0], i[1], 'stockname', i[2], self.expiry,
                    i[3], i[4], i[5], 0.0,
                    i[5], i[8], 0.0, buyQ, 0.0, sellQ, 0.0, 0.0, 0.0, self.lotsize, self.freezeQty, i[8], 0, 0.0]
            self.sgFolioOpenPos.emit(data)

    def saveJson(self,cf=False):
        self.getKeyParameterFile(self.folioName)
        self.craeteKeyParameterJson(cf)
        f2 = open(self.keyParameterFile, 'w')
        jInfo_new = json.dumps(self.keyParameterJson, indent=4)
        f2.write(jInfo_new)
        f2.close()

    def getKeyParameterFile(self,folioName):
        todate = datetime.datetime.today().strftime('%Y%m%d')
        loc = os.getcwd().split('Application')
        self.keyParameterFile = os.path.join(loc[0], 'Application', 'DB', 'Stretegy_data', todate,
                                             '%s.json' % folioName)


    def squreOff(self):
        for i in self.position:
            token = i[1]
            exchange = i[0]
            quantity = i[5]

            if(quantity==0):
                pass
            elif quantity > 0:
                absQuantity = abs(quantity)
                while(absQuantity > self.freezeQty):
                    # print('if while')
                    PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Sell',
                               qty=self.freezeQty,
                               limitPrice=0.0,
                               validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                               productType='NRML')
                    time.sleep(0.1)
                    absQuantity -= self.freezeQty
                PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Sell',
                           qty=absQuantity,
                           limitPrice=0.0,
                           validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                           productType='NRML')
                time.sleep(0.1)
            else:

                absQuantity = abs(quantity)
                while (absQuantity > self.freezeQty):
                    print('else while')
                    PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Buy',
                               qty= self.freezeQty,
                               limitPrice=0.0,
                               validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                               productType='NRML')
                    time.sleep(0.1)
                    absQuantity -= self.freezeQty
                PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Buy',
                           qty=absQuantity,
                           limitPrice=0.0,
                           validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                           productType='NRML')


                time.sleep(0.1)