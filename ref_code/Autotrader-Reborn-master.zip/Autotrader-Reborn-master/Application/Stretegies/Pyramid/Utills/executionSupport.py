import traceback
from Application.Services.Xts.Api.servicesMD import getQuote


def getBaseInfo(self):
    try:
        self.addW.symbol = self.addW.cbSymbol.currentText()
        self.addW.expiry = self.addW.cbExp.currentText()
        self.addW.cashToken = self.getCashToken(self.addW.symbol)

        self.addW.futureToken = self.getFutureToken(self.addW.symbol)
        self.addW.strikeDiff = self.getStrikeDiff(self.addW.futureToken)

        data = getQuote(self, self.addW.cashToken, 'NSECM', 1501)
        self.addW.cashPrice = data['LastTradedPrice']
        data = getQuote(self, self.addW.futureToken, 'NSEFO', 1501)
        self.addW.futurePrice = data['LastTradedPrice']

        self.addW.ATM = self.getATM(self.addW.cashPrice, self.addW.strikeDiff)

        self.addW.ceTable = self.getCETable(self.addW.symbol, self.addW.expiry)
        self.addW.peTable = self.getPETable(self.addW.symbol, self.addW.expiry)

        self.addW.lb_ltp_cash.setText(str(self.addW.cashPrice))
        self.addW.lb_ltp_fo.setText(str(self.addW.futurePrice))
        self.addW.lb_atm.setText(str(self.addW.ATM))

        self.addW.ATM_CE_Token = self.getATM_CE_Token(self.addW.ATM, self.addW.ceTable)
        self.addW.ATM_PE_Token = self.getATM_PE_Token(self.addW.ATM, self.addW.peTable)

        data = getQuote(self, self.addW.ATM_CE_Token, 'NSEFO', 1501)
        self.addW.atmCEPrice = data['LastTradedPrice']

        data1 = getQuote(self, self.addW.ATM_PE_Token, 'NSEFO', 1501)
        self.addW.atmPEPrice = data1['LastTradedPrice']

        pairTotal = self.addW.atmPEPrice + self.addW.atmCEPrice
        self.addW.lb_pTotal.setText('%.2f' % pairTotal)
        #
        # print('self.addW.ATM_CE_Token',self.addW.ATM_CE_Token,'self.addW.ATM_PE_Token',self.addW.ATM_PE_Token)

    except:
        print(traceback.print_exc())