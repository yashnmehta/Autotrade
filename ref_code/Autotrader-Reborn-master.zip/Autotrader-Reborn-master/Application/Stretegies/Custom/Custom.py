import os
import traceback

import json
from PyQt5.QtCore import QObject,QTimer,pyqtSignal
from Application.Stretegies.Custom.Views.addW import addW
from Application.Stretegies.Custom.Views.modifyW import modifyW
import numpy as np
import datatable as dt
from Application.Services.Xts.Api.servicesIA import PlaceOrder
import datetime
import time
from Application.Services.Xts.Api.servicesMD import getQuote
from Application.Utils.configReader import refresh




class logic(QObject):
    sgMTM = pyqtSignal(str,float)
    sgSL = pyqtSignal(str,float)
    sgTSL = pyqtSignal(str,float)
    sgAlert = pyqtSignal(str)
    sgParamSet = pyqtSignal()
    sgFolioOpenPos = pyqtSignal(list)

    ################################# Intialization Here ##################################################
    def __init__(self):
        super(logic, self).__init__()

        self.position = np.zeros((100,11),dtype=object)
        self.posHeads = ['exch',
                         'token','symbol','strike','c/p','qty',
                         'requestedOrder','openOrder','amt','ltp','mtm']
        self.addW = addW(self)
        self.modifyW = modifyW(self)
        self.initVaribles()
        self.createConnection()


    def initVaribles(self):
        self.stype = 'Custom'
        self.symbol = ''
        self.isStart = False
        self.isClose = False

        self.isSL = False
        self.isTrail = False
        self.isTarget =False

        self.sl = 0.0
        self.tsl = 0.0
        self.trailP = 0.0
        self.target = 0.0


        self.lastOrderPoint = 0
        self.isAnyOpenPos = False
        self.lastSerialNo = 0
        self.lotsize=0
        self.DOI = datetime.datetime.today().strftime('%d%m%Y')

    def setParameters(self):
        self.folioName = self.addW.leFolioName.text()
        self.getKeyParameterFile(self.folioName)
        self.clientId = self.addW.cbClient.currentText()
        self.isSL =  self.addW.cxbSL.isChecked()
        self.isTrail = self.addW.cxbTrail.isChecked()
        self.isSL =self.addW.cxbTarget.isChecked()

        self.sl =  - float(self.addW.leSL.text())
        self.tsl = self.sl
        self.trailP = float(self.addW.leTrail.text())
        self.target = float(self.addW.leTarget.text())

        self.saveJson()

        self.modifyW.leFolioName.setText(self.folioName)
        self.modifyW.cbClient.addItem(self.clientId)
        # self.modifyW.cxbSL.setChecked(self.isSL)
        # self.modifyW.cxbTrail.setChecked(self.isTrail)
        # self.modifyW.cxbTarget.setChecked(self.isTarget)
        #
        # self.modifyW.leSL.setText('%.2f'%self.sl)
        # self.modifyW.leTrail.setText('%.2f'%self.trailP)
        # self.modifyW.leTarget.setText('%.2f'%self.target)


        print(self.clientId, self.folioName)

        self.sgParamSet.emit()




    def createObject(self,fo_contract):
        self.fo_contract = fo_contract
        refresh(self)
        refresh(self.addW)
        refresh(self.modifyW)

    def updateTrade(self, trade, source='on_trade'):
        # print('in update position stretegy')
        if (source == "on_trade"):
            trade1 = trade[0]
        else:
            trade1 = trade
        # print(self.folioName,trade1)

        if (trade1[15] == self.folioName):

            exchange = trade1[20]
            token = trade1[2]
            fltr0 = np.asarray([token])
            filteredArray0 = self.position[np.in1d(self.position[:, 1], fltr0)]
            isRecordExist = False
            if (filteredArray0.size != 0):
                isRecordExist = True

            if (isRecordExist):
                array = self.position[np.where(self.position[:, 1] == token)]
                # print('in is record exist',array)
                prev_qty = array[0][5]
                prev_amt = array[0][8]

                Prev_Dqty = array[0][13]
                Prev_Damt = array[0][14]

                Dqty = Prev_Dqty + trade1[18]
                DAmt = Prev_Damt + trade1[19]

                newQty = prev_qty + trade1[18]
                newAmt = prev_amt + trade1[19]

                self.position[np.where(self.position[:, 1] == token), [5, 8, 13, 14]] = [newQty, newAmt, Dqty, DAmt]

                # print('updated position dekh lo',self.position)
            else:
                new = dt.Frame([[exchange],
                                [token], [trade1[4]], [float(trade1[6])], [trade1[7]], [trade1[18]],
                                [0], [0], [trade1[19]], [trade1[17]], [0.0],
                                [0.0], [0.0], [trade1[18]], [trade1[19]]
                                ]).to_numpy()

                # print('new position dekh lo',self.position,'\n\n\n\n',new,'\n\n\najsgd'
                #
                #       )
                self.position[self.lastSerialNo, :] = new
                self.lastSerialNo += 1
                # print('new position dekh lo',self.position)
            self.checkIsAnyPosition()

    def checkTrade(self,data):
        pass
        ####################################################
        ####################################################


    def updateMTM(self,data):
        if (self.isAnyOpenPos == True):
            if (data['Token'] in self.position[:, 1]):
                fltr0 = np.asarray([data['Token']])
                array = self.position[np.in1d(self.position[:, 1], fltr0)][0]
                netAmt = array[8]
                ltp = data['LTP']
                qty = array[5]
                mtm = netAmt + (qty * ltp)
                self.position[np.in1d(self.position[:, 1], fltr0), [9, 10]] = [ltp, mtm]
                total_mtm = np.sum(self.position[:, 10])
                self.mtm = total_mtm
                # print(self.stype, self.isAnyOpenPos,total_mtm)
                self.sgMTM.emit(self.folioName, total_mtm)

#        print('updateMTM ',self.folioName,self.mtm)
        self.checkSL()

    def checkSL(self):
        if(self.tsl):
            print(self.tsl,self,self.tsl+self.trailP,self.mtm-self.sl)
            if((self.tsl+self.trailP) <= (self.mtm + self.sl)):
                self.tsl = self.mtm + self.sl
                self.sgTSL.emit(self.folioName,self.tsl)


            ####################################################
            # if(self.mtm<=self.tsl):
            #     self.squreOff()
            # elif(self.mtm<=self.sl):
            #     self.squreOff()
            ####################################################
    def checkTarget(self):
        if(self.mtm>=self.target):
            self.squreOff()
            d = {'MTM': self.mtm, 'SlAmount': self.target}
            self.Slogger.info('Target Trigger (mtm>targetAmt)....', d)

    def createConnection(self):
        self.addW.pbApply.clicked.connect(self.setParameters)

    def checkIsAnyPosition(self):
        isAnyOpenPos = False
        print('isANypos', self.folioName, self.position[:self.lastSerialNo, 5])

        for i in self.position[:self.lastSerialNo, 5]:
            if (i != 0):
                isAnyOpenPos = True
                self.isAnyOpenPos = isAnyOpenPos
        self.isAnyOpenPos = isAnyOpenPos


    def hideAddW(self):
        self.addW.hide()

    def hideModifyW(self):
        self.timerUpdateWindows.stop()
        self.addW.hide()

    def squreOff(self):
        for i in self.position:
            token = i[1]
            exchange = i[0]
            quantity = i[5]
            self.freezeQty = self.fo_contract[token-35000,14]
            if(quantity==0):
                pass
            elif quantity > 0:
                absQuantity = abs(quantity)
                while(absQuantity > self.freezeQty):
                    # print('if while')
                    PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Sell',
                               qty=self.freezeQty,
                               limitPrice=0.0,
                               validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                               productType='NRML')
                    time.sleep(0.1)
                    absQuantity -= self.freezeQty
                PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Sell',
                           qty=absQuantity,
                           limitPrice=0.0,
                           validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                           productType='NRML')
                time.sleep(0.1)
            else:

                absQuantity = abs(quantity)
                while (absQuantity > self.freezeQty):
                    print('else while')
                    PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Buy',
                               qty= self.freezeQty,
                               limitPrice=0.0,
                               validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                               productType='NRML')
                    time.sleep(0.1)
                    absQuantity -= self.freezeQty
                PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Buy',
                           qty=absQuantity,
                           limitPrice=0.0,
                           validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                           productType='NRML')


                time.sleep(0.1)




    def saveJson(self,cf=False):
        self.getKeyParameterFile(self.folioName)
        self.craeteKeyParameterJson(cf)
        f2 = open(self.keyParameterFile, 'w')
        jInfo_new = json.dumps(self.keyParameterJson, indent=4)
        f2.write(jInfo_new)
        f2.close()

    def getKeyParameterFile(self,folioName):
        todate = datetime.datetime.today().strftime('%Y%m%d')
        loc = os.getcwd().split('Application')
        self.keyParameterFile = os.path.join(loc[0], 'Application', 'DB', 'Stretegy_data', todate,
                                             '%s.json' % folioName)



    def reloadKeyParameter(self):
        try:
            # print('in reload',self.folioName)

            f1 = open(self.keyParameterFile)
            self.keyParameterJson= json.load(f1)
            f1.close()
            self.stype = self.keyParameterJson['stype']
            self.symbol = self.keyParameterJson['symbol']
            self.clientId = self.keyParameterJson['clientId']


            # self.position = np.asarray(self.keyParameterJson['position'])
            print(self.folioName,'position reload',type(self.position),self.position)

            self.isSL = self.keyParameterJson['isSL']
            self.isTrail = self.keyParameterJson['isTrail']
            self.isTarget = self.keyParameterJson['isTarget']
            self.sl = self.keyParameterJson['SL']
            self.tsl = self.keyParameterJson['TrailSL']
            self.trailP = self.keyParameterJson['TrailP']
            self.target = self.keyParameterJson['Target']
            self.DOI = self.keyParameterJson['DateOfInitialization']
            if (self.keyParameterJson['open_position'] != []):
                self.open_position = np.asarray(self.keyParameterJson['open_position'], dtype=object)
                self.updateOpenPos()






            self.modifyW.leFolioName.setText(self.folioName)

            self.modifyW.cbClient.addItem(self.clientId)

            self.modifyW.cxbSL.setChecked(self.isSL)
            self.modifyW.cxbTrail.setChecked(self.isTrail)
            self.modifyW.cxbTarget.setChecked(self.isTarget)

            self.modifyW.leSL.setText('%.2f' % self.sl)
            self.modifyW.leTrail.setText('%.2f' % self.trailP)
            self.modifyW.leTarget.setText('%.2f' % self.target)

            # print('freezeQty', self.freezeQty)
        except:
            print('in reload',traceback.print_exc())
        # self.cashPrice = self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
        # self.futurePrice = self.getPrice(token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
        # self.ATM = self.getATM(self.cashPrice, self.strikeDiff)

    def updateOpenPos(self):

        for i in self.open_position:
            # print(i)
            # fltr = [i[1]]
            rowarray = np.where(self.position[:self.lastSerialNo, 1] == i[1])[0]

            if (rowarray.size != 0):

                rowNO = rowarray[0]

                filteredArray = self.position[np.where(self.position[:self.lastSerialNo, 1] == i[1])][0]

                openQty = i[5] + filteredArray[5]
                openamt = i[8] + filteredArray[8]

                editList = [5, 8, 11, 12, 13, 14]
                self.position[rowNO, editList] = [openQty, openamt, openQty, openamt, 0.0, 0.0]

            else:
                self.position[self.lastSerialNo] = [i[0], i[1], i[2], i[3], i[4], i[5], i[6], i[7], i[8], i[9], i[10],
                                                    i[5], i[8], 0.0, 0.0]
                self.lastSerialNo += 1

            self.checkIsAnyPosition()

            if (i[5] > 0):
                sellQ = i[5]
                buyQ = 0
            else:
                sellQ = 0
                buyQ = i[5]
            data = [self.userID, self.clientId, self.stype, self.folioName, i[0], i[1], 'stockname', i[2], self.expiry,
                    i[3], i[4], i[5], 0.0,
                    i[5], i[8], 0.0, buyQ, 0.0, sellQ, 0.0, 0.0, 0.0, self.lotsize, self.freezeQty, i[8], 0, 0.0]
            self.sgFolioOpenPos.emit(data)

    def flushTradeData(self):
        self.position = np.zeros((100,11),dtype=object)




    def craeteKeyParameterJson(self,cf):
        if (cf):

            open_pos = self.position[:self.lastSerialNo, :].tolist()
            #self.DOI = self.DOI
        else:

            open_pos = []
            #self.DOI = datetime.datetime.today().strftime('%d%m%Y')



        self.keyParameterJson = {
            "folioName": self.folioName,
            "stype": self.stype,
            "symbol": self.symbol,
            'clientId' : self.clientId ,
            "SL":self.sl,
            "TrailSL":self.tsl,
            "TrailP":self.trailP,
            "Target":self.target,
            "isSL": self.isSL,
            "isTrail":self.isTrail,
            "isTarget":self.isTarget,
            'open_position': open_pos,
            'DateOfInitialization':self.DOI


        }
