import os
import threading
import traceback
import sys
import json
from PyQt5.QtCore import *
from PyQt5.QtCore import QObject,QTimer,pyqtSignal
from PyQt5.QtGui import QKeySequence
from PyQt5.QtWidgets import QMessageBox,QApplication

from Application.Stretegies.JodiATM.Utills.checkTrade import checkTrade
from Application.Stretegies.JodiATM.Utills.orderSupport import makeOrder
from Application.Stretegies.JodiATM.Utills.setParameters import setParameters
from Application.Stretegies.JodiATM.Utills.sqreoff import squreOff
from Application.Stretegies.JodiATM.Views.addW import addW
from Application.Stretegies.JodiATM.Views.modifyW import modifyW
import numpy as np
import datatable as dt
from Application.Services.Xts.Api.servicesIA import PlaceOrder
import datetime
import time
from Application.Services.Xts.Api.servicesMD import getQuote
from Application.Utils.configReader import refresh
from Application.Stretegies.JodiATM.Utills.executionSupport import getBaseInfo, setParametersModifyW, modifyBaseInfo
from Application.Stretegies.JodiATM.Utills.keyParameters import reloadKeyParameter, getKeyParameterFile, saveJson
from Application.Stretegies.JodiATM.Utills.eventsBind import eventsBind
from Application.Stretegies.JodiATM.Utills.timer import createTimer
from Application.Stretegies.JodiATM.Utills.executionSupport import *
from Application.Stretegies.JodiATM.Utills.signal import configureSignals
'''
bootstrap Strategy
'''
class logic(QObject):
    sgMTM = pyqtSignal(str, float)
    sgSL = pyqtSignal(str, float)
    sgTarget = pyqtSignal(str, float)
    sgAlert = pyqtSignal(str)
    sgParamSet = pyqtSignal()
    sgStart = pyqtSignal()
    sgActivate = pyqtSignal()
    sgStop = pyqtSignal()
    sgClose = pyqtSignal()
    sgFolioOpenPos = pyqtSignal(list)
    ################################# Intialization Here ##################################################
    def __init__(self):
        super(logic, self).__init__()
        try:
            self.position = np.zeros((100,15),dtype=object)
            self.posHeads = ['exch',
                             'token','symbol','strike','c/p','netqty',
                             'requestedOrder','openOrder','netamt','ltp','mtm',
                             'OpenQty','OpenAmt','DQty','Damt']

            # initialize add and modify window
            self.addW = addW(self)
            self.modifyW = modifyW(self)
            # initialize core variables
            self.setAllShortCut()

            self.initVaribles()

        except:
            print(traceback.print_exc())

    def createObject(self,fo_contract):

        try:
            #print(self.folioName,'createObject has called')
            self.fo_contract=fo_contract
            refresh(self)
            refresh(self.addW)
            refresh(self.modifyW)
            self.addW.getSymbolList(self.fo_contract)
            self.addW.cbSymbol.setCurrentText('BANKNIFTY')
            self.symbol = self.addW.cbSymbol.currentText()
            self.addW.getOptionExpiryList(self.fo_contract)
            self.createTimer()
            # bind events
            eventsBind(self)
            # configure timers

            # configure signals
            # print("11")
            #configureSignals(self)
        except:
            print(traceback.print_exc())

    def setParameters(self):
        setParameters(self,self.addW)

    def createTimer(self):
        createTimer(self)

    def updateTrade(self,trade,source="on_Trade"):
        try:
            # print('in update position stretegy')
            trade1 = trade
            # print('trade,trade1',trade,trade1)

            if(source == "on_Trade"):
                trade1 = trade[0]
            else:
                trade1 = trade
            if(trade1[15]==self.folioName):

                exchange = trade1[20]
                token = trade1[2]
                fltr0 = np.asarray([token])
                filteredArray0 = self.position[np.in1d(self.position[:, 1], fltr0)]
                isRecordExist = False
                if(filteredArray0.size!=0):
                    isRecordExist=True

                if(isRecordExist):
                    array = self.position[np.where(self.position[:,1]==token)]
                    # print('in is record exist',array)
                    prev_qty = array[0][5]
                    prev_amt = array[0][8]

                    Prev_Dqty=array[0][13]
                    Prev_Damt=array[0][14]

                    Dqty=Prev_Dqty + trade1[18]
                    DAmt = Prev_Damt + trade1[19]

                    newQty = prev_qty + trade1[18]
                    newAmt = prev_amt + trade1[19]

                    self.position[np.where(self.position[:, 1] == token),[5,8,13,14]] = [newQty,newAmt,Dqty,DAmt]

                    # print('updated position dekh lo',self.position)
                else:
                    new = dt.Frame([[exchange],
                            [token],[trade1[4]],[float(trade1[6])],[trade1[7]],[trade1[18]],
                            [0],[0],[trade1[19]],[trade1[17]],[0.0],
                            [0.0],[0.0],[trade1[18]],[trade1[19]]
                                    ]).to_numpy()

                    # print('new position dekh lo',self.position,'\n\n\n\n',new,'\n\n\najsgd'
                    #
                    #       )
                    self.position[self.lastSerialNo,:] = new
                    self.lastSerialNo+=1

                checkIsAnyPosition(self)
                # saveJson(self)
        except:
            print('error in uptrade',traceback.print_exc())

    def getPrice(self, token, seg, streamType):
        data = getQuote(self, token, seg, streamType)
        # print("data jodiATM",data)
        ltp = data['LastTradedPrice']
        try:
            bid = data['AskInfo']['Price']
            ask = data['BidInfo']['Price']
        except:
            bid = 0.00
            ask = 0.00
        return {"bid": bid, "ask": ask, "ltp": ltp}

    def makeFirstOrder(self):
        print('makeFirstOrder',self.isFirstOrderPunch)
        try:
            if(self.isFirstOrderPunch==False):
                print('makeFirstOrder',self.baseQty)
                makeOrder(self, self.ceToken, self.baseQty, 'Sell')
                makeOrder(self, self.peToken, self.baseQty, 'Sell')
                # self.cashPrice = self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
                # self.futurePrice = self.getPrice(token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
                # self.ATM = getATM(self,self.cashPrice + self.adjPts, self.strikeDiff)

                self.getNewData(isFirst=True)
                # self.placeFirstOrder()

                self.blDP = self.SlDict['Bullish'][str(self.CSlLeg+1)][0]
                self.brDP = self.SlDict['Bearish'][str(self.CSlLeg+1)][0]

                self.modifyW.lb_slLeg.setText(str(self.CSlLeg))
                self.modifyW.leBRDP.setText('%.2f' % self.brDP)
                self.modifyW.leBLDP.setText('%.2f' % self.brDP)
                self.modifyW.leBLRCP.setText('%.2f' % self.BLRCP)
                self.modifyW.leBRRCP.setText('%.2f' % self.BRRCP)
                self.modifyW.lb_revP.setText('%.2f' % self.reversalP)
                self.modifyW.lbTrend.setText(self.trend)


                self.sgStart.emit()
                self.isStart = True
                self.isFirstOrderPunch =True

                setParametersModifyW(self,self.modifyW)
                saveJson(self)
                self.Slogger.info('First Order Placed Successfully..')
        except:
            self.Slogger.error(sys.exc_info()[1])


    def modifyParameter(self):
        # print("modifyParameter:")
        if(self.isFirstOrderPunch==False):
            # print("modifyParameter:11111")
            self.setParameters()
        else:
            # print("modifyParameter:1111/1")
            self.SlAmount = float(self.modifyW.leSLAmount.text())
            self.adjPts = float(self.modifyW.leAdjPts.text())
            self.sgSL.emit(self.folioName, self.SlAmount)
            self.targetAmt = float(self.modifyW.leTargetAmount.text())
            self.sgTarget.emit(self.folioName, self.targetAmt)
            self.modifyW.leSLAmount.setText('%.2f'%self.SlAmount)
            self.modifyW.leTargetAmount.setText('%.2f' % self.targetAmt)
            self.modifyW.leRSLAmount.setText('%.2f' % self.SlAmount)
            self.modifyW.leRTargetAmount.setText('%.2f' % self.targetAmt)
            #self.modifyW.leAdjPts.setText()
            saveJson(self)

        self.hideModifyW()

    def checkTrade(self,priceFeed):
        checkTrade(self,priceFeed)



    def updateMTM(self,data):
        if(self.isAnyOpenPos == True):
            if (data['Token'] in self.position[:,1]):
                fltr0 = np.asarray([data['Token']])
                array = self.position[np.in1d(self.position[:, 1], fltr0)][0]
                # print(array)
                netAmt = array[8]
                ltp = data['LTP']
                qty = array[5]
                mtm = netAmt + (qty * ltp)
                self.position[np.in1d(self.position[:, 1], fltr0),[9,10]] = [ltp,mtm]
                # print(self.position[np.in1d(self.position[:, 1], fltr0)][0])
                total_mtm = np.sum(self.position[:,10])
                self.mtm = total_mtm
                self.sgMTM.emit(self.folioName,total_mtm)
                # print('emited')
                self.modifyW.leRMTM.setText('%.2f'%total_mtm)
                self.checkSL()
                self.checkTarget()

    def checkTarget(self):
        if(self.isSlHitOnce==False ):

            if(self.mtm>=self.targetAmt):
                self.isSlHitOnce = True
                self.squreOff()

                d = {'MTM': self.mtm, 'SlAmount': self.targetAmt}
                self.Slogger.info('Target Trigger (mtm>targetAmt)....', d)


    def checkSL(self):
        if(self.isSlHitOnce==False and self.SlAmount != 0 and self.isStart==True):
            if(self.mtm<=self.SlAmount):
                # print('trgger sl', self.mtm, self.SlAmount)
                self.isSlHitOnce = True
                self.squreOff()
                d = {'MTM': self.mtm, 'SlAmount': self.SlAmount}
                self.Slogger.info('SL Trigger (mtm>Slamt)....', d)
            ####################################################
        # print("SlAmount:,", self.SlAmount)

    def setAllShortCut(self):
        # print("parthhhhhhhhhhhhh")
        self.addW.leQty.sc_up = QShortcut(QKeySequence('Up'),self.addW.leQty)
        self.addW.leQty.sc_up.setContext(Qt.WidgetWithChildrenShortcut)
        self.addW.leQty.sc_up.activated.connect(lambda:inc_v(self,self.addW))
        self.addW.leQty.sc_down = QShortcut(QKeySequence('Down'), self.addW.leQty)
        self.addW.leQty.sc_down.setContext(Qt.WidgetWithChildrenShortcut)
        self.addW.leQty.sc_down.activated.connect(lambda :dec_v(self,self.addW))


        self.modifyW.leQty.sc_up = QShortcut(QKeySequence('Up'),self.modifyW.leQty)
        self.modifyW.leQty.sc_up.setContext(Qt.WidgetWithChildrenShortcut)
        self.modifyW.leQty.sc_up.activated.connect(lambda:inc_v(self,self.modifyW))
        self.modifyW.leQty.sc_down = QShortcut(QKeySequence('Down'), self.modifyW.leQty)
        self.modifyW.leQty.sc_down.setContext(Qt.WidgetWithChildrenShortcut)
        self.modifyW.leQty.sc_down.activated.connect(lambda:dec_v(self,self.modifyW))
    #
    def initVaribles(self):
        self.stype = 'JodiATM'
        self.isStart = False
        self.isClose = False
        self.isFirstOrderPunch = False
        self.isParameterSet = False
        self.executionRunning =False
        self.cashPrice = 0.0
        self.futurePrice = 0.0
        self.ATM = 0.0
        self.strikeDiff = 0.0
        self.pairTotal = 0.0

        self.lastOrderPoint = 0

        self.isSlHitOnce = False
        self.isAnyOpenPos = False
        self.lastSerialNo = 0

        # self.CSlDict = {"Bullish":{1:[0,0],2:[0,0],3:[0,0],4:[0,0]},
        #                 "Bearish":{1:[0,0],2:[0,0],3:[0,0],4:[0,0]}}
        #
        self.SlDict = {"Bullish":{1:[0,0],2:[0,0],3:[0,0],4:[0,0]},
                        "Bearish":{1:[0,0],2:[0,0],3:[0,0],4:[0,0]}}

        # self.NSlBLDict = {"Bullish":{1:[0,0],2:[0,0],3:[0,0],4:[0,0]},
        #                 "Bearish":{1:[0,0],2:[0,0],3:[0,0],4:[0,0]}}
        #
        # self.NSlBRDict = {"Bullish": {1: [0, 0], 2: [0, 0], 3: [0, 0], 4: [0, 0]},
        #                   "Bearish": {1: [0, 0], 2: [0, 0], 3: [0, 0], 4: [0, 0]}}
        #
        self.CSlLeg = 0        #  0  / 1 / 2 / 3 / 4
        self.trend = 'Nutral'  #  Bullish / Bearish /Nutral

        # self.CPairStrike = 0
        # self.strike_up   = 0
        # self.strike_down = 0
        # self.CPairStrike = 0
        # self.slPonit = 0
        # self.slPonitUp = 0
        # self.slPonitDown = 0
        # self.revPonit = 0

        self.tokenList = [0,0,0,0,0,0,0,0]
        """        # tokenlist  
                                0 cashToken  
                                1 futureToken
                                2 ATM CE Token
                                3 ATM PE Token
                                4 SCE Token                               
                                5 SPE Token                               
                                6 HCE Token                               
                                7 HPE Token                               
        """


        self.ceToken = 0
        self.ceTokenUp = 0
        self.ceTokenDown = 0

        self.peToken = 0
        self.peTokenUp = 0
        self.peTokenDown = 0

        self.ofset = 0
        self.threshold = 0
        self.diffPoints = 0

        self.mtm = 0.0
        self.sl = 0.0
        self.tsl = 0.0

        self.SlAmount = 0
        self.targetAmt = 0.0

        self.BLRCP = 0
        self.BRRCP = 0
        self.brDP = 0
        self.blDP = 0
        self.reversalP = 0
        self.lotsize = 0
        self.DOI = datetime.datetime.today().strftime('%d%m%Y')

        # self.upCompletionPts = 0
        # self.downCompletionPts = 0
    def setLTP(self, window):
        self.cashPrice = float(window.leLTP.text())
        print("cashPrice:", self.cashPrice)

    def updateOrder(self,order,orderDict):
        pass
    def hideAddW(self):
        try:
            self.timerUpdateWindows.stop()
            self.addW.hide()
        except:
            print(traceback)

    # def checkTrade(self, priceFeed):
    #     # print("check Tread!!!")
    #     self.updateWindows(priceFeed)
    #     pass

    def hideModifyW(self):
        self.timerUpdateWindows.stop()
        self.timerGetPrices.stop()
        self.modifyW.hide()

    def getBaseInfoModify(self):
        modifyBaseInfo(self)

    def getBaseInfo(self,window):
        getBaseInfo(self,window)

    def getBasePrices(self, window):
        print("getbaseinfooooo")
        try:
            data = getQuote(self, window.cashToken, 'NSECM', 1501)
            print("self.addW.cashToken:",window.cashToken, data)
            window.cashPrice=data['LastTradedPrice']
            data = getQuote(self, window.futureToken, 'NSEFO', 1501)
            window.futurePrice=data['LastTradedPrice']

            window.ATM = getATM(self,window.cashPrice,window.strikeDiff)
            window.cashToken = getCashToken(self,window.symbol)
            window.strikeDiff = getStrikeDiff(self,window.futureToken)
            window.ceTable = getCETable(self,window.symbol,window.expiry)
            window.peTable = getPETable(self,window.symbol,window.expiry)
            updateValues(self)
        except:
            print(traceback.print_exc())

    def flushTradeData(self):
        self.position = np.zeros((100,11),dtype=object)

    def checkShortPosExist(self,array):
        isPos =False
        # print('array',array)
        for i in array[0]:
            if(i < 0):
                isPos = True
                return isPos
        return isPos

    def reloadKeyParameter(self):
        try:
            reloadKeyParameter(self)
        except:
            print(traceback.print_exc())
        # self.cashPrice = self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
        # self.futurePrice = self.getPrice(token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
        # self.ATM = self.getATM(self.cashPrice, self.strikeDiff)

    def squreOff(self):
        squreOff(self)

    def getKeyParameterFile(self, folioName):
        getKeyParameterFile(self, folioName)
    def connect2slots(self):
        eventsBind(self)

    def saveJson(self, cf=False):
        saveJson(self, cf)

    def showSLDictW(self):
        self.modifyW.a = QWidget()
        self.modifyW.a.setMinimumHeight(200)
        self.modifyW.a.setMinimumWidth(500)
        abc = QLabel(self.modifyW.a)
        x= str(self.SlDict).replace('],','],\n\t').replace("'B","\n'B")
        abc.setText(x)
        self.modifyW.a.show()

    def switchCurrent2Upper(self):
        self.executionRunning=True

        makeOrder(self, self.ceToken, self.tradeQty, 'Buy')
        makeOrder(self, self.peToken, self.tradeQty, 'Buy')
        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.ceToken, orderSide='Buy',
        #            qty=self.tradeQty, limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #            productType='NRML')
        #
        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.peToken, orderSide='Buy',
        #            qty=self.tradeQty, limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #            productType='NRML')
        # time.sleep(0.2)


        ## sell
        makeOrder(self, self.ceTokenUp, self.tradeQty, 'Sell')
        makeOrder(self, self.peTokenUp, self.tradeQty, 'Sell')
        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.ceTokenUp, orderSide='Sell',
        #            qty=self.tradeQty, limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #            productType='NRML')
        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.peTokenUp, orderSide='Sell',
        #            qty=self.tradeQty, limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #            productType='NRML')
        # time.sleep(0.2)
        self.executionRunning=False

    def switchUpper2Current(self):
        self.executionRunning=True
        makeOrder(self, self.ceTokenUp, self.tradeQty, 'Buy')
        makeOrder(self, self.peTokenUp, self.tradeQty, 'Buy')
        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.ceTokenUp, orderSide='Buy',
        #            qty=self.tradeQty, limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #            productType='NRML')
        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.peTokenUp, orderSide='Buy',
        #            qty=self.tradeQty, limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #            productType='NRML')
        # time.sleep(0.2)

        # sell
        makeOrder(self, self.ceToken, self.tradeQty, 'Sell')
        makeOrder(self, self.peToken, self.tradeQty, 'Sell')
        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.ceToken,
        #            orderSide='Sell',
        #            qty=self.tradeQty, limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #            productType='NRML')
        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.peToken, orderSide='Sell',
        #            qty=self.tradeQty, limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #            productType='NRML')
        # time.sleep(0.2)

        self.executionRunning=False

    def switchCurrent2Lower(self):
        self.executionRunning=True
        makeOrder(self, self.ceToken, self.tradeQty, 'Buy')
        makeOrder(self, self.peToken, self.tradeQty, 'Buy')

        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.ceToken, orderSide='Buy',
        #            qty=self.tradeQty, limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #            productType='NRML')
        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.peToken, orderSide='Buy',
        #            qty=self.tradeQty, limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #            productType='NRML')
        # time.sleep(0.2)

        # sell
        makeOrder(self, self.ceTokenDown, self.tradeQty, 'Sell')
        makeOrder(self, self.peTokenDown, self.tradeQty, 'Sell')

        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.ceTokenDown, orderSide='Sell',
        #            qty=self.tradeQty, limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #            productType='NRML')
        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.peTokenDown, orderSide='Sell',
        #            qty=self.tradeQty, limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #            productType='NRML')
        # time.sleep(0.2)

        self.executionRunning=False

    def switchLower2Current(self):
        self.executionRunning=True
        makeOrder(self, self.ceTokenDown, self.tradeQty, 'Buy')
        makeOrder(self, self.peTokenDown, self.tradeQty, 'Buy')
        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.ceTokenDown, orderSide='Buy',
        #            qty=self.tradeQty, limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #            productType='NRML')
        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.peTokenDown, orderSide='Buy',
        #            qty=self.tradeQty, limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #            productType='NRML')
        # time.sleep(0.2)

        ## sell
        makeOrder(self, self.ceToken, self.tradeQty, 'Sell')
        makeOrder(self, self.peToken, self.tradeQty, 'Sell')
        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.ceToken,
        #            orderSide='Sell',
        #            qty=self.tradeQty, limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #            productType='NRML')
        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.peToken,
        #            orderSide='Sell',
        #            qty=self.tradeQty, limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #            productType='NRML')
        # time.sleep(0.2)

        self.executionRunning=False



    def placeFirstOrder(self):
        print('placeFirstOrder')
        self.executionRunning=True
        makeOrder(self, self.ceToken, self.baseQty, 'Sell')
        makeOrder(self, self.peToken, self.baseQty, 'Sell')
        # while ceQty > self.freezeQty:
        #     PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.ceToken, orderSide='Sell',
        #                qty=self.freezeQty, limitPrice=0.0,
        #                validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #                productType='NRML')
        #     ceQty -= self.freezeQty
        #     PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.peToken, orderSide='Sell',
        #                qty=self.freezeQty, limitPrice=0.0,
        #                validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
        #                productType='NRML')
        #     peQty -= self.freezeQty
        #     time.sleep(0.2)

        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.ceToken, orderSide='Sell', qty=ceQty,
        #            limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET', productType='NRML')
        #
        # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.peToken, orderSide='Sell', qty=peQty,
        #            limitPrice=0.0,
        #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET', productType='NRML')
        # time.sleep(0.2)
        self.executionRunning=False

    # def changeAdjPts(self, window):
    #     self.adjPts = float(window.leAdjPts.text())
    #     adjCashprice = float(window.lb_ltp_cash.text()) + self.adjPts
    #     window.lbAdjCashP.setText('%.2f' % adjCashprice)
    #
    #
    #
    #     self.getNewData()
    #
    #     # self.blDP = self.SlDict['Bullish'][str(self.CSlLeg + 1)][0]
    #     # self.blDP = self.SlDict['Bullish'][str(self.CSlLeg + 1)][0]
    #     # self.reversalP = self.SlDict['Bullish'][str(self.CSlLeg)][1]
    #
    #     if (self.trend == "Bullish"):
    #         self.reversalP = self.SlDict['Bullish'][str(self.CSlLeg)][1]
    #         if (lastBLRCP == self.blDP):
    #             self.blDP = lastBLRCP
    #         else:
    #             self.blDP = self.SlDict['Bullish'][str(self.CSlLeg+1)][0]
    #
    #         self.brDP = self.SlDict['Bearish'][str(1)][0]
    #
    #         if (self.trend == "Bearish"):
    #             self.reversalP = self.SlDict['Bearish'][str(self.CSlLeg)][1]
    #             if (lastBRRCP == self.brDP):
    #                 self.brDP = lastBRRCP
    #             else:
    #                 self.brDP = self.SlDict['Bearish'][str(self.CSlLeg+1)][0]
    #
    #             self.blDP = self.SlDict['Bullish'][str(1)][0]
    #
    #
    #         # self.blDP = self.blDP - self.adjPts
    #         # self.brDP = self.brDP - self.adjPts
    #         # self.reversalP = self.reversalP - self.reversalP
    #         window.leBRDP.setText('%.2f' % self.brDP)
    #         window.leBLDP.setText('%.2f' % self.brDP)
    #         window.leBLRCP.setText('%.2f' % self.BLRCP)
    #         window.leBRRCP.setText('%.2f' % self.BRRCP)
    #         window.lb_revP.setText('%.2f' % self.reversalP)
    #
    #
    #
    #     saveJson(self)
    #     # updateValues(self)


    # def changeAdjPts(self, window):
    #     self.adjPts = float(window.leAdjPts.text())
    #     adjCashprice = float(window.lb_ltp_cash.text()) + self.adjPts
    #     window.lbAdjCashP.setText('%.2f' % adjCashprice)
    #     self.getNewData()
    #     if (self.trend == "Bullish"):
    #         self.reversalP = self.SlDict['Bullish'][str(self.CSlLeg)][1]
    #         self.blDP = self.SlDict['Bullish'][str(self.CSlLeg+1)][0]
    #         self.brDP = self.SlDict['Bearish']['1'][0]
    #     elif (self.trend == "Bearish"):
    #         self.reversalP = self.SlDict['Bearish'][str(self.CSlLeg)][1]
    #         self.brDP = self.SlDict['Bearish'][str(self.CSlLeg+1)][0]
    #         self.blDP = self.SlDict['Bullish']['1'][0]
    #     elif(self.trend == "Nutral"):
    #         self.brDP = self.SlDict['Bearish']['1'][0]
    #         self.blDP = self.SlDict['Bullish']['1'][0]
    #
    #
    #     window.leBRDP.setText('%.2f' % self.brDP)
    #     window.leBLDP.setText('%.2f' % self.brDP)
    #     window.leBLRCP.setText('%.2f' % self.BLRCP)
    #     window.leBRRCP.setText('%.2f' % self.BRRCP)
    #     window.lb_revP.setText('%.2f' % self.reversalP)
    #
    #     saveJson(self)
    #     # updateValues(self)


    def changeAdjPts(self, window):
        self.adjPts = float(window.leAdjPts.text())
        adjCashprice = float(window.lb_ltp_cash.text()) + self.adjPts
        window.lbAdjCashP.setText('%.2f' % adjCashprice)
        # print("self.isStart",self.isParameterSet,self.isFirstOrderPunch )
        window.ATM =  getATM(window,adjCashprice,window.strikeDiff)

        # print(window.ATM)
        window.lb_atm.setText('%.2f' % window.ATM )


    def getNewTokens(self):
        ATM = getATM(self,self.cashPrice,self.strikeDiff)

        ATMStrike_CE = ATM + (self.strikeDiff * self.ATMStrikeIndex_CE)
        ATMStrike_PE = ATM - (self.strikeDiff * self.ATMStrikeIndex_PE)

        self.ATM_CE_TOKEN  = get_ce_token(self,ATMStrike_CE)
        self.ATM_PE_TOKEN  = get_pe_token(self,ATMStrike_PE)



    def getNewData(self,isFirst =False):

        self.BLRCP = self.ATM  + (1.6 * self.strikeDiff) + self.ofset - self.adjPts  # ATM - thresold + strikeDiff
        self.BRRCP = self.ATM  - (1.6 * self.strikeDiff) - self.ofset - self.adjPts

        self.modifyW.leBRRCP.setText('%.2f' % self.BRRCP)
        self.modifyW.leBLRCP.setText('%.2f' % self.BLRCP)
        if(isFirst):
            getFSlDict(self, self.ATM)
        else:
            getSlDict(self, self.ATM, self.trend)

        ceStrike = self.ceStrike#self.ATM + (self.strikeDiff * self.ceStrikeIndex)
        peStrike = self.peStrike#self.ATM - (self.strikeDiff * self.peStrikeIndex)

        # print('getNewData    ATM',self.ATM,'strikediff',self.strikeDiff,self.BLRCP,self.BRRCP,'\n\n',self.SlDict,'\n\n#############')
        self.ceToken = getATM_CE_Token(self, ceStrike, self.ceTable)
        self.peToken = getATM_PE_Token(self, peStrike, self.peTable)
        self.ceTokenUp = getATM_CE_Token(self, ceStrike + self.strikeDiff, self.ceTable)
        self.peTokenUp = getATM_PE_Token(self, peStrike + self.strikeDiff, self.peTable)
        self.ceTokenDown = getATM_CE_Token(self, ceStrike - self.strikeDiff, self.ceTable)
        self.peTokenDown = getATM_PE_Token(self, peStrike - self.strikeDiff, self.peTable)

        print('getNewData',self.ceTokenUp,self.peTokenUp, self.ceTokenDown, self.peTokenDown)


        # print('self.ceToken',self.ceToken,'self.peToken',self.peToken,'self.ceTokenUp',self.ceTokenUp,'self.peTokenUp',self.peTokenUp,
        #       'self.ceTokenDown',self.ceTokenDown,'self.peTokenDown',self.peTokenDown,'ATM',self.ATM)

    def updateWindows(self, feed, window):
        priceToken = feed['Token']
        if (window.isParachange == False):
            if (window.visibleRegion().isEmpty() == False):

                if (priceToken == self.tokenList[0]):
                    if (window.cashFut == 'CASH'):
                        window.baseToken = window.cashToken
                        window.cashPrice = feed['LTP']
                        window.basePrice = window.cashPrice
                        if (self.isFirstOrderPunch == False):
                            ATM = getATM(self, window.basePrice, window.strikeDiff)
                            if (ATM != window.ATM):
                                window.ATM = ATM
                                window.lb_atm.setText(str(window.ATM))
                                window.ATMCEToken = getATM_CE_Token(self, window.ATM, window.ceTable)
                                window.ATMPEToken = getATM_PE_Token(self, window.ATM, window.peTable)
                                self.tokenList[2] = window.ATMCEToken
                                self.tokenList[3] = window.ATMPEToken
                        window.lb_ltp.setText(str(window.basePrice))

                elif (priceToken == self.tokenList[1]):
                    if (window.cashFut != 'CASH'):
                        window.baseToken = window.futureToken
                        window.futPrice = feed['LTP']
                        window.basePrice = window.futPrice
                        ATM = getATM(self, window.basePrice, window.strikeDiff)
                        if (self.isFirstOrderPunch == False):
                            if (ATM != window.ATM):
                                window.ATM = ATM
                                window.lb_atm.setText(str(window.ATM))
                                window.ATMCEToken = getATM_CE_Token(self, window.ATM, window.ceTable)
                                window.ATMPEToken = getATM_PE_Token(self, window.ATM, window.peTable)
                                self.tokenList[2] = window.ATMCEToken
                                self.tokenList[3] = window.ATMPEToken
                        window.lb_ltp.setText(str(window.basePrice))

                elif (priceToken == self.tokenList[2]):
                    window.atmcePrice = feed['LTP']
                    window.lbATMCE.setText('%.2f' % window.atmcePrice)
                    if (priceToken == self.tokenList[4]):
                        window.cePrice = feed['LTP']
                        window.lbcePrice.setText('%.2f' % window.cePrice)

                elif (priceToken == self.tokenList[3]):
                    window.atmpePrice = feed['LTP']
                    window.lbATMPE.setText('%.2f' % window.atmpePrice)

                    if (priceToken == self.tokenList[5]):
                        window.pePrice = feed['LTP']
                        window.lbpePrice.setText('%.2f' % window.pePrice)

                elif (priceToken == self.tokenList[4]):
                    print('priceToken')
                    window.cePrice = feed['LTP']
                    window.lbcePrice.setText('%.2f' % window.cePrice)

                elif (priceToken == self.tokenList[5]):
                    print('priceToken')
                    window.pePrice = feed['LTP']
                    window.lbcePrice.setText('%.2f' % window.pePrice)
    def getStrikeOT(self,token):
        data=self.fo_contract[token-35000,:]
        return data[7],data[8]

if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = logic()
    form.addW.show()
    sys.exit(app.exec_())






"""


                elif(self.cashPrice > self.BLRCP):
                    print("-----*******_-----------------")
                    print("self.cashPrice > self.BLRCP")
                    #new BLRCP & new BRRCP
                    self.ATM = getATM(self,self.cashPrice, self.strikeDiff)
                    self.BLRCP = self.ATM + (1.6 * self.strikeDiff) + self.ofset  # ATM - thresold + strikeDiff
                    self.BRRCP = self.ATM - (1.6 * self.strikeDiff) - self.ofset
                    self.trend = "Bullish"

                    print("---New BLRCP, BRRCP, old reversal")
                    print(self.BLRCP, self.BRRCP, self.reversalP)
                    print("-------------------")
                    # new FSL and new NFSLR
                    getFSlDict(self,self.ATM)
                    print("new FSLFICT:",self.SlDict)
                    print("-----------------")
                    # new bullish and bearish NSL DICT
                    # getSlDict(self,self.ATM)

                    # increase ATM = ATM + strike DIFF
                    # new ceTOken & pe TOKEN
                    self.ceToken = getATM_CE_Token(self,self.ATM, self.ceTable)
                    self.peToken = getATM_PE_Token(self,self.ATM, self.peTable)

                    self.ceTokenUp = getATM_CE_Token(self,self.ATM + self.strikeDiff, self.ceTable)
                    self.peTokenUp = getATM_PE_Token(self,self.ATM + self.strikeDiff, self.peTable)

                    self.ceTokenDown = getATM_CE_Token(self,self.ATM - self.strikeDiff, self.ceTable)
                    self.peTokenDown = getATM_PE_Token(self,self.ATM - self.strikeDiff, self.peTable)
                    # set bullish DP
                    self.blDP = self.SlDict['Bullish'][1][0]
                    self.CSlLeg = 0
                    print("CE PE : ", self.ceToken, self.peToken)
                    print("CE PE UP : ", self.ceTokenUp, self.peTokenUp)
                    print("CE PE DOWN: ", self.ceTokenDown, self.peTokenDown)
                    print("-----*******_-----------------  self.blDP :",  self.blDP)
                    saveJson(self)
                elif(self.cashPrice < self.BRRCP):
                    #new BLRCP & new BRRCP
                    print("-----*******_-----------------")
                    print("self.cashPrice < self.BRRCP")
                    self.ATM = getATM(self,self.cashPrice, self.strikeDiff)
                    self.BLRCP = self.ATM  + self.strikeDiff + self.ofset  # ATM - thresold + strikeDiff
                    self.BRRCP = self.ATM  - self.strikeDiff - self.ofset
                    self.trend = "Bearish"
                    print("---New BLRCP, BRRCP, old reversal")
                    print(self.BLRCP, self.BRRCP, self.reversalP)
                    print("-------------------")

                    # new FSL and new NSLDT
                    getFSlDict(self,self.ATM)
                    print("new FSLFICT:", self.SlDict)
                    print("-----------------")
                    # new bullish and bearish NSL DICT
                    # getSlDict(self,self.ATM)

                    # increase ATM = ATM - strike DIFF
                    # new ceTOken & pe TOKEN
                    self.ceToken = getATM_CE_Token(self,self.ATM, self.ceTable)
                    self.peToken = getATM_PE_Token(self,self.ATM, self.peTable)

                    self.ceTokenUp = getATM_CE_Token(self,self.ATM + self.strikeDiff, self.ceTable)
                    self.peTokenUp = getATM_PE_Token(self,self.ATM + self.strikeDiff, self.peTable)

                    self.ceTokenDown = getATM_CE_Token(self,self.ATM - self.strikeDiff, self.ceTable)
                    self.peTokenDown = getATM_PE_Token(self,self.ATM - self.strikeDiff, self.peTable)
                    # set bullish DP
                    self.brDP = self.SlDict['Bearish'][1][0]
                    self.CSlLeg = 0
                    print("CE PE : ", self.ceToken, self.peToken)
                    print("CE PE UP : ", self.ceTokenUp, self.peTokenUp)
                    print("CE PE DOWN: ", self.ceTokenDown, self.peTokenDown)
                    print("-----*******_-----------------  self.blDP :", self.blDP)
                    saveJson(self)







############################################################################################################33


    def placeHedgeOrder(self):
        ATM = getATM(self,self.cashPrice, self.strikeDiff)
        ##################### get hedge qty ############################

        peHedgeStrike = ATM - ((self.lowerRangeIndex + 2)* self.strikeDiff)
        ceHedgeStrike = ATM + ((self.upperRangeIndex + 2)* self.strikeDiff)


        ceHedgeToken = self.ceTable[np.where(self.ceTable[:,12]==ceHedgeStrike),2][0][0]
        peHedgeToken = self.peTable[np.where(self.peTable[:,12]==peHedgeStrike),2][0][0]

        ### while freeze qty

        PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=ceHedgeToken, orderSide='Buy', qty=self.qty,
                   limitPrice=0.0,
                   validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET', productType='NRML')
        PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=peHedgeToken, orderSide='Buy', qty=self.qty,
                   limitPrice=0.0,
                   validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET', productType='NRML')


"""