'''
bind events
'''
from Application.Stretegies.JodiATM.Utills.executionSupport import updateATMCEToken, updateATMPEToken, updateAllToken


def eventsBind(self):
    self.addW.pbApply.clicked.connect(self.setParameters)
    self.addW.cbSymbol.currentIndexChanged.connect(lambda: self.addW.getOptionExpiryList(self.fo_contract))
    self.addW.pbGet.clicked.connect(lambda : self.getBaseInfo(self.addW))
    self.modifyW.pbApply.clicked.connect(self.modifyParameter)
    self.modifyW.pbGetInfo.clicked.connect(lambda: self.getBaseInfo(self.modifyW))
    self.modifyW.pbShowDict.clicked.connect(self.showSLDictW)
    self.modifyW.pbAdjApply.clicked.connect(lambda : self.changeAdjPts(self.modifyW))
    # self.addW.pbAdjApply.clicked.connect(lambda : self.changeAdjPts(self.addW))
    self.modifyW.pbSetLTP.clicked.connect(lambda : self.setLTP(self.modifyW))

    self.addW.cbStrike_CE.currentIndexChanged.connect(lambda: updateATMCEToken(self, self.addW))
    self.addW.cbStrike_PE.currentIndexChanged.connect(lambda: updateATMPEToken(self, self.addW))

    self.addW.pbGetPrices.clicked.connect(lambda: updateAllToken(self, self.addW))
