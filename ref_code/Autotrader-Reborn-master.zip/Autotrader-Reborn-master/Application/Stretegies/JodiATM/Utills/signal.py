from PyQt5.QtCore import pyqtSignal

'''
configure signals for strategy
'''
def configureSignals(self):
    print("saddsd:", self)
    self.sgMTM = pyqtSignal(str, float)
    print("9999:", self.sgMTM)
    self.sgAlert = pyqtSignal(str)
    self.sgParamSet = pyqtSignal()
    self.sgStart = pyqtSignal()
    self.sgActivate = pyqtSignal()
    self.sgStop = pyqtSignal()
    self.sgClose = pyqtSignal()