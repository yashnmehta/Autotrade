import datetime

from Application.Stretegies.JodiATM.Utills.keyParameters import saveJson


def checkTrade(self, priceFeed):
    # print(priceFeed)
    self.updateWindows(priceFeed, self.modifyW)
    #
    if (self.isStart and self.executionRunning == False):
        priceToken = priceFeed['Token']
        if (self.cashToken == priceToken):
            cashPrice = priceFeed['LTP']
            self.cashPrice = cashPrice
            # print("CashPrice",self.cashPrice)
            #  print("checkTrade:", self.cashPrice)
            if (self.trend == 'Nutral'):
                if (self.cashPrice > self.blDP):
                    # make 25% qty shift to next bullish strike
                    self.tradeQty = int(self.baseQty / 4)
                    self.trend = 'Bullish'
                    # print(datetime.datetime.now(),'############### \n 1 st switch bullish',self.cashPrice,self.CSlLeg,
                    #       self.trend,self.blDP,self.brDP,self.reversalP,self.BLRCP,self.BRRCP,'\n',self.SlDict,'\n#####################\n')
                    ###########################################
                    self.CSlLeg += 1
                    self.blDP = self.SlDict['Bullish'][str(self.CSlLeg + 1)][0]
                    self.reversalP = self.SlDict['Bullish'][str(self.CSlLeg)][1]

                    self.switchCurrent2Upper()

                    self.modifyW.lb_slLeg.setText(str(self.CSlLeg))
                    self.modifyW.leBLDP.setText('%.2f' % self.blDP)
                    self.modifyW.lb_revP.setText('%.2f' % self.reversalP)
                    self.modifyW.lbTrend.setText(self.trend)

                    d = {'Trend': self.trend, 'cashPrice': self.cashPrice, 'blDP': self.blDP}
                    self.Slogger.info('checkTrade  Nutral(cashPrice > blDP)....', d)

                    saveJson(self)
                elif (self.cashPrice < self.brDP):
                    self.tradeQty = int(self.baseQty / 4)
                    self.trend = 'Bearish'

                    # print(datetime.datetime.now(),'############### \n 1 st switch bearish',self.cashPrice,self.CSlLeg,
                    # self.trend,self.blDP,self.brDP,self.reversalP,self.BLRCP,self.BRRCP,'\n',self.SlDict,'\n#####################\n')

                    self.CSlLeg += 1
                    ###########################################
                    self.brDP = self.SlDict['Bearish'][str(self.CSlLeg + 1)][0]
                    self.reversalP = self.SlDict['Bearish'][str(self.CSlLeg)][1]
                    self.switchCurrent2Lower()

                    self.modifyW.lb_slLeg.setText(str(self.CSlLeg))
                    self.modifyW.leBRDP.setText('%.2f' % self.brDP)
                    self.modifyW.lb_revP.setText('%.2f' % self.reversalP)
                    self.modifyW.lbTrend.setText(self.trend)

                    d = {'Trend': self.trend, 'cashPrice': self.cashPrice, 'brDP': self.brDP}
                    self.Slogger.info('checkTrade  Nutral(cashPrice < brDP)....', d)

                    saveJson(self)
            elif (self.trend == 'Bullish'):
                if (self.cashPrice > self.blDP):

                    # print(datetime.datetime.now(),'############### \n  switch bullish',self.cashPrice,self.CSlLeg,
                    #       self.trend,self.blDP,self.brDP,self.reversalP,self.BLRCP,self.BRRCP,'\n',self.SlDict,'\n#####################\n')
                    if (self.blDP == self.BLRCP):
                        self.trend = "Bullish"
                        # print(datetime.datetime.now(), '############### \n  self.blDP==self.BLRCP hits')
                        self.ATM += self.strikeDiff
                        self.getNewData()
                        self.CSlLeg = 1
                        self.blDP = self.SlDict['Bullish'][str(self.CSlLeg + 1)][0]
                        self.bRDP = self.SlDict['Bearish'][str(self.CSlLeg + 1)][0]
                        self.reversalP = self.SlDict['Bullish'][str(self.CSlLeg)][1]

                    else:
                        self.CSlLeg += 1
                        if (self.CSlLeg < 4):
                            self.reversalP = self.SlDict['Bullish'][str(self.CSlLeg)][1]
                            self.blDP = self.SlDict['Bullish'][str(self.CSlLeg + 1)][0]
                        else:
                            self.blDP = self.BLRCP
                            self.reversalP = self.SlDict['Bullish'][str(self.CSlLeg)][1]

                    self.switchCurrent2Upper()

                    self.modifyW.lb_slLeg.setText(str(self.CSlLeg))
                    self.modifyW.leBLDP.setText('%.2f' % self.blDP)
                    self.modifyW.lb_revP.setText('%.2f' % self.reversalP)
                    self.modifyW.lbTrend.setText(self.trend)
                    ###########################################

                    d = {'Trend': self.trend, 'cashPrice': self.cashPrice, 'blDP': self.blDP}
                    self.Slogger.info('checkTrade  Bullish(cashPrice > blDP)....', d)

                    saveJson(self)

                # note ***** : construct new disct is pending
                elif (self.cashPrice < self.reversalP):

                    # print(datetime.datetime.now(),'############### \n reversal',self.cashPrice,self.CSlLeg,
                    #       self.trend,self.blDP,self.brDP,self.reversalP,self.BLRCP,self.BRRCP,'\n',self.SlDict,'\n#####################\n')
                    self.CSlLeg -= 1

                    if (self.CSlLeg == 0):
                        self.trend = "Nutral"
                        self.blDP = self.SlDict['Bullish'][str(self.CSlLeg + 1)][0]
                        self.brDP = self.SlDict['Bearish'][str(self.CSlLeg + 1)][0]
                    else:
                        self.reversalP = self.SlDict['Bullish'][str(self.CSlLeg)][1]
                        self.blDP = self.SlDict['Bullish'][str(self.CSlLeg + 1)][0]

                    self.switchUpper2Current()
                    self.modifyW.lb_slLeg.setText(str(self.CSlLeg))
                    self.modifyW.leBRDP.setText('%.2f' % self.brDP)
                    self.modifyW.leBLDP.setText('%.2f' % self.blDP)
                    self.modifyW.lb_revP.setText('%.2f' % self.reversalP)
                    self.modifyW.lbTrend.setText(self.trend)

                    d = {'Trend': self.trend, 'cashPrice': self.cashPrice, 'reversalP': self.reversalP}
                    self.Slogger.info('checkTrade  Bullish(cashPrice < reversalP)....', d)

                    saveJson(self)

            elif (self.trend == 'Bearish'):
                if (self.cashPrice < self.brDP):
                    print(datetime.datetime.now(), '############### \n  switch Bearish', self.cashPrice,
                          self.CSlLeg,
                          self.trend, self.blDP, self.brDP, self.reversalP, self.BLRCP, self.BRRCP, '\n', self.SlDict,
                          '\n#####################\n')

                    if (self.brDP == self.BRRCP):
                        self.trend = "Bearish"
                        # print(datetime.datetime.now(), '############### \n  self.brDP==self.BRRCP hits')

                        self.ATM = self.ATM - self.strikeDiff
                        self.getNewData()

                        self.CSlLeg = 1
                        self.brDP = self.SlDict['Bearish'][str(self.CSlLeg + 1)][0]
                        self.blDP = self.SlDict['Bullish'][str(self.CSlLeg + 1)][0]
                        self.reversalP = self.SlDict['Bearish'][str(self.CSlLeg)][1]

                        # print(datetime.datetime.now(), '############### \n  aftermath Bearish brdp==brrcp', self.cashPrice,
                        #       self.CSlLeg,
                        #       self.trend, self.blDP, self.brDP, self.reversalP, self.BLRCP,self.BRRCP,'\n', self.SlDict,
                        #       '\n#####################\n')

                    else:
                        self.CSlLeg += 1
                        if (self.CSlLeg < 4):
                            self.brDP = self.SlDict['Bearish'][str(self.CSlLeg + 1)][0]
                            self.reversalP = self.SlDict['Bearish'][str(self.CSlLeg)][1]
                        else:
                            self.brDP = self.BRRCP
                            self.reversalP = self.SlDict['Bearish'][str(self.CSlLeg)][1]
                            # self.CSlLeg = 0

                    ###########################################
                    self.switchCurrent2Lower()

                    self.modifyW.lb_slLeg.setText(str(self.CSlLeg))
                    self.modifyW.leBRDP.setText('%.2f' % self.brDP)
                    self.modifyW.leBLDP.setText('%.2f' % self.blDP)
                    self.modifyW.lb_revP.setText('%.2f' % self.reversalP)
                    self.modifyW.lbTrend.setText(self.trend)

                    d = {'Trend': self.trend, 'cashPrice': self.cashPrice, 'brDP': self.brDP}
                    self.Slogger.info('checkTrade  Bearish(cashPrice < brDP)....', d)

                    saveJson(self)
                # note ***** : construct new disct is pending
                elif (self.cashPrice > self.reversalP):
                    print(datetime.datetime.now(), '############### \n reversal bearish', self.cashPrice, self.CSlLeg,
                          self.trend, self.blDP, self.brDP, self.reversalP, self.BLRCP, self.BRRCP, '\n', self.SlDict,
                          '\n#####################\n')

                    self.CSlLeg -= 1
                    if (self.CSlLeg == 0):
                        self.trend = "Nutral"
                        self.blDP = self.SlDict['Bullish'][str(self.CSlLeg + 1)][0]
                        self.brDP = self.SlDict['Bearish'][str(self.CSlLeg + 1)][0]
                    else:
                        self.reversalP = self.SlDict['Bearish'][str(self.CSlLeg)][1]
                        self.brDP = self.SlDict['Bearish'][str(self.CSlLeg + 1)][0]

                    self.switchLower2Current()

                    self.modifyW.lb_slLeg.setText(str(self.CSlLeg))
                    self.modifyW.leBRDP.setText('%.2f' % self.brDP)
                    self.modifyW.leBLDP.setText('%.2f' % self.blDP)
                    self.modifyW.lb_revP.setText('%.2f' % self.reversalP)
                    self.modifyW.lbTrend.setText(self.trend)

                    d = {'Trend': self.trend, 'cashPrice': self.cashPrice, 'reversalP': self.reversalP}
                    self.Slogger.info('checkTrade  Bearish(cashPrice > reversalP)....', d)

                    saveJson(self)