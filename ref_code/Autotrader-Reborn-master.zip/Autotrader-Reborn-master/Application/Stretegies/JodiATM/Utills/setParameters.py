import traceback
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QMessageBox
from Application.Stretegies.JodiATM.Utills.executionSupport import getCashToken, getFutureToken, getStrikeDiff, \
    getCETable, getPETable, getATM, setParametersModifyW
from Application.Stretegies.JodiATM.Utills.keyParameters import saveJson


def setParameters(self,window):
    try:
        self.baseQty = int(window.leQty.text())

        if self.baseQty%self.lotsize != 0:
            self.messageBox = QMessageBox()
            self.messageBox.setIcon(QMessageBox.Critical)
            self.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
            self.messageBox.setText(f'Quantity must be multiple of lotsize {self.lotsize}')
            self.messageBox.show()

        elif (self.baseQty <= 0):
            self.messageBox = QMessageBox()
            self.messageBox.setIcon(QMessageBox.Critical)
            self.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
            self.messageBox.setText('Quantity must be greater than zero!!')
            self.messageBox.show()
        else:
            self.folioName = window.leFolioName.text()
            self.clientId = window.cbClient.currentText()

            self.symbol = window.cbSymbol.currentText()
            self.expiry = window.cbExp.currentText()

            self.ceTable = getCETable(self, self.symbol, self.expiry)
            self.peTable = getPETable(self, self.symbol, self.expiry)

            self.Base = window.cbCF.currentText()
            self.baseToken = window.baseToken
            self.basePrice = window.basePrice
            self.cashToken = window.cashToken
            self.futToken = window.futToken
            self.lotsize = int(self.fo_contract[self.futToken - 35000, 11])
            self.cashPrice = self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
            self.futPrice = self.getPrice(token=self.futToken, seg='NSEFO', streamType=1501)['ltp']
            self.ATM = window.ATM
            self.ATMCEToken = window.ATMCEToken
            self.ATMPEToken = window.ATMPEToken
            self.atmcePrice = self.getPrice(token=self.ATMCEToken, seg='NSEFO', streamType=1501)['ltp']
            self.atmpePrice = self.getPrice(token=self.ATMPEToken, seg='NSEFO', streamType=1501)['ltp']
            self.ceToken = window.ceToken
            self.peToken = window.peToken
            self.strikeDiff = getStrikeDiff(self, self.futToken)

            self.ceStrike = window.ceStrike
            self.peStrike = window.peStrike

            self.cePrice = self.getPrice(token=self.ceToken, seg='NSEFO', streamType=1501)['ltp']
            self.pePrice = self.getPrice(token=self.peToken, seg='NSEFO', streamType=1501)['ltp']

            self.atmIdx = window.atmIdx
            self.ceIdx = window.cbStrike_CE.currentIndex()
            self.peIdx = window.cbStrike_PE.currentIndex()
            self.freezeQty = int(self.fo_contract[self.futToken - 35000, 14])

            # assign values
            self.threshold = float(window.leThreshold.text())
            self.ofset = float(window.leOffset.text())
            self.diffPoints = float(window.leDiffPoints.text())

            self.SlAmount = float(window.leSLAmount.text())
            self.targetAmt = float(window.leTargetAmount.text())
            self.folioName = window.leFolioName.text()
            self.getKeyParameterFile(self.folioName)

            self.adjPts = float(window.leAdjPts.text())

            self.isParameterSet = True
            # print("%%%%%%%%%")
            setParametersModifyW(self,self.modifyW)
            saveJson(self)
            self.sgParamSet.emit()

    except:
        print(traceback.print_exc())





