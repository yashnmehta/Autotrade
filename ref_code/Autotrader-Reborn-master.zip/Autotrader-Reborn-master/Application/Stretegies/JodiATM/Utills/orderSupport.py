import traceback

from Application.Services.Xts.Api.servicesIA import PlaceOrder
from Application.Utils.log import insertLogRow
import time as ttime

def makeOrder(self,token,qty,orderSide = 'Sell', orderType  = 'MARKET', limitPrice = 0.0, triggerPrice = 0 ):
    try:
        tQty =qty
        appOrderIdList = []
        while qty > self.freezeQty:
            appOrderId = PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=token, orderSide=orderSide,
                       qty=self.freezeQty,
                       limitPrice=limitPrice,
                       validity='DAY', disQty=0, triggerPrice=triggerPrice, uid=self.folioName, orderType=orderType,
                       productType='NRML')

            # need to add in OMS
            appOrderIdList.append(appOrderId)
            ttime.sleep(0.1)
            qty -= self.freezeQty
        appOrderId = PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=token, orderSide=orderSide,
                   qty=qty,
                   limitPrice=limitPrice,
                   validity='DAY', disQty=0, triggerPrice=triggerPrice, uid=self.folioName, orderType=orderType,
                   productType='NRML')
        # need to add in OMS
        appOrderIdList.append(appOrderId)
        insertLogRow(self, tQty, token, orderSide)
        ttime.sleep(0.1)
        return appOrderIdList
    except:
        print(traceback.print_exc())
