import time as ttime
import traceback
from Application.Services.Xts.Api.servicesIA import PlaceOrder
from Application.Stretegies.JodiSt.Utills.executionSupport import setParametersModify
from Application.Stretegies.JodiSt.Utills.keyParameters import saveJson
from Application.Utils.log import insertLogRow


def makeOrder(self,token,qty,orderSide = 'Sell', orderType  = 'MARKET', limitPrice = 0.0, triggerPrice = 0 ):
    try:
        tQty = qty
        appOrderIdList = []
        while qty > self.freezeQty:
            appOrderId = PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=token, orderSide=orderSide,
                       qty=self.freezeQty,
                       limitPrice=limitPrice,
                       validity='DAY', disQty=0, triggerPrice=triggerPrice, uid=self.folioName, orderType=orderType,
                       productType='NRML')

            # need to add in OMS
            appOrderIdList.append(appOrderId)
            ttime.sleep(0.1)
            qty -= self.freezeQty
        appOrderId = PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=token, orderSide=orderSide,
                   qty=qty,
                   limitPrice=limitPrice,
                   validity='DAY', disQty=0, triggerPrice=triggerPrice, uid=self.folioName, orderType=orderType,
                   productType='NRML')
        # need to add in OMS
        appOrderIdList.append(appOrderId)
        insertLogRow(self, tQty, token, orderSide)
        ttime.sleep(0.1)
        return appOrderIdList
    except:
        print(traceback.print_exc())

def makeFirstOrder(self):
    print('makeFirstOrder')
    try:
        if(self.isFirstOrderPunch==False):
            makeOrder(self,self.ceToken,self.qty,'Sell')
            makeOrder(self,self.peToken,self.qty,'Sell')
            self.ceLastOrderPunchPrice = self.cePrice
            self.peLastOrderPunchPrice = self.pePrice
            self.sgStart.emit()
            self.isStart = True
            self.isFirstOrderPunch = True
            print('self.isFirstOrderPunch',self.isFirstOrderPunch)
            self.baseStrike = self.ATM
            setParametersModify(self)
            saveJson(self)
    except:
        print(traceback.print_exc())
