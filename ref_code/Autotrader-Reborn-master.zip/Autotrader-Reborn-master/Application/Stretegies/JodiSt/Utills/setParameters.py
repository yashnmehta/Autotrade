from PyQt5.QtCore import *
from Application.Stretegies.JodiSt.Utills.executionSupport import *
from PyQt5.QtWidgets import *
from Application.Stretegies.JodiSt.Utills.executionSupport import getCashToken, getfutToken, getStrikeDiff, \
    getCETable, getPETable, getPrice
from Application.Stretegies.JodiSt.Utills.keyParameters import getKeyParameterFile, saveJson


def setParameters(self, window):
    # print('JodiSt setParameters')
    try:
        self.baseQty = int(window.leQty.text())

        self.Sl1Qty = int(window.leSl1Qty.text())
        self.Sl2Qty = int(window.leSl2Qty.text())

        self.Tgt1Qty = int(window.leTgt1Qty.text())
        self.Tgt2Qty = int(window.leTgt2Qty.text())

        if self.baseQty % self.lotsize != 0 or self.Sl1Qty % self.lotsize != 0 or self.Sl2Qty % self.lotsize != 0 or self.Tgt1Qty % self.lotsize != 0 or self.Tgt2Qty % self.lotsize != 0:
            self.messageBox = QMessageBox()
            self.messageBox.setIcon(QMessageBox.Critical)
            self.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
            self.messageBox.setText(f'Quantity must be multiple of lotsize {self.lotsize}')
            self.messageBox.show()

        elif (self.baseQty <= 0):
            self.messageBox = QMessageBox()
            self.messageBox.setIcon(QMessageBox.Critical)
            self.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
            self.messageBox.setText('Quantity must be greater than zero!!')
            self.messageBox.show()

        else:
            self.folioName = window.leFolioName.text()
            self.clientId = window.cbClient.currentText()

            self.symbol = window.cbSymbol.currentText()
            self.expiry = window.cbExp.currentText()

            self.Base = window.cbCF.currentText()
            self.baseToken = window.baseToken
            self.basePrice = self.getPrice(token=self.baseToken, seg='NSECM', streamType=1501)['ltp']
            self.cashToken = window.cashToken
            self.futToken = window.futToken
            self.cashPrice = self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
            self.futPrice = self.getPrice(token=self.futToken, seg='NSEFO', streamType=1501)['ltp']
            self.ATM = window.ATM
            self.ATMCEToken = window.ATMCEToken
            self.ATMPEToken = window.ATMPEToken
            self.atmcePrice = self.getPrice(token=self.ATMCEToken, seg='NSEFO', streamType=1501)['ltp']
            self.atmpePrice = self.getPrice(token=self.ATMPEToken, seg='NSEFO', streamType=1501)['ltp']
            self.ceToken = window.ceToken
            self.peToken = window.peToken
            self.strikeDiff = getStrikeDiff(self, self.futToken)

            self.ceStrike = window.ceStrike
            self.peStrike = window.peStrike


            self.cePrice = self.getPrice(token=self.ceToken, seg='NSEFO', streamType=1501)['ltp']
            self.pePrice = self.getPrice(token=self.peToken, seg='NSEFO', streamType=1501)['ltp']

            self.atmIdx = window.atmIdx
            self.ceIdx = window.cbStrike_CE.currentIndex()
            self.peIdx = window.cbStrike_PE.currentIndex()
            self.freezeQty = int(self.fo_contract[self.futToken - 35000, 14])

            self.qty = int(window.leQty.text())

            self.ceQty = self.qty
            self.peQty = self.qty

            self.Sl1pr = float(window.leSl1pr.text())
            self.Sl2pr = float(window.leSl2pr.text())

            self.pairPrice = self.cePrice + self.pePrice


            self.Sl1Amt = self.pairPrice * self.Sl1pr / 100
            self.Sl2Amt = self.pairPrice * self.Sl2pr / 100


            self.Tgt1Amt = int(window.leTgt1Amt.text())
            self.Tgt2Amt = int(window.leTgt2Amt.text())

            self.ceTable = getCETable(self, self.symbol, self.expiry)
            self.peTable = getPETable(self, self.symbol, self.expiry)

            getKeyParameterFile(self, self.folioName)

            self.heads = ['serialNo','appOrderId', 'orderTag', 'token', 'optionType', 'orderSide',
                          'strike', 'status', 'orderQty', 'fillQty', 'pendingQty',
                          'avgPrice', 'slPrice', 'tslPrice', 'targetPrice', 'slAOID',
                          'slStatus', 'targetAOID', 'targetLeg', 'targetStatus', 'targetQty',
                          'cpOrderId', 'cpStatus', 'primaryAOID'
                          ]

            self.lastOrderSerialNo = 0
            self.OMS = np.zeros((500, 24), dtype=object)

            self.inactiveOMS = np.zeros((500, 23), dtype=object)
            self.iomslastOrderSerialNo = 0

            self.isParameterSet = True
            updateModifyInfo(self)
            setParametersModify(self)
            saveJson(self)
            self.sgParamSet.emit()

    except:
        print(traceback.print_exc())



