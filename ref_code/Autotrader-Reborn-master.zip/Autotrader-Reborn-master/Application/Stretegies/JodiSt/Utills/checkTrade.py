from Application.Stretegies.JodiSt.Utills.keyParameters import saveJson
from Application.Stretegies.JodiSt.Utills.orderSupport import makeOrder

def checkTrade(self, priceFeed):
    if self.isStart:
        # if self.isSlHit == False and self.isTgtHit == False:
        if self.isFirstOrderPunch:
            priceToken = priceFeed['Token']
            if self.ceToken == priceToken or self.peToken == priceToken:
                price = priceFeed['LTP']
                if self.isSlHit == False:
                    if self.isTgt1Hit == False and self.Tgt1Amt < self.mtm and self.inModifyOrder == False:
                        self.inCheckTradeOrder = True
                        makeOrder(self, self.ceToken, self.Tgt1Qty, 'Buy')
                        makeOrder(self, self.peToken, self.Tgt1Qty, 'Buy')
                        self.isTgt1Hit = True
                        if self.isSl1Hit:
                            # self.isTgtHit = True
                            self.isStart = False
                        saveJson(self)
                        self.Slogger.info("Tgt1Hit")
                        self.inCheckTradeOrder = False

                    elif self.isTgt2Hit == False and self.Tgt2Amt < self.mtm and self.inModifyOrder == False:
                        self.inCheckTradeOrder = True
                        makeOrder(self, self.ceToken, self.Tgt2Qty, 'Buy')
                        makeOrder(self, self.peToken, self.Tgt2Qty, 'Buy')
                        self.isTgt2Hit = True
                        # self.isTgtHit = True
                        self.isStart = False
                        saveJson(self)
                        self.Slogger.info("Tgt2Hit")
                        self.inCheckTradeOrder = False

                if self.isTgtHit == False:
                    if self.isSl1Hit == False and self.Sl1Amt < price and self.inModifyOrder == False:
                        self.inCheckTradeOrder = True
                        makeOrder(self, self.ceToken, self.Sl1Qty, 'Buy')
                        makeOrder(self, self.peToken, self.Sl1Qty, 'Buy')
                        self.isSl1Hit = True
                        if self.isTgt1Hit:
                            self.isStart = False
                            # self.isSlHit = True
                        saveJson(self)
                        self.Slogger.info("Sl1Hit")
                        self.inCheckTradeOrder = False

                    elif self.isSl2Hit == False and self.Sl2Amt < price and self.inModifyOrder == False:
                        self.inCheckTradeOrder = True
                        makeOrder(self, self.ceToken, self.Sl2Qty, 'Buy')
                        makeOrder(self, self.peToken, self.Sl2Qty, 'Buy')
                        self.isSl2Hit = True
                        self.isStart = False
                        # self.isSlHit = True
                        saveJson(self)
                        self.Slogger.info("Sl2Hit")
                        self.inCheckTradeOrder = False

                if self.ceToken == priceToken:
                    self.cePrice = priceFeed['LTP']

                if self.peToken == priceToken:
                    self.pePrice = priceFeed['LTP']

