'''
bind events
'''

from Application.Stretegies.JodiSt.Utills.executionSupport import baseChange, symchange, expchange, updateATMCEToken, \
    updateATMPEToken, updateSl2Amt, updateSl1Amt

def eventsBind(self):
    self.addW.pbApply.clicked.connect(self.setParameters)
    # self.addW.cbSymbol.currentIndexChanged.connect(lambda: self.addW.getOptionExpiryList(self.fo_contract))
    self.addW.cbSymbol.currentTextChanged.connect(lambda: symchange(self, self.addW))
    self.addW.cbCF.currentIndexChanged.connect(lambda: baseChange(self, self.addW))
    self.addW.cbExp.currentTextChanged.connect(lambda:expchange(self,self.addW))
    self.addW.pbGet.clicked.connect(lambda : self.getBaseInfo(self.addW))

    self.addW.cbStrike_CE.currentIndexChanged.connect(lambda: updateATMCEToken(self, self.addW))
    self.addW.cbStrike_PE.currentIndexChanged.connect(lambda: updateATMPEToken(self, self.addW))
    self.addW.leSl1pr.textChanged.connect(lambda: updateSl1Amt(self, self.addW))
    self.addW.leSl2pr.textChanged.connect(lambda: updateSl2Amt(self, self.addW))

    self.modifyW.leSl1pr.textChanged.connect(lambda: updateSl1Amt(self, self.modifyW))
    self.modifyW.leSl2pr.textChanged.connect(lambda: updateSl2Amt(self, self.modifyW))

    self.modifyW.pbApply.clicked.connect(lambda : self.modifyParameter(self.modifyW))
