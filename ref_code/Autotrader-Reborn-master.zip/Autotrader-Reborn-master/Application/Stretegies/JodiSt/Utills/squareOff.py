
from Application.Stretegies.OCheetah.Utills.orderSupport import *
def squreOff(self):
    # print('squreOff',self.position)
    for i in self.position:
        token = i[1]
        quantity = i[5]

        if (quantity == 0):
            pass
        elif quantity > 0:
            makeOrder(self, token, quantity, 'Sell')
        else:
            absQuantity = abs(quantity)
            makeOrder(self, token, absQuantity, 'Buy')
