from PyQt5.QtGui import QKeySequence
from PyQt5.QtWidgets import QShortcut
from Application.Stretegies.JodiSt.Utills.checkTrade import checkTrade
from Application.Stretegies.JodiSt.Utills.keyParameters import reloadKeyParameter
from Application.Stretegies.JodiSt.Utills.orderSupport import makeFirstOrder
from Application.Stretegies.JodiSt.Utills.squareOff import squreOff
from Application.Stretegies.JodiSt.Utills.timer import createTimer
from Application.Stretegies.JodiSt.Views.addW import addW
from Application.Stretegies.JodiSt.Views.modifyW import modifyW
from Application.Utils.configReader import refresh
from Application.Stretegies.JodiSt.Utills.eventsBind import eventsBind
from Application.Stretegies.JodiSt.Utills.setParameters import *
from PyQt5.QtCore import QObject
import datatable as dt

class logic(QObject):
    sgMTM = pyqtSignal(str,float)
    sgSL = pyqtSignal(str, float)
    sgAlert = pyqtSignal(str)
    sgParamSet = pyqtSignal()
    # sgParamModify = pyqtSignal()
    sgStart = pyqtSignal()
    # sgActivate =pyqtSignal()
    # sgStop = pyqtSignal()
    # sgClose =pyqtSignal()
    sgFolioOpenPos = pyqtSignal(list)
    sgTarget = pyqtSignal(str, float)

    ################################# Intialization Here ##################################################
    def __init__(self):
        super(logic, self).__init__()
        self.position = np.zeros((100, 15), dtype=object)
        self.posHeads = ['exch',
                         'token', 'symbol', 'strike', 'c/p', 'netqty',
                         'requestedOrder', 'openOrder', 'netamt', 'ltp', 'mtm',
                         'OpenQty', 'OpenAmt', 'DQty', 'Damt']

        self.addW = addW(self)
        self.modifyW = modifyW(self)
        self.setAllShortCut()
        self.initVaribles()

    def initVaribles(self):

        self.lastSerialNo = 0
        self.stype = 'JodiSt'
        self.isFirstOrderPunch = False

        self.isStart = False

        self.base = 'CASH'
        self.baseToken = 0
        self.basePrice = 0.0
        self.cashToken = 0
        self.futToken = 0
        self.cashPrice = 0.0
        self.futPrice = 0.0
        self.strikeDiff = 0.0
        self.lotsize = 0



        self.ATM = 0.0
        self.ATMCEToken = 0
        self.ATMPEToken = 0
        self.atmcePrice = 0.0
        self.atmpePrice = 0.0
        self.ceToken = 0
        self.peToken = 0
        self.ceStrike = 0.0
        self.peStrike = 0.0
        self.cePrice = 0.0
        self.pePrice = 0.0

        self.ceTradedPrice = 0.0
        self.peTradedPrice = 0.0
        self.tradedPairPrice = 0.0

        self.atmIdx = 0
        self.ceIdx = 0
        self.peIdx = 0


        self.Sl1Qty = 0
        self.Sl2Qty = 0
        self.Sl1pr = 0.0
        self.Sl2pr = 0.0
        self.Sl1Amt = 0
        self.Sl2Amt = 0

        self.isSl1Hit = False
        self.isSl2Hit = False


        self.Tgt1Qty = 0
        self.Tgt2Qty = 0
        self.Tgt1Amt = 0
        self.Tgt2Amt = 0

        self.isTgt1Hit = False
        self.isTgt2Hit = False


        self.Target = 0.0
        self.SlAmt = 0.0
        self.TargetAmt = 0.0

        self.qty = 0
        self.freezeQty = 0

        self.SlAmount = 0.0
        self.tsl = 0.0
        self.targetAmt = 0.0
        
        self.pairPrice = 0.0

        self.ceOrderPunch = False
        self.peOrderPunch = False

        self.inCheckTradeOrder = False
        self.inModifyOrder = False

        self.isSlHit = False
        self.isTgtHit = False

        self.tokenList = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

        """        # tokenlist
                            0 cashToken
                            1 futToken
                            2 ATM CE Token
                            3 ATM PE Token
                            4 CE Token
                            5 PE Token """



        self.stype = 'JodiSt'
        self.isStart = False
        self.isClose = False

        self.isParameterSet = False
        self.isAnyOpenPos = False
        self.lastSerialNo = 0
        self.mtm = 0.0


    def setAllShortCut(self):
        self.addW.leQty.sc_up = QShortcut(QKeySequence('Up'),self.addW.leQty)
        self.addW.leQty.sc_up.setContext(Qt.WidgetWithChildrenShortcut)
        self.addW.leQty.sc_up.activated.connect(lambda:inc_v(self,self.addW))
        self.addW.leQty.sc_down = QShortcut(QKeySequence('Down'), self.addW.leQty)
        self.addW.leQty.sc_down.setContext(Qt.WidgetWithChildrenShortcut)
        self.addW.leQty.sc_down.activated.connect(lambda :dec_v(self,self.addW))


        self.modifyW.leQty.sc_up = QShortcut(QKeySequence('Up'),self.modifyW.leQty)
        self.modifyW.leQty.sc_up.setContext(Qt.WidgetWithChildrenShortcut)
        self.modifyW.leQty.sc_up.activated.connect(lambda:inc_v(self,self.modifyW))
        self.modifyW.leQty.sc_down = QShortcut(QKeySequence('Down'), self.modifyW.leQty)
        self.modifyW.leQty.sc_down.setContext(Qt.WidgetWithChildrenShortcut)
        self.modifyW.leQty.sc_down.activated.connect(lambda:dec_v(self,self.modifyW))

    def createTimer(self):
        createTimer(self)

    def createObject(self,fo_contract):
        try:
            self.fo_contract=fo_contract

            refresh(self)
            refresh(self.addW)
            refresh(self.modifyW)
            self.addW.getSymbolList(self.fo_contract)
            self.addW.cbSymbol.setCurrentText('BANKNIFTY')
            self.symbol = self.addW.cbSymbol.currentText()
            self.addW.getOptionExpiryList(self.fo_contract)
            eventsBind(self)
            self.createTimer()
        except:
            print(traceback.print_exc())

    def reloadKeyParameter(self):
        try:
            reloadKeyParameter(self)
        except:
            print(traceback.print_exc())

    def updateMTM(self,data):
        if(self.isAnyOpenPos == True):
            if (data['Token'] in self.position[:,1]):
                fltr0 = np.asarray([data['Token']])
                array = self.position[np.in1d(self.position[:, 1], fltr0)][0]
                # print(array)
                netAmt = array[8]
                ltp = data['LTP']
                qty = array[5]
                mtm = netAmt + (qty * ltp)
                self.position[np.in1d(self.position[:, 1], fltr0),[9,10]] = [ltp,mtm]
                # print(self.position[np.in1d(self.position[:, 1], fltr0)][0])
                total_mtm = np.sum(self.position[:,10])
                self.mtm = total_mtm
                self.sgMTM.emit(self.folioName,total_mtm)
                self.modifyW.leMTM.setText('%.2f'%total_mtm)

    def setParameters(self):
        setParameters(self,self.addW)

    def squreOff(self):
        squreOff(self)

    def modifyParameter(self,window):
        print('modifyParameter')
        try:
            if self.inCheckTradeOrder == False:
                self.inModifyOrder = True
                self.Sl1Qty = int(window.leSl1Qty.text())
                self.Sl2Qty = int(window.leSl2Qty.text())
                self.Tgt1Qty = int(window.leTgt1Qty.text())
                self.Tgt2Qty = int(window.leTgt2Qty.text())

                if self.Sl1Qty % self.lotsize != 0 or self.Sl2Qty % self.lotsize != 0 or self.Tgt1Qty % self.lotsize != 0 or self.Tgt2Qty % self.lotsize != 0:
                    self.messageBox = QMessageBox()
                    self.messageBox.setIcon(QMessageBox.Critical)
                    self.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
                    self.messageBox.setText(f'Quantity must be multiple of lotsize {self.lotsize}')
                    self.messageBox.show()
                else:
                    self.Sl1pr = float(window.leSl1pr.text())
                    self.Sl2pr = float(window.leSl2pr.text())

                    self.Sl1Amt = float(window.lbSl1Amt.text())
                    self.Sl2Amt = float(window.lbSl2Amt.text())

                    self.Tgt1Amt = int(window.leTgt1Amt.text())
                    self.Tgt2Amt = int(window.leTgt2Amt.text())

                    saveJson(self)
                    self.hideModifyW()
                self.inModifyOrder = False
        except:
            traceback.print_exc()

    def hideModifyW(self):
        self.timerUpdateWindows.stop()
        self.modifyW.hide()

    def setParametersModify(self,window):
        setParametersModify(self,window)

    def getKeyParameterFile(self, folioName):
        getKeyParameterFile(self, folioName)

    def updateTrade(self, trade, source='on_trade'):
        if (source == "on_trade"):
            trade1 = trade[0]
        else:
            trade1 = trade
        # print(" Pairsel  update trade:,",trade1)
        # print(self.folioName, trade1)

        if (trade1[15] == self.folioName):

            exchange = trade1[20]
            token = trade1[2]
            fltr0 = np.asarray([token])
            filteredArray0 = self.position[np.in1d(self.position[:, 1], fltr0)]
            isRecordExist = False
            if (filteredArray0.size != 0):
                isRecordExist = True

            if (isRecordExist):
                array = self.position[np.where(self.position[:, 1] == token)]
                # print('in is record exist',array)
                prev_qty = array[0][5]
                prev_amt = array[0][8]

                Prev_Dqty = array[0][13]
                Prev_Damt = array[0][14]

                Dqty = Prev_Dqty + trade1[18]
                DAmt = Prev_Damt + trade1[19]

                newQty = prev_qty + trade1[18]
                newAmt = prev_amt + trade1[19]

                self.position[np.where(self.position[:, 1] == token), [5, 8, 13, 14]] = [newQty, newAmt, Dqty, DAmt]

                # print('updated position dekh lo',self.position)
            else:
                new = dt.Frame([[exchange],
                                [token], [trade1[4]], [float(trade1[6])], [trade1[7]], [trade1[18]],
                                [0], [0], [trade1[19]], [trade1[17]], [0.0],
                                [0.0], [0.0], [trade1[18]], [trade1[19]]
                                ]).to_numpy()


                self.position[self.lastSerialNo, :] = new
                self.lastSerialNo += 1

            checkIsAnyPosition(self)

    def makeFirstOrder(self):
        makeFirstOrder(self)
    def checkTrade(self,priceFeed):
        checkTrade(self,priceFeed)

    def getPrice(self, token, seg, streamType):
        try:
            data = getQuote(self, token, seg, streamType)
            bid = data['AskInfo']['Price']
            ask = data['BidInfo']['Price']
            ltp = data['LastTradedPrice']
            return {"bid": bid, "ask": ask, "ltp": ltp}
        except:
            print('jfjf',traceback.print_exc(),token,seg,streamType,data)

    def updateOrder(self, order, orderDict):
        pass

    def getStrikeDiff(self,futToken):
        # print(self.fo_contract[futToken-35000,:])
        strikeDiff = self.fo_contract[futToken-35000,36]
        return strikeDiff

    def hideAddW(self):
        try:
            # self.timerUpdateWindows.stop()
            self.addW.hide()
        except:
            print(traceback)

    def updateWindows(self, feed,window):
        priceToken = feed['Token']
        if (window.isParachange == False):
            if (window.visibleRegion().isEmpty() == False):

                if (priceToken == self.tokenList[0]):
                    if (window.cashFut == 'CASH'):
                        window.baseToken = window.cashToken
                        window.cashPrice = feed['LTP']
                        window.basePrice = window.cashPrice
                        if (self.isFirstOrderPunch == False):
                            ATM = getATM(self, window.basePrice, window.strikeDiff)
                            if (ATM != window.ATM):
                                window.ATM = ATM
                                window.lb_atm.setText(str(window.ATM))
                                window.ATMCEToken = getATM_CE_Token(self, window.ATM, window.ceTable)
                                window.ATMPEToken = getATM_PE_Token(self, window.ATM, window.peTable)
                                self.tokenList[2] = window.ATMCEToken
                                self.tokenList[3] = window.ATMPEToken
                        window.lb_ltp.setText(str(window.basePrice))


                elif (priceToken == self.tokenList[1]):
                    if (window.cashFut != 'CASH'):
                        window.baseToken = window.futToken
                        window.futPrice = feed['LTP']
                        window.basePrice = window.futPrice
                        ATM = getATM(self, window.basePrice, window.strikeDiff)
                        if (self.isFirstOrderPunch == False):
                            if (ATM != window.ATM):
                                window.ATM = ATM
                                window.lb_atm.setText(str(window.ATM))
                                window.ATMCEToken = getATM_CE_Token(self, window.ATM, window.ceTable)
                                window.ATMPEToken = getATM_PE_Token(self, window.ATM, window.peTable)
                                self.tokenList[2] = window.ATMCEToken
                                self.tokenList[3] = window.ATMPEToken

                        window.lb_ltp.setText(str(window.basePrice))


                elif (priceToken == self.tokenList[2]):
                    window.atmcePrice = feed['LTP']
                    window.lbATMCE.setText('%.2f' % window.atmcePrice)
                    if (priceToken == self.tokenList[4]):
                        window.cePrice = feed['LTP']
                        window.lbcePrice.setText('%.2f' % window.cePrice)

                elif (priceToken == self.tokenList[3]):
                    window.atmpePrice = feed['LTP']
                    window.lbATMPE.setText('%.2f' % window.atmpePrice)

                    if (priceToken == self.tokenList[5]):
                        window.pePrice = feed['LTP']
                        window.lbpePrice.setText('%.2f' % window.pePrice)

                elif (priceToken == self.tokenList[4]):
                    window.ATMcePrice = feed['LTP']
                    window.lbcePrice.setText('%.2f' % window.ATMcePrice)

                elif (priceToken == self.tokenList[5]):
                    window.ATMpePrice = feed['LTP']
                    window.lbcePrice.setText('%.2f' % window.ATMpePrice)

    def getBaseInfo(self, window):
        getBaseInfo(self, window)

    def getStrikeOT(self,token):
        data=self.fo_contract[token-35000,:]
        return data[7],data[8]
