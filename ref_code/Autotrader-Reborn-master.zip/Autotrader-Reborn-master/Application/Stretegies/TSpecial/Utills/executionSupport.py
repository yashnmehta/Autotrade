import threading
import traceback


from Application.Services.Xts.Api.servicesMD import getQuote,subscribeToken
import numpy as np


import  datetime
import time

# from Application.Stretegies.TSpecial.Utills.keyParameters import getKeyParameterFile, saveJson


def getBaseInfo(self,window):
    try:
        window.symbol = window.cbSymbol.currentText()
        window.expiry = window.cbExp.currentText()
        window.cashToken = getCashToken(self,window.symbol)
        self.tokenList[0] = window.cashToken
        subscribeToken(self, window.cashToken, 'NSECM')

        window.futureToken = getFutureToken(self,window.symbol)
        self.tokenList[1] = window.futureToken
        # print(window.futureToken,self.tokenList)
        subscribeToken(self, window.futureToken, 'NSEFO')

        data = getQuote(self, window.cashToken, 'NSECM', 1501)
        # print("data",data)
        window.cashPrice = data['LastTradedPrice']


        data = getQuote(self, window.futureToken, 'NSEFO', 1501)
        window.futurePrice = data['LastTradedPrice']

        window.cashFut = window.cbCF.currentText()
        if (window.cashFut == 'CASH'):
            window.BaseToken = window.cashToken
            window.basePrice = window.cashPrice
        else:
            window.BaseToken = window.futureToken
            window.basePrice = window.futurePrice

        window.strikeDiff = getStrikeDiff(self, window.futureToken)
        window.lotsize = getLotSize(self, window.futureToken)
        window.ATM = getATM(self,window.cashPrice, window.strikeDiff)

        window.ceTable = getCETable(self, window.symbol, window.expiry)
        window.peTable = getPETable(self, window.symbol, window.expiry)

        window.lb_ltp_cash.setText(str(window.cashPrice))
        window.lb_ltp_fo.setText(str(window.futurePrice))
        window.lb_atm.setText(str(window.ATM))

        window.ATM_CE_Token = getATM_CE_Token(self, window.ATM, window.ceTable)
        window.ATM_PE_Token = getATM_PE_Token(self, window.ATM, window.peTable)

        self.tokenList[2] = window.ATM_CE_Token
        self.tokenList[3] = window.ATM_PE_Token

        subscribeToken(self, window.ATM_CE_Token, 'NSEFO')
        subscribeToken(self, window.ATM_PE_Token, 'NSEFO')

        data = getQuote(self, window.ATM_CE_Token, 'NSEFO', 1501)
        window.atmCEPrice = data['LastTradedPrice']

        data1 = getQuote(self, window.ATM_PE_Token, 'NSEFO', 1501)
        window.atmPEPrice = data1['LastTradedPrice']

        window.pairTotal = window.atmPEPrice + window.atmCEPrice
        window.lb_pTotal.setText('%.2f' % window.pairTotal)

        window.upperRangeIndex = window.cbUpperRange.currentIndex()
        window.lowerRangeIndex = window.cbLowerRange.currentIndex()

        window.ce_buy_strike = window.ATM + ((window.upperRangeIndex + 2 ) * window.strikeDiff)
        window.pe_buy_strike = window.ATM - ((window.lowerRangeIndex + 2 ) * window.strikeDiff)


        window.ce_buy_strike = window.ATM + (window.upperRangeIndex * window.strikeDiff) + window.strikeDiff
        window.pe_buy_strike = window.ATM - (window.lowerRangeIndex * window.strikeDiff) - window.strikeDiff

        window.lbCeBuyStrk.setText('%.2f' % window.ce_buy_strike)
        window.lbPeBuyStrk.setText('%.2f' % window.pe_buy_strike)

        window.Hedge_Token_CE = getATM_CE_Token(self,window.ce_buy_strike  , window.ceTable)
        window.Hedge_Token_PE = getATM_PE_Token(self, window.pe_buy_strike, window.peTable)

        self.tokenList[4] = window.Hedge_Token_CE
        self.tokenList[5] = window.Hedge_Token_PE


        data = getQuote(self, window.Hedge_Token_CE, 'NSEFO', 1501)
        # print("data", window.Hedge_Token_CE)
        window.CeBuyPrc = data['LastTradedPrice']
        data1 = getQuote(self, window.Hedge_Token_PE, 'NSEFO', 1501)

        window.PeBuyPrc = data1['LastTradedPrice']


        window.lbCeBuyPrc.setText('%.2f' % window.CeBuyPrc)
        window.lbPeBuyPrc.setText('%.2f' % window.PeBuyPrc)


        subscribeToken(self, window.Hedge_Token_CE, 'NSEFO')
        subscribeToken(self, window.Hedge_Token_PE, 'NSEFO')

        window.isParachange = False
        self

    except:
        print(traceback.print_exc())


def checkIsAnyPosition(self):
    isAnyOpenPos = False
    for i in self.position[:self.lastSerialNo,5]:
        if(i != 0):
            isAnyOpenPos = True
            self.isAnyOpenPos = isAnyOpenPos

            return
    self.isAnyOpenPos = isAnyOpenPos


def getStrikeDiff(self,futureToken):
    # print(self.fo_contract[futureToken-35000,:])
    strikeDiff = self.fo_contract[futureToken-35000,36]
    return strikeDiff

def getLotSize(self,futureToken):
    lotsize = self.fo_contract[futureToken-35000,11]
    return lotsize

def getATM(self,cashPrice,strikeDiff):
    # print('cash....',cashPrice,strikeDiff)
    ATM1 = (cashPrice / strikeDiff)
    frac = ATM1 % 1

    strikeDecisionPoint = float(0.4)
    # print(frac)
    if(frac > strikeDecisionPoint):
        ATM = int(ATM1+1) * strikeDiff
    else:
        ATM= int(ATM1)  * strikeDiff
    # print("Else Atttttmmm",ATM)
    # ATM1 = (cashPrice / strikeDiff) * strikeDiff

    return ATM



def getCETable(self,symbol,exp):
    # print("enter GetTable")

    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    fltr1 = np.asarray([exp])
    filteredarray2 = filteredarray[np.in1d(filteredarray[:, 6], fltr1)]
    filteredarray1 = filteredarray2[filteredarray2[:, 12].argsort()]

    # as ce table array by default price descending no need to sort array

    fltr2 = np.asarray(['CE'])
    ceTable= filteredarray1[np.in1d(filteredarray1[:, 8], fltr2)]
    # print('ceTableeee',ceTable)
    return ceTable

def getPETable(self,symbol,exp):
    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    fltr1 = np.asarray([exp])
    filteredarray2 = filteredarray[np.in1d(filteredarray[:, 6], fltr1)]
    filteredarray1 = filteredarray2[filteredarray2[:, 12].argsort()][::-1]  # here we invert array to sort by price desc
    fltr2 = np.asarray(['PE'])
    peTable= filteredarray1[np.in1d(filteredarray1[:, 8], fltr2)]
    return peTable

def getATM_CE_Token(self,atm,ceTable):
    try:
        # print("aaaaatm",atm,"cetssssssable",ceTable)
        ATM_CE_Token = ceTable[np.where(ceTable[:,12]==atm),2][0][0]

        return ATM_CE_Token
    except:
        print(traceback.print_exc(),'error \n###############\n','atm',atm,'ceTable',ceTable,'\n###############\n')
def getATM_PE_Token(self,atm,peTable):
    try:
        # print(atm)
        ATM_PE_Token = peTable[np.where(peTable[:,12]==atm),2][0][0]
        return ATM_PE_Token
    except:
        print(traceback.print_exc(),'error \n###############\n','atm',atm,'peTable',peTable,'\n###############\n')

def getFutureToken(self,symbol):
    futureToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 17]
    return futureToken

def getCashToken(self,symbol):
    # print(self.fo_contract)
    assetToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 9]

    # print(symbol,self.symbol,'getCashToken',assetToken)
    return assetToken



def getLists(self,ATMStrike):
    lowerRange= ATMStrike - ((self.lowerRangeIndex+1) *self.strikeDiff)
    upperRange= ATMStrike + ((self.upperRangeIndex+1) *self.strikeDiff)
    CEList = getCEList(self,upperRange,lowerRange)
    PEList = getPEList(self,upperRange,lowerRange)
    return CEList,PEList

def getCEList(self,upperRange,lowerRange):
    array1 = self.ceTable[np.where(self.ceTable[:, 12] >= lowerRange)]
    array2 = array1[np.where(array1[:, 12] <= upperRange)]
    array3 = array2[:, [2, 8, 12]]
    return array3

def getPEList(self,upperRange,lowerRange):
    array1 = self.peTable[np.where(self.peTable[:, 12] >= lowerRange)]
    array2 = array1[np.where(array1[:, 12] <= upperRange)]
    array3 = array2[:, [2, 8, 12]]
    return array3


def getExecutionTime(self):
    now = datetime.datetime.today()
    date = now.strftime('%Y-%m-%d ')
    a915 = datetime.datetime.strptime(date + '09:15:00', '%Y-%m-%d %H:%M:%S')
    a920 = datetime.datetime.strptime(date + self.etime, '%Y-%m-%d %H:%M:%S')
    self.timeout1 = int(a920.timestamp()-time.time())*1000
    return self.timeout1


def checkIsAnyPosition(self):
    isAnyOpenPos = False
    for i in self.position[:self.lastSerialNo,5]:
        if(i != 0):
            isAnyOpenPos = True
            self.isAnyOpenPos = isAnyOpenPos

            return
    self.isAnyOpenPos = isAnyOpenPos




def checkShortPosExist(self,array):
    isPos =False
    for i in array[0]:
        if(i < 0):
            isPos = True
            return isPos
    return isPos


def updateAllToken(self,window):
    subscribeToken(self,window.Hedge_Token_PE,'NSEFO')
    subscribeToken(self,window.Hedge_Token_CE,'NSEFO')
    # subscribeToken(self,window.hedgeToken_CE,'NSEFO')
    # subscribeToken(self,window.hedgeToken_PE,'NSEFO')
    subscribeToken(self,window.ATM_CE_Token,'NSEFO')
    subscribeToken(self,window.ATM_PE_Token,'NSEFO')
    window.isParachange = False


def dec_v(self,window):
    if (window.leQty.text() != '0'):
        newQ = int(window.leQty.text()) - window.lotsize

        window.leQty.setText(str(newQ))

def inc_v(self,window):
    # print('in inc_v',window.lotsize)

    newQ = int(window.leQty.text()) + window.lotsize
    window.leQty.setText(str(newQ))


def updateModifyInfo(self):
    try:
        # print("UPDATE MODIFYYYYYYYYYYYYYYYYYY iF0")
        connectModifyWindowSlot(self)

        self.modifyW.leFolioName.setText(self.folioName)
        self.modifyW.cbClient.addItem(self.clientId)

        self.modifyW.cbSymbol.setCurrentText(self.symbol)

        # self.modifyW.cbCF.setCurrentText(self.Base)
        self.modifyW.cbExp.setCurrentText(self.expiry)
        self.modifyW.ceTable = self.ceTable
        self.modifyW.peTable = self.peTable
        self.modifyW.strikeDiff = self.strikeDiff
        self.modifyW.lotsize = self.lotsize
        self.modifyW.freezeQty = self.freezeQty
        self.modifyW.symbol = self.symbol
        self.modifyW.expiry = self.expiry
        # self.modifyW.cashFut = self.Base
        # self.modifyW.BaseVIX = self.BaseVIX
        self.modifyW.cashToken = self.cashToken
        self.modifyW.futureToken = self.futureToken
        # self.modifyW.BaseToken = self.BaseToken
        # self.modifyW.basePrice =self.basePrice
        self.modifyW.cashPrice =self.cashPrice
        self.modifyW.futurePrice =self.futurePrice
        # self.modifyW.adjPts = self.adjPts
        self.modifyW.ATM = self.ATM

        self.ceStrikeIndex = self.modifyW.cbUpperRange.currentIndex()
        self.peStrikeIndex = self.modifyW.cbLowerRange.currentIndex()

        self.modifyW.lb_atm.setText('%.2f'%self.ATM)
        # self.modifyW.cbUpperRange.currentIndex(self.ceStrikeIndex())
        # self.modifyW.cbLowerRange.currentIndex(self.peStrikeIndex())
        self.modifyW.lb_ltp_cash.setText(self.addW.lb_ltp_cash.text())
        self.modifyW.lb_ltp_fo.setText(self.addW.lb_ltp_fo.text())
        self.modifyW.lbCeBuyStrk.setText(self.addW.lbCeBuyStrk.text())
        self.modifyW.lbPeBuyStrk.setText(self.addW.lbPeBuyStrk.text())
        self.modifyW.lbCeBuyPrc.setText(self.addW.lbCeBuyPrc.text())
        self.modifyW.lbPeBuyPrc.setText(self.addW.lbPeBuyPrc.text())

        self.modifyW.cashPrice = getPrice(self, token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
        self.modifyW.ATM = getATM(self, self.modifyW.cashPrice, self.strikeDiff)

        self.modifyW.ATM_CE_Token = getATM_CE_Token(self,self.modifyW.ATM,self.ceTable)
        self.modifyW.ATM_PE_Token = getATM_PE_Token(self,self.modifyW.ATM,self.peTable)


        self.modifyW.leSLAmount.setText(str(self.SlAmount))
        self.modifyW.leTargetAmount.setText(str(self.targetAmt))
        print("sl",self.SlAmount)
    except:
        print(traceback.print_exc(),'tttt')

def connectModifyWindowSlot(self):

    self.modifyW.pbApply.clicked.connect(self.modifyParameter)
    # self.modifyW.cbExp.currentTextChanged.connect(lambda: expchange(self, self.modifyW))
    # self.modifyW.cbTrend.currentIndexChanged.connect(lambda: trendChanged(self, self.modifyW))
    self.modifyW.pbGetInfo.clicked.connect(lambda: getBaseInfo(self, self.modifyW))
def getPrice(self, token, seg, streamType):

    data = getQuote(self, token, seg, streamType)
    # print('dataaaa:',data)
    ltp = data['LastTradedPrice']
    try:
        bid = data['AskInfo']['Price']
        ask = data['BidInfo']['Price']
    except:
        bid = 0.00
        ask = 0.00
    return {"bid": bid, "ask": ask, "ltp": ltp}
def getPrices(self):
    try:
        th = threading.Thread(target=getCEPEPrice,args=(self,))
        th.start()
    except:
        print(traceback.print_exc())

def getCEPEPrice(self):
    try:
        # print("(self.isFirstOrderPunch)",self.isFirstOrderPunch)
        # print("(self.isParameterSet)", self.isParameterSet)
        if (self.isFirstOrderPunch):
            window = self.modifyW
            a='modify'
        elif (self.isParameterSet):
            window = self.modifyW
            a='modify'

        else:
            window = self.addW
            a='add'

        if (window.visibleRegion().isEmpty() == False):
            # print(window,'llllll')
            # print(window.cashToken)
            window.cashPrice = getPrice(self=self, token=window.cashToken, seg='NSECM', streamType=1501)['ltp']
            window.futurePrice = getPrice(self=self, token=window.futureToken, seg='NSEFO', streamType=1501)['ltp']
            window.ATM = getATM(self, window.cashPrice, window.strikeDiff)

            data = getQuote(self,window.ATM_CE_Token, 'NSEFO', 1501)
            window.atmCEPrice = data['LastTradedPrice']

            data1 = getQuote(self, window.ATM_PE_Token, 'NSEFO', 1501)
            window.atmPEPrice = data1['LastTradedPrice']
           # print('xyz2')
    except:
        print(traceback.print_exc())



def setParametersModifyW(self):


    self.modifyW.folioName = self.addW.leFolioName.text()
    self.modifyW.clientId = self.addW.cbClient.currentText()
    self.modifyW.symbol = self.addW.cbSymbol.currentText()
    self.modifyW.expiry = self.addW.cbExp.currentText()

    # self.modifyW.cashToken = getCashToken(self, self.symbol)
    # self.modifyW.futureToken = getFutureToken(self, self.symbol)
    self.modifyW.strikeDiff = getStrikeDiff(self, self.futureToken)
    self.modifyW.freezeQty = int(self.fo_contract[self.futureToken - 35000, 14])

    # print('freezeQty',self.freezeQty)

    self.modifyW.ceTable = getCETable(self, self.symbol, self.expiry)
    self.modifyW.peTable = getPETable(self, self.symbol, self.expiry)
    self.modifyW.cashPrice = getPrice(self, token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
    self.modifyW.futurePrice = getPrice(self, token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']

    self.modifyW.ATM = getATM(self, self.modifyW.cashPrice, self.strikeDiff)



    # print("ATM:", self.modifyW.ATM, self.modifyW.cashPrice)
    # print("ceTable:", self.ceTable)

    self.modifyW.ceToken = getATM_CE_Token(self, self.modifyW.ATM, self.ceTable)
    self.modifyW.peToken = getATM_PE_Token(self, self.modifyW.ATM, self.peTable)
    self.modifyW.ATM_PE_Token = self.modifyW.ceToken
    self.modifyW.ATM_CE_Token = self.modifyW.peToken
    ###################################


    self.modifyW.cbSymbol.addItem(self.symbol)
    self.modifyW.cbExp.addItem(self.expiry)
    self.modifyW.leFolioName.setText(self.folioName)
    self.modifyW.cbClient.addItem(self.clientId)
    self.modifyW.leQty.setText(str(self.qty))

    self.modifyW.leSLAmount.setText(str(self.SlAmount))
    self.modifyW.leTargetAmount.setText(str(self.targetAmt))
    self.modifyW.lb_ltp_cash.setText(self.addW.lb_ltp_cash.text())
    self.modifyW.lb_ltp_fo.setText(self.addW.lb_ltp_fo.text())
    self.modifyW.lb_atm.setText(self.addW.lb_atm.text())
    self.modifyW.lbCeBuyStrk.setText(self.addW.lbCeBuyStrk.text())
    self.modifyW.lbPeBuyStrk.setText(self.addW.lbPeBuyStrk.text())
    self.modifyW.lbCeBuyPrc.setText(self.addW.lbCeBuyPrc.text())
    self.modifyW.lbPeBuyPrc.setText(self.addW.lbPeBuyPrc.text())
    # self.modifyW.lbCEPrice.setText(str(self.addW.CEPrice))
    # self.modifyW.lbPEPrice.setText(str(self.addW.PEPrice))
    self.modifyW.lb_pTotal.setText(self.addW.lb_pTotal.text())
    # self.modifyW.leAdjPts.setText( str(self.adjPts))
    # self.modifyW.cbUpperRange.setCurrentIndex(self.ceStrikeIndex)
    # self.modifyW.cbLowerRange.setCurrentIndex(self.peStrikeIndex)

    # self.modifyW.leSLPoint.setText(str(self.slPts))
    # self.modifyW.leTrendPts.setText(str(self.trendPts))
    # self.modifyW.leRevPts.setText(str(self.revPts))
    # self.modifyW.leTargetPts2.setText(str(self.targetPts2))
    # self.modifyW.leTargetPts3.setText(str(self.targetPts3))
    # self.modifyW.leLowerPoint.setText(str(self.strikeDecisionPoint))
    # self.modifyW.lbBaseStrike.setText(str(self.baseStrike))
    # self.modifyW.lbLastOrderPoint.setText(str(self.lastOrderPoint))
    self.modifyW.SlAmount = float(self.addW.leSLAmount.text())
    self.modifyW.targetAmount = float(self.addW.leTargetAmount.text())
    # self.modifyW.lbPEPrice.setText(str(self.modifyW.atmPEPrice))


