import traceback

import numpy as np
from PyQt5.QtCore import *
from Application.Stretegies.TSpecial.Utills.keyParameters import reloadKeyParameter, getKeyParameterFile, saveJson
from Application.Stretegies.TSpecial.Utills.executionSupport import *
from PyQt5.QtWidgets import *

from Application.Stretegies.TSpecial.Utills.orderSupport import getHedgeToken


def setParameters(self,window):
    try:
        self.qty = int(window.leQty.text())
        if (self.qty <= 0):
            self.messageBox = QMessageBox()
            self.messageBox.setIcon(QMessageBox.Critical)
            self.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
            self.messageBox.setText('Quantity must be greater than zero!!')
            self.messageBox.show()
        else:

            self.folioName = window.leFolioName.text()

            getKeyParameterFile(self, self.folioName)
            self.isExecuteOnTimer = window.cxbPunchOnETime.isChecked()
            if (self.isExecuteOnTimer):
                date = datetime.datetime.today().strftime('%Y-%m-%d ')

                self.executionTime = datetime.datetime.strptime(
                    date + window.lt1.text() + ":" + window.lt2.text() + ":" + window.lt3.text(),
                    '%Y-%m-%d %H:%M:%S')

                checkTime = datetime.datetime.now() + datetime.timedelta(minutes=1)

                self.timeout1 = int(self.executionTime.timestamp() - time.time()) * 1000
                if (self.executionTime < checkTime):
                    return
                else:
                    # print('in else')
                    self.timerExecution.setInterval(self.timeout1)
                    self.timerExecution.start()

            self.clientId = window.cbClient.currentText()
            self.symbol = window.cbSymbol.currentText()
            self.expiry = window.cbExp.currentText()
            self.upperRangeIndex = window.cbUpperRange.currentIndex()
            self.lowerRangeIndex = window.cbLowerRange.currentIndex()
            self.coverType = "Half" if window.rbCHalf.isChecked() else "Full"
            self.strikeDecisionPoint = float(window.leLowerPoint.text())
            self.SlAmount = float(window.leSLAmount.text())
            self.targetAmt = float(window.leTargetAmount.text())

            self.cashToken = getCashToken(self,self.symbol)
            self.futureToken = getFutureToken(self,self.symbol)

            self.Hedge_Token_PE = window.Hedge_Token_PE
            self.Hedge_Token_CE = window.Hedge_Token_CE

            self.strikeDiff = getStrikeDiff(self,self.futureToken)
            self.freezeQty = int(self.fo_contract[self.futureToken - 35000, 14])
            self.lotsize = int(self.fo_contract[self.futureToken - 35000, 11])
            # print('freezeQty',self.freezeQty)

            self.ceTable = getCETable(self,self.symbol, self.expiry)
            self.peTable = getPETable(self,self.symbol, self.expiry)

            self.isParameterSet = True
            updateModifyInfo(self)
            setParametersModifyW(self)
            self.sgParamSet.emit()
            saveJson(self)


    except:
        print(traceback.print_exc(),'yyyyyy')
        


def setParametersModify(self,window):
    try:
        self.qty = int(self.addW.leQty.text())
        if (self.qty <= 0):
            self.messageBox = QMessageBox()
            self.messageBox.setIcon(QMessageBox.Critical)
            self.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
            self.messageBox.setText('Quantity must be greater than zero!!')
            self.messageBox.show()
        else:

            print("setparametermmmmmmmm")
            self.folioName = window.leFolioName.text()

            getKeyParameterFile(self, self.folioName)
            self.isExecuteOnTimer = window.cxbPunchOnETime.isChecked()
            if (self.isExecuteOnTimer):
                date = datetime.datetime.today().strftime('%Y-%m-%d ')

                self.executionTime = datetime.datetime.strptime(
                    date + window.lt1.text() + ":" + window.lt2.text() + ":" + window.lt3.text(),
                    '%Y-%m-%d %H:%M:%S')

                checkTime = datetime.datetime.now() + datetime.timedelta(minutes=1)

                self.timeout1 = int(self.executionTime.timestamp() - time.time()) * 1000
                if (self.executionTime < checkTime):
                    return
                else:
                    # print('in else')
                    self.timerExecution.setInterval(self.timeout1)
                    self.timerExecution.start()

            self.clientId = window.cbClient.currentText()
            self.symbol = window.cbSymbol.currentText()
            self.expiry = window.cbExp.currentText()
            self.upperRangeIndex = window.cbUpperRange.currentIndex()
            self.lowerRangeIndex = window.cbLowerRange.currentIndex()
            self.coverType = "Half" if window.rbCHalf.isChecked() else "Full"
            self.strikeDecisionPoint = float(window.leLowerPoint.text())
            self.SlAmount = float(window.leSLAmount.text())
            self.targetAmt = float(window.leTargetAmount.text())
            self.cashToken = getCashToken(self,self.symbol)
            self.futureToken = getFutureToken(self,self.symbol)

            self.Hedge_Token_PE = window.Hedge_Token_PE
            self.Hedge_Token_CE = window.Hedge_Token_CE

            self.strikeDiff = getStrikeDiff(self,self.futureToken)
            self.freezeQty = int(self.fo_contract[self.futureToken - 35000, 14])
            self.lotsize = int(self.fo_contract[self.futureToken - 35000, 11])
            # print('freezeQty',self.freezeQty)
            self.ceStrikeIndex = window.cbUpperRange.currentIndex()
            self.peStrikeIndex = window.cbLowerRange.currentIndex()

            self.ceTable = getCETable(self,self.symbol, self.expiry)
            self.peTable = getPETable(self,self.symbol, self.expiry)


            self.isParameterSet = True
            updateModifyInfo(self)
            self.sgParamModify.emit()
            saveJson(self)


    except:
        print(traceback.print_exc())
