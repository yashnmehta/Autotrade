import json
import datetime
import os
import numpy as np
import traceback
from Application.Stretegies.TSpecial.Utills.executionSupport import *


def craeteKeyParameterJson(self, cf):
    try:
        if (cf):

            open_pos = self.position[:self.lastSerialNo, :].tolist()
            #self.DOI = self.DOI
        else:

            open_pos = []
            #self.DOI = datetime.datetime.today().strftime('%d%m%Y')
        self.keyParameterJson = {
            'clientId': self.clientId,
            "folioName": self.folioName,
            "stype": self.stype,
            "symbol": self.symbol,
            "lastOrderPoint": self.lastOrderPoint,
            "expiry": self.expiry,
            "qty": self.qty,

            "upperRangeIndex": self.upperRangeIndex,
            "lowerRangeIndex": self.lowerRangeIndex,

            "coverType": self.coverType,
            "freezeQty": self.freezeQty,
            "strikeDiff": self.strikeDiff,
            "lotsize": self.lotsize,

            'strikeDecisionPoint': self.strikeDecisionPoint,
            'SlAmount': self.SlAmount,
            'targetAmt': self.targetAmt,

            'cashToken': self.cashToken,
            'futureToken': self.futureToken,
            'Hedge_Token_PE': self.Hedge_Token_PE,
            'Hedge_Token_CE': self.Hedge_Token_CE,
            'fullPos': self.fullPos,
            'ATM': self.ATM,
            'isParameterSet': self.isParameterSet,
            'tokenList': self.tokenList,
            'open_position': open_pos,
            'isFirstOrderPunch':self. isFirstOrderPunch,
            'DateOfInitialization': self.DOI,


        }
    except:
        print(traceback.print_exc(),'yyyy')



def reloadKeyParameter(self):
    try:
        f1 = open(self.keyParameterFile)
        self.keyParameterJson = json.load(f1)
        f1.close()
        self.clientId = self.keyParameterJson['clientId']
        self.folioName = self.keyParameterJson['folioName']
        self.stype = self.keyParameterJson['stype']
        self.symbol = self.keyParameterJson['symbol']
        self.expiry = self.keyParameterJson['expiry']
        self.upperRangeIndex = self.keyParameterJson['upperRangeIndex']
        self.lowerRangeIndex = self.keyParameterJson['lowerRangeIndex']
        self.coverType = self.keyParameterJson['coverType']
        self.lastOrderPoint = self.keyParameterJson['lastOrderPoint']

        self.qty = self.keyParameterJson['qty']
        self.lotsize = self.keyParameterJson['lotsize']
        self.isFirstOrderPunch = self.keyParameterJson['isFirstOrderPunch']
        self.DOI = self.keyParameterJson['DateOfInitialization']

        self.SlAmount = self.keyParameterJson['SlAmount']
        self.targetAmt = self.keyParameterJson['targetAmt']


        self.ceTable = getCETable(self,self.symbol, self.expiry)
        self.peTable = getPETable(self,self.symbol, self.expiry)

        # print('stretegy parameter has been set, cashToken', self.cashToken)
        self.cashToken = getCashToken(self,self.symbol)
        self.futureToken = getFutureToken(self,self.symbol)
        self.strikeDiff = getStrikeDiff(self,self.futureToken)
        self.freezeQty = int(self.fo_contract[self.futureToken - 35000, 14])
        if (self.keyParameterJson['open_position'] != []):
            self.open_position = np.asarray(self.keyParameterJson['open_position'])
            updateOpenPos()
        setParametersModifyW(self)
        updateModifyInfo(self)
        connectModifyWindowSlot(self)

        # print('freezeQty', self.freezeQty)
    except:
        print(traceback.print_exc())


def updateOpenPos(self):
    for i in self.open_position:
        # print(i)
        # fltr = [i[1]]
        rowarray = np.where(self.position[:self.lastSerialNo, 1] == i[1])[0]

        if (rowarray.size != 0):

            rowNO = rowarray[0]

            filteredArray = self.position[np.where(self.position[:self.lastSerialNo, 1] == i[1])][0]

            openQty = i[5] + filteredArray[5]
            openamt = i[8] + filteredArray[8]

            editList = [5, 8, 11, 12, 13, 14]
            self.position[rowNO, editList] = [openQty, openamt, openQty, openamt, 0.0, 0.0]

        else:
            self.position[self.lastSerialNo] = [i[0], i[1], i[2], i[3], i[4], i[5], i[6], i[7], i[8], i[9], i[10],
                                                i[5], i[8], 0.0, 0.0]
            self.lastSerialNo += 1

        self.checkIsAnyPosition()

        if (i[5] > 0):
            sellQ = i[5]
            buyQ = 0
        else:
            sellQ = 0
            buyQ = i[5]
        data = [self.userID, self.clientId, self.stype, self.folioName, i[0], i[1], 'stockname', i[2], self.expiry,
                i[3], i[4], i[5], 0.0,
                i[5], i[8], 0.0, buyQ, 0.0, sellQ, 0.0, 0.0, 0.0, self.lotsize, self.freezeQty, i[8], 0, 0.0]
        self.sgFolioOpenPos.emit(data)


def saveJson(self, cf=False):
    getKeyParameterFile(self,self.folioName)
    craeteKeyParameterJson(self,cf)
    f2 = open(self.keyParameterFile, 'w')
    jInfo_new = json.dumps(self.keyParameterJson, indent=4)
    f2.write(jInfo_new)
    f2.close()


def getKeyParameterFile(self, folioName):
    todate = datetime.datetime.today().strftime('%Y%m%d')
    loc = os.getcwd().split('Application')
    self.keyParameterFile = os.path.join(loc[0], 'Application', 'DB', 'Stretegy_data', todate,
                                         '%s.json' % folioName)