import sys
import traceback

from Application.Services.Xts.Api.servicesIA import PlaceOrder, modifyOrder
import time as ttime
from Application.Stretegies.TSpecial.Utills.keyParameters import  saveJson
from Application.Stretegies.TSpecial.Utills.executionSupport import *

def makeOrder(self,token,qty,orderSide, orderType  = 'MARKET', limitPrice = 0.0, triggerPrice = 0 ):
    appOrderIdList = []
    while qty > self.freezeQty:
        appOrderId = PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=token, orderSide=orderSide,
                   qty=self.freezeQty,
                   limitPrice=limitPrice,
                   validity='DAY', disQty=0, triggerPrice=triggerPrice, uid=self.folioName, orderType=orderType,
                   productType='NRML')

        # need to add in OMS
        appOrderIdList.append(appOrderId)
        ttime.sleep(0.1)
        qty -= self.freezeQty
    appOrderId = PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=token, orderSide=orderSide,
               qty=qty,
               limitPrice=limitPrice,
               validity='DAY', disQty=0, triggerPrice=triggerPrice, uid=self.folioName, orderType=orderType,
               productType='NRML')
    # need to add in OMS
    appOrderIdList.append(appOrderId)
    ttime.sleep(0.1)
    return appOrderIdList

def getHedgeToken(self,ATM):
    peHedgeStrike = ATM - ((self.lowerRangeIndex + 2) * self.strikeDiff)
    ceHedgeStrike = ATM + ((self.upperRangeIndex + 2) * self.strikeDiff)

    # print('ceHedgeStrike',ceHedgeStrike,'peHedgeStrike',peHedgeStrike,'\n\n\n',self.ceTable,'\n\n\n',self.peTable)
    ceHedgeToken = self.ceTable[np.where(self.ceTable[:, 12] == ceHedgeStrike), 2][0][0]
    peHedgeToken = self.peTable[np.where(self.peTable[:, 12] == peHedgeStrike), 2][0][0]
    # print('ceHedgeToken',ceHedgeToken,'peHedgeToken',peHedgeToken,'peHedgeStrike',peHedgeStrike,'ceHedgeStrike',ceHedgeStrike)
    return ceHedgeToken,peHedgeToken


def getHedgeQty(self):
    if (self.coverType == 'Half'):
        hedge_ce_Qty = self.qty * (self.lowerRangeIndex + 1)
        hedge_pe_Qty = self.qty * (self.upperRangeIndex + 1)
    else:
        hedge_ce_Qty = self.qty * (self.lowerRangeIndex + self.upperRangeIndex + 3)
        hedge_pe_Qty = hedge_ce_Qty
    return hedge_ce_Qty,hedge_pe_Qty

def makeFirstOrder(self):
    try:
        if (self.isFirstOrderPunch == False):
            # print("fdkhfkdfh")
            self.cashPrice = getPrice(self,token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
            self.futurePrice = getPrice(self,token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
            self.ATM = getATM(self,self.cashPrice, self.strikeDiff)
            ATM = getATM(self,self.cashPrice, self.strikeDiff)

            ##################### get hedge qty ############################
            hedge_ce_Qty, hedge_pe_Qty = getHedgeQty(self)
            ###################################################################
            ##################### get hedge strike ############################
            self.ceHedgeToken, self.peHedgeToken = getHedgeToken(self,ATM)
            ###################################################################
            ###################### place order for hedge ######################
            makeOrder(self,self.ceHedgeToken,hedge_ce_Qty,'Buy')
            makeOrder(self,self.peHedgeToken,hedge_pe_Qty,'Buy')
            ###################################################################
            ceList,peList = getLists(self,ATM)

            for j, i in enumerate(ceList):
                ct = ceList[j, 0]
                pt = peList[j, 0]
                ceQty = self.qty
                peQty = self.qty

                makeOrder(self,ct,ceQty,'Sell')
                makeOrder(self,pt,peQty,'Sell')

            self.lastOrderPoint = self.cashPrice
            self.ceHedgeStrike = ATM + ((self.upperRangeIndex + 2) * self.strikeDiff)
            self.peHedgeStrike = ATM - ((self.lowerRangeIndex + 2) * self.strikeDiff)
            self.last_ITM_CE = self.ceHedgeStrike - self.strikeDiff
            self.last_ITM_PE = self.peHedgeStrike + self.strikeDiff

            self.sgStart.emit()
            self.isStart = True
            self.isFirstOrderPunch = True
            self.saveJson()
            self.Slogger.info('First Order Placed Successfully..')
    except:
        print("kjsdkjksjkf",traceback.print_exc())
        self.Slogger.error(sys.exc_info()[1])




def makeFirstOrder1(self):
    try:
        if (self.isFirstOrderPunch == False):
            self.cashPrice = self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
            print("CahPrice:",self.cashPrice)
            self.futurePrice = self.getPrice(token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
            self.ATM = self.getATM(self.cashPrice, self.strikeDiff)
            ATM = self.getATM(self.cashPrice, self.strikeDiff)
            ##################### get hedge qty ############################
            if (self.coverType == 'Half'):
                hedge_ce_Qty = self.qty * (self.lowerRangeIndex + 1)
                hedge_pe_Qty = self.qty * (self.upperRangeIndex + 1)
            else:
                hedge_ce_Qty = self.qty * (self.lowerRangeIndex + self.upperRangeIndex + 3)
                hedge_pe_Qty = hedge_ce_Qty
            ###################################################################
            ##################### get hedge strike ############################
            peHedgeStrike = ATM - ((self.lowerRangeIndex + 2) * self.strikeDiff)
            ceHedgeStrike = ATM + ((self.upperRangeIndex + 2) * self.strikeDiff)
            # print('ceHedgeStrike',ceHedgeStrike,'peHedgeStrike',peHedgeStrike,'\n\n\n',self.ceTable,'\n\n\n',self.peTable)
            ceHedgeToken = self.ceTable[np.where(self.ceTable[:, 12] == ceHedgeStrike), 2][0][0]
            peHedgeToken = self.peTable[np.where(self.peTable[:, 12] == peHedgeStrike), 2][0][0]
            # print('ceHedgeToken',ceHedgeToken,'peHedgeToken',peHedgeToken,'peHedgeStrike',peHedgeStrike,'ceHedgeStrike',ceHedgeStrike)
            ###################################################################
            ###################### place order for hedge ######################
            # while hedge_ce_Qty > self.freezeQty:
            #     PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=ceHedgeToken, orderSide='Buy',
            #                qty=self.freezeQty,
            #                limitPrice=0.0,
            #                validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
            #                productType='NRML')
            #     time.sleep(0.1)
            #     hedge_ce_Qty -= self.freezeQty

            #
            # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=ceHedgeToken, orderSide='Buy',
            #            qty=hedge_ce_Qty,
            #            limitPrice=0.0,
            #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
            #            productType='NRML')
            # time.sleep(0.1)


            # while hedge_pe_Qty > self.freezeQty:
            #     PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=peHedgeToken, orderSide='Buy',
            #                qty=self.freezeQty,
            #                limitPrice=0.0,
            #                validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
            #                productType='NRML')
            #     hedge_pe_Qty -= self.freezeQty
            #     time.sleep(0.1)
            # PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=peHedgeToken, orderSide='Buy',
            #            qty=hedge_pe_Qty,
            #            limitPrice=0.0,
            #            validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
            #            productType='NRML')
            # time.sleep(0.1)

            makeOrder(self,ceHedgeToken,hedge_ce_Qty,'Buy')
            makeOrder(self,peHedgeToken,hedge_pe_Qty,'Buy')

            ###################################################################

            ceList = self.getCEList(ATM)
            peList = self.getPEList(ATM)

            lis = ceList if (len(ceList) > len(peList)) else peList
            for j, i in enumerate(lis):
                ct = 0
                pt = 0
                if (j < len(ceList)):
                    ct = ceList[j, 0]
                if (j < len(peList)):
                    pt = peList[j, 0]

                ceQty = self.qty
                peQty = self.qty
                while ceQty > self.freezeQty:
                    PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=ct, orderSide='Sell',
                               qty=self.freezeQty, limitPrice=0.0,
                               validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                               productType='NRML')
                    ceQty -= self.freezeQty
                    PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=ct, orderSide='Sell',
                               qty=self.freezeQty, limitPrice=0.0,
                               validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                               productType='NRML')
                    peQty -= self.freezeQty
                    time.sleep(0.2)

                PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=ct, orderSide='Sell', qty=ceQty,
                           limitPrice=0.0,
                           validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                           productType='NRML')

                PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=pt, orderSide='Sell', qty=peQty,
                           limitPrice=0.0,
                           validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                           productType='NRML')
                time.sleep(0.2)

            self.lastOrderPoint = self.cashPrice

            self.sgStart.emit()
            self.isStart = True
            self.isFirstOrderPunch = True
            self.saveJson()
            self.Slogger.info('First Order Placed Successfully..')
    except:
        self.Slogger.error(sys.exc_info()[1])


def updateOpenPos(self):

    for i in self.open_position:
        rowarray = np.where(self.position[:self.lastSerialNo, 1] == i[1])[0]
        if (rowarray.size != 0):
            rowNO = rowarray[0]
            filteredArray = self.position[np.where(self.position[:self.lastSerialNo, 1] == i[1])][0]
            openQty = i[5] + filteredArray[5]
            openamt = i[8] + filteredArray[8]
            editList = [5, 8, 11, 12, 13, 14]
            self.position[rowNO, editList] = [openQty, openamt, openQty, openamt, 0.0, 0.0]
        else:
            self.position[self.lastSerialNo] = [i[0], i[1], i[2], i[3], i[4], i[5], i[6], i[7], i[8], i[9], i[10],
                                                i[5], i[8], 0.0, 0.0]
            self.lastSerialNo += 1
        self.checkIsAnyPosition()
        if (i[5] > 0):
            sellQ = i[5]
            buyQ = 0
        else:
            sellQ = 0
            buyQ = i[5]
        data = [self.userID, self.clientId, self.stype, self.folioName, i[0], i[1], 'stockname', i[2], self.expiry,
                i[3], i[4], i[5], 0.0,
                i[5], i[8], 0.0, buyQ, 0.0, sellQ, 0.0, 0.0, 0.0, self.lotsize, self.freezeQty, i[8], 0, 0.0]
        self.sgFolioOpenPos.emit(data)

def placeHedgeOrder(self):

    peHedgeStrike = self.last_ITM_CE  -  self.strikeDiff
    ceHedgeStrike = self.last_ITM_PE  +  self.strikeDiff

    ceHedgeToken = self.ceTable[np.where(self.ceTable[:,12]==ceHedgeStrike),2][0][0]
    peHedgeToken = self.peTable[np.where(self.peTable[:,12]==peHedgeStrike),2][0][0]

    makeOrder(self,ceHedgeToken,self.qty,'Buy')
    makeOrder(self,peHedgeToken,self.qty,'Buy')
