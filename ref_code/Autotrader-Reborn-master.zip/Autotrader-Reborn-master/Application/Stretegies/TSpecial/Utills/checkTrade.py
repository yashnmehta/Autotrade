

from Application.Stretegies.TSpecial.Utills.orderSupport import *
from Application.Stretegies.TSpecial.Utills.executionSupport import *


def checkTrade(self, priceFeed):
    if (self.isStart):
        priceToken = priceFeed['Token']
        if (self.cashToken == priceToken):
            cashPrice = priceFeed['LTP']
            self.cashPrice = cashPrice
            if (self.cashPrice > (self.lastOrderPoint + self.strikeDiff)):
                atm = getATM(self,cashPrice, self.strikeDiff)

                self.last_ITM_PE += self.strikeDiff

                peToken = self.peTable[np.where(self.peTable[:, 12] == self.last_ITM_PE), 2][0][0]
                array = self.position[np.where(self.position[:, 1] == peToken), 5]
                if(array.size==0):
                    isPosExist = False
                else:
                    isPosExist = checkShortPosExist(array)
                ##################################
                if (isPosExist != True):
                    placeHedgeOrder(self)
                    peToken = self.peTable[np.where(self.peTable[:, 12] == self.last_ITM_PE), 2][0][0]
                    ceToken = self.ceTable[np.where(self.ceTable[:, 12] == atm), 2][0][0]
                    makeOrder(self,peToken,self.qty,'Sell')
                    makeOrder(self,ceToken,self.qty,'Sell')
                    time.sleep(0.2)

                ##################################
                self.lastOrderPoint = cashPrice
                self.saveJson()
                d = {'cashPrice': self.cashPrice, 'strikeDiff': self.strikeDiff, 'lastOrderPoint': self.lastOrderPoint}
                self.Slogger.info('checkTrade (cashPrice > (lastOrderPoint + strikeDiff))....', d)

            elif (self.cashPrice < (self.lastOrderPoint - self.strikeDiff)):
                # print('in else',self.cashPrice,self.lastOrderPoint - 100.0,self.cashPrice < (self.lastOrderPoint - 100.0))

                atm = self.getATM(cashPrice, self.strikeDiff)
                self.last_ITM_CE -= self.strikeDiff

                ceToken = self.ceTable[np.where(self.ceTable[:, 12] == self.last_ITM_CE), 2][0][0]
                array = self.position[np.where(self.position[:, 1] == ceToken), 5]

                isPosExist = self.checkShortPosExist(array)
                ##################################
                if (isPosExist != True):
                    placeHedgeOrder(self)
                    ####################### pledge hedge Qty #################################
                    ceToken = self.ceTable[np.where(self.ceTable[:, 12] == self.last_ITM_CE), 2][0][0]
                    peToken = self.peTable[np.where(self.peTable[:, 12] == atm), 2][0][0]

                    makeOrder(self,peToken,self.qty,'Sell')
                    makeOrder(self,ceToken,self.qty,'Sell')


                ##################################
                self.lastOrderPoint = cashPrice
                self.saveJson()
                d = {'cashPrice': self.cashPrice, 'strikeDiff': self.strikeDiff, 'lastOrderPoint': self.lastOrderPoint}
                self.Slogger.info('checkTrade (cashPrice < (lastOrderPoint - strikeDiff))....', d)


