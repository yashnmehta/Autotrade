
import traceback
from Application.Stretegies.TSpecial.Utills.executionSupport import  getQuote,getATM_PE_Token,getATM_CE_Token,getATM

def updateWindows(self, feed,window):
    priceToken  = feed['Token']

    if(window.isParachange==False):
        if(window.visibleRegion().isEmpty() == False):
            if(priceToken==self.tokenList[0]):
                if (window.cashFut == 'CASH'):
                    window.BaseToken = window.cashToken
                    window.cashPrice = feed['LTP']
                    window.basePrice = window.cashPrice
                    if(self.isFirstOrderPunch==False):
                        ATM = getATM(self, window.basePrice, window.strikeDiff)
                        if(ATM != window.ATM):
                            window.ATM = ATM
                            window.lb_atm.setText(str(window.ATM))
                            window.ATM_CE_Token = getATM_CE_Token(self, window.ATM, window.ceTable)
                            window.ATM_PE_Token = getATM_PE_Token(self, window.ATM, window.peTable)
                            self.tokenList[2] = window.ATM_CE_Token
                            self.tokenList[3] = window.ATM_PE_Token
                window.lb_ltp_cash.setText(str(window.basePrice))

            elif(priceToken==self.tokenList[1]):
                if (window.cashFut != 'CASH'):
                    window.BaseToken = window.futureToken
                    window.futurePrice = feed['LTP']
                    window.basePrice = window.futurePrice
                    ATM = getATM(self, window.basePrice, window.strikeDiff)
                    if(self.isFirstOrderPunch==False):
                        if(ATM != window.ATM):
                            window.ATM = ATM
                            window.lb_atm.setText(str(window.ATM))
                            window.ATM_CE_Token = getATM_CE_Token(self, window.ATM, window.ceTable)
                            window.ATM_PE_Token = getATM_PE_Token(self, window.ATM, window.peTable)
                            self.tokenList[2] = window.ATM_CE_Token
                            self.tokenList[3] = window.ATM_PE_Token

                window.lb_ltp_fo.setText(str(window.basePrice))

            elif(priceToken==self.tokenList[2]):
                window.atmCEPrice = feed['LTP']
                window.pairTotal = window.atmPEPrice + window.atmCEPrice
                window.lb_pTotal.setText('%.2f' % window.pairTotal)


            elif(priceToken==self.tokenList[3]):
                window.atmPEPrice = feed['LTP']
                window.pairTotal = window.atmPEPrice + window.atmCEPrice
                window.lb_pTotal.setText('%.2f' % window.pairTotal)
            elif(priceToken==self.tokenList[4]):
                window.CeBuyPrc= feed['LTP']
                window.lbCeBuyPrc.setText('%.2f' % window.CeBuyPrc)
                print('lbCeBuyPrc',window.lbCeBuyPrc)

            elif(priceToken==self.tokenList[5]):
                window.PeBuyPrc= feed['LTP']
                window.lbPeBuyPrc.setText('%.2f' % window.PeBuyPrc)




def updateValues(self):
    if (self.isFirstOrderPunch):
        window = self.modifyW
        # window.lb_hedge_prc.setText('%.2f' % window.hedgeOptPrc)

    elif (self.isParameterSet):
        window = self.modifyW
        # window.lb_hedge_Prc.setText('%.2f' % window.hedgeOptPrc)

    else:
        print('addW')
        window = self.addW

    try:
        window.symbol = window.cbSymbol.currentText()
        window.expiry = window.cbExp.currentText()
        window.cashToken = self.getCashToken(window.symbol)
        window.futureToken = self.getFutureToken(window.symbol)
        data = getQuote(self, window.cashToken, 'NSECM', 1501)
        window.cashPrice = data['LastTradedPrice']
        data = getQuote(self, window.futureToken, 'NSEFO', 1501)
        window.futurePrice = data['LastTradedPrice']

        window.ATM = self.getATM(window.cashPrice, window.strikeDiff)

        window.lb_ltp_cash.setText(str(window.cashPrice))
        window.lb_ltp_fo.setText(str(window.futurePrice))
        window.lb_atm.setText(str(window.ATM))

        window.ATM = getATM(window.cashPrice, window.strikeDiff)

        window.ATM_CE_Token=getATM_CE_Token(window.ATM,window.ceTable)
        window.ATM_PE_Token=getATM_PE_Token(window.ATM,window.peTable)

        pairTotal = window.atmPEPrice + window.atmCEPrice
        window.lb_pTotal.setText('%.2f'%pairTotal)
    except:
        print(traceback.print_exc())

