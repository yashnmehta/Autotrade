import sys
import logging
import os
import threading
import traceback
from PyQt5.QtCore import *
import json
from PyQt5.QtCore import QObject,QTimer,pyqtSignal
from PyQt5.QtGui import QKeySequence
from PyQt5.QtWidgets import QMessageBox

import numpy as np
import datatable as dt
from Application.Services.Xts.Api.servicesIA import PlaceOrder
import datetime
import time
from Application.Services.Xts.Api.servicesMD import getQuote
from Application.Utils.configReader import refresh
from Application.Stretegies.TSpecial.Utills.executionSupport import getBaseInfo
from Application.Stretegies.TSpecial.Utills.keyParameters import *
from Application.Stretegies.TSpecial.Utills.checkTrade import checkTrade
from Application.Stretegies.TSpecial.Utills.orderSupport import *
from Application.Stretegies.TSpecial.Utills.riskSupport import *
from Application.Stretegies.TSpecial.Utills.setParameters import *
from Application.Stretegies.TSpecial.Utills.squareOff import *
from Application.Stretegies.TSpecial.Utills.uiSupport import *
from Application.Stretegies.TSpecial.Views.addW import addW
from Application.Stretegies.TSpecial.Views.modifyW import modifyW
# from Application.Stretegies.TSpecial.Utills.eventBind import eventsBind





class logic(QObject):
    sgMTM = pyqtSignal(str,float)
    sgSL = pyqtSignal(str, float)
    sgTarget = pyqtSignal(str, float)
    sgAlert = pyqtSignal(str)
    sgParamSet = pyqtSignal()
    sgParamModify = pyqtSignal()

    sgStart = pyqtSignal()
    sgActivate =pyqtSignal()
    sgStop = pyqtSignal()
    sgClose =pyqtSignal()
    sgFolioOpenPos = pyqtSignal(list)
    ################################# Intialization Here ##################################################
    def __init__(self):
        super(logic, self).__init__()

        self.position = np.zeros((100, 15), dtype=object)
        self.posHeads = ['exch',
                         'token', 'symbol', 'strike', 'c/p', 'netqty',
                         'requestedOrder', 'openOrder', 'netamt', 'ltp', 'mtm',
                         'OpenQty', 'OpenAmt', 'DQty', 'Damt']

        self.addW = addW(self)
        self.modifyW = modifyW(self)
        self.setAllShortCut()
        # eventsBind(self)
        self.connect2slots()
        self.initVaribles()



    def createTimer(self):

        self.timerExecution = QTimer()
        self.timerExecution.timeout.connect(lambda:makeFirstOrder(self))
        self.timerExecution.setSingleShot(True)

        self.timerUpdateWindows = QTimer()
        self.timerUpdateWindows.setInterval(500)
        self.timerUpdateWindows.timeout.connect(lambda: updateValues(self))

        self.timerGetPrices = QTimer()
        self.timerGetPrices.setInterval(500)
        self.timerGetPrices.timeout.connect(lambda:getPrices(self))



    # def createConnection(self):
    #     self.addW.pbApply.clicked.connect(lambda: setParameters(self))
    #     self.addW.cbSymbol.currentIndexChanged.connect(lambda:self.addW.getOptionExpiryList(self.fo_contract))
    #     self.addW.pbGet.clicked.connect(lambda:self.getBaseInfo(self.addW))
    # #
    def connect2slots(self):

        self.addW.pbApply.clicked.connect(self.setParameters)
        self.addW.cbSymbol.currentIndexChanged.connect(lambda: self.addW.getOptionExpiryList(self.fo_contract))
        self.addW.pbGet.clicked.connect(lambda: getBaseInfo(self, self.addW))
        self.modifyW.pbApply.clicked.connect(self.modifyParameter)

        self.modifyW.pbGetInfo.clicked.connect(lambda: getBaseInfo(self,self.modifyW))
        # self.addW.pbGetPrices.clicked.connect(lambda :updateAllToken(self,self.addW))
        self.modifyW.pbGetPrices.clicked.connect(lambda: updateAllToken(self, self.modifyW))

    def createObject(self,fo_contract):

        try:
            self.fo_contract=fo_contract
            refresh(self)
            refresh(self.addW)
            refresh(self.modifyW)
            self.addW.getSymbolList(self.fo_contract)
            self.addW.cbSymbol.setCurrentText('BANKNIFTY')
            self.symbol = self.addW.cbSymbol.currentText()
            self.addW.getOptionExpiryList(self.fo_contract)
            # self.createConnection()
            self.createTimer()
        except:
            print(traceback.print_exc())



    def updateTrade(self, trade, source='on_trade'):
        # print('in update position stretegy')
        if (source == "on_trade"):
            trade1 = trade[0]
        else:
            trade1 = trade
        # print(self.folioName,trade1)

        if (trade1[15] == self.folioName):

            exchange = trade1[20]
            token = trade1[2]
            fltr0 = np.asarray([token])
            filteredArray0 = self.position[np.in1d(self.position[:, 1], fltr0)]
            isRecordExist = False
            if (filteredArray0.size != 0):
                isRecordExist = True

            if (isRecordExist):
                array = self.position[np.where(self.position[:, 1] == token)]
                # print('in is record exist',array)
                prev_qty = array[0][5]
                prev_amt = array[0][8]

                Prev_Dqty = array[0][13]
                Prev_Damt = array[0][14]

                Dqty = Prev_Dqty + trade1[18]
                DAmt = Prev_Damt + trade1[19]

                newQty = prev_qty + trade1[18]
                newAmt = prev_amt + trade1[19]

                self.position[np.where(self.position[:, 1] == token), [5, 8, 13, 14]] = [newQty, newAmt, Dqty, DAmt]

                # print('updated position dekh lo',self.position)
            else:
                new = dt.Frame([[exchange],
                                [token], [trade1[4]], [float(trade1[6])], [trade1[7]], [trade1[18]],
                                [0], [0], [trade1[19]], [trade1[17]], [0.0],
                                [0.0], [0.0], [trade1[18]], [trade1[19]]
                                ]).to_numpy()

                # print('new position dekh lo',self.position,'\n\n\n\n',new,'\n\n\najsgd'
                #
                #       )
                self.position[self.lastSerialNo, :] = new
                self.lastSerialNo += 1
                # print('new position dekh lo',self.position)
            checkIsAnyPosition(self)




    def initVaribles(self):
        self.stype = 'TSpecial'
        self.isStart = False
        self.isClose = False
        self.isFirstOrderPunch = False

        self.isParameterSet = False
        self.isSlHitOnce = False
        self.fullPos = False

        self.SlAmount = 0.0
        self.tsl = 0.0
        self.targetAmt = 0.0
        self.cashPrice = 0.0
        self.futurePrice = 0.0
        self.ATM = 0.0
        self.strikeDiff = 0.0
        self.pairTotal = 0.0
        self.lastOrderPoint = 0

        self.isAnyOpenPos = False
        self.lastSerialNo = 0
        self.lotsize = 0
        self.DOI = datetime.datetime.today().strftime('%d%m%Y')
        self.tokenList = [0,0,0,0,0,0,0]
        """        # tokenlist  
                                0 cashToken  
                                1 futureToken
                                2 ATM CE Token
                                3 ATM PE Token
                                4 HCE Token
                                5 HPE Token
        """

    def hideAddW(self):
        try:
            self.timerUpdateWindows.stop()
            self.timerGetPrices.stop()
            self.addW.hide()
        except:
            print(traceback)


    def hideModifyW(self):
        self.timerUpdateWindows.stop()
        self.timerGetPrices.stop()
        self.modifyW.hide()

    def craeteKeyParameterJson(self,cf):
        craeteKeyParameterJson(self, cf)

    def reloadKeyParameter(self):
        reloadKeyParameter(self)

    def saveJson(self,cf=False):
        saveJson(self,cf)

    def setParameters( self):
        setParameters(self,self.addW)

    def getKeyParameterFile(self,folioName):
        getKeyParameterFile(self,folioName)
    # def getCETable(self,symbol,exp):
    #     getCETable(self,symbol,exp)
    #
    # def getPETable(self,symbol,exp):
    #     getPETable(self,symbol,exp)

    def getBaseInfo(self,window):
        getBaseInfo(self,window)

    def setParametersModify(self,window):
        setParametersModify(self,window)

    def flushTradeData(self):
        self.position = np.zeros((100,11),dtype=object)

    def tradeVarification(self):
        pass

    def updateOrder(self,order,orderDict):
        pass

    def orderVarification(self):
        pass

    def updateWindows(self,feed,window):
        updateWindows(self,feed,window)

    def setAllShortCut(self):
        # print("parthhhhhhhhhhhhh")
        self.addW.leQty.sc_up1 = QShortcut(QKeySequence('Up'),self.addW.leQty)
        self.addW.leQty.sc_up1.setContext(Qt.WidgetWithChildrenShortcut)
        self.addW.leQty.sc_up1.activated.connect(lambda:inc_v(self,self.addW))
        self.addW.leQty.sc_down11= QShortcut(QKeySequence('Down'), self.addW.leQty)
        self.addW.leQty.sc_down11.setContext(Qt.WidgetWithChildrenShortcut)
        self.addW.leQty.sc_down11.activated.connect(lambda :dec_v(self,self.addW))


        self.modifyW.leQty.sc_up2 = QShortcut(QKeySequence('Up'),self.modifyW.leQty)
        self.modifyW.leQty.sc_up2.setContext(Qt.WidgetWithChildrenShortcut)
        self.modifyW.leQty.sc_up2.activated.connect(lambda:inc_v(self,self.modifyW))
        self.modifyW.leQty.sc_down12= QShortcut(QKeySequence('Down'), self.modifyW.leQty)
        self.modifyW.leQty.sc_down12.setContext(Qt.WidgetWithChildrenShortcut)
        self.modifyW.leQty.sc_down12.activated.connect(lambda:dec_v(self,self.modifyW))

    def checkTrade(self ,priceFeed):
        checkTrade(self,priceFeed)



    def checkTarget(self):
        if(self.isSlHitOnce==False ):

            if(self.mtm>=self.targetAmt):
                self.isSlHitOnce = True
                squreOff(self)

                d = {'MTM': self.mtm, 'SlAmount': self.targetAmt}
                self.Slogger.info('Target Trigger (mtm>targetAmt)....', d)


    def checkSL(self):
        if(self.isSlHitOnce==False and self.SlAmount != 0 and self.isStart==True):
            if(self.mtm<=self.SlAmount):
                # print('trgger sl', self.mtm, self.SlAmount)
                self.isSlHitOnce = True
                squreOff(self)
                d = {'MTM': self.mtm, 'SlAmount': self.SlAmount}
                self.Slogger.info('SL Trigger (mtm>Slamt)....', d)
            ####################################################
        # print("SlAmount:,", self.SlAmount)

    def modifyParameter(self):
        # print("hhhhhhyyyyyyyyyyyy"
        try:
            if (self.isFirstOrderPunch == False):
                self.setParametersModify(self.modifyW)

            else:
                print("MODIFY ORDER")
                if (self.modifyW.cxbSL.isChecked()):
                    self.SlAmount = float(self.modifyW.leSLAmount.text())
                    self.sgSL.emit(self.folioName, self.SlAmount)
                    self.modifyW.lb_SlAmount.setText('%.2f' % self.SlAmount)

                if (self.modifyW.cxbTarget.isChecked()):
                    self.targetAmt = float(self.modifyW.leTargetAmount.text())
                    self.modifyW.lb_Target.setText('%.2f' % self.targetAmt)
                    self.sgTarget.emit(self.folioName, self.targetAmt)
            self.hideModifyW()
        except:
            traceback.print_exc()

    def updateMTM(self,data):
        if(self.isAnyOpenPos == True):
            if (data['Token'] in self.position[:,1]):
                fltr0 = np.asarray([data['Token']])
                array = self.position[np.in1d(self.position[:, 1], fltr0)][0]
                # print(array)
                netAmt = array[8]
                ltp = data['LTP']
                qty = array[5]
                mtm = netAmt + (qty * ltp)
                self.position[np.in1d(self.position[:, 1], fltr0),[9,10]] = [ltp,mtm]
                # print(self.position[np.in1d(self.position[:, 1], fltr0)][0])
                total_mtm = np.sum(self.position[:,10])
                self.mtm = total_mtm
                self.sgMTM.emit(self.folioName,total_mtm)
                # print('emited')
                self.modifyW.lbRMTM.setText('%.2f'%total_mtm)
                self.checkSL()
                self.checkTarget()

    def makeFirstOrder(self):
        makeFirstOrder(self)





