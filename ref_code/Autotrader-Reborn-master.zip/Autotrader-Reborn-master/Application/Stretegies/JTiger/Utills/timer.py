from PyQt5.QtCore import QTimer
from Application.Stretegies.JTiger.Utills.executionSupport import updateValues,getPrices

'''
configure timers
'''
def createTimer(self):
    self.timerUpdateWindows = QTimer()
    self.timerUpdateWindows.setInterval(500)
    self.timerUpdateWindows.timeout.connect(lambda : updateValues(self))

    self.timerGetPrices = QTimer()
    self.timerGetPrices.setInterval(500)
    self.timerGetPrices.timeout.connect(lambda : getPrices(self))
