import traceback

import numpy as np
from PyQt5.QtCore import *
from Application.Stretegies.JTiger.Utills.keyParameters import reloadKeyParameter, getKeyParameterFile, saveJson
from Application.Stretegies.JTiger.Utills.executionSupport import *
from PyQt5.QtWidgets import *


def setParameters(self, window):
    try:
        # print("setParm modify called")
        # print(window)
        # self.incrQty = int(window.leIncQty.text())
        self.baseQty = int(window.leQty.text())
        self.maxQty = int(window.leMaxQty.text())
        # print("QTY :::::::::::", self.baseQty)
        if (self.baseQty <= 0 and self.maxQty <= 0):
            self.messageBox = QMessageBox()
            self.messageBox.setIcon(QMessageBox.Critical)
            self.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
            self.messageBox.setText('Quantity must be greater than zero!!')
            self.messageBox.show()
        else:
            # assign values
            self.symbol = window.cbSymbol.currentText()
            self.folioName = window.leFolioName.text()
            self.clientId = window.cbClient.currentText()
            self.expiry = window.cbExp.currentText()
            self.Base = window.cbCF.currentText()
            self.BaseToken = window.BaseToken
            # self.BaseToken = window.BaseToken
            print('setparasymbol', self.symbol)
            self.cashToken = getCashToken(self, self.symbol)
            self.futureToken = getFutureToken(self, self.symbol)
            self.strikeDiff = getStrikeDiff(self, self.futureToken)

            self.cashPrice = self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
            self.futurePrice = self.getPrice(token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
            self.ATM = window.ATM

            self.ceStrikeIndex = window.cbStrike_CE.currentIndex()
            self.peStrikeIndex = window.cbStrike_PE.currentIndex()

            self.slPts = float(window.leSLPoint.text())
            self.trendPts = float(window.leTrendPts.text())
            self.trend = window.cbTrend.currentText()
            self.revPts = float(window.leRevPts.text())

            self.orderSide = window.cbOrderSide.currentText()
            if(self.orderSide == "Buy"):
                self.revOrderSide = "Sell"

            else:
                self.revOrderSide = "Buy"
            self.basePrice = window.basePrice

            self.incrQty = int(window.leIncQty.text())
            self.maxQty = int(window.leMaxQty.text())
            self.qty = self.baseQty
            self.freezeQty = int(self.fo_contract[self.futureToken - 35000, 14])

            self.SlAmount = float(window.leSLAmount.text())
            self.targetAmount = float(window.leTargetAmount.text())
            self.targetAmt = float(window.leTargetAmount.text())
            getKeyParameterFile(self, self.folioName)

            self.ceTable = getCETable(self, self.symbol, self.expiry)
            print("ceTable",self.ceTable)
            self.peTable = getPETable(self, self.symbol, self.expiry)

            # print('StrikeDifferanceeeeee', self.strikeDiff)
            self.ATM = getATM(self, self.cashPrice, self.strikeDiff)

            atmIdx = window.cbStrike_CE.findText('ATM')

            # self.ceStrike = self.ATM + ((self.ceStrikeIndex) * self.strikeDiff)
            self.ceStrike = window.ATM + (window.strikeDiff * (window.cbStrike_CE.currentIndex() - atmIdx))

            # self.peStrike = self.ATM - ((self.peStrikeIndex) * self.strikeDiff)
            self.peStrike = window.ATM - (window.strikeDiff * (window.cbStrike_PE.currentIndex() - atmIdx))


            ####################################################################
            # self.ceStrike = self.ATM + ((self.ceStrikeIndex) * self.strikeDiff)
            # self.peStrike = self.ATM - ((self.peStrikeIndex) * self.strikeDiff)
            ####################################################################


            self.ceToken = self.ceTable[np.where(self.ceTable[:, 12] == self.ceStrike), 2][0][0]
            self.peToken = self.peTable[np.where(self.peTable[:, 12] == self.peStrike), 2][0][0]

            self.cePrice = getPrice(self, token=self.ceToken, seg='NSEFO', streamType=1501)['ltp']
            self.pePrice = getPrice(self, token=self.peToken, seg='NSEFO', streamType=1501)['ltp']

            self.ceHighPrice = self.cePrice
            self.peHighPrice = self.pePrice

            self.ceLowPrice = self.cePrice
            self.peLowPrice = self.pePrice

            self.netQtyCE = 0
            self.netQtyPE = 0

            self.ceLastOrderPunchPrice = 0
            self.peLastOrderPunchPrice = 0
            self.optionType = "call"
            self.baseStrike = self.ATM
            self.heads = ['serialNo',
                          'appOrderId', 'orderTag', 'token', 'optionType', 'orderSide',
                          'strike', 'status', 'orderQty', 'fillQty', 'pendingQty',
                          'avgPrice', 'slPrice', 'tslPrice', 'targetPrice', 'slAOID',
                          'slStatus', 'targetAOID', 'targetLeg', 'targetStatus', 'targetQty',
                          'cpOrderId', 'cpStatus', 'primaryAOID'
                          ]
            # exchange
            self.lastOrderSerialNo = 0
            self.OMS = np.zeros((500, 24), dtype=object)

            self.inactiveOMS = np.zeros((500, 23), dtype=object)
            self.iomslastOrderSerialNo = 0

            self.isParameterSet = True
            updateModifyInfo(self)
            setParametersModifyW(self)
            saveJson(self)
            self.sgParamSet.emit()
    except:
        print(traceback.print_exc())


def setParametersModify(self, window):
    try:
        print("setParm modify called")
        self.baseQty = int(window.leQty.text())
        self.maxQty = int(window.leMaxQty.text())
        print("QTY :::::::::::", self.baseQty)
        if (self.baseQty <= 0 and self.maxQty <= 0):
            self.messageBox = QMessageBox()
            self.messageBox.setIcon(QMessageBox.Critical)
            self.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
            self.messageBox.setText('Quantity must be greater than zero!!')
            self.messageBox.show()
        else:
            # assign values
            self.folioName = window.leFolioName.text()
            self.clientId = window.cbClient.currentText()
            self.symbol = window.cbSymbol.currentText()
            self.expiry = window.cbExp.currentText()
            self.Base = window.cbCF.currentText()
            # self.BaseToken = window.BaseToken

            self.cashToken = getCashToken(self, self.symbol)
            self.futureToken = getFutureToken(self, self.symbol)
            self.strikeDiff = getStrikeDiff(self, self.futureToken)
            self.freezeQty = int(self.fo_contract[self.futureToken - 35000, 14])

            self.lotsize = int(self.fo_contract[self.futureToken - 35000, 11])
            self.BaseToken = window.BaseToken
            self.cashPrice = getPrice(self, token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
            self.futurePrice = getPrice(self, token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
            self.basePrice = window.basePrice

            self.atm_ce_strike = window.cbStrike_CE.currentIndex()
            self.atm_pe_strike = window.cbStrike_PE.currentIndex()

            self.ceStrikeIndex = window.cbStrike_CE.currentIndex()
            self.peStrikeIndex = window.cbStrike_PE.currentIndex()

            self.incrQty = int(window.leIncQty.text())
            self.slPts = float(window.leSLPoint.text())
            self.trendPts = float(window.leTrendPts.text())
            self.orderSide = window.cbOrderSide.currentText()
            self.revPts = float(window.leRevPts.text())
            self.qty = self.baseQty
            # self.strikeDecisionPoint = float(window.leLowerPoint.text())
            self.lhQty = self.baseQty

            self.SlAmount = float(window.leSLAmount.text())
            self.targetAmt = float(window.leTargetAmount.text())
            getKeyParameterFile(self, self.folioName)
            self.lotsize = int(self.fo_contract[self.futureToken - 35000, 11])

            self.ceTable = getCETable(self, self.symbol, self.expiry)
            self.peTable = getPETable(self, self.symbol, self.expiry)
            # print(":", self.ceTable, self.peTable)
            self.ATM = getATM(self, self.cashPrice, self.strikeDiff)
            # print("ATM:", self.ATM)
            self.ceStrike = self.ATM + ((self.ceStrikeIndex) * self.strikeDiff)
            self.peStrike = self.ATM - ((self.peStrikeIndex) * self.strikeDiff)
            # print("strike:", self.ceStrike, self.peStrike)
            self.ceToken = self.ceTable[np.where(self.ceTable[:, 12] == self.ceStrike), 2][0][0]
            self.peToken = self.peTable[np.where(self.peTable[:, 12] == self.peStrike), 2][0][0]
            # print("token:", self.ceToken, self.peToken)
            self.trend = window.leTrend.text()

            self.cePrice = getPrice(self, token=self.ceToken, seg='NSEFO', streamType=1501)['ltp']
            # print("CePrice:",self.cePrice )
            self.pePrice = getPrice(self, token=self.peToken, seg='NSEFO', streamType=1501)['ltp']
            # print("PePrice:",self.pePrice )
            #
            # self.ceHighPrice = self.cePrice
            # self.peHighPrice = self.pePrice
            self.ceLastOrderPunchPrice = 0
            self.peLastOrderPunchPrice = 0

            self.optionType = "call"
            self.orderSide =  window.cbOrderSide.currentIndex()
            # self.optionType = "put"
            self.baseStrike = self.ATM
            self.heads = ['serialNo',
                          'appOrderId', 'orderTag', 'token', 'optionType', 'orderSide',
                          'strike', 'status', 'orderQty', 'fillQty', 'pendingQty',
                          'avgPrice', 'slPrice', 'tslPrice', 'targetPrice', 'slAOID',
                          'slStatus', 'targetAOID', 'targetLeg', 'targetStatus', 'targetQty',
                          'cpOrderId', 'cpStatus', 'primaryAOID'
                          ]
            # exchange
            # self.lastOrderSerialNo = 0
            # self.OMS = np.zeros((500, 24), dtype=object)

            #### Inactive OMS
            # self.inactiveOMS = np.zeros((500, 23), dtype=object)
            # self.iomslastOrderSerialNo = 0
            # setParametersModifyW(self)
            # print("dfff:",self.keyParameterJson)

            # print(" -*******-**----------")
            # print(self.clientId, self.folioName)
            # print(" -*******-**----------")
            # self.isParameterSet = True

            # self.cashPrice = self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
            # self.futurePrice = self.getPrice(token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
            # self.ATM = self.getATM(self.cashPrice, self.strikeDiff)
            updateModifyInfo(self)
            self.sgParamModify.emit()
            saveJson(self)
    except:
        print(traceback.print_exc())