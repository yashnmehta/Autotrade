import os
import threading
import traceback

import json
from PyQt5.QtCore import QObject,QTimer,pyqtSignal
from PyQt5.QtGui import QKeySequence

from Application.Stretegies.JTiger.Utills.squareOff import squreOff
from Application.Stretegies.JTiger.Views.addW import addW
from Application.Stretegies.JTiger.Views.modifyW import modifyW
import numpy as np
import datatable as dt
from Application.Services.Xts.Api.servicesIA import PlaceOrder
import datetime
import time
from Application.Services.Xts.Api.servicesMD import getQuote
from Application.Utils.configReader import refresh
from Application.Stretegies.JTiger.Utills.keyParameters import reloadKeyParameter, getKeyParameterFile, saveJson
from Application.Stretegies.JTiger.Utills.eventsBind import eventsBind
from Application.Stretegies.JTiger.Utills.timer import createTimer
from Application.Stretegies.JTiger.Utills.positionSupport import *
from Application.Stretegies.JTiger.Utills.orderSupport import *
from Application.Stretegies.JTiger.Utills.executionSupport import *
from Application.Stretegies.JTiger.Utills.checkTrade import *
from Application.Stretegies.JTiger.Utills.setParameters import *
from Application.Stretegies.JTiger.Utills.inactiveOMSSupport import *
from Application.Stretegies.JTiger.Utills.strategyOp import addNew

class logic(QObject):
    sgMTM = pyqtSignal(str,float)
    sgSL = pyqtSignal(str, float)
    sgAlert = pyqtSignal(str)
    sgParamSet = pyqtSignal()
    sgParamModify = pyqtSignal()
    sgStart = pyqtSignal()
    sgActivate =pyqtSignal()
    sgStop = pyqtSignal()
    sgClose =pyqtSignal()
    sgFolioOpenPos = pyqtSignal(list)
    sgTarget = pyqtSignal(str, float)
    sgSlPts = pyqtSignal(str, float)
    sgtrendPts = pyqtSignal(str, float)
    sgRevPts = pyqtSignal(str, float)
    ################################# Intialization Here ##################################################
    def __init__(self):
        super(logic, self).__init__()

        self.position = np.zeros((100, 15), dtype=object)
        # print("ffffff",self.position )
        self.posHeads = ['exch',
                         'token', 'symbol', 'strike', 'c/p', 'netqty',
                         'requestedOrder', 'openOrder', 'netamt', 'ltp', 'mtm',
                         'OpenQty', 'OpenAmt', 'DQty', 'Damt']

        self.addW = addW(self)
        self.modifyW = modifyW(self)
        self.setAllShortCut()
        self.initVaribles()

    def flushTradeData(self):
        self.position = np.zeros((100,11),dtype=object)
    def initVaribles(self):
        # print("jtiger ----")
        self.stype = 'JTiger'
        self.isStart = False
        self.isClose = False
        self.isFirstOrderPunch = False
        self.isParameterSet = False
        self.executionRunning =False
        self.isAnyOpenPos = False
        self.lastSerialNo = 0

        self.lastOrderPoint = 0
        self.isSlHitOnce = False
        self.isAnyOpenPos = False
        self.cashPrice = 0.0
        self.futurePrice = 0.0
        self.ATM = 0.0
        self.baseStrike = 0.0
        self.basePrice = 0.0
        self.strikeDiff = 0.0
        self.pairTotal = 0.0
        self.incrQty = 0
        self.baseQty = 0
        self.maxQty = 0
        self.tsl = 0.0
        self.SlAmount = 0
        self.targetAmt = 0

        self.lhQty = 0
        self.mtm = 0.0
        self.lastOrderSerialNo = 0
        self.iomslastOrderSerialNo = 0
        self.OMS = []
        self.inactiveOMS = []

        self.lotsize = 0
        self.DOI = datetime.datetime.today().strftime('%d%m%Y')

        self.tokenList = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        """        # tokenlist  
                            0 cashToken  
                            1 futureToken
                            2 VixToken
                            3 Actual ATM CE
                            4 Actual ATM PE
                            5 OTM CE Token
                            6 OTM PE Token
                            7 ATM CE Token
                            8 ATM PE Token                                
                            9 hedge Token CE
                            10 hedge Token PE


        """
    def setAllShortCut(self):
        # print("parthhhhhhhhhhhhh")
        self.addW.leQty.sc_up = QShortcut(QKeySequence('Up'),self.addW.leQty)
        self.addW.leQty.sc_up.setContext(Qt.WidgetWithChildrenShortcut)
        self.addW.leQty.sc_up.activated.connect(lambda:inc_v(self,self.addW))
        self.addW.leQty.sc_down = QShortcut(QKeySequence('Down'), self.addW.leQty)
        self.addW.leQty.sc_down.setContext(Qt.WidgetWithChildrenShortcut)
        self.addW.leQty.sc_down.activated.connect(lambda :dec_v(self,self.addW))


        self.modifyW.leQty.sc_up = QShortcut(QKeySequence('Up'),self.modifyW.leQty)
        self.modifyW.leQty.sc_up.setContext(Qt.WidgetWithChildrenShortcut)
        self.modifyW.leQty.sc_up.activated.connect(lambda:inc_v(self,self.modifyW))
        self.modifyW.leQty.sc_down = QShortcut(QKeySequence('Down'), self.modifyW.leQty)
        self.modifyW.leQty.sc_down.setContext(Qt.WidgetWithChildrenShortcut)
        self.modifyW.leQty.sc_down.activated.connect(lambda:dec_v(self,self.modifyW))
    #

    def createTimer(self):
        createTimer(self)


    def createObject(self,fo_contract):
        try:
            self.fo_contract=fo_contract

            refresh(self)
            refresh(self.addW)
            refresh(self.modifyW)

            self.addW.getSymbolList(self.fo_contract)
            self.addW.cbSymbol.setCurrentText('BANKNIFTY')
            self.symbol = self.addW.cbSymbol.currentText()
            self.addW.getOptionExpiryList(self.fo_contract)
            eventsBind(self)
            self.createTimer()
        except:
            print(traceback.print_exc())

    def reloadKeyParameter(self):
        try:
            reloadKeyParameter(self)
        except:
            print(traceback.print_exc())

    def checkSL(self):
        # print("checkSLLLLLLLLL")
        if(self.isSlHitOnce==False and self.SlAmount != 0 ):
            if(self.mtm<=self.SlAmount):
                # print('trgger sl', self.mtm, self.SlAmount)
                self.isSlHitOnce = True
                self.squreOff()
                # print("SQureOf Parthhhhhhh!!!! ")
                d = {'MTM': self.mtm, 'SlAmount': self.SlAmount}
                self.Slogger.info('SL Trigger (mtm>Slamt)....', d)

    def checkTarget(self):
        # print("TargetHittt")
        if (self.isSlHitOnce == False):
            # print(" targetAmount", self.targetAmt)

            if (self.mtm >= self.targetAmt):
                self.isSlHitOnce = True
                self.squreOff()

                d = {'MTM': self.mtm, 'SlAmount': self.targetAmount}
                self.Slogger.info('Target Trigger (mtm>targetAmt)....', d)

    def updateMTM(self,data):
        if(self.isAnyOpenPos == True):
            if (data['Token'] in self.position[:,1]):
                fltr0 = np.asarray([data['Token']])
                array = self.position[np.in1d(self.position[:, 1], fltr0)][0]
                # print(array)
                netAmt = array[8]
                ltp = data['LTP']
                qty = array[5]
                mtm = netAmt + (qty * ltp)
                self.position[np.in1d(self.position[:, 1], fltr0),[9,10]] = [ltp,mtm]
                # print(self.position[np.in1d(self.position[:, 1], fltr0)][0])
                total_mtm = np.sum(self.position[:,10])
                self.mtm = total_mtm
                self.sgMTM.emit(self.folioName,total_mtm)
                # print('emited')
                self.modifyW.leRMTM.setText('%.2f'%total_mtm)
                self.checkSL()
                self.checkTarget()

    def setParameters( self):
        setParameters(self,self.addW)

    def setLTP(self, window):
        self.cashPrice = float(window.leLTP.text())
        self.cePrice = float(window.lbCEPrice.text())
        self.pePrice = float(window.lbPEPrice.text())
        # print("cashPrice:", self.cashPrice, "lst order point:", self.lastOrderPoint)

    def modifyParameter(self):
        # print("hhhhhhyyyyyyyyyyyy"
        try:
            if (self.isFirstOrderPunch == False):
                self.setParametersModify(self.modifyW)
                print("modify jtiger!!!!")
            else:
                print("MODIFY ORDER")
                if (self.modifyW.cxbSL.isChecked()):
                    self.SlAmount = float(self.modifyW.leSLAmount.text())
                    self.sgSL.emit(self.folioName, self.SlAmount)
                    self.modifyW.lb_SlAmount.setText('%.2f' % self.SlAmount)

                if (self.modifyW.cxbTarget.isChecked()):
                    self.targetAmt = float(self.modifyW.leTargetAmount.text())
                    self.modifyW.lb_Target.setText('%.2f' % self.targetAmt)
                    self.sgTarget.emit(self.folioName, self.targetAmt)

                if (self.modifyW.cxbSlPts.isChecked()):
                    self.slPts = float(self.modifyW.leSLPoint.text())
                    self.modifyW.leSLPoint.setText('%.2f' % self.slPts)
                    self.sgSlPts.emit(self.folioName, self.slPts)

                if (self.modifyW.cxbTrendPts.isChecked()):
                    self.trendPts = float(self.modifyW.leTrendPts.text())
                    self.modifyW.leTrendPts.setText('%.2f' % self.trendPts)
                    self.sgtrendPts.emit(self.folioName, self.trendPts)

                if (self.modifyW.cxbRevPts.isChecked()):
                    self.revPts = float(self.modifyW.leRevPts.text())
                    self.modifyW.leRevPts.setText('%.2f' % self.revPts)
                    self.sgRevPts.emit(self.folioName, self.revPts)

            self.hideModifyW()
        except:
            traceback.print_exc()

    def setParametersModify(self,window):
        setParametersModify(self,window)

    def saveJson(self, cf = False):
        saveJson(self, cf)
    def getKeyParameterFile(self, folioName):
        getKeyParameterFile(self, folioName)

    def addNew(self, main):
        return addNew(self,main)

    def updateTrade(self, trade, source='on_trade'):

        # print('in update position stretegy,',trade)
        if (source == "on_trade"):
            trade1 = trade[0]
        else:
            trade1 = trade
        # print(" Pairsel  update trade:,",trade1)
        # print(self.folioName, trade1)

        if (trade1[15] == self.folioName):

            exchange = trade1[20]
            token = trade1[2]
            fltr0 = np.asarray([token])
            filteredArray0 = self.position[np.in1d(self.position[:, 1], fltr0)]
            isRecordExist = False
            if (filteredArray0.size != 0):
                isRecordExist = True

            if (isRecordExist):
                array = self.position[np.where(self.position[:, 1] == token)]
                # print('in is record exist',array)
                prev_qty = array[0][5]
                prev_amt = array[0][8]

                Prev_Dqty = array[0][13]
                Prev_Damt = array[0][14]

                Dqty = Prev_Dqty + trade1[18]
                DAmt = Prev_Damt + trade1[19]

                newQty = prev_qty + trade1[18]
                newAmt = prev_amt + trade1[19]

                self.position[np.where(self.position[:, 1] == token), [5, 8, 13, 14]] = [newQty, newAmt, Dqty, DAmt]

                # print('updated position dekh lo',self.position)
            else:
                new = dt.Frame([[exchange],
                                [token], [trade1[4]], [float(trade1[6])], [trade1[7]], [trade1[18]],
                                [0], [0], [trade1[19]], [trade1[17]], [0.0],
                                [0.0], [0.0], [trade1[18]], [trade1[19]]
                                ]).to_numpy()


                self.position[self.lastSerialNo, :] = new
                self.lastSerialNo += 1

            checkIsAnyPosition(self)


            # saveJson(self)





    def tradeVarification(self):
        pass

    def updateOrder(self,order, orderDict):
        pass
        # updateOrder(self, orderDict)

    def orderVarification(self):
        pass


    def makeFirstOrder(self):
        makeFirstOrder(self)

    def checkTrade(self,priceFeed):
        if (self.addW.cbOrderSide.currentText() == 'Buy'):
            checkTradeBuy(self,priceFeed)
        elif (self.addW.cbOrderSide.currentText() == 'Sell'):
            checkTradeSell(self,priceFeed)



    def getPrice(self, token, seg, streamType):
        data = getQuote(self, token, seg, streamType)
        bid = data['AskInfo']['Price']
        ask = data['BidInfo']['Price']
        ltp = data['LastTradedPrice']
        return {"bid": bid, "ask": ask, "ltp": ltp}


    def getExecutionTime(self):
        now = datetime.datetime.today()
        date = now.strftime('%Y-%m-%d ')
        a915 = datetime.datetime.strptime(date + '09:15:00', '%Y-%m-%d %H:%M:%S')
        a920 = datetime.datetime.strptime(date + self.etime, '%Y-%m-%d %H:%M:%S')
        self.timeout1 = int(a920.timestamp()-time.time())*1000
        return self.timeout1



    def getStrikeDiff(self,futureToken):
        # print(self.fo_contract[futureToken-35000,:])
        strikeDiff = self.fo_contract[futureToken-35000,36]
        return strikeDiff

    def hideAddW(self):
        try:
            self.timerUpdateWindows.stop()
            self.addW.hide()
        except:
            print(traceback)
    def hideModifyW(self):
        self.timerUpdateWindows.stop()
        self.modifyW.hide()

    def updateWindows(self, feed,window):

        # print("Window",window)
        priceToken = feed['Token']

        if (window.isParachange == False):
            if (window.visibleRegion().isEmpty() == False):

                if (priceToken == self.tokenList[0]):
                    if (window.cashFut == 'CASH'):
                        window.BaseToken = window.cashToken
                        window.cashPrice = feed['LTP']
                        window.basePrice = window.cashPrice
                        if (self.isFirstOrderPunch == False):
                            ATM = getATM(self, window.basePrice, window.strikeDiff)
                            if (ATM != window.ATM):
                                window.ATM = ATM
                                window.lb_atm.setText(str(window.ATM))
                                window.ATM_CE_Token = getATM_CE_Token(self, window.ATM, window.ceTable)
                                window.ATM_PE_Token = getATM_PE_Token(self, window.ATM, window.peTable)
                                self.tokenList[2] = window.ATM_CE_Token
                                self.tokenList[3] = window.ATM_PE_Token

                        window.lb_ltp.setText(str(window.basePrice))



                elif (priceToken == self.tokenList[1]):
                    if (window.cashFut != 'CASH'):
                        window.BaseToken = window.futureToken
                        window.futurePrice = feed['LTP']
                        window.basePrice = window.futurePrice
                        ATM = getATM(self, window.basePrice, window.strikeDiff)
                        if (self.isFirstOrderPunch == False):
                            if (ATM != window.ATM):
                                window.ATM = ATM
                                window.lb_atm.setText(str(window.ATM))
                                window.ATM_CE_Token = getATM_CE_Token(self, window.ATM, window.ceTable)
                                window.ATM_PE_Token = getATM_PE_Token(self, window.ATM, window.peTable)
                                self.tokenList[2] = window.ATM_CE_Token
                                self.tokenList[3] = window.ATM_PE_Token

                        window.lb_ltp.setText(str(window.basePrice))

                elif (priceToken == self.tokenList[3]):
                    window.CEPrice = feed['LTP']
                    window.lbCEPrice.setText('%.2f' % window.CEPrice)
                    # print("hssssssssssssshhhhhh")
                    if (priceToken == self.tokenList[7]):
                        window.ATMCEPrice = feed['LTP']
                        window.lbATMCE.setText('%.2f' % window.ATMCEPrice)

                elif (priceToken == self.tokenList[4]):
                    window.PEPrice = feed['LTP']
                    window.lbPEPrice.setText('%.2f' % window.PEPrice)
                    if (priceToken == self.tokenList[8]):
                        window.ATMPEPrice = feed['LTP']
                        window.lbATMPE.setText('%.2f' % window.ATMPEPrice)

                elif (priceToken == self.tokenList[7]):
                    window.ATMCEPrice = feed['LTP']
                    window.lbATMCE.setText('%.2f' % window.ATMCEPrice)

                elif (priceToken == self.tokenList[8]):
                    window.ATMPEPrice = feed['LTP']
                    window.lbATMPE.setText('%.2f' % window.ATMPEPrice)

    def getCEPEPrice(self):
        try:
            # print('xyz1')
            data = getQuote(self,self.addW.ATM_CE_Token, 'NSEFO', 1501)
            self.addW.atmCEPrice = data['LastTradedPrice']

            data1 = getQuote(self, self.addW.ATM_PE_Token, 'NSEFO', 1501)
            self.addW.atmPEPrice = data1['LastTradedPrice']
        except:
            print(traceback.print_exc())


    def getPrices(self):
        try:
            th = threading.Thread(target=self.getCEPEPrice,args=())
            th.start()
        except:
            print(traceback.print_exc())

    def getBaseInfo(self, window):
        getBaseInfo(self, window)

    def getBasePrices(self):
        try:
            data = getQuote(self, self.addW.cashToken, 'NSECM', 1501)
            self.addW.cashPrice=data['LastTradedPrice']
            data = getQuote(self, self.addW.futureToken, 'NSEFO', 1501)
            self.addW.futurePrice=data['LastTradedPrice']

            self.addW.ATM = self.getATM(self.addW.cashPrice,self.addW.strikeDiff)

            self.addW.ceTable = self.getCETable(self.addW.symbol,self.addW.expiry)
            self.addW.peTable = self.getPETable(self.addW.symbol,self.addW.expiry)
            self.updateValues()
        except:
            print(traceback.print_exc())

    def flushTradeData(self):
        self.position = np.zeros((100,11),dtype=object)

    def checkShortPosExist(self,array):
        isPos =False
        # print('array',array)
        for i in array[0]:
            if(i < 0):
                isPos = True
                return isPos
        return isPos


    def squreOff(self):
        squreOff(self)
