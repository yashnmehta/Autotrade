# import numpy as np
# def fetchTokenQuantity(self ,token):
#     print("fetchTokenQuantity :  token : ", token, self.position)
#     if (token in self.position[: ,1]):
#         fltr0 = np.asarray([token])
#         array = self.position[np.in1d(self.position[:, 1], fltr0)][0]
#         print("fetchTokenQuantity:",array)
#         qty = array[5]
#         if(qty == None):
#             qty = 0
#         print("qty : ", qty)
#         return qty
#     else:
#         return 0

# def fetchToken(table,strike):
#     return table[np.where(table[:, 12] == strike), 2][0][0]

