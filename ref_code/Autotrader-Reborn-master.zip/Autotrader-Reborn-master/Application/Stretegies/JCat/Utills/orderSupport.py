import sys
from Application.Services.Xts.Api.servicesIA import PlaceOrder, modifyOrder
import time as ttime
from Application.Stretegies.JCat.Utills.keyParameters import  saveJson
from Application.Stretegies.JCat.Utills.executionSupport import *
from Application.Stretegies.JCat.Utills.OMSSupport import *
from Application.Stretegies.JCat.Utills.inactiveOMSSupport import *

def makeOrder(self,token,qty,orderSide, orderType  = 'MARKET', limitPrice = 0.0, triggerPrice = 0 ):
    print('makeOrder',token,qty,orderSide)
    try:
        appOrderIdList = []
        # print('AppOrderList',appOrderIdList)
        while qty > self.freezeQty:
            appOrderId = PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=token, orderSide=orderSide,
                       qty=self.freezeQty,
                       limitPrice=limitPrice,
                       validity='DAY', disQty=0, triggerPrice=triggerPrice, uid=self.folioName, orderType=orderType,
                       productType='NRML')

            # need to add in OMS
            appOrderIdList.append(appOrderId)
            ttime.sleep(0.1)
            qty -= self.freezeQty
        appOrderId = PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=token, orderSide=orderSide,
                   qty=qty,
                   limitPrice=limitPrice,
                   validity='DAY', disQty=0, triggerPrice=triggerPrice, uid=self.folioName, orderType=orderType,
                   productType='NRML')
        # need to add in OMS
        appOrderIdList.append(appOrderId)
        ttime.sleep(0.1)
        # print("makeOrder Done")
        return appOrderIdList
    except:
        print(traceback.print_exc())
def makeFirstOrder(self):
    try:

        # print('self.isFirstOrderPunch',self.isFirstOrderPunch)
        if(self.isFirstOrderPunch==False):
            # print('self.isFirstOrderPunch 2', self.trend)

            makeOrder(self,self.ceToken,self.baseQty,self.orderSide)

            # self.ceLastOrderPunchPrice = getPrice(self, token=self.ceToken, seg='NSECM', streamType=1501)['ltp']
            self.ceLastOrderPunchPrice = self.cePrice
            # print("First  order punched cePrice : ", self.cePrice)
            # print("pePrice : ", self.pePrice)
            self.optionType = "call"
            self.sgStart.emit()
            self.isStart = True
            self.isFirstOrderPunch = True
            self.baseStrike = self.ATM
            # self.lastOrderPoint = self.cashPrice
            # print("self.lastOrderPoint = self.cashPrice:", self.lastOrderPoint ,self.cashPrice)
            # print("OMS:", self.OMS[0],self.OMS[1])
            setParametersModifyW(self)
            saveJson(self)
            # self.Slogger.info('First Order Placed Successfully..')
    except:
        self.Slogger.error(sys.exc_info()[1])
