
from Application.Stretegies.JCat.Utills.orderSupport import *


def squreOff(self):
    # print("Squre off donehhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh")
    for i in self.position:
        token = i[1]
        exchange = i[0]
        quantity = i[5]

        if (quantity == 0):
            pass
        elif quantity > 0:
            absQuantity = abs(quantity)
            while (absQuantity > self.freezeQty):
                # print('if while')
                PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Sell',
                           qty=self.freezeQty,
                           limitPrice=0.0,
                           validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                           productType='NRML')
                time.sleep(0.1)
                absQuantity -= self.freezeQty
            PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Sell',
                       qty=absQuantity,
                       limitPrice=0.0,
                       validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                       productType='NRML')
            time.sleep(0.1)
        else:

            absQuantity = abs(quantity)
            while (absQuantity > self.freezeQty):
                print('else while')
                PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Buy',
                           qty=self.freezeQty,
                           limitPrice=0.0,
                           validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                           productType='NRML')
                time.sleep(0.1)
                absQuantity -= self.freezeQty
            PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Buy',
                       qty=absQuantity,
                       limitPrice=0.0,
                       validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                       productType='NRML')

            time.sleep(0.1)