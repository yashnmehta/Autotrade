
import numpy as np
import traceback
from Application.Services.Xts.Api.servicesMD import getQuote, subscribeToken
import datetime, time
import threading

def getBaseInfo(self,window):
    # print('in get info TSpeciallllll')
    window.symbol = window.cbSymbol.currentText()
    window.expiry = window.cbExp.currentText()
    # window.orderSide = window.cbOrderSide.currentText()

    window.cashToken = getCashToken(self,window.symbol)
    self.tokenList[0] =  window.cashToken
    subscribeToken(self,window.cashToken,'NSECM')

    window.cashFut = window.cbCF.currentText()

    window.futureToken = getFutureToken(self,window.symbol)
    self.tokenList[1] = window.futureToken
    subscribeToken(self,window.futureToken,'NSEFO')

    data = getQuote(self, window.cashToken, 'NSECM', 1501)
    window.cashPrice = data['LastTradedPrice']
    data = getQuote(self, window.futureToken, 'NSEFO', 1501)
    window.futurePrice = data['LastTradedPrice']

    if(window.cashFut == 'CASH'):
        window.BaseToken = window.cashToken
        window.basePrice = window.cashPrice
    else:
        window.BaseToken = window.futureToken
        window.basePrice = window.futurePrice

    window.strikeDiff = getStrikeDiff(self,window.futureToken)
    window.lotsize = getLotSize(self,window.futureToken)
    print('lot size',window.lotsize)
    window.ATM = getATM(self,window.basePrice, window.strikeDiff)

    # print('window.ATM',window.ATM)

    window.ceTable = getCETable(self,window.symbol, window.expiry)
    window.peTable = getPETable(self,window.symbol, window.expiry)

    window.lb_ltp.setText(str(window.basePrice))
    window.lb_atm.setText(str(window.ATM))

    # print('window.ceTable',window.ceTable)

    window.CE_Token_A = getATM_CE_Token(window, window.ATM ,window.ceTable)
    window.PE_Token_A = getATM_PE_Token(window, window.ATM, window.peTable)
    subscribeToken(self,window.ATM_CE_Token,'NSEFO')
    subscribeToken(self,window.ATM_PE_Token,'NSEFO')

    self.tokenList[3] = window.CE_Token_A
    self.tokenList[4] = window.PE_Token_A

    data = getQuote(self, window.CE_Token_A, 'NSEFO', 1501)
    window.ACEP = data['LastTradedPrice']

    data1 = getQuote(self, window.PE_Token_A, 'NSEFO', 1501)
    window.APEP = data1['LastTradedPrice']

    window.lbCEPrice.setText('%.2f' % window.ACEP)
    window.lbPEPrice.setText('%.2f' % window.APEP)

    ceStrikeIndex = window.ATM + (window.strikeDiff * window.cbStrike_CE.currentIndex())
    peStrikeIndex = window.ATM - (window.strikeDiff * window.cbStrike_PE.currentIndex())


    # window.ceStrikeIndex = window.cbStrike_CE.currentIndex()
    # window.peStrikeIndex = window.cbStrike_PE.currentIndex()

    window.ATM_CE_Token = getATM_CE_Token(window, ceStrikeIndex, window.ceTable)
    window.ATM_PE_Token = getATM_PE_Token(window, peStrikeIndex, window.peTable)
    #
    # window.ATM_CE_Token = getATM_CE_Token(self,window.ATM, window.ceTable)
    # window.ATM_PE_Token = getATM_PE_Token(self,window.ATM, window.peTable)

    self.tokenList[7] = window.ATM_CE_Token
    self.tokenList[8] = window.ATM_PE_Token

    data = getQuote(self, window.ATM_CE_Token, 'NSEFO', 1501)
    window.atmCEPrice = data['LastTradedPrice']

    data1 = getQuote(self, window.ATM_PE_Token, 'NSEFO', 1501)
    window.atmPEPrice = data1['LastTradedPrice']

    window.lbATMCE.setText('%.2f' % window.atmCEPrice)
    window.lbATMPE.setText('%.2f' % window.atmPEPrice)
    diffP = window.ATM - window.cashPrice


    window.isParachange = False

def updateATMCEToken(self,window):
    atmIdx = window.cbStrike_CE.findText('ATM')
    ATMStrike_CE = window.ATM + (window.strikeDiff * (window.cbStrike_CE.currentIndex() - atmIdx))

    # ATMStrike_CE = window.ATM +  (window.strikeDiff * window.cbStrike_CE.currentIndex())
    window.ATM_CE_Token = getATM_CE_Token(window,ATMStrike_CE,window.ceTable)
    self.tokenList[7] =window.ATM_CE_Token
    data1 = getQuote(self, window.ATM_CE_Token, 'NSEFO', 1501)
    window.ATMPrice_CE = data1['LastTradedPrice']
    window.lbATMCE.setText('%.2f'%window.ATMPrice_CE)
    # recalculateATMQtyONSC(self,window)


def updateATMPEToken(self,window):
    atmIdx = window.cbStrike_CE.findText('ATM')
    ATMStrike_PE = window.ATM - (window.strikeDiff * (window.cbStrike_PE.currentIndex() - atmIdx))

    # ATMStrike_PE = window.ATM -  (window.strikeDiff * window.cbStrike_PE.currentIndex())
    window.ATM_PE_Token = getATM_PE_Token(window,ATMStrike_PE,window.peTable)
    self.tokenList[8] =window.ATM_PE_Token
    data1 = getQuote(self, window.ATM_PE_Token, 'NSEFO', 1501)
    window.ATMPrice_PE = data1['LastTradedPrice']
    window.lbATMPE.setText('%.2f'%window.ATMPrice_PE)
    # recalculateATMQtyONSC(self,window)

def updateModifyInfo(self):
    self.modifyW.leFolioName.setText(self.folioName)
    self.modifyW.cbClient.setCurrentText(self.clientId)
    self.modifyW.cbSymbol.setCurrentText(self.symbol)
    self.modifyW.cbCF.setCurrentText(self.Base)
    self.modifyW.cbExp.setCurrentText(self.expiry)


    self.modifyW.ceTable = self.ceTable
    self.modifyW.peTable = self.peTable


    self.modifyW.strikeDiff = self.strikeDiff
    self.modifyW.lotsize = self.lotsize
    # self.modifyW.freezeQty = self.freezeQty
    # print("freezeQty",self.modifyW.freezeQty )

    self.modifyW.ATM = self.ATM
    # self.modifyW.hedgeStrike = self.hedgeStrike

    self.modifyW.symbol = self.symbol
    self.modifyW.expiry = self.expiry
    self.modifyW.cashFut = self.Base

    self.modifyW.cashToken = self.cashToken
    self.modifyW.futureToken = self.futureToken

    self.modifyW.BaseToken = self.BaseToken
    self.modifyW.cashPrice =self.cashPrice
    self.modifyW.futurePrice =self.futurePrice
    self.modifyW.basePrice =self.basePrice

    self.modifyW.cbStrike_CE.setCurrentIndex(self.ceStrikeIndex)
    self.modifyW.cbStrike_PE.setCurrentIndex(self.ceStrikeIndex)

    self.modifyW.cbSymbol.setCurrentText(self.symbol)
    self.modifyW.cbCF.setCurrentText(self.Base)

    self.modifyW.cbTrend.setCurrentText(self.trend)
    self.modifyW.cbOrderSide.setCurrentText(self.orderSide)

    self.modifyW.lb_ltp.setText(self.addW.lb_ltp.text())
    self.modifyW.lb_atm.setText(self.addW.lb_atm.text())

    self.modifyW.ATM = self.ATM
    #
    # self.modifyW.ATM_CE_Token = self.ATM_CE_Token
    # self.modifyW.ATM_PE_Token = self.ATM_PE_Token

    self.modifyW.ATM_CE_Token = getATM_CE_Token(self,self.ATM,self.ceTable)
    self.modifyW.ATM_PE_Token = getATM_PE_Token(self,self.ATM,self.peTable)



def getCETable(self,symbol,exp):

    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    fltr1 = np.asarray([exp])
    filteredarray2 = filteredarray[np.in1d(filteredarray[:, 6], fltr1)]

    filteredarray1 = filteredarray2[filteredarray2[:, 12].argsort()]
    fltr2 = np.asarray(['CE'])
    ceTable= filteredarray1[np.in1d(filteredarray1[:, 8], fltr2)]

    return ceTable


def getPETable(self,symbol,exp):
    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    fltr1 = np.asarray([exp])
    filteredarray2 = filteredarray[np.in1d(filteredarray[:, 6], fltr1)]
    filteredarray1 = filteredarray2[filteredarray2[:, 12].argsort()][::-1]
    fltr2 = np.asarray(['PE'])
    peTable= filteredarray1[np.in1d(filteredarray1[:, 8], fltr2)]
    return peTable

def getATM_CE_Token(self,atm,ceTable):
    ATM_CE_Token = ceTable[np.where(ceTable[:,12]==atm),2][0][0]
    return ATM_CE_Token

def getATM_PE_Token(self,atm,peTable):
    ATM_PE_Token = peTable[np.where(peTable[:,12]==atm),2][0][0]
    return ATM_PE_Token


def dec_v(self,window):
    if (window.leQty.text() != '0'):
        newQ = int(window.leQty.text()) - window.lotsize

        window.leQty.setText(str(newQ))

def inc_v(self,window):
    # print('in inc_v',window.lotsize)

    newQ = int(window.leQty.text()) + window.lotsize
    window.leQty.setText(str(newQ))


def getCEList(self,ATMStrike):
    lowerRange= ATMStrike - ((self.lowerRangeIndex+1) *self.strikeDiff)
    upperRange= ATMStrike + ((self.upperRangeIndex+1) *self.strikeDiff)
    array1 = self.ceTable[np.where(self.ceTable[:, 12] >= lowerRange)]
    array2 = array1[np.where(array1[:, 12] <= upperRange)]
    array3 = array2[:, [2, 8, 12]]
    return array3

def getPEList(self,ATMStrike):
    lowerRange= ATMStrike - ((self.lowerRangeIndex+1) *self.strikeDiff)
    upperRange= ATMStrike + ((self.upperRangeIndex+1) *self.strikeDiff)
    array1 = self.peTable[np.where(self.peTable[:, 12] >= lowerRange)]
    array2 = array1[np.where(array1[:, 12] <= upperRange)]
    array3 = array2[:, [2, 8, 12]]
    # print(array3)
    return array3

def getExecutionTime(self):
    now = datetime.datetime.today()
    date = now.strftime('%Y-%m-%d ')
    a915 = datetime.datetime.strptime(date + '09:15:00', '%Y-%m-%d %H:%M:%S')
    a920 = datetime.datetime.strptime(date + self.etime, '%Y-%m-%d %H:%M:%S')
    self.timeout1 = int(a920.timestamp()- time.time())*1000
    return self.timeout1

def getFutureToken(self,symbol=''):
    futureToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 17]
    return futureToken


def getCashToken(self,symbol=''):
    print('symbo',symbol)

    assetToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 9]
    print('sss',assetToken)
    return assetToken

def checkIsAnyPosition(self):
    isAnyOpenPos = False
    for i in self.position[:self.lastSerialNo,5]:
        if(i != 0):
            isAnyOpenPos = True
            self.isAnyOpenPos = isAnyOpenPos

            return
    self.isAnyOpenPos = isAnyOpenPos

def updateValues(self):
    try:
        if(self.isFirstOrderPunch):
            window = self.modifyW
            # window.lb_hedge_prc.setText('%.2f' % window.hedgeOptPrc)

        elif(self.isParameterSet):
            window = self.modifyW
            # window.lb_hedge_Prc.setText('%.2f' % window.hedgeOptPrc)

        else:
            window= self.addW

        window.lb_ltp.setText(str(window.cashPrice))
        window.lb_atm.setText(str(window.ATM))

        window.lbATMCE.setText('%.2f' % window.atmCEPrice)
        window.lbATMPE.setText('%.2f' % window.atmPEPrice)

        window.lbCEPrice.setText('%.2f' % window.atmCEPrice)
        window.lbPEPrice.setText('%.2f' % window.atmPEPrice)

    except:
        print(traceback.print_exc())
def getLotSize(self,futureToken):
    lotsize = self.fo_contract[futureToken-35000,11]
    return lotsize
    print("lotsize:",lotsize)


def getCEPEPrice(self):
    try:
        # print("(self.isFirstOrderPunch)",self.isFirstOrderPunch)
        # print("(self.isParameterSet)", self.isParameterSet)
        if (self.isFirstOrderPunch):
            window = self.modifyW
            a='modify'
        elif (self.isParameterSet):
            window = self.modifyW
            a='modify'

        else:
            window = self.addW
            a='add'

        if (window.visibleRegion().isEmpty() == False):

            window.cashPrice = getPrice(self=self, token=window.cashToken, seg='NSECM', streamType=1501)['ltp']
            window.futurePrice = getPrice(self=self, token=window.futureToken, seg='NSEFO', streamType=1501)['ltp']
            window.ATM = getATM(self, window.cashPrice, window.strikeDiff)

            data = getQuote(self,window.ATM_CE_Token, 'NSEFO', 1501)
            window.atmCEPrice = data['LastTradedPrice']

            data1 = getQuote(self, window.ATM_PE_Token, 'NSEFO', 1501)
            window.atmPEPrice = data1['LastTradedPrice']
           # print('xyz2')
    except:
        print(traceback.print_exc())


def getStrikeDiff(self,futureToken):
    # print(self.fo_contract[futureToken-35000,:])
    strikeDiff = self.fo_contract[futureToken-35000,36]
    # print('strikeDiff',strikeDiff)
    return strikeDiff


def getATM(self,cashPrice,strikeDiff):
    # print("cAsh And StrDiff",cashPrice,strikeDiff)
    ATM1 = (cashPrice / strikeDiff)
    # print((cashPrice / strikeDiff))
    frac = ATM1 % 1
    # ** NOTE  : need to chge below
    strikeDecisionPoint = 0.5 #float(self.addW.leLowerPoint.text())
    # print(frac)
    if(frac > strikeDecisionPoint):
        ATM = int(ATM1+1) * strikeDiff
    else:
        ATM= int(ATM1)  * strikeDiff
    # ATM1 = (cashPrice / strikeDiff) * strikeDiff
    return ATM

def getPrice(self, token, seg, streamType):

    data = getQuote(self, token, seg, streamType)
    # print('dataaaa:',data)
    ltp = data['LastTradedPrice']
    try:
        bid = data['AskInfo']['Price']
        ask = data['BidInfo']['Price']
    except:
        bid = 0.00
        ask = 0.00
    return {"bid": bid, "ask": ask, "ltp": ltp}
def getPrices(self):
    try:
        th = threading.Thread(target=getCEPEPrice,args=(self,))
        th.start()
    except:
        print(traceback.print_exc())

def setParametersModifyW(self):
    try:


        self.modifyW.folioName = self.addW.leFolioName.text()
        self.modifyW.clientId = self.addW.cbClient.currentText()
        self.modifyW.symbol = self.addW.cbSymbol.currentText()
        self.modifyW.expiry = self.addW.cbExp.currentText()

        self.modifyW.cashToken = getCashToken(self, self.symbol)
        self.modifyW.futureToken = getFutureToken(self, self.symbol)
        self.modifyW.strikeDiff = getStrikeDiff(self, self.futureToken)
        self.modifyW.freezeQty = int(self.fo_contract[self.futureToken - 35000, 14])

        # print('freezeQty',self.freezeQty)

        self.modifyW.ceTable = getCETable(self, self.symbol, self.expiry)
        self.modifyW.peTable = getPETable(self, self.symbol, self.expiry)
        self.modifyW.cashPrice = getPrice(self, token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
        self.modifyW.futurePrice = getPrice(self, token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']

        self.modifyW.ATM = getATM(self, self.cashPrice, self.strikeDiff)

        self.modifyW.ceToken = getATM_CE_Token(self, self.ATM, self.ceTable)
        self.modifyW.peToken = getATM_PE_Token(self, self.ATM, self.peTable)
        self.modifyW.ATM_PE_Token = self.modifyW.ceToken
        self.modifyW.ATM_CE_Token = self.modifyW.peToken

        self.modifyW.cbSymbol.addItem(self.symbol)
        self.modifyW.cbExp.addItem(self.expiry)
        self.modifyW.leFolioName.setText(self.folioName)
        self.modifyW.cbClient.addItem(self.clientId)
        self.modifyW.leQty.setText(str(self.baseQty))
        self.modifyW.leMaxQty.setText(str(self.maxQty))
        self.modifyW.leIncQty.setText(str(self.incrQty))
        self.modifyW.leSLAmount.setText(str(self.SlAmount))
        self.modifyW.leTargetAmount.setText(str(self.targetAmt))

        self.modifyW.lb_atm.setText(self.addW.lb_atm.text())
        self.modifyW.lbCEPrice.setText(str(self.addW.cePrice))
        self.modifyW.lbPEPrice.setText(str(self.addW.pePrice))

        self.modifyW.cbStrike_CE.setCurrentIndex(self.ceStrikeIndex)
        self.modifyW.cbStrike_PE.setCurrentIndex(self.peStrikeIndex)

        self.modifyW.leSLPoint.setText(str(self.slPts))
        self.modifyW.leTrendPts.setText(str(self.trendPts))
        self.modifyW.leRevPts.setText(str(self.revPts))

        self.modifyW.SlAmount = float(self.addW.leSLAmount.text())
        self.modifyW.targetAmount = float(self.addW.leTargetAmount.text())


    except:
        print(traceback.print_exc())
