
from Application.Stretegies.JCat.Utills.keyParameters import reloadKeyParameter, getKeyParameterFile, saveJson
from Application.Stretegies.JCat.Utills.positionSupport import *
from Application.Stretegies.JCat.Utills.orderSupport import *
from Application.Stretegies.JCat.Utills.executionSupport import *
from Application.Stretegies.JCat.Utills.positionSupport import *
from Application.Services.Xts.Api.servicesIA import PlaceOrder, modifyOrder
def checkTradeBuy(self, priceFeed):
    try:
        if (self.isStart):
            priceToken = priceFeed['Token']
            if (self.ceToken == priceToken):
                self.cePrice = priceFeed['LTP']
                if(self.ceHighPrice < self.cePrice):
                    self.ceHighPrice = self.cePrice
            elif (self.peToken == priceToken):
                self.pePrice = priceFeed['LTP']
                if (self.peHighPrice < self.pePrice):
                    self.peHighPrice = self.pePrice

            if(self.optionType == 'call'):
                if(self.ceHighPrice - self.cePrice >= self.slPts):
                    print('checkTradeBuy 1')
                    # print("self.ceHighPrice - self.cePrice >= self.slPts:",self.ceHighPrice - self.cePrice,self.slPts)
                    makeOrder(self,self.ceToken,self.qty,self.revOrderSide)
                    makeOrder(self, self.peToken, self.baseQty, self.orderSide)
                    self.qty = self.baseQty
                    self.optionType = "put"
                    self.peLastOrderPunchPrice = self.pePrice
                    self.peHighPrice = self.pePrice
                    # print('qty',self.qty, self.baseQty, self.incrQty,self.maxQty)
                if(self.cePrice - self.ceLastOrderPunchPrice >= self.trendPts):

                    # print("self.cePrice - self.ceLastOrderPunchPrice >= self.trendPts:",self.cePrice - self.ceLastOrderPunchPrice , self.trendPts)
                    if(self.qty + self.incrQty <= self.maxQty):
                        print('checkTradeBuy 2')
                        # print("qty :", self.qty)
                        makeOrder(self, self.ceToken, self.incrQty,self.orderSide)
                        self.qty = self.qty + self.incrQty
                        # add new quantity in call
                        self.ceLastOrderPunchPrice = self.cePrice
                        # print('qty', self.qty, self.baseQty, self.incrQty, self.maxQty)
                # print("---------------------------------------------------")
            elif(self.optionType == 'put'):
                # print(" #### put")
                if (self.peHighPrice - self.pePrice >= self.slPts):
                    print('checkTradeBuy 3')
                    # print("self.peHighPrice - self.pePrice >= self.slPts :",self.peHighPrice - self.pePrice, self.slPts)
                    makeOrder(self, self.peToken, self.qty, self.revOrderSide)
                    makeOrder(self, self.ceToken, self.baseQty, self.orderSide)
                    self.qty = self.baseQty
                    self.optionType = "call"
                    self.ceLastOrderPunchPrice = self.cePrice
                    self.ceHighPrice = self.cePrice
                    # print('qty', self.qty, self.baseQty, self.incrQty, self.maxQty)
                if (self.pePrice - self.peLastOrderPunchPrice >= self.trendPts):
                    # print("self.pePrice - self.peLastOrderPunchPrice >= self.trendPts:", self.pePrice - self.peLastOrderPunchPrice, self.trendPts)
                    if (self.qty + self.incrQty <= self.maxQty):
                        print('checkTradeBuy 4')

                        makeOrder(self, self.peToken, self.incrQty, self.orderSide)
                        self.qty = self.qty + self.incrQty
                        self.peLastOrderPunchPrice = self.pePrice
                        # print('qty', self.qty, self.baseQty, self.incrQty, self.maxQty)
    except:
        print(traceback.print_exc())
# print("----------------------CE & PE high price-----------------------------", self.ceHighPrice,self.peHighPrice,self.ceLastOrderPunchPrice,self.peLastOrderPunchPrice,self.ceToken, self.peToken)

###################################################################################################################################################################################################


def checkTradeSell(self, priceFeed):
    # print("Enter in Sell Order")
    # self.updateWindows(priceFeed, self.modifyW)
    try:
        if (self.isStart):
            priceToken = priceFeed['Token']
            if (self.ceToken == priceToken):
                self.cePrice = priceFeed['LTP']
                if (self.ceLowPrice > self.cePrice):
                    self.ceLowPrice = self.cePrice
            elif (self.peToken == priceToken):
                self.pePrice = priceFeed['LTP']
                if (self.peLowPrice > self.pePrice):
                    self.peLowPrice = self.pePrice

        if(self.optionType == 'call'):
            # print(" #### CALL")
            if(self.cePrice - self.ceLowPrice  >= self.slPts):
                print('checkTradesell 1')
                makeOrder(self,self.ceToken,self.qty,self.revOrderSide)
                makeOrder(self, self.peToken, self.baseQty, self.orderSide)
                self.qty = self.baseQty
                self.optionType = "put"
                self.peLastOrderPunchPrice = self.pePrice
                self.peLowPrice = self.pePrice
                print('qty',self.qty, self.baseQty, self.incrQty,self.maxQty)
            if( self.ceLastOrderPunchPrice - self.cePrice  >= self.trendPts):
                print('checkTradesell 1')
                if(self.qty + self.incrQty <= self.maxQty):
                    self.qty = self.qty + self.incrQty
                    print("qty :", self.qty)
                    makeOrder(self, self.ceToken, self.incrQty, self.orderSide)
                # add new quantity in call
                    self.ceLastOrderPunchPrice = self.cePrice
                    print('qty', self.qty, self.baseQty, self.incrQty, self.maxQty)
            # print("---------------------------------------------------")
        elif(self.optionType == 'put'):
            # print(" #### put")
            if ( self.pePrice - self.peLowPrice  >= self.slPts):
                print('checkTradesell 1')
                makeOrder(self, self.peToken,self.qty, self.revOrderSide)
                makeOrder(self, self.ceToken, self.baseQty, self.orderSide)
                self.qty = self.baseQty
                self.optionType = "call"
                self.ceLastOrderPunchPrice = self.cePrice
                self.ceLowPrice = self.cePrice
                print('qty', self.qty, self.baseQty, self.incrQty, self.maxQty)
            if (self.pePrice - self.peLastOrderPunchPrice >= self.trendPts):
                print('checkTradesell 1')
                if (self.qty + self.incrQty <= self.maxQty):
                    self.qty = self.qty + self.incrQty
                    makeOrder(self, self.peToken, self.incrQty, self.orderSide)
                    self.peLastOrderPunchPrice = self.pePrice
                    # print('qty', self.qty, self.baseQty, self.incrQty, self.maxQty)
    except:
        print(traceback.print_exc())

# def getOrderQty(self, token):
#     ind = abs(self.baseStrike - self.ATM)/self.strikeDiff
#     # print("ind:", ind, "baseQty:", self.baseQty)
#     initOQty = self.baseQty + (ind * self.incrQty)
#     # print("initOQty:", initOQty, "lhQty:", self.lhQty)
#     if(initOQty>self.maxQty):
#         initOQty = self.maxQty
#     elif(initOQty<self.lhQty):
#         initOQty = self.lhQty
#     else:
#         self.lhQty = initOQty
#
#     # print("after init qty:", initOQty)
#
#     existingQty = abs(fetchTokenQuantity(self, token))
#     # print("existingQty:", existingQty)
#     return  initOQty - existingQty