import logging
import sys
import traceback
from os import path, getcwd
import threading
import time
import requests
import json
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import uic
import qdarkstyle
import qtpy
from Application.Utils.configReader import *
from Application.Views.titlebar import tBar
from Theme.dt2 import  dt1
import platform
import numpy as np
from Application.Services.Xts.Api.servicesMD import getQuote



class modifyW(QMainWindow):
    sgGetFolioBook=pyqtSignal(str,str)
    def __init__(self, parent= None):
        super(modifyW, self).__init__(parent=None)
        self.setObjectName('addParameter')

        #####################################################################

        loc1 = getcwd().split('Application')
        # print(loc1)
        ui_login = os.path.join(loc1[0] ,'Application','Stretegies','ValSpread','UI','modify.ui')
        uic.loadUi(ui_login, self)
        dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()


        self.setStyleSheet(dt1)
        QSizeGrip(self.modifyGrip)
        osType = platform.system()

        if (osType == 'Darwin'):
            flags = Qt.WindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        else:
            flags = Qt.WindowFlags(Qt.SubWindow | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setWindowFlags(flags)
        self.pbCancel.clicked.connect(self.hide)

        self.title = tBar('MODIFY PARAMETER')
        self.headerFrame.layout().addWidget(self.title, 0, 0)
        self.title.sgPoss.connect(self.movWin)
        self.updateValues()
        self.connectAllSlots()
        # self.movWin()
        self.isParachange = True

        self.createShortcuts()



        self.shortcut_FB = QShortcut(QKeySequence('F11'), self)
        self.shortcut_FB.activated.connect(self.requestFolioBook)



    def requestFolioBook(self):
        # print('abcd')
        self.sgGetFolioBook.emit(self.leFolioName.text(),self.cbClient.currentText())




    def updateValues(self):
        # print('ppp modify')
        if (self.visibleRegion().isEmpty() == False):
            self.lb_ltp.setText(str(self.basePrice))
            self.lb_atm.setText(str(self.ATM))

            self.lbOTMPrc.setText('%.2f' % self.OTMPrice)

            self.lbATMPrc.setText('%.2f' % self.ATMPrice)

            self.lb_CEP.setText('%.2f' % self.atmCEPrice)
            self.lb_PEP.setText('%.2f' % self.atmPEPrice)

            # print('abc')
            if (self.leQty_O.text() != '' and self.leQty_A.text() != ''):
                # print('xyz')

                OTMQty = float(int(self.leQty_O.text()))
                ATMQty = int(self.leQty_A.text())

                OTMPrem = self.OTMPrice * OTMQty
                ATMPrem = self.ATMPrice * ATMQty

                self.lbOTM_Prem.setText('%.2f' % OTMPrem)
                self.lbATM_Prem.setText('%.2f' % ATMPrem)

    def movWin(self, x, y):
        self.move(self.pos().x() + x, self.pos().y() + y)

    def connectAllSlots(self):
        self.bt_close.clicked.connect(self.hide)
        self.bt_min.clicked.connect(self.hide)

    def createShortcuts(self):
        self.quitSc = QShortcut(QKeySequence('Esc'), self)
        self.quitSc.activated.connect(self.hide)

    def getOptionExpiryList(self,fo_contract):
        symbol = self.cbSymbol.currentText()
        fltr = np.asarray([symbol])
        filteredarray = fo_contract[np.in1d(fo_contract[:, 3], fltr)]
        uniqueExp = np.unique(filteredarray[:,6])
        self.cbExp.addItems(uniqueExp)

    def getStrikePriceList(self,fo_contract):
        symbol = self.cbSymbol.currentText()
        fltr = np.asarray([symbol])
        filteredarray = fo_contract[np.in1d(fo_contract[:, 3], fltr)]
        fltr1 = np.asarray(['OPTSTK','OPTIDX'])

        filteredarray1 = filteredarray[np.in1d(filteredarray[:, 5], fltr1)]
        exp = self.cbExp.currentText()

        fltr2 = np.asarray([exp])
        filteredarray2 = filteredarray1[np.in1d(filteredarray1[:, 6], fltr2)]

        uniqueStrike = np.unique(filteredarray2[:,7])
        self.cbStrikePrice.addItems(uniqueStrike)


    def getContractFO(self,fo_contract):
        self.contractFo = fo_contract

    #
    # def getPairTotal(self):
    #     atmCeTOken = 0
    #     atmPeTOken = 0
    #     atmCePrice = 0
    #     atmPePrice = 0
    #     pairTotal = atmCePrice + atmPePrice
    #     return pairTotal
    #
    #
    # # def getPrice(self,token,seg,streamType):
    # #     try:
    # #         data = getQuote(self,token,seg,streamType)
    # #         bid = data['AskInfo']['Price']
    # #         ask = data['BidInfo']['Price']
    # #         ltp = data['LastTradedPrice']
    # #
    # #         return {"bid":bid,"ask":ask ,"ltp":ltp}
    # #     except:
    # #         print(traceback.print_exc(),token)
    # #         return {"bid": 0.0, "ask": 0.0, "ltp": 0.0}
    # #
    #
    # # def getBasePrices(self):
    # #     try:
    # #         data = getQuote(self, self.modifyW.cashToken, 'NSECM', 1501)
    # #         self.modifyW.cashPrice=data['LastTradedPrice']
    # #         data = getQuote(self, self.modifyW.futureToken, 'NSEFO', 1501)
    # #         self.modifyW.futurePrice=data['LastTradedPrice']
    # #
    # #         self.modifyW.ATM = self.getATM(self.modifyW.cashPrice,self.modifyW.strikeDiff)
    # #
    # #         self.modifyW.ceTable = self.getCETable(self.modifyW.symbol,self.modifyW.expiry)
    # #         self.modifyW.peTable = self.getPETable(self.modifyW.symbol,self.modifyW.expiry)
    # #         self.updateValues()
    # #     except:
    # #         print(traceback.print_exc())
    # #
    # # def getNewPriceData(self):
    # #
    # #     self.cashPrice=self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
    # #     self.futurePrice=self.getPrice(token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
    # #     self.ATM = self.getATM(self.cashPrice,self.strikeDiff)
    #
    #
    # # def getATM(self,cashPrice,strikeDiff):
    # #     ATM1 = (cashPrice / strikeDiff)
    # #     frac = ATM1 % 1
    # #
    # #     strikeDecisionPoint = float(0.4)
    # #     # print(frac)
    # #     if(frac > strikeDecisionPoint):
    # #         ATM = int(ATM1+1) * strikeDiff
    # #     else:
    # #         ATM= int(ATM1)  * strikeDiff
    # #     # ATM1 = (cashPrice / strikeDiff) * strikeDiff
    # #     return ATM
    # #
    # #
    #

if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = modifyW()
    form.show()
    sys.exit(app.exec_())
