import datetime
import os
import threading
import traceback

import json

from PyQt5.QtWidgets import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import uic
from Application.Stretegies.ValSpread.Views.addW import addW
from Application.Stretegies.ValSpread.Views.modifyW import modifyW
import numpy as np
import datatable as dt
from Application.Services.Xts.Api.servicesIA import PlaceOrder
import time as ttime
from Application.Services.Xts.Api.servicesMD import getQuote
from Application.Utils.configReader import refresh

# from Application.Stretegies.ValSpread.Utills.executionSupport import getBaseInfo,modifyBaseInfo,trendChangedAddW,trendChangedmodifyW,symchange,expchange
from Application.Stretegies.ValSpread.Utills.executionSupport import *
from Application.Stretegies.ValSpread.Utills.keyParameters import *

# from Application.Views.BuyWindow.support import inc_v, dec_v
from Application.Stretegies.ValSpread.Utills.executionSupport import *
from Application.Stretegies.ValSpread.Utills.square import *

class logic(QObject):
    sgMTM = pyqtSignal(str,float)
    sgSL = pyqtSignal(str,float)
    sgTarget = pyqtSignal(str,float)
    sgAlert = pyqtSignal(str)
    sgParamSet = pyqtSignal()
    sgStart = pyqtSignal()
    sgActivate =pyqtSignal()
    sgStop = pyqtSignal()
    sgClose =pyqtSignal()
    sgFolioOpenPos=pyqtSignal(list)
    ################################# Intialization Here ##################################################
    def __init__(self):
        super(logic, self).__init__()

        self.position = np.zeros((100, 15), dtype=object)
        self.posHeads = ['exch',
                         'token', 'symbol', 'strike', 'c/p', 'netqty',
                         'requestedOrder', 'openOrder', 'netamt', 'ltp', 'mtm',
                         'OpenQty', 'OpenAmt', 'DQty', 'Damt']

        self.addW = addW(self)
        self.modifyW = modifyW(self)
        self.setAllShortCut()


        self.initVaribles()

    def initVaribles(self):
        self.stype = 'ValSpread'
        self.fullPos = False
        self.isFirstOrderPunch = False
        self.isParameterSet = False
        self.isStart = False
        self.isClose = False
        self.isSlHitOnce = False
        self.mtm = 0
        self.SlAmount = 0.0
        self.targetAmt = 0.0
        self.tsl = 0.0
        # self.cashPrice = 0.0
        # self.futurePrice = 0.0
        # self.basePrice = 0.0
        self.ATM = 0.0
        self.strikeDiff = 0.0
        self.pairTotal = 0.0
        self.lastOrderPoint = 0
        self.isAnyOpenPos = False
        self.lastSerialNo = 0
        self.lotsize = 0

        self.DOI = datetime.datetime.today().strftime('%d%m%Y')



        self.tokenList = [0,0,0,0,0,0,0]
        """        # tokenlist  
                                0 cashToken  
                                1 futureToken
                                2 ATM CE Token
                                3 ATM PE Token
                                4 OTM Token
                                5 ATM Token
                                6 hedge Token
        """


    def createObject(self,fo_contract):

        try:
            self.fo_contract=fo_contract
            refresh(self)
            refresh(self.addW)
            refresh(self.modifyW)

            fltr = np.asarray(['OPTSTK','OPTIDX'])
            self.addW.t = self.fo_contract[np.in1d(self.fo_contract[:, 5], fltr)]
            self.modifyW.t = self.fo_contract[np.in1d(self.fo_contract[:, 5], fltr)]
            lsSymbol = np.unique(self.addW.t[:, 3])
            self.addW.cbSymbol.addItems(lsSymbol)
            self.addW.cbSymbol.setCurrentText('BANKNIFTY')
            self.modifyW.cbSymbol.addItems(lsSymbol)
            self.modifyW.cbSymbol.setCurrentText('BANKNIFTY')

            symchange(self,self.addW)
            symchange(self,self.modifyW)
            expchange(self,self.addW)
            expchange(self,self.modifyW)
            getOptionExpiryList(self,self.addW)
            getOptionExpiryList(self,self.modifyW)
            getStrikePriceList(self,self.addW)
            getStrikePriceList(self,self.modifyW)
            updateHedgeStrikes(self)
            self.createTimer()
            # self.createTimer()
        except:
            print(traceback.print_exc())

    def connect2slots(self):
        self.addW.cbCF.currentIndexChanged.connect(lambda: baseChange(self, self.addW))
        self.addW.cbSymbol.currentTextChanged.connect(lambda: symchange(self, self.addW))
        self.addW.cbExp.currentTextChanged.connect(lambda:expchange(self,self.addW))
        self.addW.pbGetInfo.clicked.connect(lambda :getBaseInfo(self,self.addW))
        self.addW.cbTrend.currentIndexChanged.connect(lambda:trendChanged(self,self.addW))

        self.addW.cbStrikePrice.currentIndexChanged.connect(lambda :recalculateATMQtyONSC(self,self.addW))
        self.addW.cbATMStrike.currentIndexChanged.connect(lambda :recalculateATMQtyONSC(self,self.addW))

        self.addW.pbGetPrices.clicked.connect(lambda :updateAllToken(self,self.addW))

        self.addW.cbOptType.currentIndexChanged.connect(lambda:recalOTMStrike(self,self.addW))
        self.addW.leQty_O.textChanged.connect(lambda :recalculateATMQty(self,self.addW))
        self.addW.pbApply.clicked.connect(self.setParameters)


    def setParameters(self):
        try:
            self.OTMqty = int(self.addW.leQty_O.text())
            self.ATMqty = int(self.addW.leQty_A.text())
            if(self.OTMqty <= 0  and self.ATMqty <= 0):
                self.messageBox = QMessageBox()
                self.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
                self.messageBox.setIcon(QMessageBox.Critical)
                self.messageBox.setText('Quantity must be greater than zero!!')
                self.messageBox.show()
            else:
                self.Base = self.addW.cbCF.currentText()
                self.BaseToken = self.addW.BaseToken
                self.folioName = self.addW.leFolioName.text()
                getKeyParameterFile(self,self.folioName)
                self.clientId = self.addW.cbClient.currentText()
                self.symbol = self.addW.cbSymbol.currentText()
                self.expiry = self.addW.cbExp.currentText()
                self.optType = self.addW.cbOptType.currentText()
                self.OTMStrike = self.addW.cbStrikePrice.currentText()
                self.ATMStrikeIndex = self.addW.cbATMStrike.currentIndex()
                self.Trend = self.addW.cbTrend.currentText()
                self.cashToken = getCashToken(self,self.symbol)
                self.futureToken = getFutureToken(self,self.symbol)

                self.cashPrice = self.addW.cashPrice
                self.futurePrice = self.addW.futurePrice
                self.basePrice = self.addW.basePrice
                self.ATM = self.addW.ATM


                self.strikeDiff = getStrikeDiff(self,self.futureToken)
                self.freezeQty = int(self.fo_contract[self.futureToken-35000,14])
                self.lotsize = int(self.fo_contract[self.futureToken-35000,11])

                self.ceTable = getCETable(self, self.symbol, self.expiry)
                self.peTable = getPETable(self, self.symbol, self.expiry)

                self.OTMToken = self.addW.OTMToken
                self.ATMToken = self.addW.ATMToken

                self.strikeDecisionPoint = float(0.4)

                self.OTMqty = int(self.addW.leQty_O.text())
                self.ATMqty = int(self.addW.leQty_A.text())

                self.hedgeQty =    self.OTMqty +  self.ATMqty
                self.hedgeStrike = self.hedgeStrike
                self.SlAmount = float(self.addW.leSl.text())
                self.targetAmt = float(self.addW.leTarget.text())
                self.isParameterSet = True

                updateModifyInfo(self)

                connectModifyWindowSlot(self)
                self.sgParamSet.emit()

                saveJson(self)
                self.Slogger.info('%s Stretegy Initialized Successfully..' % (self.folioName))
                # self.position = np.asarray(self.keyParameterJson['position'])

        except:
            print(traceback.print_exc())
            self.Slogger.error(sys.exc_info()[1])


    def squreOff(self):
        squreOff(self)



    def updateTrade(self,trade,source='on_trade'):
        # print('in update position stretegy')
        if (source == "on_trade"):
            trade1 = trade[0]
        else:
            trade1 = trade
        # print(self.folioName,trade1)

        if(trade1[15]==self.folioName):

            exchange = trade1[20]
            token = trade1[2]
            fltr0 = np.asarray([token])
            filteredArray0 = self.position[np.in1d(self.position[:, 1], fltr0)]
            isRecordExist = False
            if(filteredArray0.size!=0):
                isRecordExist=True

            if (isRecordExist):
                array = self.position[np.where(self.position[:, 1] == token)]
                # print('in is record exist',array)
                prev_qty = array[0][5]
                prev_amt = array[0][8]

                Prev_Dqty = array[0][13]
                Prev_Damt = array[0][14]

                Dqty = Prev_Dqty + trade1[18]
                DAmt = Prev_Damt + trade1[19]

                newQty = prev_qty + trade1[18]
                newAmt = prev_amt + trade1[19]

                self.position[np.where(self.position[:, 1] == token), [5, 8, 13, 14]] = [newQty, newAmt, Dqty, DAmt]

                # print('updated position dekh lo',self.position)
            else:
                new = dt.Frame([[exchange],
                                [token], [trade1[4]], [float(trade1[6])], [trade1[7]], [trade1[18]],
                                [0], [0], [trade1[19]], [trade1[17]], [0.0],
                                [0.0], [0.0], [trade1[18]], [trade1[19]]
                                ]).to_numpy()

                # print('new position dekh lo',self.position,'\n\n\n\n',new,'\n\n\najsgd'
                #
                #       )
                self.position[self.lastSerialNo, :] = new
                self.lastSerialNo += 1
                # print('new position dekh lo',self.position)
            checkIsAnyPosition(self)

    def makeFirstOrder(self):
        try:
            if(self.isFirstOrderPunch==False):


                OTMQty = self.OTMqty
                ATMQty =self.ATMqty
                self.hedgeQty = OTMQty - ATMQty


                while ATMQty > self.freezeQty:
                    PlaceOrder(self,exchange='NSEFO',clientID=self.clientId,token=self.ATMToken,orderSide='Buy',qty=self.freezeQty,limitPrice=0.0,
                               validity='DAY',disQty=0,triggerPrice=0,uid=self.folioName,orderType='MARKET',productType='NRML')
                    ATMQty -= self.freezeQty
                    ttime.sleep(0.2)

                PlaceOrder(self,exchange='NSEFO',clientID=self.clientId,token=self.ATMToken,orderSide='Buy',qty=ATMQty,limitPrice=0.0,
                           validity='DAY',disQty=0,triggerPrice=0,uid=self.folioName,orderType='MARKET',productType='NRML')

                while OTMQty > self.freezeQty:
                    PlaceOrder(self,exchange='NSEFO',clientID=self.clientId,token=self.OTMToken,orderSide='Sell',qty=self.freezeQty,limitPrice=0.0,
                               validity='DAY',disQty=0,triggerPrice=0,uid=self.folioName,orderType='MARKET',productType='NRML')
                    OTMQty -= self.freezeQty
                    ttime.sleep(0.2)

                PlaceOrder(self,exchange='NSEFO',clientID=self.clientId,token=self.OTMToken,orderSide='Sell',qty=OTMQty,limitPrice=0.0,
                           validity='DAY',disQty=0,triggerPrice=0,uid=self.folioName,orderType='MARKET',productType='NRML')



                self.lastOrderPoint = self.cashPrice


                self.fullPos  = True
                self.sgStart.emit()
                self.isStart = True
                self.isFirstOrderPunch =True
                self.saveJson()
                self.Slogger.info('First Order Placed Successfully..')
        except:
            self.Slogger.error(sys.exc_info()[1])


            # print('lastOrderPoint',self.lastOrderPoint)

    def saveJson(self,cf=False):
        saveJson(self,cf)



    def checkTarget(self):
        if(self.isSlHitOnce==False ):

            if(self.mtm>=self.targetAmt and self.targetAmt!=0):
                self.isSlHitOnce = True
                squreOff(self)

                d = {'MTM': self.mtm, 'SlAmount': self.targetAmt}
                self.Slogger.info('Target Trigger (mtm>targetAmt)....', d)

    def updateWindows(self,feed,window):
        priceToken  = feed['Token']

        if(window.isParachange==False):
            if(window.visibleRegion().isEmpty() == False):

                if(priceToken==self.tokenList[0]):
                    if (window.cashFut == 'CASH'):
                        window.BaseToken = window.cashToken
                        window.cashPrice = feed['LTP']
                        window.basePrice = window.cashPrice
                        if(self.isFirstOrderPunch==False):
                            ATM = getATM(self, window.basePrice, window.strikeDiff)
                            if(ATM != window.ATM):
                                window.ATM = ATM
                                window.lb_atm.setText(str(window.ATM))
                                window.ATM_CE_Token = getATM_CE_Token(self, window.ATM, window.ceTable)
                                window.ATM_PE_Token = getATM_PE_Token(self, window.ATM, window.peTable)
                                self.tokenList[2] = window.ATM_CE_Token
                                self.tokenList[3] = window.ATM_PE_Token

                        window.lb_ltp.setText(str(window.basePrice))



                elif(priceToken==self.tokenList[1]):
                    if (window.cashFut != 'CASH'):
                        window.BaseToken = window.futureToken
                        window.futurePrice = feed['LTP']
                        window.basePrice = window.futurePrice
                        ATM = getATM(self, window.basePrice, window.strikeDiff)
                        if(self.isFirstOrderPunch==False):
                            if(ATM != window.ATM):
                                window.ATM = ATM
                                window.lb_atm.setText(str(window.ATM))
                                window.ATM_CE_Token = getATM_CE_Token(self, window.ATM, window.ceTable)
                                window.ATM_PE_Token = getATM_PE_Token(self, window.ATM, window.peTable)
                                self.tokenList[2] = window.ATM_CE_Token
                                self.tokenList[3] = window.ATM_PE_Token

                        window.lb_ltp.setText(str(window.basePrice))

                elif(priceToken==self.tokenList[2]):
                    # print('enterr!!!')
                    window.atmCEPrice = feed['LTP']
                    window.lb_CEP.setText('%.2f' % window.atmCEPrice)
                    if(priceToken==self.tokenList[4]):
                        window.OTMPrice= feed['LTP']
                        window.lbOTMPrc.setText('%.2f' % window.OTMPrice)
                        try:
                            if (window.leQty_O.text() != '' and window.leQty_A.text() != ''):
                                OTMQty = float(int(window.leQty_O.text()))
                                ATMQty = int(window.leQty_A.text())

                                OTMPrem = window.OTMPrice * OTMQty
                                ATMPrem = window.ATMPrice * ATMQty

                                window.lbOTM_Prem.setText('%.2f' % OTMPrem)
                                window.lbATM_Prem.setText('%.2f' % ATMPrem)
                        except:
                            pass

                    elif(priceToken==self.tokenList[5]):
                        window.ATMPrice= feed['LTP']
                        window.lbATMPrc.setText('%.2f' % window.ATMPrice)
                        try:
                            if (window.leQty_O.text() != '' and window.leQty_A.text() != ''):
                                OTMQty = float(int(window.leQty_O.text()))
                                ATMQty = int(window.leQty_A.text())

                                OTMPrem = window.OTMPrice * OTMQty
                                ATMPrem = window.ATMPrice * ATMQty

                                window.lbOTM_Prem.setText('%.2f' % OTMPrem)
                                window.lbATM_Prem.setText('%.2f' % ATMPrem)
                        except:

                            pass

                elif(priceToken==self.tokenList[3]):
                    window.atmPEPrice = feed['LTP']
                    window.lb_PEP.setText('%.2f' % window.atmPEPrice)
                    if(priceToken==self.tokenList[4]):
                        window.OTMPrice= feed['LTP']
                        window.lbOTMPrc.setText('%.2f' % window.OTMPrice)
                        try:
                            if (window.leQty_O.text() != '' and window.leQty_A.text() != ''):
                                OTMQty = float(int(window.leQty_O.text()))
                                ATMQty = int(window.leQty_A.text())

                                OTMPrem = window.OTMPrice * OTMQty
                                ATMPrem = window.ATMPrice * ATMQty

                                window.lbOTM_Prem.setText('%.2f' % OTMPrem)
                                window.lbATM_Prem.setText('%.2f' % ATMPrem)
                        except:
                            pass
                    elif(priceToken==self.tokenList[5]):
                        window.ATMPrice= feed['LTP']
                        window.lbATMPrc.setText('%.2f' % window.ATMPrice)
                        try:
                            if (window.leQty_O.text() != '' and window.leQty_A.text() != ''):
                                OTMQty = float(int(window.leQty_O.text()))
                                ATMQty = int(window.leQty_A.text())

                                OTMPrem = window.OTMPrice * OTMQty
                                ATMPrem = window.ATMPrice * ATMQty

                                window.lbOTM_Prem.setText('%.2f' % OTMPrem)
                                window.lbATM_Prem.setText('%.2f' % ATMPrem)
                        except:
                            pass

                elif(priceToken==self.tokenList[4]):
                    window.OTMPrice= feed['LTP']
                    window.lbOTMPrc.setText('%.2f' % window.OTMPrice)
                    if (window.leQty_O.text() != '' and window.leQty_A.text() != ''):
                        OTMQty = float(int(window.leQty_O.text()))
                        ATMQty = int(window.leQty_A.text())
                        try:
                            OTMPrem = window.OTMPrice * OTMQty
                            ATMPrem = window.ATMPrice * ATMQty

                            window.lbOTM_Prem.setText('%.2f' % OTMPrem)
                            window.lbATM_Prem.setText('%.2f' % ATMPrem)
                        except:
                            pass

                elif(priceToken==self.tokenList[5]):
                    window.ATMPrice= feed['LTP']
                    window.lbATMPrc.setText('%.2f' % window.ATMPrice)
                    try:
                        if (window.leQty_O.text() != '' and window.leQty_A.text() != ''):
                            OTMQty = float(int(window.leQty_O.text()))
                            ATMQty = int(window.leQty_A.text())

                            OTMPrem = window.OTMPrice * OTMQty
                            ATMPrem = window.ATMPrice * ATMQty

                            window.lbOTM_Prem.setText('%.2f' % OTMPrem)
                            window.lbATM_Prem.setText('%.2f' % ATMPrem)
                    except:
                        pass
    def updateOrder(self,order,orderDict):
        pass

    def checkTrade(self,priceFeed):
        # print("enterrrrrr")
        self.updateWindows(priceFeed,self.modifyW)
        pass
        #
        # if(self.isFirstOrderPunch==False):
        #     priceToken  = priceFeed['Token']
        #     if(self.addW.cashToken == priceToken):
        #         cashPrice = priceFeed['LTP']
        #         self.addW.lb_ltp.setText('%.2f'%cashPrice)
        #
        # elif(self.isStart):
        #
        #
        #
        #     priceToken  = priceFeed['Token']
        #
        #
        #     if(self.cashToken == priceToken):
        #         cashPrice = priceFeed['LTP']
        #         self.cashPrice = cashPrice
        #
        #
        #             # ##################################
        #             # self.lastOrderPoint = cashPrice
        #             # self.saveJson()

    def placeHedgeOrder(self):
        ATM = self.getATM(self.cashPrice, self.strikeDiff)
        ##################### get hedge qty ############################

        peHedgeStrike = ATM - ((self.lowerRangeIndex + 2)* self.strikeDiff)
        ceHedgeStrike = ATM + ((self.upperRangeIndex + 2)* self.strikeDiff)


        ceHedgeToken = self.ceTable[np.where(self.ceTable[:,12]==ceHedgeStrike),2][0][0]
        peHedgeToken = self.peTable[np.where(self.peTable[:,12]==peHedgeStrike),2][0][0]

        ### while freeze qty

        PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=ceHedgeToken, orderSide='Buy', qty=self.qty,
                   limitPrice=0.0,
                   validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET', productType='NRML')
        PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=peHedgeToken, orderSide='Buy', qty=self.qty,
                   limitPrice=0.0,
                   validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET', productType='NRML')

    def updateMTM(self,data):
        # print('dd',self.isAnyOpenPos)
        if(self.isAnyOpenPos == True):
            if (data['Token'] in self.position[:,1]):
                fltr0 = np.asarray([data['Token']])
                array = self.position[np.in1d(self.position[:, 1], fltr0)][0]
                # print(array)
                netAmt = array[8]
                ltp = data['LTP']
                qty = array[5]
                mtm = netAmt + (qty * ltp)
                self.position[np.in1d(self.position[:, 1], fltr0),[9,10]] = [ltp,mtm]
                # print(self.position[np.in1d(self.position[:, 1], fltr0)][0])
                total_mtm = np.sum(self.position[:,10])
                self.mtm = total_mtm

                self.modifyW.lbMTM.setText('%.2f'%self.mtm)
                # print(self.mtm)
                self.sgMTM.emit(self.folioName,total_mtm)
                # print('emited')
                self.checkSL()
                self.checkTarget()


    def checkSL(self):
        # print('a',self.folioName,self.isSlHitOnce)

        if(self.isSlHitOnce==False and self.SlAmount != 0 and self.isStart==True):
            # if((self.tsl+self.trailP) <= (self.mtm + self.sl)):
            #     self.tsl = self.mtm + self.sl
            #     self.sgTSL.emit(self.folioName,self.tsl)
            ####################################################
            # if(self.mtm<=self.tsl):
            #     self.squreOff()

            if(self.mtm<=self.SlAmount):
                # print('trgger sl', self.mtm, self.SlAmount)
                self.isSlHitOnce = True
                self.squreOff()
                d={'MTM':self.mtm,'SlAmount':self.SlAmount}
                self.Slogger.info('SL Trigger (mtm>Slamt)....' ,d)
            ####################################################


    def setAllShortCut(self):
        # print("parthhhhhhhhhhhhh")
        self.addW.leQty_O.sc_up = QShortcut(QKeySequence('Up'),self.addW.leQty_O)
        self.addW.leQty_O.sc_up.setContext(Qt.WidgetWithChildrenShortcut)
        self.addW.leQty_O.sc_up.activated.connect(lambda:inc_v(self,self.addW))
        self.addW.leQty_O.sc_down = QShortcut(QKeySequence('Down'), self.addW.leQty_O)
        self.addW.leQty_O.sc_down.activated.connect(lambda :dec_v(self,self.addW))
        self.addW.leQty_O.sc_down.setContext(Qt.WidgetWithChildrenShortcut)


        self.modifyW.leQty_O.sc_up = QShortcut(QKeySequence('Up'),self.modifyW.leQty_O)
        self.modifyW.leQty_O.sc_up.setContext(Qt.WidgetWithChildrenShortcut)
        self.modifyW.leQty_O.sc_up.activated.connect(lambda:inc_v(self,self.modifyW))
        self.modifyW.leQty_O.sc_down = QShortcut(QKeySequence('Down'), self.modifyW.leQty_O)
        self.modifyW.leQty_O.sc_down.setContext(Qt.WidgetWithChildrenShortcut)
        self.modifyW.leQty_O.sc_down.activated.connect(lambda:dec_v(self,self.modifyW))
    #

    def hideAddW(self):
        try:
            self.timerUpdateWindows.stop()
            self.timerGetPrices.stop()
            self.addW.hide()
        except:
            print(traceback)

    def hideModifyW(self):
        self.timerUpdateWindows.stop()
        self.timerGetPrices.stop()
        self.modifyW.hide()

    def getBaseInfo(self,window):
        getBaseInfo(self,self.addW)

    def flushTradeData(self):
        self.position = np.zeros((100,11),dtype=object)


    def modifyParameter(self):

            if(self.isFirstOrderPunch==False):
                self.setParameters()
            else:

                print("Modify Order")
                if(self.modifyW.cxbSL.isChecked()):
                    print('-----')
                    self.SlAmount = float(self.modifyW.leSl.text())
                    self.sgSL.emit(self.folioName,self.SlAmount)
                    self.modifyW.lb_SlAmount.setText('%.2f'%self.SlAmount)

                if (self.modifyW.cxbTarget.isChecked()):
                    self.targetAmt = float(self.modifyW.leTarget.text())
                    self.sgTarget.emit(self.folioName,self.targetAmt)
                    self.modifyW.lb_Target.setText('%.2f'%self.targetAmt)

            self.hideModifyW()

    def createTimer(self):
        self.timerUpdateWindows = QTimer()
        self.timerUpdateWindows.setInterval(500)
        self.timerUpdateWindows.timeout.connect(lambda:updateValues(self))

        self.timerGetPrices = QTimer()
        self.timerGetPrices.setInterval(500)
        self.timerGetPrices.timeout.connect(lambda:getPrices(self))


    def getKeyParameterFile(self,folio):
        getKeyParameterFile(self,folio)


    def reloadKeyParameter(self):
        reloadKeyParameter(self)