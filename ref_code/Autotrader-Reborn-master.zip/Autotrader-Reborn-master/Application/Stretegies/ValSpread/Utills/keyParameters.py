import datetime
import shutil
import time
import json
import os
import traceback
import numpy as np


from Application.Stretegies.ValSpread.Utills.executionSupport import *


def craeteKeyParameterJson(self,cf):
    # today=datetime.today().strftime('%d%m%Y')
    if (cf):

        open_pos = self.position[:self.lastSerialNo, :].tolist()
        # DOI=self.DOI
    else:

        open_pos = []
        # DOI = datetime.today().strftime('%d%m%Y')

    self.keyParameterJson = {
        "folioName": self.folioName,
        'clientId': self.clientId,
        "stype": self.stype,
        "symbol": self.symbol,
        "Base":self.Base,
        "expiry": self.expiry,
        'isFirstOrderPunch': self.isFirstOrderPunch,
        'ATMStrikeIndex':self.ATMStrikeIndex,
        'OTMStrike':self.OTMStrike,
        'ATMToken': self.ATMToken,
        'OTMToken': self.OTMToken,
        'Trend' : self.Trend,
        'lotSize':self.lotsize,
        'freezeQty':self.freezeQty,
        'cashToken':self.cashToken,
        'futureToken':self.futureToken,
        'OTMqty': self.OTMqty,
        "optType":self.optType,
        'ATMqty': self.ATMqty,
        'hedgeQty':self.hedgeQty,
        'hedgeStrike':self.hedgeStrike,
        'SlAmount': self.SlAmount,
        'Target': self.targetAmt,
        'fullPos':self.fullPos,
        'ATM': self.ATM,
        'strikeDecisionPoint': self.strikeDecisionPoint,
        'isParameterSet' : self.isParameterSet,
        'tokenList' : self.tokenList,

        'open_position': open_pos,
        'DateOfInitialization':self.DOI,

    }


def reloadKeyParameter(self):
    try:
        f1 = open(self.keyParameterFile)
        self.keyParameterJson = json.load(f1)
        f1.close()
        self.clientId = self.keyParameterJson['clientId']
        self.symbol = self.keyParameterJson['symbol']
        self.stype = self.keyParameterJson['stype']
        self.expiry = self.keyParameterJson['expiry']
        self.strikeDecisionPoint = self.keyParameterJson['strikeDecisionPoint']
        self.Base = self.keyParameterJson['Base']
        self.optType = self.keyParameterJson['optType']
        self.Trend = self.keyParameterJson['Trend']
        self.ATMStrikeIndex = self.keyParameterJson['ATMStrikeIndex']
        self.ATM = self.keyParameterJson['ATM']
        self.OTMqty = self.keyParameterJson['OTMqty']
        self.OTMStrike = self.keyParameterJson['OTMStrike']
        self.ATMqty = self.keyParameterJson['ATMqty']
        self.hedgeQty = self.keyParameterJson['hedgeQty']
        self.hedgeStrike = self.keyParameterJson['hedgeStrike']
        # self.hedgeToken = self.keyParameterJson['hedgeToken']
        self.SlAmount = self.keyParameterJson['SlAmount']
        self.targetAmt = self.keyParameterJson['Target']
        self.fullPos = self.keyParameterJson['fullPos']
        self.isParameterSet = self.keyParameterJson['isParameterSet']
        self.tokenList= self.keyParameterJson['tokenList']
        self.ATMToken= self.keyParameterJson['ATMToken']
        self.OTMToken= self.keyParameterJson['OTMToken']
        self.freezeQty = self.keyParameterJson['freezeQty']
        self.DOI = self.keyParameterJson['DateOfInitialization']

        self.isFirstOrderPunch = self.keyParameterJson['isFirstOrderPunch']
        #
        self.cashToken =getCashToken(self,self.symbol)
        self.futureToken = getFutureToken(self,self.symbol)
        self.strikeDiff = getStrikeDiff(self,self.futureToken)

        self.lotsize = getLotSize(self, self.futureToken)

        data = getQuote(self, self.cashToken, 'NSECM', 1501)
        self.cashPrice = data['LastTradedPrice']
        data = getQuote(self, self.futureToken, 'NSEFO', 1501)
        self.futurePrice = data['LastTradedPrice']




        if (self.Base == 'CASH'):
            self.BaseToken = self.cashToken
            self.basePrice = self.cashPrice
        else:
            self.BaseToken = self.futureToken
            self.basePrice = self.futurePrice


        # print(self.folioName, 'position reload', type(self.position), self.position)

        # self.position = self.keyParameterJson['position']

        # print('ppp',self.symbol, self.expiry)

        self.ceTable = getCETable(self,self.symbol, self.expiry)
        self.peTable = getPETable(self,self.symbol, self.expiry)

        # if (self.keyParameterJson['position'] != []):
        #     self.position = np.asarray(self.keyParameterJson['position'])
        if (self.keyParameterJson['open_position'] != []):
            self.open_position = np.asarray(self.keyParameterJson['open_position'],dtype=object)
            updateOpenPos(self)

        # print('stretegy parameter has been set, cashToken', self.cashToken)
        # print(self.folioName,self.modifyW)
        updateModifyInfo(self)
        connectModifyWindowSlot(self)
        # print('freezeQty', self.freezeQty)
    except:
        print(traceback.print_exc())

def updateOpenPos(self):

    for i in self.open_position:
        # print(i)
        # fltr = [i[1]]
        rowarray = np.where(self.position[:self.lastSerialNo, 1]== i[1])[0]




        if(rowarray.size!=0):

            rowNO=rowarray[0]

            filteredArray = self.position[np.where(self.position[:self.lastSerialNo, 1] == i[1])][0]

            openQty=i[5] + filteredArray[5]
            openamt=i[8] +filteredArray[8]

            editList=[5,8,11,12,13,14]
            self.position[rowNO, editList] = [openQty,openamt,openQty,openamt,0.0,0.0]

        else:
            self.position[self.lastSerialNo]=[i[0],i[1],i[2],i[3],i[4],i[5],i[6],i[7],i[8],i[9],i[10],i[5],i[8],0.0,0.0]
            self.lastSerialNo+=1

        checkIsAnyPosition(self)

        if(i[5]>0):
            sellQ=i[5]
            buyQ=0
        else:
            sellQ = 0
            buyQ = i[5]
        data=[self.userID,self.clientId, self.stype,self.folioName,i[0],i[1],'stockname',i[2],self.expiry,i[3],i[4],i[5],0.0,
              i[5],i[8],0.0,buyQ,0.0,sellQ,0.0,0.0,0.0, self.lotsize,self.freezeQty,i[8],0,0.0]
        self.sgFolioOpenPos.emit(data)




def saveJson(self,cf=False):
    getKeyParameterFile(self,self.folioName)
    craeteKeyParameterJson(self,cf)
    f2 = open(self.keyParameterFile, 'w')
    jInfo_new = json.dumps(self.keyParameterJson, indent=4)
    f2.write(jInfo_new)
    f2.close()



# def copyJson_CF_data(self):
#     todayDate = datetime.today().strftime('%Y%m%d')
#     loc1 = os.getcwd().split('Application')
#     destPath = os.path.join(loc1[0], 'Application', 'DB', 'CF_data',self.folioName+'.json')
#     sourcepath = os.path.join(loc1[0], 'Application', 'DB', 'Stretegy_data', todayDate,self.folioName+'.json')
#     shutil.copy(sourcepath, destPath)

    # ls = os.listdir(sourceDir)
    # for iz in ls:
    #     src_path = os.path.join(sourceDir, iz)
    #     shutil.copy(src_path, destPath)


# def getKeyParameterFile(self, folioName):
#     todate = datetime.datetime.today().strftime('%Y%m%d')
#     loc = os.getcwd().split('Application')
#     self.keyParameterFile = os.path.join(loc[0], 'Application', 'DB', 'Stretegy_data', todate,
#                                          '%s.json' % folioName)
def getKeyParameterFile(self,folioName):
    todate = datetime.datetime.today().strftime('%Y%m%d')
    loc = os.getcwd().split('Application')
    self.keyParameterFile = os.path.join(loc[0], 'Application', 'DB', 'Stretegy_data', todate,
                                         '%s.json' % folioName)
