import threading
import traceback
# from datetime import datetime, time

from Application.Services.Xts.Api.servicesMD import getQuote,subscribeToken
import logging
import sys
import numpy as np

from Application.Stretegies.ValSpread.Utills.square import *

def getBaseInfo(self,window):
    print('in get info')
    window.symbol = window.cbSymbol.currentText()
    window.expiry = window.cbExp.currentText()
    window.cashToken = getCashToken(self,window.symbol)
    self.tokenList[0] =  window.cashToken
    subscribeToken(self,window.cashToken,'NSECM')
    window.cashFut = window.cbCF.currentText()
    window.futureToken = getFutureToken(self,window.symbol)
    self.tokenList[1] = window.futureToken
    subscribeToken(self,window.futureToken,'NSEFO')

    data = getQuote(self, window.cashToken, 'NSECM', 1501)
    window.cashPrice = data['LastTradedPrice']
    data = getQuote(self, window.futureToken, 'NSEFO', 1501)
    window.futurePrice = data['LastTradedPrice']

    if(window.cashFut == 'CASH'):
        window.BaseToken = window.cashToken
        window.basePrice = window.cashPrice
    else:
        window.BaseToken = window.futureToken
        window.basePrice = window.futurePrice

    window.strikeDiff = getStrikeDiff(self,window.futureToken)
    window.lotsize = getLotSize(self,window.futureToken)
    print('lot size',window.lotsize)
    window.ATM = getATM(self,window.basePrice, window.strikeDiff)

    # print('window.ATM',window.ATM)

    window.ceTable = getCETable(self,window.symbol, window.expiry)
    window.peTable = getPETable(self,window.symbol, window.expiry)

    window.lb_ltp.setText(str(window.basePrice))
    window.lb_atm.setText(str(window.ATM))

    # print('window.ceTable',window.ceTable)

    window.ATM_CE_Token = getATM_CE_Token(self,window.ATM, window.ceTable)
    window.ATM_PE_Token = getATM_PE_Token(self,window.ATM, window.peTable)
    subscribeToken(self,window.ATM_CE_Token,'NSEFO')
    subscribeToken(self,window.ATM_PE_Token,'NSEFO')

    self.tokenList[2] = window.ATM_CE_Token
    self.tokenList[3] = window.ATM_PE_Token

    data = getQuote(self, window.ATM_CE_Token, 'NSEFO', 1501)
    # print(data)
    window.atmCEPrice = data['LastTradedPrice']

    data1 = getQuote(self, window.ATM_PE_Token, 'NSEFO', 1501)
    window.atmPEPrice = data1['LastTradedPrice']

    diffP = window.ATM - window.cashPrice


    window.lb_CEP.setText('%.2f' % window.atmCEPrice)
    window.lb_PEP.setText('%.2f' % window.atmPEPrice)
    # print('diffp',diffP,'ATM',window.ATM,'cash',window.cashPrice)
    if (diffP >= 0):
        cePrem = window.atmCEPrice
        pePrem = window.atmPEPrice - abs(diffP)
    else:
        cePrem = window.atmCEPrice - abs(diffP)
        pePrem = window.atmPEPrice


    # print('cePrem',cePrem,'pePrem',pePrem)
    if (cePrem > pePrem):
        window.Trend = 'Bullish'
        window.cbTrend.setCurrentText(window.Trend)
        window.cbOptType.setCurrentText('CE')
        OTMStrike = window.ATM + (window.strikeDiff * 10)
        window.cbStrikePrice.setCurrentText('%.2f'%OTMStrike)
        ATMStrike =  window.ATM
        window.OTMToken=getATM_CE_Token(self,OTMStrike,window.ceTable)
        window.ATMToken=getATM_CE_Token(self,ATMStrike,window.ceTable)


        self.tokenList[4] = window.OTMToken
        subscribeToken(self, window.OTMToken, 'NSEFO')

        self.tokenList[5] = window.ATMToken
        subscribeToken(self, window.ATMToken, 'NSEFO')
        self.hedgeStrike = OTMStrike + (window.strikeDiff * 10)
        window.hedgeStrike = self.hedgeStrike

        window.hedgeToken=getATM_CE_Token(self,self.hedgeStrike,window.ceTable)
        self.tokenList[6] = window.hedgeToken
        subscribeToken(self, window.hedgeToken, 'NSEFO')

    else:
        window.Trend = 'Bearish'
        window.cbTrend.setCurrentText(window.Trend)

        window.cbOptType.setCurrentText('PE')
        OTMStrike = window.ATM - (window.strikeDiff * 10)
        window.cbStrikePrice.setCurrentText('%.2f'%OTMStrike)
        ATMStrike =  window.ATM

        window.OTMToken=getATM_PE_Token(self,OTMStrike,window.peTable)
        window.ATMToken=getATM_PE_Token(self,ATMStrike,window.peTable)


        self.tokenList[4] = window.OTMToken
        subscribeToken(self, window.OTMToken, 'NSEFO')

        self.tokenList[5] = window.ATMToken
        subscribeToken(self, window.ATMToken, 'NSEFO')

        self.hedgeStrike = OTMStrike + (window.strikeDiff * 10)
        window.hedgeStrike = self.hedgeStrike
        window.hedgeToken=getATM_CE_Token(self,window.hedgeStrike,window.peTable)
        self.tokenList[6] = window.hedgeToken
    # print(self.tokenList)
    window.isParachange = False



def updateModifyInfo(self):
    self.modifyW.leFolioName.setText(self.folioName)
    self.modifyW.cbClient.setCurrentText(self.clientId)




    self.modifyW.ceTable = self.ceTable
    self.modifyW.peTable = self.peTable


    self.modifyW.strikeDiff = self.strikeDiff
    self.modifyW.lotsize = self.lotsize
    self.modifyW.freezeQty = self.freezeQty

    self.modifyW.ATM = self.ATM
    self.modifyW.hedgeStrike = self.hedgeStrike

    self.modifyW.symbol = self.symbol
    self.modifyW.expiry = self.expiry
    self.modifyW.cashFut = self.Base

    self.modifyW.cashToken = self.cashToken

    self.modifyW.futureToken = self.futureToken

    self.modifyW.BaseToken = self.BaseToken
    self.modifyW.cashPrice =self.cashPrice
    self.modifyW.futurePrice =self.futurePrice
    self.modifyW.basePrice =self.basePrice




    self.modifyW.cbSymbol.setCurrentText(self.symbol)
    self.modifyW.cbCF.setCurrentText(self.Base)
    self.modifyW.cbOptType.setCurrentText(self.optType)
    self.modifyW.cbStrikePrice.setCurrentText(self.OTMStrike)
    self.modifyW.cbHedgeStrike.setCurrentText('%.2f'%self.hedgeStrike)
    self.modifyW.cbATMStrike.setCurrentIndex(self.ATMStrikeIndex)
    self.modifyW.cbTrend.setCurrentText(self.Trend)


    self.modifyW.lb_ltp.setText(self.addW.lb_ltp.text())
    self.modifyW.lb_atm.setText(self.addW.lb_atm.text())

    self.modifyW.ATM = self.ATM

    self.modifyW.ATM_CE_Token = getATM_CE_Token(self,self.ATM,self.ceTable)
    self.modifyW.ATM_PE_Token = getATM_PE_Token(self,self.ATM,self.peTable)

    self.modifyW.lb_CEP.setText(self.addW.lb_CEP.text())
    self.modifyW.lb_PEP.setText(self.addW.lb_PEP.text())



    self.modifyW.ATMToken = self.ATMToken
    self.modifyW.OTMToken = self.OTMToken

    print('Qty',self.OTMqty)
    self.modifyW.leQty_O.setText(str(self.OTMqty))
    self.modifyW.leQty_A.setText(str(self.ATMqty))
    self.modifyW.leSl.setText(str(self.SlAmount))
    self.modifyW.leTarget.setText(str(self.targetAmt))

def connectModifyWindowSlot(self):
    try:

        # print('in modifyconnectiom')
        self.modifyW.cbSymbol.currentTextChanged.connect(lambda: symchange(self, self.modifyW))
        self.modifyW.pbApply.clicked.connect(self.modifyParameter)
        self.modifyW.cbExp.currentTextChanged.connect(lambda: expchange(self, self.modifyW))
        self.modifyW.cbTrend.currentIndexChanged.connect(lambda: trendChanged(self, self.modifyW))
        self.modifyW.pbGetInfo.clicked.connect(lambda: getBaseInfo(self, self.modifyW))
        self.modifyW.cbATMStrike.currentIndexChanged.connect(lambda: recalculateATMQtyONSC(self, self.modifyW))
        self.modifyW.cbStrikePrice.currentIndexChanged.connect(lambda: recalculateATMQtyONSC(self, self.modifyW))
        self.modifyW.cbHedgeStrike.currentIndexChanged.connect(lambda: getHedgeToken(self))
        self.modifyW.leQty_O.textChanged.connect(lambda: recalculateATMQty(self, self.modifyW))

        self.modifyW.pb50.clicked.connect(lambda: profitBook50(self))
        self.modifyW.pbFull.clicked.connect(lambda: squreOff(self))
        self.modifyW.pbHedge.clicked.connect(lambda: hedgeorder(self))

    except:
        print('error in modify connections',traceback.print_exc())


def getHedgeToken(self):
    print('kjdfhksdjhfjksdhfkjhsdkf')
    self.hedgeStrike = self.modifyW.cbHedgeStrike.currentText()
    if(self.modifyW.cbOptType.currentText()=="CE"):
        self.hedgeToken = getATM_CE_Token(self,float(self.hedgeStrike),self.ceTable)
    else:
        self.hedgeToken = getATM_PE_Token(self,self.hedgeStrike,self.peTable)

def trendChanged(self,window):
    if(window.cbTrend.currentText()=='Bullish'):
        window.cbOptType.setCurrentText('CE')
    elif(window.cbTrend.currentText()=='Bearish'):
        window.cbOptType.setCurrentText('PE')

def symchange(self,window):
    try:
        a = window.cbSymbol.currentText()
        fltr = np.asarray([a])
        window.t2 = window.t[np.in1d(window.t[:, 3], fltr)]
        window.t2_tp = window.t2.transpose()
        lsExp = np.unique(window.t2_tp[6])
        window.cbExp.clear()
        window.cbExp.addItems(lsExp)
        # self.getBaseInfo(window)

        window.isParachange = True


    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])

def expchange(self,window):
    try:
        a = window.cbExp.currentText()
        fltr = np.asarray([a])
        window.t3 = window.t2[np.in1d(window.t2[:, 6], fltr)]
        window.t3_tp = window.t3.transpose()
        window.lsstrk = np.unique(window.t3_tp[7])
        window.cbStrikePrice.clear()
        window.cbStrikePrice.addItems(window.lsstrk)
        # updateHedgeStrikes(self)
        window.isParachange = True

    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])



def baseChange(self,window):
    window.cashFut = window.cbCF.currentText()
    window.isParachange = True

def changesrtike(self,window):
    try:
        a = window.cbStrikePrice.currentText()
        if ('FUT' in window.cbInstrumentType.currentText()):
            window.cbOptType.clear()
            window.cbOptType.addItem(' ')

        elif ('OPT' in window.cbInstrumentType.currentText()):
            if (window.cbOptType.currentText() not in ['CE', 'PE']):
                window.cbOptType.clear()
                window.cbOptType.addItems(['CE', 'PE'])
            else:
                pass

    except:
        print(traceback.print_exc())
        logging.error(sys.exc_info()[1])

def getStrikePriceList(self,window):
    symbol = window.cbSymbol.currentText()
    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    fltr1 = np.asarray(['OPTSTK','OPTIDX'])

    filteredarray1 = filteredarray[np.in1d(filteredarray[:, 5], fltr1)]
    exp = window.cbExp.currentText()

    fltr2 = np.asarray([exp])
    filteredarray2 = filteredarray1[np.in1d(filteredarray1[:, 6], fltr2)]

    uniqueStrike = np.unique(filteredarray2[:,7])
    window.cbStrikePrice.addItems(uniqueStrike)

def getOptionExpiryList(self,window):
    symbol = window.cbSymbol.currentText()
    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    uniqueExp = np.unique(filteredarray[:,6])
    window.cbExp.addItems(uniqueExp)

def updateHedgeStrikes(self):
    self.modifyW.cbHedgeStrike.clear()
    self.modifyW.cbHedgeStrike.addItems(self.addW.lsstrk.tolist())
    # self.hedgeStrike = self.modifyW.cbHedgeStrike.currentText()
    # self.modifyW.hedgeStrike = self.modifyW.cbHedgeStrike.currentText()
    if(self.isParameterSet):
        self.modifyW.cbHedgeStrike.setCurrentText(self.addW.hedgeStrike)
# def onExpChange(self,window):
#     window.ceTable = self.getCETable(window.symbol, window.expiry)
#     window.peTable = self.getPETable(window.symbol, window.expiry)
#
#
#     window.ATM_CE_Token = self.getATM_CE_Token(window.ATM, window.ceTable)
#     window.ATM_PE_Token = self.getATM_PE_Token(window.ATM, window.peTable)



def recalOTMStrike(self,window):

    if(window.cbOptType.currentText()=='CE'):
        OTMStrike=window.ATM  + (window.strikeDiff * 10)
    else:
        OTMStrike = window.ATM - (window.strikeDiff * 10)
    # print('pappapapap',OTMStrike)
    window.cbStrikePrice.setCurrentText('%.2f'%OTMStrike)

def recalculateATMQty(self,window):

    OTMQty = float(int(window.leQty_O.text()))
    OTMPrc = float(window.lbOTMPrc.text())
    OTMPrem = OTMPrc * OTMQty
    ATMPrc = float(window.lbATMPrc.text())
    atmQty =  int(OTMPrem / (ATMPrc * window.lotsize))*window.lotsize
    window.leQty_A.setText(str(atmQty))


def recalculateATMQtyONSC(self,window):
    window.isParachange =True

    OTMStrike = float(window.cbStrikePrice.currentText())
    if(window.cbOptType.currentText()=='CE'):
        window.OTMToken = getATM_CE_Token(self,OTMStrike, window.ceTable)
    else:
        window.OTMToken = getATM_CE_Token(self,OTMStrike, window.peTable)
    self.tokenList[4] =window.OTMToken

    if(window.cbOptType.currentText()=='CE'):
        ATMStrike = window.ATM +  (window.strikeDiff * window.cbATMStrike.currentIndex())
        window.ATMToken = getATM_CE_Token(self,ATMStrike, window.ceTable)
    else:
        ATMStrike = window.ATM -  (window.strikeDiff * window.cbATMStrike.currentIndex())
        window.ATMToken = getATM_CE_Token(self,ATMStrike, window.peTable)
    self.tokenList[5] =window.ATMToken
    window.isParachange =True
    getCEPEPrice(self)
    updateValues(self)
    OTMQty = int(window.leQty_O.text())
    OTMPrc = float(window.lbOTMPrc.text())
    OTMPrem = OTMPrc * OTMQty
    ATMPrc = float(window.lbATMPrc.text())
    atmQty =  int(OTMPrem / (ATMPrc *window.lotsize))*window.lotsize
    window.leQty_A.setText(str(atmQty))




def updateAllToken(self,window):
    subscribeToken(self,window.OTMToken,'NSEFO')
    subscribeToken(self,window.ATMToken,'NSEFO')
    subscribeToken(self,window.hedgeToken,'NSEFO')
    window.isParachange = False




def getCETable(self,symbol,exp):
    # print('in getCETable',symbol,exp)
    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    fltr1 = np.asarray([exp])
    filteredarray2 = filteredarray[np.in1d(filteredarray[:, 6], fltr1)]
    filteredarray1 = filteredarray2[filteredarray2[:, 12].argsort()]
    fltr2 = np.asarray(['CE'])
    ceTable= filteredarray1[np.in1d(filteredarray1[:, 8], fltr2)]
    # print('ceTableeee',ceTable)
    return ceTable

def getPETable(self,symbol,exp):
    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    fltr1 = np.asarray([exp])
    filteredarray2 = filteredarray[np.in1d(filteredarray[:, 6], fltr1)]
    filteredarray1 = filteredarray2[filteredarray2[:, 12].argsort()][::-1]
    fltr2 = np.asarray(['PE'])
    peTable= filteredarray1[np.in1d(filteredarray1[:, 8], fltr2)]
    return peTable



def checkIsAnyPosition(self):
    isAnyOpenPos = False
    for i in self.position[:self.lastSerialNo,5]:
        if(i != 0):
            isAnyOpenPos = True
            self.isAnyOpenPos = isAnyOpenPos

            return
    self.isAnyOpenPos = isAnyOpenPos


    # if(np.unique(self.position[:self.lastSerialNo,5])==[0]):
    #     self.isAnyOpenPos = False

    # print('isANYposition',self.isAnyOpenPos)


def tradeVarification(self):
    pass

def updateOrder(self):
    pass

def orderVarification(self):
    pass

def getPrice(self, token, seg, streamType):
    data = getQuote(self, token, seg, streamType)
    bid = data['AskInfo']['Price']
    ask = data['BidInfo']['Price']
    ltp = data['LastTradedPrice']
    return {"bid": bid, "ask": ask, "ltp": ltp}


def dec_v(self,window):
    if (window.leQty_O.text() != '0'):
        newQ = int(window.leQty_O.text()) - window.lotsize

        window.leQty_O.setText(str(newQ))

def inc_v(self,window):
    # print('in inc_v',window.lotsize)

    newQ = int(window.leQty_O.text()) + window.lotsize
    window.leQty_O.setText(str(newQ))


def getCEList(self,ATMStrike):
    lowerRange= ATMStrike - ((self.lowerRangeIndex+1) *self.strikeDiff)
    upperRange= ATMStrike + ((self.upperRangeIndex+1) *self.strikeDiff)
    array1 = self.ceTable[np.where(self.ceTable[:, 12] >= lowerRange)]
    array2 = array1[np.where(array1[:, 12] <= upperRange)]
    array3 = array2[:, [2, 8, 12]]
    return array3

def getPEList(self,ATMStrike):
    lowerRange= ATMStrike - ((self.lowerRangeIndex+1) *self.strikeDiff)
    upperRange= ATMStrike + ((self.upperRangeIndex+1) *self.strikeDiff)
    array1 = self.peTable[np.where(self.peTable[:, 12] >= lowerRange)]
    array2 = array1[np.where(array1[:, 12] <= upperRange)]
    array3 = array2[:, [2, 8, 12]]
    # print(array3)
    return array3

def getExecutionTime(self):
    now = datetime.datetime.today()
    date = now.strftime('%Y-%m-%d ')
    a915 = datetime.datetime.strptime(date + '09:15:00', '%Y-%m-%d %H:%M:%S')
    a920 = datetime.datetime.strptime(date + self.etime, '%Y-%m-%d %H:%M:%S')
    self.timeout1 = int(a920.timestamp()-time.time())*1000
    return self.timeout1

def getFutureToken(self,symbol):
    futureToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 17]
    return futureToken

def getCashToken(self,symbol):
    # print(self.fo_contract)
    assetToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 9]

    # print(symbol,self.symbol,'getCashToken',assetToken)
    return assetToken
# def getHedgeToken(self,symbol):
#
#     hedgeToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0,]

def getStrikeDiff(self,futureToken):
    # print(self.fo_contract[futureToken-35000,:])
    strikeDiff = self.fo_contract[futureToken-35000,36]
    return strikeDiff

def getLotSize(self,futureToken):
    lotsize = self.fo_contract[futureToken-35000,11]
    print('futureToken',futureToken)
    print('lotsize:',lotsize)
    return lotsize

def getATM(self,cashPrice,strikeDiff):
    ATM1 = (cashPrice / strikeDiff)
    frac = ATM1 % 1

    strikeDecisionPoint = float(0.4)
    # print(frac)
    if(frac > strikeDecisionPoint):
        ATM = int(ATM1+1) * strikeDiff
    else:
        ATM= int(ATM1)  * strikeDiff
    # ATM1 = (cashPrice / strikeDiff) * strikeDiff
    return ATM



def getCEPEPrice(self ):
    try:

        # print('ppuuu')
        if(self.isFirstOrderPunch):
            window = self.modifyW
            # print('hedgeToken hedgeToken',self.hedgeToken)
            data1 = getQuote(self, self.hedgeToken, 'NSEFO', 1501)
            window.hedgeOptPrc = data1['LastTradedPrice']


        elif(self.isParameterSet):
            window = self.modifyW
            print('hedgeToken hedgeToken',self.hedgeToken)

            data1 = getQuote(self, self.hedgeToken, 'NSEFO', 1501)
            # window.hedgeOptPrc = data1['LastTradedPrice']



        else:
            window = self.addW

        if(window.visibleRegion().isEmpty() == False):
            # print(window,'llllll')
            window.cashPrice = getPrice(self=self,token=window.cashToken, seg='NSECM', streamType=1501)['ltp']
            window.futurePrice =getPrice(self=self,token=window.futureToken, seg='NSEFO', streamType=1501)['ltp']
            window.ATM = getATM(self,window.cashPrice, window.strikeDiff)

            data = getQuote(self,window.OTMToken, 'NSEFO', 1501)
            try:
                window.OTMPrice = data['LastTradedPrice']
            except:
                print('error in getQuote getCEPEPrice ')




            data1 = getQuote(self, window.ATMToken, 'NSEFO', 1501)
            window.ATMPrice = data1['LastTradedPrice']

            data = getQuote(self, window.ATM_CE_Token, 'NSEFO', 1501)
            window.atmCEPrice = data['LastTradedPrice']

            data1 = getQuote(self, window.ATM_PE_Token, 'NSEFO', 1501)
            window.atmPEPrice = data1['LastTradedPrice']            # print('xyz2')

    except:
        print(traceback.print_exc())


def updateValues(self):
    try:
        if(self.isFirstOrderPunch):
            window = self.modifyW
            window.lb_hedge_prc.setText('%.2f' % window.hedgeOptPrc)

        elif(self.isParameterSet):
            window = self.modifyW
            window.lb_hedge_Prc.setText('%.2f' % window.hedgeOptPrc)

        else:
            window= self.addW

        window.lb_ltp.setText(str(window.basePrice))
        window.lb_atm.setText(str(window.ATM))

        window.lbOTMPrc.setText('%.2f' % window.OTMPrice)
        window.lbATMPrc.setText('%.2f' % window.ATMPrice)

        window.lb_CEP.setText('%.2f' % window.atmCEPrice)
        window.lb_PEP.setText('%.2f' % window.atmPEPrice)

        if(window.leQty_O.text() != '' and  window.leQty_A.text() != ''):
            OTMQty =float(int(window.leQty_O.text()))
            ATMQty = int(window.leQty_A.text())


            OTMPrem = window.OTMPrice * OTMQty
            ATMPrem = window.ATMPrice * ATMQty

            window.lbOTM_Prem.setText('%.2f' % OTMPrem)
            window.lbATM_Prem.setText('%.2f' % ATMPrem)

    except:
        print(traceback.print_exc())

def getPrices(self):
    try:
        th = threading.Thread(target=getCEPEPrice,args=(self,))
        th.start()
    except:
        print(traceback.print_exc())





def getATM_CE_Token(self,atm,ceTable):
    try:
        ATM_CE_Token = ceTable[np.where(ceTable[:,12]==atm),2][0][0]
        return ATM_CE_Token
    except:
        print(traceback.print_exc(),'error \n###############\n','atm',atm,'ceTable',ceTable,'\n###############\n')
def getATM_PE_Token(self,atm,peTable):
    try:
        ATM_PE_Token = peTable[np.where(peTable[:,12]==atm),2][0][0]
        return ATM_PE_Token
    except:
        print(traceback.print_exc(),'error \n###############\n','atm',atm,'peTable',peTable,'\n###############\n')

