import time as ttime


import traceback
from Application.Services.Xts.Api.servicesIA import PlaceOrder
from Application.Stretegies.ValSpread.Utills.executionSupport import *
def squreOff(self):
    try:
        for i in self.position:
            token = i[1]
            exchange = i[0]
            quantity = i[5]

            # print("order SqureOffffff!!!")
            if (quantity == 0):
                pass
            elif quantity > 0:
                absQuantity = abs(quantity)
                while (absQuantity > self.freezeQty):
                    # print('if while')
                    PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Sell',
                               qty=self.freezeQty,
                               limitPrice=0.0,
                               validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                               productType='NRML')
                    ttime.sleep(0.1)
                    absQuantity -= self.freezeQty
                PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Sell',
                           qty=absQuantity,
                           limitPrice=0.0,
                           validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                           productType='NRML')
                ttime.sleep(0.1)
            else:

                absQuantity = abs(quantity)
                while (absQuantity > self.freezeQty):
                    print('else while')
                    PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Buy',
                               qty=self.freezeQty,
                               limitPrice=0.0,
                               validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                               productType='NRML')
                    ttime.sleep(0.1)
                    absQuantity -= self.freezeQty
                PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Buy',
                           qty=absQuantity,
                           limitPrice=0.0,
                           validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                           productType='NRML')

                ttime.sleep(0.1)

    except:
        print(traceback.print_exc())


def profitBook50(self):
    try:
        if (self.fullPos == True):
            for i in self.position:
                token = i[1]
                exchange = i[0]
                quantity = i[5]

                if (quantity == 0):
                    pass
                elif quantity > 0:
                    absQuantity = int(abs(quantity * 0.5) / self.lotsize) * self.lotsize
                    while (absQuantity > self.freezeQty):
                        # print('if while')
                        PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Sell',
                                   qty=self.freezeQty,
                                   limitPrice=0.0,
                                   validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                                   productType='NRML')
                        ttime.sleep(0.1)
                        absQuantity -= self.freezeQty
                    PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Sell',
                               qty=absQuantity,
                               limitPrice=0.0,
                               validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                               productType='NRML')
                    ttime.sleep(0.1)
                else:

                    absQuantity = int(abs(quantity * 0.5) / self.lotsize) * self.lotsize
                    while (absQuantity > self.freezeQty):
                        print('else while')
                        PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Buy',
                                   qty=self.freezeQty,
                                   limitPrice=0.0,
                                   validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                                   productType='NRML')
                        ttime.sleep(0.1)
                        absQuantity -= self.freezeQty
                    PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Buy',
                               qty=absQuantity,
                               limitPrice=0.0,
                               validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                               productType='NRML')

                    ttime.sleep(0.1)
            self.pb50.setEnabled(False)
            self.fullPos = False
            print("hyyyyyyyyy")
    except:
        print(traceback.print_exc())

def hedgeorder(self):

    hedgeQty =self.hedgeQty


    self.hedgeStrike = self.modifyW.cbHedgeStrike.currentText()
    if(self.optType=='CE'):
        self.hedgeToken = getATM_CE_Token(self, self.hedgeStrike, self.ceTable)
    else:
        self.hedgeToken = getATM_PE_Token(self, self.hedgeStrike, self.peTable)

    while (hedgeQty > self.freezeQty):
        PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.hedgeToken, orderSide='Buy',
                   qty=self.freezeQty,
                   limitPrice=0.0,
                   validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                   productType='NRML')
        ttime.sleep(0.1)
        hedgeQty -= self.freezeQty
    PlaceOrder(self, exchange='NSEFO', clientID=self.clientId, token=self.hedgeToken, orderSide='Buy',
               qty=hedgeQty,
               limitPrice=0.0,
               validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
               productType='NRML')
