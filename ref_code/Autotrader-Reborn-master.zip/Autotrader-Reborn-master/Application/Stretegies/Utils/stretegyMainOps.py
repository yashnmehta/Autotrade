import traceback

import numpy as np
import json
import sys
from Application.Utils.supMethods import checkIsAnyPosition, messageBoxDeleteStretegy
from PyQt5.Qt import *
from Application.Stretegies.Utils.stretegySideOps import deletedStretegyRecordUpdate
def activateStretegy(main):
    print('activateStretegy')
    selectedIndexes = main.Manager.tableView.selectedIndexes()
    folioName = selectedIndexes[3].data()
    Srno = selectedIndexes[0].data()
    try:
        for i in main.Manager.All_stretegyList:
            if (i.folioName == folioName):
                print("folioname same.....",i.folioName == folioName)
                i.makeFirstOrder()
                i.isStart = True
                checkStretegy(main)
                main.Manager.table[np.where(main.Manager.table[:,3]==i.folioName),4]='Activated'
                main.Manager.stretegyList.append(i)
                i.Slogger.info('Stretegy Activated Successfully..   %s')
                break

    except:
        print(traceback.print_exc())
        # i.Slogger.error(sys.exc_info()[1])

def checkStretegy(main):
    selectedIndexes = main.Manager.tableView.selectedIndexes()
    folioName = selectedIndexes[3].data()
    Srno = selectedIndexes[0].data()
    Status = selectedIndexes[4].data()
    if Status not in ['Activated','Started']:
        for j in main.Manager.jInfo['Today_list']['All']:
            if j['serialNo'] == Srno:
                j['Status'] = 'Active'

                main.Manager.jInfo['Today_list']['Active'].append(j)

    f2 = open(main.StInfo_location, 'w')
    jInfo_new = json.dumps(main.Manager.jInfo, indent=4)
    f2.write(jInfo_new)
    f2.close()

    ind = main.Manager.model.index(0, 0)
    ind1 = main.Manager.model.index(0, 1)
    main.Manager.model.dataChanged.emit(ind, ind1)


def resumeStretegy(main):
    print('in resumeStretegy')
    selectedIndexes = main.Manager.tableView.selectedIndexes()
    folioName = selectedIndexes[3].data()
    print("startStretegy:", folioName, main.Manager.stretegyList)

    for i in main.Manager.stretegyList:
        print("i.isStart ::", i.isStart, i.folioName)
        if(i.folioName == folioName and i.isStart == False):
            print("startStretegy: found", folioName)
            i.isStart = True
            # print("folioName:",folioName,i.isStart)
            main.Manager.table[np.where(main.Manager.table[:,3]==i.folioName),4]='Started'


            if i not in main.Manager.stretegyList:
                print('kjfkjf')
                main.Manager.stretegyList.append(i)

            ind = main.Manager.model.index(0, 0)
            ind1 = main.Manager.model.index(0, 1)
            main.Manager.model.dataChanged.emit(ind, ind1)


            i.Slogger.info('Stretegy Started Successfully.....')
            break

            # main.Manager.stretegyList.append(i)

def stopStretegy(main):
    selectedIndexes = main.Manager.tableView.selectedIndexes()

    folioName = selectedIndexes[3].data()
    # print(folioName)
    for i in main.Manager.stretegyList:
        if(i.folioName == folioName and i.isStart == True):
            i.isStart = False
            main.Manager.table[np.where(main.Manager.table[:,3]==i.folioName),4]='Stopped'

            i.Slogger.info('Stretegy Stopped Successfully.....')

            ind = main.Manager.model.index(0, 0)
            ind1 = main.Manager.model.index(0, 1)
            main.Manager.model.dataChanged.emit(ind, ind1)
            i.Slogger.info('Stretegy Stopped Successfully.....')

def deleteStretegy(main):
    selectedIndexes = main.Manager.tableView.selectedIndexes()
    folioName = selectedIndexes[3].data()
    client = selectedIndexes[2].data()
    Srno = selectedIndexes[0].data()
    # print(folioName)
    for i in main.Manager.All_stretegyList:
        if(i.folioName == folioName):
            main.IsDelete=False
            main.IsSquareOff=False

            checkIsAnyPosition(i)


            if(i.isAnyOpenPos):

                main.messageBox = QMessageBox()

                main.messageBox.setIcon(QMessageBox.Critical)
                main.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
                main.messageBox.setText('This Stretegy has Position Or Pending Order !!')
                main.messageBox.setInformativeText("Do you want to SquareOff Postion?")
                main.messageBox.setWindowTitle('Delete Stretegy')
                main.messageBox.addButton(QPushButton('SquareOff'), QMessageBox.YesRole)
                main.messageBox.addButton(QPushButton('Cancel'), QMessageBox.RejectRole)
                main.messageBox.buttonClicked.connect(main.SuareOffButtonClicked)
                main.messageBox.exec()

            else:
                messageBoxDeleteStretegy(main)

            # print('yeeejjjj')
            if main.IsDelete:
                # main.FolioPos.squareOffSelected()
                # i.squreOff()
                if main.IsSquareOff==True:
                    i.squreOff()

                i.isStart = False

                main.Manager.table[np.where(main.Manager.table[:, 3] == i.folioName), 4] = 'Deleted'
                main.deleteFolio(folioName, client)
                deletedStretegyRecordUpdate(main, i, Srno)
                main.Manager.All_stretegyList.remove(i)
                if i in main.Manager.stretegyList:
                    main.Manager.stretegyList.remove(i)

                i.Slogger.info('Stretegy Deleted Successfully.....')
                del i


                ind = main.Manager.model.index(0, 0)
                ind1 = main.Manager.model.index(0, 1)
                main.Manager.model.dataChanged.emit(ind, ind1)


            # main.Manager.table=np.delete(main.Manager.table, Srno, axis=0)
            # main.Manager.lastSerialNo -= 1
            # main.Manager.model.lastSerialNo -= 1
            #
            # main.Manager.model.rowCount()
            # main.Manager.model.DelRows()

