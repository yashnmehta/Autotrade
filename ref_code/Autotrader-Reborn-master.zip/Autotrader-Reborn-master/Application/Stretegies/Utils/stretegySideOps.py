import datetime
import json
import numpy as np
import traceback
import datatable as dt
import os
import shutil
from Application.Stretegies import TSpecial
from Application.Stretegies import Custom
from Application.Stretegies import Momentum
from Application.Stretegies.JCat import JCat
from Application.Stretegies.JodiSt import JodiST
from Application.Stretegies.OCheetah import OCheetah
from Application.Stretegies.LevelSpecial import LevelSpecial
from Application.Stretegies.ValSpread import ValSpread
from Application.Stretegies.JodiATM import JodiATM
from Application.Stretegies.PairSell import PairSell
from Application.Utils.log import createLogfile, loadLogTable
from Application.Utils.configReader import refresh
from Application.Stretegies import VixMonkey
from Application.Stretegies.JTiger import JTiger
from Application.Stretegies.EMASpecial import EMASpecial
def newStretegyRecordUpdate(main,newStretegy,symbol):
    try:
        date1 = datetime.datetime.now().strftime('%d-%b-%Y')
        isExist = False
        for i in main.Manager.jInfo['Today_list']['All']:
            print(i['FolioName'])
            if(i['FolioName']==newStretegy.folioName):
                isExist = True

        if(isExist==False):
            main.Manager.jInfo['Today_list']['All'].append(
                {"serialNo": main.Manager.lastSerialNo-1,"FolioName": newStretegy.folioName,"Date": date1,
                "StretegyType": newStretegy.stype,"clientId": newStretegy.addW.cbClient.currentText(),"symbol":symbol,"Status":"Initialized"})
            main.Manager.jInfo['lastSerialNO'] = main.Manager.lastSerialNo-1

            main.Manager.All_stretegyList.append(newStretegy)


            xj = 0
            for iz in main.Manager.stretegyList_temp:
                if (iz.addW.leFolioName.text() == newStretegy.folioName):
                    main.Manager.stretegyList_temp.pop(xj)
                xj += 1

            f2 = open(main.StInfo_location, 'w')
            jInfo_new = json.dumps(main.Manager.jInfo, indent=4)
            f2.write(jInfo_new)
            f2.close()
    except:
        print('ex',traceback.print_exc())

def setStretegyParameters(main,stretegy):
    try:
        today_str = datetime.datetime.now().strftime('%d-%b-%Y')
        addW = stretegy.addW
        modifyW = stretegy.modifyW
        abc = main.Manager.table[np.where(main.Manager.table[:,3]==addW.leFolioName.text()),0]
        # print('abc.size',abc.size)
        if(abc.size==0):
            # print(main.Manager.SerialInUse,'ssss')
            if(main.Manager.lastSerialNo in main.Manager.SerialInUse):
                main.Manager.lastSerialNo +=1

            sl = stretegy.SlAmount
            array1 = dt.Frame([[main.Manager.lastSerialNo],
                               [main.loggedInUser], [addW.cbClient.currentText()], [addW.leFolioName.text()], ['Innitialised'],
                               [0.0], [sl], [stretegy.tsl], [stretegy.targetAmt],  [stretegy.symbol],
                               ['Nutral'],[stretegy.stype], [today_str], [0.0]]).to_numpy()

            main.Manager.table[main.Manager.model.lastSerialNo, :] = array1
            main.Manager.lastSerialNo += 1
            main.Manager.model.lastSerialNo += 1
            main.Manager.model.rowCount()
            main.Manager.model.insertRows()

            ind = main.Manager.model.index(0, 0)
            ind1 = main.Manager.model.index(0, 1)
            main.Manager.model.dataChanged.emit(ind, ind1)
            main.addFolio(addW.leFolioName.text(), addW.cbClient.currentText())
            stretegy.hideAddW()
        else:
            lastSerialNo = abc[0][0]
            print('modify lastsrno', lastSerialNo)

            if (stretegy.stype == 'ValSpread' or stretegy.stype == 'JodiATM' or stretegy.stype == 'PairSell' or stretegy.stype == 'JTiger'):
                sl = stretegy.SlAmount
            else:
                sl = stretegy.SlAmount

            array1 = dt.Frame([[main.Manager.lastSerialNo],
                               [main.loggedInUser], [addW.cbClient.currentText()], [addW.leFolioName.text()], ['Innitialised'],
                               [0.0], [sl], [stretegy.tsl], [stretegy.targetAmt],  [stretegy.symbol],
                               ['Nutral'],[stretegy.stype], [today_str], [0.0]]).to_numpy()

            main.Manager.table[lastSerialNo, :] = array1

            ind = main.Manager.model.index(0, 0)
            ind1 = main.Manager.model.index(0, 1)
            main.Manager.model.dataChanged.emit(ind, ind1)
    except:
        print(traceback.print_exc())

def checkStretegiesDatectory(self):
    todayDate = datetime.datetime.today().strftime('%Y%m%d')
    loc1 = os.getcwd().split('Application')
    StretegyDataLocation = os.path.join(loc1[0], 'Application', 'DB','Stretegy_data', todayDate )
    if(os.path.isdir(StretegyDataLocation)== False):
        os.mkdir(StretegyDataLocation)

def copyActiveStretegyParameters(main):
    todayDate = datetime.datetime.today().strftime('%Y%m%d')
    loc1 = os.getcwd().split('Application')
    sourceDir = os.path.join(loc1[0], 'Application', 'DB', 'CF_data')
    destPath = os.path.join(loc1[0], 'Application', 'DB','Stretegy_data', todayDate )
    ls = os.listdir(sourceDir)
    for iz in ls:
        src_path = os.path.join(sourceDir,iz)
        shutil.copy(src_path, destPath)

def getPreviousActiveStretegies(main):

    loc1 = os.getcwd().split('Application')
    main.StInfo_location = os.path.join(loc1[0], 'Application', 'DB', 'stretwgyList.json')
    # print(info_location)
    with open(main.StInfo_location,"r") as f1:
        main.Manager.jInfo = json.load(f1)
        f1.close()
        today = main.Manager.jInfo['Today']

        today_str = datetime.datetime.now().strftime('%Y%m%d')
        if(today != today_str):
            checkStretegiesDatectory(main)
            copyActiveStretegyParameters(main)

            ################# update date ##########################
            main.Manager.jInfo['Yesterday'] = main.Manager.jInfo['Today']
            main.Manager.jInfo['Today'] = today_str
            #######################################################
            main.Manager.jInfo['lastSerialNO'] = 0
            main.Manager.jInfo['Today_list']['Active'] = []
            main.Manager.jInfo['Today_list']['All'] = []
            main.Manager.jInfo['SerialInUse'] = []

            # jInfo['Previous']['Active'] = jInfo['Today_list']['Active']
            for i in main.Manager.jInfo['Previous']['Active']:
                # main.Manager.jInfo['Today_list']['Active'].append(i)
                main.Manager.jInfo['Today_list']['All'].append(i)
                main.Manager.jInfo['SerialInUse'].append(i['serialNo'])
            # print(jInfo['Today_list']['Active'])

        else:
            # pass
            main.Manager.jInfo['Today_list']['Active'] = []

        main.Manager.SerialInUse = main.Manager.jInfo['SerialInUse']
        # print('papapa',main.Manager.SerialInUse)
        j=0

        # print(main.Manager.jInfo['Today_list']['Active'])
        for i in main.Manager.jInfo['Today_list']['All']:

            if(i['StretegyType'] == 'TSpecial'):
                newStretegy = TSpecial.TSpecial.logic()
                newStretegy.getKeyParameterFile(i['FolioName'])
                newStretegy.folioName = i['FolioName']

                newStretegy.createObject(main.fo_contract)
                newStretegy.sgFolioOpenPos.connect(main.updateFolioOpenPos)

                newStretegy.reloadKeyParameter()


                sl = newStretegy.SlAmount
                # newStretegy.modifyW.sgGetFolioBook.connect(main.stFolioBook)
                newStretegy.connect2slots()
                # newStretegy.connect2slots()


            elif(i['StretegyType'] == 'Custom'):
                newStretegy = Custom.Custom.logic()
                newStretegy.getKeyParameterFile(i['FolioName'])
                newStretegy.sgSL.connect(main.updateStSL)
                newStretegy.sgTSL.connect(main.updateStTSL)
                newStretegy.folioName = i['FolioName']

                newStretegy.createObject(main.fo_contract)
                newStretegy.sgFolioOpenPos.connect(main.updateFolioOpenPos)

                newStretegy.reloadKeyParameter()

                sl = newStretegy.sl

            elif (i['StretegyType'] == 'Momentum'):
                newStretegy = Momentum.Momentum.logic()

                newStretegy.getKeyParameterFile(i['FolioName'])
                newStretegy.folioName = i['FolioName']

                newStretegy.createObject(main.fo_contract)
                newStretegy.sgFolioOpenPos.connect(main.updateFolioOpenPos)

                newStretegy.reloadKeyParameter()

                sl = newStretegy.sl

            elif (i['StretegyType'] == 'ValSpread'):
                newStretegy = ValSpread.logic()
                newStretegy.getKeyParameterFile(i['FolioName'])
                newStretegy.folioName = i['FolioName']

                newStretegy.createObject(main.fo_contract)
                newStretegy.sgFolioOpenPos.connect(main.updateFolioOpenPos)
                newStretegy.sgSL.connect(main.updateStSL)
                newStretegy.sgTarget.connect(main.updateStTarget)


                newStretegy.reloadKeyParameter()

                sl = newStretegy.SlAmount
                newStretegy.modifyW.sgGetFolioBook.connect(main.stFolioBook)
                newStretegy.connect2slots()

            elif (i['StretegyType'] == 'JodiATM'):
                newStretegy = JodiATM.logic()
                newStretegy.getKeyParameterFile(i['FolioName'])
                newStretegy.folioName = i['FolioName']

                newStretegy.createObject(main.fo_contract)
                newStretegy.sgFolioOpenPos.connect(main.updateFolioOpenPos)

                newStretegy.reloadKeyParameter()

                sl = newStretegy.SlAmount
                newStretegy.timerGetPrices.start()
                newStretegy.timerUpdateWindows.start()

                newStretegy.sgMTM.connect(main.updateStMTM)
                newStretegy.sgSL.connect(main.updateStSL)
                newStretegy.sgTarget.connect(main.updateStTarget)

                newStretegy.sgAlert.connect(main.showMsgW)
                loadLogTable(newStretegy)

            elif (i['StretegyType'] == 'JTiger'):
                newStretegy = JTiger.logic()
                newStretegy.getKeyParameterFile(i['FolioName'])
                newStretegy.folioName = i['FolioName']

                newStretegy.createObject(main.fo_contract)
                newStretegy.sgFolioOpenPos.connect(main.updateFolioOpenPos)

                newStretegy.reloadKeyParameter()

                sl = newStretegy.SlAmount
                newStretegy.timerGetPrices.start()
                newStretegy.timerUpdateWindows.start()

                newStretegy.sgMTM.connect(main.updateStMTM)
                newStretegy.sgSL.connect(main.updateStSL)
                newStretegy.sgAlert.connect(main.showMsgW)


            elif (i['StretegyType'] == 'Vix_Monkey'):
                newStretegy = VixMonkey.VixMonkey.logic()
                newStretegy.getKeyParameterFile(i['FolioName'])
                newStretegy.folioName = i['FolioName']
                newStretegy.createObject(main.fo_contract)
                newStretegy.sgFolioOpenPos.connect(main.updateFolioOpenPos)

                newStretegy.reloadKeyParameter()

                newStretegy.sgSL.connect(main.updateStSL)
                newStretegy.sgTSL.connect(main.updateStTSL)


                sl = newStretegy.SlAmount

                # newStretegy.timerGetPrices.start()
                # newStretegy.timerUpdateWindows.start()


                newStretegy.connect2slots()

            elif (i['StretegyType'] == 'PairSell'):
                newStretegy = PairSell.logic()
                newStretegy.getKeyParameterFile(i['FolioName'])
                newStretegy.folioName = i['FolioName']
                newStretegy.createObject(main.fo_contract)
                newStretegy.sgFolioOpenPos.connect(main.updateFolioOpenPos)
                newStretegy.reloadKeyParameter()

                sl = newStretegy.SlAmount
                # signals
                newStretegy.timerGetPrices.start()
                newStretegy.timerUpdateWindows.start()

                newStretegy.sgMTM.connect(main.updateStMTM)
                newStretegy.sgSL.connect(main.updateStSL)
                # newStretegy.sgTSL.connect(main.updateStTSL)
                newStretegy.sgAlert.connect(main.showMsgW)
                # newStretegy.sgStart.connect(lambda: updateStStatus(main, newStretegy, 'Started'))
                # newStretegy.sgParamSet.connect(lambda: setStretegyParameters(main, newStretegy))
                # newStretegy.sgParamSet.connect(lambda: newStretegyRecordUpdate(main, newStretegy, newStretegy.symbol))

            elif (i['StretegyType'] == 'OCheetah'):
                newStretegy = OCheetah.logic()
                newStretegy.getKeyParameterFile(i['FolioName'])
                newStretegy.folioName = i['FolioName']

                newStretegy.createObject(main.fo_contract)
                newStretegy.sgFolioOpenPos.connect(main.updateFolioOpenPos)

                newStretegy.reloadKeyParameter()

                sl = newStretegy.SlAmount
                # newStretegy.timerGetPrices.start()
                # newStretegy.timerUpdateWindows.start()

                newStretegy.sgMTM.connect(main.updateStMTM)
                newStretegy.sgSL.connect(main.updateStSL)
                newStretegy.sgTarget.connect(main.updateStTarget)

                newStretegy.sgAlert.connect(main.showMsgW)
                loadLogTable(newStretegy)

            elif (i['StretegyType'] == 'EMASpecial'):
                newStretegy = EMASpecial.logic()
                newStretegy.getKeyParameterFile(i['FolioName'])
                newStretegy.folioName = i['FolioName']

                newStretegy.createObject(main.fo_contract)
                newStretegy.sgFolioOpenPos.connect(main.updateFolioOpenPos)

                newStretegy.reloadKeyParameter()

                sl = newStretegy.SlAmount
                # newStretegy.timerGetPrices.start()
                # newStretegy.timerUpdateWindows.start()

                newStretegy.sgMTM.connect(main.updateStMTM)
                newStretegy.sgSL.connect(main.updateStSL)
                newStretegy.sgTarget.connect(main.updateStTarget)

                newStretegy.sgAlert.connect(main.showMsgW)
                loadLogTable(newStretegy)
                # main.Manager.stretegyList.append(newStretegy)
                refresh(newStretegy)

            elif (i['StretegyType'] == 'JodiSt'):
                newStretegy = JodiST.logic()
                newStretegy.getKeyParameterFile(i['FolioName'])
                newStretegy.folioName = i['FolioName']

                newStretegy.createObject(main.fo_contract)
                newStretegy.sgFolioOpenPos.connect(main.updateFolioOpenPos)

                newStretegy.reloadKeyParameter()

                sl = newStretegy.SlAmount
                # newStretegy.timerGetPrices.start()
                # newStretegy.timerUpdateWindows.start()
                # main.Manager.stretegyList.append(newStretegy)
                newStretegy.sgMTM.connect(main.updateStMTM)
                newStretegy.sgSL.connect(main.updateStSL)
                newStretegy.sgTarget.connect(main.updateStTarget)
                loadLogTable(newStretegy)
                # newStretegy.sgAlert.connect(main.showMsgW)
                refresh(newStretegy)

            elif (i['StretegyType'] == 'JCat'):
                newStretegy = JCat.logic()
                newStretegy.getKeyParameterFile(i['FolioName'])
                newStretegy.folioName = i['FolioName']

                newStretegy.createObject(main.fo_contract)
                newStretegy.sgFolioOpenPos.connect(main.updateFolioOpenPos)

                newStretegy.reloadKeyParameter()

                sl = newStretegy.SlAmount
                # newStretegy.timerGetPrices.start()
                # newStretegy.timerUpdateWindows.start()
                # main.Manager.stretegyList.append(newStretegy)
                newStretegy.sgMTM.connect(main.updateStMTM)
                # newStretegy.sgSL.connect(main.updateStSL)
                # newStretegy.sgTarget.connect(main.updateStTarget)
                #
                # newStretegy.sgAlert.connect(main.showMsgW)
                refresh(newStretegy)

            elif (i['StretegyType'] == 'LevelSpecial'):
                newStretegy = LevelSpecial.logic()
                newStretegy.getKeyParameterFile(i['FolioName'])
                newStretegy.folioName = i['FolioName']

                newStretegy.createObject(main.fo_contract)
                newStretegy.sgFolioOpenPos.connect(main.updateFolioOpenPos)

                newStretegy.reloadKeyParameter()

                sl = newStretegy.SlAmount
                # newStretegy.timerGetPrices.start()
                # newStretegy.timerUpdateWindows.start()
                # main.Manager.stretegyList.append(newStretegy)
                newStretegy.sgMTM.connect(main.updateStMTM)
                newStretegy.sgSL.connect(main.updateStSL)
                newStretegy.sgTarget.connect(main.updateStTarget)
                loadLogTable(newStretegy)
                # newStretegy.sgAlert.connect(main.showMsgW)
                refresh(newStretegy)



            #newStretegy.fo_contract = main.fo_contract

            # print('parth')
            if(i['Status']=='Deleted'):
                status='Deleted'
            else:
                if(i['Status'] in ['Activated','Started']):
                    main.Manager.stretegyList.append(newStretegy)

                status='Fetched'
                main.Manager.All_stretegyList.append(newStretegy)
                newStretegy.sgMTM.connect(main.updateStMTM)
                createLogfile(main,newStretegy,newStretegy.folioName)
                newStretegy.Slogger.info('Stretegy Fetched Successfully..' )




            array1 = dt.Frame([[i['serialNo']],
                               [main.login.userID], [i['clientId']], [i['FolioName']],[status],[0.00] ,
                                [sl], [newStretegy.tsl],[newStretegy.targetAmt] ,[i['symbol']],['Nutral'],
                               [i['StretegyType']],[i['Date']], [0.0]]).to_numpy()


            main.Manager.table[j, :] = array1
            # main.Manager.lastSerialNo += 1
            main.Manager.model.lastSerialNo += 1
            main.Manager.model.rowCount()
            main.Manager.model.insertRows()

            ind = main.Manager.model.index(0, 0)
            ind1 = main.Manager.model.index(0, 1)
            main.Manager.model.dataChanged.emit(ind, ind1)

            if( i['Status']=='Deleted'):
                del newStretegy

            # print(newStretegy.folioName)


            main.addFolio(i['FolioName'],i['clientId'])


            j+=1


    # main.Manager.jInfo['Previous']['Active'] = []

    main.Manager.lastSerialNo = main.Manager.jInfo['lastSerialNO']
    main.Manager.lastSerialNo += 1

    f2 = open(main.StInfo_location,'w')
    jInfo_new = json.dumps(main.Manager.jInfo,indent=4)
    f2.write(jInfo_new)
    f2.close()

def deletedStretegyRecordUpdate(main,newStretegy,Srno):
    date1 = datetime.datetime.now().strftime('%d-%b-%Y')
    # print("main.Manager:strtegy",newStretegy)

    for j in main.Manager.jInfo['Today_list']['All']:

        if j['serialNo']==Srno:
            main.Manager.jInfo['Today_list']['Closed'].append(j)
            j['Status'] = 'Deleted'

    for j in main.Manager.jInfo['Today_list']['Active']:
        if j['serialNo'] == Srno:
            main.Manager.jInfo['Today_list']['Active'].remove(j)



    f2 = open(main.StInfo_location, 'w')
    jInfo_new = json.dumps(main.Manager.jInfo, indent=4)
    f2.write(jInfo_new)
    f2.close()

## ** not used
def loadEnabledStretegy(main):
    loc = os.getcwd().split('Application')[0]
    settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')

    f1 = open(settingsFilePath)
    main.statusBarSettingsJson = json.load(f1)['Statusbar']
    f1.close()

    main.enabledStretegies = main.statusBarSettingsJson['isUpdeStatusRejection']
    main.isUpdateStatusTrade = main.statusBarSettingsJson['isUpdateStatusTrade']
    main.isUpdateStatusOrder = main.statusBarSettingsJson['isUpdateStatusOrder']
    # main.isRejectionPopup = main.statusBarSettingsJson['isRejectionPopup']

def showStretegyModificationWindow(main):
    selectedIndexes = main.Manager.tableView.selectedIndexes()
    folioName = selectedIndexes[3].data()
    for i in main.Manager.All_stretegyList:
        print(i.folioName)
        if(i.folioName == folioName):
            i.modifyW.show()

def popTempStretegy(main, newStretegy):
    xj = 0
    for iz in main.Manager.stretegyList_temp:
        if (iz.addW.leFolioName.text() == newStretegy.addW.leFolioName.text()):
            main.Manager.stretegyList_temp.pop(xj)
        xj += 1
