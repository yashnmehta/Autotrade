'''
bind events
'''
from Application.Stretegies.EMASpecial.Utills.executionSupport import updateATMCEToken, updateAllToken, getBaseInfo, \
    expchange, symchange, baseChange, getBaseEma, updateCePrice, updatePePrice
from Application.Stretegies.EMASpecial.Utills.executionSupport import updateATMPEToken

def eventsBind(self):
    self.addW.pbApply.clicked.connect(self.setParameters)
    self.addW.cbSymbol.currentIndexChanged.connect(lambda: self.addW.getOptionExpiryList(self.fo_contract))
    self.modifyW.pbApply.clicked.connect(lambda :self.modifyParameter(self.modifyW))
    # self.modifyW.pbGet.clicked.connect(lambda: self.getBaseInfo(self.modifyW))
    self.addW.cbStrike_CE.currentIndexChanged.connect(lambda: updateATMCEToken(self, self.addW))
    self.addW.cbStrike_PE.currentIndexChanged.connect(lambda: updateATMPEToken(self, self.addW))
    self.modifyW.pbSetLTP.clicked.connect(lambda : self.setLTP(self.modifyW))

    self.addW.cbCF.currentIndexChanged.connect(lambda: baseChange(self, self.addW))
    self.addW.cbSymbol.currentTextChanged.connect(lambda: symchange(self, self.addW))
    self.addW.cbExp.currentTextChanged.connect(lambda: expchange(self, self.addW))
    self.addW.pbGet.clicked.connect(lambda: getBaseInfo(self, self.addW))
    self.modifyW.pbGet.clicked.connect(lambda: getBaseInfo(self, self.modifyW))
    self.addW.pbGetEma.clicked.connect(lambda : getBaseEma(self, self.addW))
    self.modifyW.pbGetEma.clicked.connect(lambda: getBaseEma(self, self.modifyW))

    self.modifyW.cbStrike_CE.currentIndexChanged.connect(lambda: updateCePrice(self, self.modifyW))
    self.modifyW.cbStrike_PE.currentIndexChanged.connect(lambda: updatePePrice(self, self.modifyW))

    # self.addW.pbGetPrices.clicked.connect(lambda: updateAllToken(self, self.addW))
