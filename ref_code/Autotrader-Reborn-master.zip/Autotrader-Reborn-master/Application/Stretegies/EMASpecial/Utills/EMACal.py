import numpy as np
import talib as ta
from Application.Services.Xts.Api.servicesMD import getOHLCData
from Application.Stretegies.EMASpecial.Utills.keyParameters import saveJson
from Application.Stretegies.EMASpecial.Utills.orderSupport import makeOrder

def EMACal(self):
    if self.isStart:
        list1 = getOHLCData(self,int(self.cashToken),1,self.candleInterval * 60)
        close = []
        for i in list1:
            data = i.split('|')
            # print("data:", data)
            if(len(data) > 3 ):
                if (data[4]):
                    close.append(float(data[4]))

        npclose = np.asarray(close)
        emadata = ta.EMA(npclose,self.candleLength)
        self.ema = round(emadata[-1], 2)
        self.finalEma = self.ema + self.finalEmaAdjPts
        print('cashPrice',self.cashPrice,'EMA :',self.ema,'finalEma :',self.finalEma,'finalEmaAdjPts :',self.finalEmaAdjPts)

        if self.orderSide == 'Buy':
            if float(self.finalEma) < float(self.cashPrice) and self.optionType != 'Call' and self.inModifyOrder == False:
                self.inCheckTradeOrder = True
                if self.isFirstOrderPunch == False:
                    self.finalEmaAdjPts = self.EmaAdjPts
                else:
                    makeOrder(self, self.peToken, self.baseQty, self.revOrderSide)

                makeOrder(self, self.ceToken, self.baseQty, self.orderSide)
                self.isFirstOrderPunch = True
                self.optionType = 'Call'
                self.Slogger.info(f"Call {self.orderSide}")
                self.inCheckTradeOrder = False
                saveJson(self)

            elif float(self.finalEma) > float(self.cashPrice) and self.optionType != 'Put' and self.inModifyOrder == False:
                self.inCheckTradeOrder = True
                if self.isFirstOrderPunch == False:
                    self.finalEmaAdjPts = -self.EmaAdjPts
                else:
                    makeOrder(self, self.ceToken, self.baseQty, self.revOrderSide)

                makeOrder(self, self.peToken, self.baseQty, self.orderSide)
                self.isFirstOrderPunch = True
                self.optionType = 'Put'
                self.Slogger.info(f"Put {self.orderSide}")
                self.inCheckTradeOrder = False
                saveJson(self)

        elif self.orderSide == 'Sell':
            if float(self.finalEma) < float(self.cashPrice) and self.optionType != 'Put' and self.inModifyOrder == False:
                self.inCheckTradeOrder = True
                if self.isFirstOrderPunch == False:
                    self.finalEmaAdjPts = self.EmaAdjPts
                else:
                    makeOrder(self, self.ceToken, self.baseQty, self.revOrderSide)

                makeOrder(self,self.peToken,self.baseQty,self.orderSide)
                self.isFirstOrderPunch = True
                self.optionType = 'Put'
                self.Slogger.info(f"Put {self.orderSide}")
                self.inCheckTradeOrder = False
                saveJson(self)

            elif float(self.finalEma) > float(self.cashPrice) and self.optionType != 'Call' and self.inModifyOrder == False:
                self.inCheckTradeOrder = True
                if self.isFirstOrderPunch == False:
                    self.finalEmaAdjPts = -self.EmaAdjPts
                else:
                    makeOrder(self, self.peToken, self.baseQty, self.revOrderSide)

                makeOrder(self,self.ceToken,self.baseQty,self.orderSide)
                self.isFirstOrderPunch = True
                self.optionType = 'Call'
                self.Slogger.info(f"Call {self.orderSide}")
                self.inCheckTradeOrder = False
                saveJson(self)

    else:
        self.timerEMACal.stop()