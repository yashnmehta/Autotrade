import numpy as np
def addOrderToInactiveOMS(self, appOrderIdList, token, qty,leavesQuantity,cumulativeQuantity, optionType,orderSide, strike,cpAppOrderIdList, orderTag, avgPrice,orderStatus='Placed'):
    print("addOrderToInactiveOMS:", appOrderIdList)
    for j,appOrder in enumerate(appOrderIdList):
        fltr = np.asarray([appOrder])
        filteredArray = self.inactiveOMS[np.in1d(self.inactiveOMS[:, 1], fltr)]

        # cpAOID = cpAppOrderIdList[j]
        print("filteredArray:",filteredArray, self.iomslastOrderSerialNo, filteredArray.size)
        self.inactiveOMS[self.iomslastOrderSerialNo, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]] = np.array(
            [self.iomslastOrderSerialNo,
             appOrder, orderTag, token, optionType, orderSide,
             strike, orderStatus, qty, cumulativeQuantity, leavesQuantity, avgPrice])
        print("inactiveOMS ==> " , self.inactiveOMS)
        if (filteredArray.size == 0):
            self.iomslastOrderSerialNo +=1

def addSLOrderToInactiveOMS(self, appOrderIdList, token, qty,leavesQuantity,cumulativeQuantity, optionType,orderSide, strike,cpAppOrderIdList, orderTag, avgPrice,orderStatus='Placed'):
    print("addOrderToInactiveOMS:", appOrderIdList)
    for j,appOrder in enumerate(appOrderIdList):
        fltr = np.asarray([appOrder])
        filteredArray = self.inactiveOMS[np.in1d(self.inactiveOMS[:, 1], fltr)]
        # cpAOID = cpAppOrderIdList[j]
        print("filteredArray:",filteredArray, self.iomslastOrderSerialNo, filteredArray.size)
        self.inactiveOMS[self.iomslastOrderSerialNo, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]] = np.array(
            [self.iomslastOrderSerialNo,
             appOrder, orderTag, token, optionType, orderSide,
             strike, orderStatus, qty, cumulativeQuantity, leavesQuantity, avgPrice])
        if (filteredArray.size == 0):
            self.iomslastOrderSerialNo +=1

def addTargetOrderToInactiveinactiveOMS(self, appOrderIdList, token, qty,leavesQuantity,cumulativeQuantity, optionType,orderSide, strike,cpAppOrderIdList, orderTag, avgPrice,orderStatus='Placed'):
    print("addOrderToInactiveOMS:", appOrderIdList)
    for j, appOrder in enumerate(appOrderIdList):
        fltr = np.asarray([appOrder])
        filteredArray = self.inactiveOMS[np.in1d(self.inactiveOMS[:, 1], fltr)]
        # cpAOID = cpAppOrderIdList[j]
        print("filteredArray:", filteredArray, self.iomslastOrderSerialNo, filteredArray.size)
        self.inactiveOMS[self.iomslastOrderSerialNo, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]] = np.array(
            [self.iomslastOrderSerialNo,
             appOrder, orderTag, token, optionType, orderSide,
             strike, orderStatus, qty, cumulativeQuantity, leavesQuantity, avgPrice])
        if (filteredArray.size == 0):
            self.iomslastOrderSerialNo += 1

def getinactiveOMSRecord(self, appOrderId):
    appOrderIdList = [appOrderId]
    print("getinactiveOMSRecord")
    for j,appOrder in enumerate(appOrderIdList):
        fltr = np.asarray([appOrder])
        filteredArray = self.inactiveOMS[np.in1d(self.inactiveOMS[:, 1], fltr)]
        print("getinactiveOMSRecord ,", filteredArray)
        return filteredArray