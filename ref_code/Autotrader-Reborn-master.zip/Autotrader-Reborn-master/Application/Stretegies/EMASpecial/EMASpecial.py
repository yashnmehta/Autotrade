import os
import threading
import traceback

import json
from PyQt5.QtCore import QObject,QTimer,pyqtSignal
from PyQt5.QtGui import QKeySequence

from Application.Stretegies.EMASpecial.Utills.squareOff import squreOff
from Application.Stretegies.EMASpecial.Views.addW import addW
from Application.Stretegies.EMASpecial.Views.modifyW import modifyW
import numpy as np
import datatable as dt
from Application.Services.Xts.Api.servicesIA import PlaceOrder
import datetime
import time
from Application.Services.Xts.Api.servicesMD import getQuote
from Application.Utils.configReader import refresh
from Application.Stretegies.EMASpecial.Utills.keyParameters import reloadKeyParameter, getKeyParameterFile, saveJson, \
    createKeyParameterJson
from Application.Stretegies.EMASpecial.Utills.eventsBind import eventsBind
from Application.Stretegies.EMASpecial.Utills.timer import createTimer
from Application.Stretegies.EMASpecial.Utills.positionSupport import *
from Application.Stretegies.EMASpecial.Utills.orderSupport import *
from Application.Stretegies.EMASpecial.Utills.executionSupport import *
# from Application.Stretegies.EMASpecial.Utills.checkTrade import *
from Application.Stretegies.EMASpecial.Utills.setParameters import *
from Application.Stretegies.EMASpecial.Utills.inactiveOMSSupport import *
from Application.Stretegies.EMASpecial.Utills.strategyOp import addNew

class logic(QObject):
    sgMTM = pyqtSignal(str,float)
    sgSL = pyqtSignal(str, float)
    sgAlert = pyqtSignal(str)
    sgParamSet = pyqtSignal()
    sgParamModify = pyqtSignal()
    sgStart = pyqtSignal()
    sgActivate =pyqtSignal()
    sgStop = pyqtSignal()
    sgClose =pyqtSignal()
    sgFolioOpenPos = pyqtSignal(list)
    sgTarget = pyqtSignal(str, float)
    sgSlPts = pyqtSignal(str, float)
    sgtrendPts = pyqtSignal(str, float)
    sgRevPts = pyqtSignal(str, float)
    ################################# Intialization Here ##################################################
    def __init__(self):
        super(logic, self).__init__()

        self.position = np.zeros((100, 15), dtype=object)
        # print("ffffff",self.position )
        self.posHeads = ['exch',
                         'token', 'symbol', 'strike', 'c/p', 'netqty',
                         'requestedOrder', 'openOrder', 'netamt', 'ltp', 'mtm',
                         'OpenQty', 'OpenAmt', 'DQty', 'Damt']

        self.addW = addW(self)
        self.modifyW = modifyW(self)
        # self.setAllShortCut()
        self.initVaribles()

    def flushTradeData(self):
        self.position = np.zeros((100,11),dtype=object)
    def initVaribles(self):
        self.stype = 'EMASpecial'
        self.isStart = False
        self.isClose = False
        self.isFirstOrderPunch = False
        self.isParameterSet = False
        self.executionRunning =False
        self.isAnyOpenPos = False
        self.lastSerialNo = 0

        self.lastOrderPoint = 0
        self.isSlHitOnce = False
        self.isAnyOpenPos = False
        self.cashPrice = 0.0
        self.futurePrice = 0.0
        self.ATM = 0.0
        self.baseStrike = 0.0
        self.basePrice = 0.0
        self.strikeDiff = 0.0
        self.pairTotal = 0.0
        self.incrQty = 0
        self.baseQty = 0

        self.orderSide = ''
        self.revOrderSide = ''

        self.maxQty = 0
        self.tsl = 0.0
        self.SlAmount = 0
        self.targetAmount = 0
        self.ceHighPrice = 0
        self.peHighPrice = 0
        self.candleLength =0
        self.candleInterval =0
        self.liveCashPrice = False
        self.lhQty = 0
        self.mtm = 0.0
        self.lastOrderSerialNo = 0
        self.iomslastOrderSerialNo = 0
        self.OMS = []
        self.inactiveOMS = []
        self.cePrice = 0.0
        self.pePrice = 0.0
        self.EmaAdjPts = 0.0
        self.finalEmaAdjPts = 0.0

        self.inCheckTradeOrder = False
        self.inModifyOrder = False

        self.lotsize = 0
        self.DOI = datetime.datetime.today().strftime('%d%m%Y')



        self.tokenList = [0, 0, 0, 0, 0, 0]
        """        # tokenlist  
                            0 cashToken  
                            1 futureToken
                            2 Actual ATM CE
                            3 Actual ATM PE
                            4 ATM CE Token
                            5 ATM PE Token                                
        """
    # def setAllShortCut(self):
    #     # print("parthhhhhhhhhhhhh")
    #     self.addW.leQty.sc_up = QShortcut(QKeySequence('Up'),self.addW.leQty)
    #     self.addW.leQty.sc_up.setContext(Qt.WidgetWithChildrenShortcut)
    #     self.addW.leQty.sc_up.activated.connect(lambda:inc_v(self,self.addW))
    #     self.addW.leQty.sc_down = QShortcut(QKeySequence('Down'), self.addW.leQty)
    #     self.addW.leQty.sc_down.setContext(Qt.WidgetWithChildrenShortcut)
    #     self.addW.leQty.sc_down.activated.connect(lambda :dec_v(self,self.addW))
    #
    #
    #     self.modifyW.leQty.sc_up = QShortcut(QKeySequence('Up'),self.modifyW.leQty)
    #     self.modifyW.leQty.sc_up.setContext(Qt.WidgetWithChildrenShortcut)
    #     self.modifyW.leQty.sc_up.activated.connect(lambda:inc_v(self,self.modifyW))
    #     self.modifyW.leQty.sc_down = QShortcut(QKeySequence('Down'), self.modifyW.leQty)
    #     self.modifyW.leQty.sc_down.setContext(Qt.WidgetWithChildrenShortcut)
    #     self.modifyW.leQty.sc_down.activated.connect(lambda:dec_v(self,self.modifyW))

    def createTimer(self):
        createTimer(self)


    def createObject(self,fo_contract):
        try:
            self.fo_contract=fo_contract

            refresh(self)
            refresh(self.addW)
            refresh(self.modifyW)
            fltr = np.asarray(['OPTSTK', 'OPTIDX'])
            self.addW.t = self.fo_contract[np.in1d(self.fo_contract[:, 5], fltr)]
            self.modifyW.t = self.fo_contract[np.in1d(self.fo_contract[:, 5], fltr)]
            lsSymbol = np.unique(self.addW.t[:, 3])
            self.addW.cbSymbol.addItems(lsSymbol)
            self.addW.cbSymbol.setCurrentText('BANKNIFTY')
            self.modifyW.cbSymbol.addItems(lsSymbol)
            self.modifyW.cbSymbol.setCurrentText('BANKNIFTY')

            symchange(self, self.addW)
            symchange(self, self.modifyW)
            expchange(self, self.addW)
            expchange(self, self.modifyW)
            getOptionExpiryList(self, self.addW)
            getOptionExpiryList(self, self.modifyW)

            eventsBind(self)
            self.createTimer()
        except:
            print(traceback.print_exc())

    def reloadKeyParameter(self):
        try:
            reloadKeyParameter(self)
        except:
            print(traceback.print_exc())

    def checkTrade(self,priceFeed):
        if self.isStart:
            if self.liveCashPrice:
                if self.cashToken == priceFeed['Token']:
                    self.cashPrice = priceFeed['LTP']


    def checkSL(self):
        if(self.isSlHitOnce==False and self.SlAmount != 0 ):
            if(self.mtm<=self.SlAmount):
                print('trgger sl', self.mtm, self.SlAmount)
                self.isSlHitOnce = True
                self.squreOff()
                print("SQureOf Parthhhhhhh!!!! ")
                d = {'MTM': self.mtm, 'SlAmount': self.SlAmount}
                self.Slogger.info('SL Trigger (mtm>Slamt)....', d)

    def checkTarget(self):
        pass
        # if (self.isSlHitOnce == False):
        #
        #     if (self.mtm >= self.targetAmount):
        #         self.isSlHitOnce = True
        #         self.squreOff()
        #
        #         d = {'MTM': self.mtm, 'SlAmount': self.targetAmount}
        #         self.Slogger.info('Target Trigger (mtm>targetAmt)....', d)

    def updateMTM(self,data):
        if(self.isAnyOpenPos == True):
            if (data['Token'] in self.position[:,1]):
                fltr0 = np.asarray([data['Token']])
                array = self.position[np.in1d(self.position[:, 1], fltr0)][0]
                # print(array)
                netAmt = array[8]
                ltp = data['LTP']
                qty = array[5]
                mtm = netAmt + (qty * ltp)
                self.position[np.in1d(self.position[:, 1], fltr0),[9,10]] = [ltp,mtm]
                # print(self.position[np.in1d(self.position[:, 1], fltr0)][0])
                total_mtm = np.sum(self.position[:,10])
                self.mtm = total_mtm
                self.sgMTM.emit(self.folioName,total_mtm)
                # print('emited')
                self.modifyW.leMTM.setText('%.2f'%total_mtm)
                self.checkSL()
                self.checkTarget()


    def setParameters(self):
        setParameters(self,self.addW)


    def setLTP(self, window):
        self.cashPrice = float(window.leLTP.text())
        print("self.cashPrice:", self.cashPrice)
        self.cePrice = float(window.lbCEPrice.text())
        self.pePrice = float(window.lbPEPrice.text())
        # print("cashPrice:", self.cashPrice, "lst order point:", self.lastOrderPoint)

    def modifyParameter(self,window):
        print('modifyParameter')
        try:
            if self.inCheckTradeOrder == False:
                self.inModifyOrder = True
                self.finalEmaAdjPts = float(window.leEmaAdjPts.text())

                newQty = int(window.leQty.text())
                qty = abs(newQty - self.baseQty)

                window.ceStrikeIndex = window.cbStrike_CE.currentIndex()
                window.peStrikeIndex = window.cbStrike_PE.currentIndex()

                if self.optionType == 'Call':
                    if window.ceStrikeIndex != self.ceStrikeIndex:
                        makeOrder(self, self.ceToken, self.baseQty, self.revOrderSide)

                        window.ceStrike = self.ATM + ((window.ceStrikeIndex) * self.strikeDiff)
                        window.ceToken = self.ceTable[np.where(self.ceTable[:, 12] == window.ceStrike), 2][0][0]
                        self.ceToken = window.ceToken
                        self.tokenList[4] = window.ceToken
                        self.ceStrike = window.ceStrike
                        self.ceStrikeIndex = window.ceStrikeIndex

                        makeOrder(self, self.ceToken, newQty, self.orderSide)

                    else:
                        if newQty > self.baseQty:
                            makeOrder(self,self.ceToken,qty,self.orderSide)

                        elif newQty < self.baseQty:
                            makeOrder(self, self.ceToken, qty, self.revOrderSide)

                if self.optionType == 'Put':
                    if window.peStrikeIndex != self.peStrikeIndex:
                        makeOrder(self, self.peToken, self.baseQty, self.revOrderSide)

                        window.peStrike = self.ATM + ((window.peStrikeIndex) * self.strikeDiff)
                        window.peToken = self.peTable[np.where(self.peTable[:, 12] == window.peStrike), 2][0][0]
                        self.peToken = window.peToken
                        self.tokenList[5] = window.peToken
                        self.peStrike = window.peStrike
                        self.peStrikeIndex = window.peStrikeIndex

                        makeOrder(self, self.peToken, newQty, self.orderSide)

                    else:
                        if newQty > self.baseQty:
                            makeOrder(self, self.peToken, qty, self.orderSide)

                        elif newQty < self.baseQty:
                            makeOrder(self, self.peToken, qty, self.revOrderSide)

                if window.ceStrikeIndex != self.ceStrikeIndex:
                    window.ceStrike = self.ATM + ((window.ceStrikeIndex) * self.strikeDiff)
                    window.ceToken = self.ceTable[np.where(self.ceTable[:, 12] == window.ceStrike), 2][0][0]
                    self.ceToken = window.ceToken
                    self.tokenList[4] = window.ceToken
                    self.ceStrike = window.ceStrike
                    self.ceStrikeIndex = window.ceStrikeIndex

                if window.peStrikeIndex != self.peStrikeIndex:
                    window.peStrike = self.ATM + ((window.peStrikeIndex) * self.strikeDiff)
                    window.peToken = self.peTable[np.where(self.peTable[:, 12] == window.peStrike), 2][0][0]
                    self.peToken = window.peToken
                    self.tokenList[5] = window.peToken
                    self.peStrike = window.peStrike
                    self.peStrikeIndex = window.peStrikeIndex

                self.baseQty = newQty

                self.candleInterval = int(window.leCandleInterval.text())

                self.candleLength = int(window.leCandleLength.text())

                self.SlAmount = float(window.leSLAmount.text())
                self.sgSL.emit(self.folioName, self.SlAmount)

                self.inModifyOrder = False
                saveJson(self)
                self.hideModifyW()

        except:
            traceback.print_exc()

    def setParametersModify(self,window):
        setParametersModify(self,window)

    def saveJson(self, cf = False):
        saveJson(self, cf)
    def getKeyParameterFile(self, folioName):
        getKeyParameterFile(self, folioName)

    def addNew(self, main):
        return addNew(self,main)

    def updateTrade(self, trade, source='on_trade'):

        # print('in update position stretegy,',trade)
        if (source == "on_trade"):
            trade1 = trade[0]
        else:
            trade1 = trade
        # print(" Pairsel  update trade:,",trade1)
        # print(self.folioName, trade1)

        if (trade1[15] == self.folioName):

            exchange = trade1[20]
            token = trade1[2]
            fltr0 = np.asarray([token])
            filteredArray0 = self.position[np.in1d(self.position[:, 1], fltr0)]
            isRecordExist = False
            if (filteredArray0.size != 0):
                isRecordExist = True

            if (isRecordExist):
                array = self.position[np.where(self.position[:, 1] == token)]
                # print('in is record exist',array)
                prev_qty = array[0][5]
                prev_amt = array[0][8]

                Prev_Dqty = array[0][13]
                Prev_Damt = array[0][14]

                Dqty = Prev_Dqty + trade1[18]
                DAmt = Prev_Damt + trade1[19]

                newQty = prev_qty + trade1[18]
                newAmt = prev_amt + trade1[19]

                self.position[np.where(self.position[:, 1] == token), [5, 8, 13, 14]] = [newQty, newAmt, Dqty, DAmt]

                # print('updated position dekh lo',self.position)
            else:
                new = dt.Frame([[exchange],
                                [token], [trade1[4]], [float(trade1[6])], [trade1[7]], [trade1[18]],
                                [0], [0], [trade1[19]], [trade1[17]], [0.0],
                                [0.0], [0.0], [trade1[18]], [trade1[19]]
                                ]).to_numpy()


                self.position[self.lastSerialNo, :] = new
                self.lastSerialNo += 1

            checkIsAnyPosition(self)


            # saveJson(self)

    def tradeVarification(self):
        pass

    def updateOrder(self,order, orderDict):
        pass
        # updateOrder(self, orderDict)

    def orderVarification(self):
        pass


    def makeFirstOrder(self):
        makeFirstOrder(self)


    def getPrice(self, token, seg, streamType):
        data = getQuote(self, token, seg, streamType)
        bid = data['AskInfo']['Price']
        ask = data['BidInfo']['Price']
        ltp = data['LastTradedPrice']
        return {"bid": bid, "ask": ask, "ltp": ltp}


    def getExecutionTime(self):
        now = datetime.datetime.today()
        date = now.strftime('%Y-%m-%d ')
        a915 = datetime.datetime.strptime(date + '09:15:00', '%Y-%m-%d %H:%M:%S')
        a920 = datetime.datetime.strptime(date + self.etime, '%Y-%m-%d %H:%M:%S')
        self.timeout1 = int(a920.timestamp()-time.time())*1000
        return self.timeout1



    def getStrikeDiff(self,futureToken):
        # print(self.fo_contract[futureToken-35000,:])
        strikeDiff = self.fo_contract[futureToken-35000,36]
        return strikeDiff

    def hideAddW(self):
        try:
            self.timerUpdateWindows.stop()
            self.addW.hide()
        except:
            print(traceback)
    def hideModifyW(self):
        self.timerUpdateWindows.stop()
        self.modifyW.hide()

    def updateWindows(self, feed,window):
        priceToken = feed['Token']
        # print(self.tokenList,"priceTokennnn")
        # print("cashFut",window.cashFut)

        # print("9999", window.cashFut)
        if (window.isParachange == False):
            if (window.visibleRegion().isEmpty() == False):

                if (priceToken == self.tokenList[0]):
                    if (window.cashFut == 'CASH'):
                        window.BaseToken = window.cashToken
                        window.cashPrice = feed['LTP']
                        window.basePrice = window.cashPrice
                        if (self.isFirstOrderPunch == False):
                            ATM = getATM(self, window.basePrice, window.strikeDiff)
                            if (ATM != window.ATM):
                                window.ATM = ATM
                                window.lb_atm.setText(str(window.ATM))
                                window.ATM_CE_Token = getATM_CE_Token(self, window.ATM)
                                window.ATM_PE_Token = getATM_PE_Token(self, window.ATM)
                                self.tokenList[2] = window.ATM_CE_Token
                                self.tokenList[3] = window.ATM_PE_Token
                                # window.basePrice = window.cashPrice

                        window.lb_ltp.setText(str(window.basePrice))
                        self.cashPrice  =window.basePrice
                        # print("LTP",self.cashPrice)



                elif (priceToken == self.tokenList[1]):
                    if (window.cashFut != 'CASH'):
                        window.BaseToken = window.futureToken
                        window.futurePrice = feed['LTP']
                        window.basePrice = window.futurePrice
                        ATM = getATM(self, window.basePrice, window.strikeDiff)
                        if (self.isFirstOrderPunch == False):
                            if (ATM != window.ATM):
                                window.ATM = ATM
                                window.lb_atm.setText(str(window.ATM))
                                window.ATM_CE_Token = getATM_CE_Token(self, window.ATM)
                                window.ATM_PE_Token = getATM_PE_Token(self, window.ATM)
                                self.tokenList[2] = window.ATM_CE_Token
                                self.tokenList[3] = window.ATM_PE_Token

                        window.lb_ltp.setText(str(window.cashPrice))
                        # print("LTP",window.lb_ltp)


                elif (priceToken == self.tokenList[2]):
                    window.CEPrice = feed['LTP']
                    window.lb_CEP.setText('%.2f' % window.CEPrice)
                    # print("hssssssssssssshhhhhh")
                    if (priceToken == self.tokenList[4]):
                        window.ATMCEPrice = feed['LTP']
                        window.lbATMCE.setText('%.2f' % window.ATMCEPrice)

                elif (priceToken == self.tokenList[3]):
                    window.PEPrice = feed['LTP']
                    window.lb_PEP.setText('%.2f' % window.PEPrice)
                    if (priceToken == self.tokenList[5]):
                        window.ATMPEPrice = feed['LTP']
                        window.lbATMPE.setText('%.2f' % window.ATMPEPrice)

                elif (priceToken == self.tokenList[4]):
                    window.ATMCEPrice = feed['LTP']
                    window.lbATMCE.setText('%.2f' % window.ATMCEPrice)

                elif (priceToken == self.tokenList[5]):
                    window.ATMPEPrice = feed['LTP']
                    window.lbATMPE.setText('%.2f' % window.ATMPEPrice)

    def getCEPEPrice(self):
        try:
            # print('xyz1')
            data = getQuote(self,self.addW.ATM_CE_Token, 'NSEFO', 1501)
            self.addW.atmCEPrice = data['LastTradedPrice']

            data1 = getQuote(self, self.addW.ATM_PE_Token, 'NSEFO', 1501)
            self.addW.atmPEPrice = data1['LastTradedPrice']
            # print('xyz2')
        except:
            print(traceback.print_exc())

    def updateValues(self):
        try:

            print('abc')

            self.addW.lb_ltp_cash.setText(str(self.addW.cashPrice))
            self.addW.lb_ltp_fo.setText(str(self.addW.futurePrice))
            self.addW.lb_atm.setText(str(self.addW.ATM))
            self.addW.lbCEPrice.setText(str(self.addW.cePrice))
            self.addW.lbPEPrice.setText(str(self.addW.pePrice))

            self.addW.ATM_CE_Token=self.getATM_CE_Token(self.addW.ATM,self.addW.ceTable)
            self.addW.ATM_PE_Token=self.getATM_PE_Token(self.addW.ATM,self.addW.peTable)

            pairTotal = self.addW.atmPEPrice + self.addW.atmCEPrice
            # self.addW.lb_pTotal.setText('%.2f'%pairTotal)
        except:
            print(traceback.print_exc())

    def getPrices(self):
        try:
            th = threading.Thread(target=self.getCEPEPrice,args=())
            th.start()
        except:
            print(traceback.print_exc())

    def getBaseInfo(self, window):
        getBaseInfo(self, window)
        # getBaseInfo(self)

    def getBasePrices(self):
        try:
            data = getQuote(self, self.addW.cashToken, 'NSECM', 1501)
            self.addW.cashPrice=data['LastTradedPrice']
            data = getQuote(self, self.addW.futureToken, 'NSEFO', 1501)
            self.addW.futurePrice=data['LastTradedPrice']

            self.addW.ATM = self.getATM(self.addW.cashPrice,self.addW.strikeDiff)

            self.addW.ceTable = self.getCETable(self.addW.symbol,self.addW.expiry)
            self.addW.peTable = self.getPETable(self.addW.symbol,self.addW.expiry)
            self.updateValues()
        except:
            print(traceback.print_exc())

    def flushTradeData(self):
        self.position = np.zeros((100,11),dtype=object)


    def checkShortPosExist(self,array):
        isPos =False
        # print('array',array)
        for i in array[0]:
            if(i < 0):
                isPos = True
                return isPos
        return isPos

    def getStrikeOT(self,token):
        data=self.fo_contract[token-35000,:]
        return data[7],data[8]

    def squreOff(self):
        squreOff(self)
