
import numpy as np
import traceback
from Application.Services.Xts.Api.servicesMD import getQuote
import datetime, time
import threading
def getBaseInfo(self, window):
    try:
        window.symbol = window.cbSymbol.currentText()
        window.expiry = window.cbExp.currentText()
        window.cashToken = getCashToken(self, window.symbol)

        window.futureToken = getFutureToken(self, window.symbol)
        window.strikeDiff = getStrikeDiff(self, window.futureToken)

        data = getQuote(self, window.cashToken, 'NSECM', 1501)
        window.cashPrice = data['LastTradedPrice']
        data = getQuote(self, window.futureToken, 'NSEFO', 1501)
        window.futurePrice = data['LastTradedPrice']
        # Print('cash',window.cashPrice,'future',window.futurePrice,window.strikeDiff)
        window.ATM = getATM(self, window.cashPrice, window.strikeDiff)

        # print('golkia',window.ATM)
        window.ceTable = getCETable(self, window.symbol, window.expiry)
        window.peTable = getPETable(self, window.symbol, window.expiry)

        window.ceStrikeIndex = window.cbCEIndex.currentIndex()
        window.peStrikeIndex = window.cbPEIndex.currentIndex()

        window.ceStrike = window.ATM + ((window.ceStrikeIndex + 1) * window.strikeDiff)
        window.peStrike = window.ATM - ((window.peStrikeIndex + 1) * window.strikeDiff)
        print("strike:", window.ceStrike, window.peStrike)
        window.ceToken = window.ceTable[np.where(window.ceTable[:, 12] == window.ceStrike), 2][0][0]
        window.peToken = window.peTable[np.where(window.peTable[:, 12] == window.peStrike), 2][0][0]
        print("Token:", window.ceToken, window.peToken)
        data = getQuote(self, window.ceToken, 'NSEFO', 1501)
        window.CEPrice = data['LastTradedPrice']

        data = getQuote(self, window.peToken, 'NSEFO', 1501)
        window.PEPrice = data['LastTradedPrice']

        window.lb_ltp_cash.setText(str(window.cashPrice))
        window.lb_ltp_fo.setText(str(window.futurePrice))
        window.lb_atm.setText(str(window.ATM))

        window.lbCEPrice.setText(str(window.CEPrice))
        window.lbPEPrice.setText(str(window.PEPrice))

        window.ATM_CE_Token = getATM_CE_Token(self, window.ATM, window.ceTable)
        window.ATM_PE_Token = getATM_PE_Token(self, window.ATM, window.peTable)

        dataCE = getQuote(self, window.ATM_CE_Token, 'NSEFO', 1501)
        window.atmCEPrice = dataCE['LastTradedPrice']

        dataPE = getQuote(self, window.ATM_PE_Token, 'NSEFO', 1501)
        window.atmPEPrice = dataPE['LastTradedPrice']

        pairTotal = window.atmPEPrice + window.atmCEPrice
        # window.lb_pTotal.setText('%.2f' % pairTotal)

        window.adjPts = float(window.leAdjPts.text())
        adjCashprice = float(window.lb_ltp_cash.text()) + window.adjPts
        # window.lbAdjCashP.setText('%.2f' % adjCashprice)

        print('window.ATM_CE_Token', window.ATM_CE_Token, 'window.ATM_PE_Token', window.ATM_PE_Token)

    except:
        print('error',traceback.print_exc())

def getCETable(self,symbol,exp):

    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    fltr1 = np.asarray([exp])
    filteredarray2 = filteredarray[np.in1d(filteredarray[:, 6], fltr1)]

    filteredarray1 = filteredarray2[filteredarray2[:, 12].argsort()]
    fltr2 = np.asarray(['CE'])
    ceTable= filteredarray1[np.in1d(filteredarray1[:, 8], fltr2)]

    return ceTable


def getPETable(self,symbol,exp):
    fltr = np.asarray([symbol])
    filteredarray = self.fo_contract[np.in1d(self.fo_contract[:, 3], fltr)]
    fltr1 = np.asarray([exp])
    filteredarray2 = filteredarray[np.in1d(filteredarray[:, 6], fltr1)]
    filteredarray1 = filteredarray2[filteredarray2[:, 12].argsort()][::-1]
    fltr2 = np.asarray(['PE'])
    peTable= filteredarray1[np.in1d(filteredarray1[:, 8], fltr2)]
    return peTable

def getATM_CE_Token(self,atm,ceTable):
    ATM_CE_Token = ceTable[np.where(ceTable[:,12]==atm),2][0][0]
    return ATM_CE_Token

def getATM_PE_Token(self,atm,peTable):
    ATM_PE_Token = peTable[np.where(peTable[:,12]==atm),2][0][0]
    return ATM_PE_Token

def getCEList(self,ATMStrike):
    lowerRange= ATMStrike - ((self.lowerRangeIndex+1) *self.strikeDiff)
    upperRange= ATMStrike + ((self.upperRangeIndex+1) *self.strikeDiff)
    array1 = self.ceTable[np.where(self.ceTable[:, 12] >= lowerRange)]
    array2 = array1[np.where(array1[:, 12] <= upperRange)]
    array3 = array2[:, [2, 8, 12]]
    return array3

def getPEList(self,ATMStrike):
    lowerRange= ATMStrike - ((self.lowerRangeIndex+1) *self.strikeDiff)
    upperRange= ATMStrike + ((self.upperRangeIndex+1) *self.strikeDiff)
    array1 = self.peTable[np.where(self.peTable[:, 12] >= lowerRange)]
    array2 = array1[np.where(array1[:, 12] <= upperRange)]
    array3 = array2[:, [2, 8, 12]]
    # print(array3)
    return array3

def getExecutionTime(self):
    now = datetime.datetime.today()
    date = now.strftime('%Y-%m-%d ')
    a915 = datetime.datetime.strptime(date + '09:15:00', '%Y-%m-%d %H:%M:%S')
    a920 = datetime.datetime.strptime(date + self.etime, '%Y-%m-%d %H:%M:%S')
    self.timeout1 = int(a920.timestamp()- time.time())*1000
    return self.timeout1

def getFutureToken(self,symbol=''):
    futureToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 17]
    return futureToken

def getCashToken(self,symbol=''):
    # print(self.fo_contract)
    assetToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 9]

    # print(symbol,self.symbol,'getCashToken',assetToken)
    return assetToken

def getStrikeDiff(self,futureToken):
    # print(self.fo_contract[futureToken-35000,:])
    strikeDiff = self.fo_contract[futureToken-35000,36]
    return strikeDiff

def checkIsAnyPosition(self):
    isAnyOpenPos = False
    for i in self.position[:self.lastSerialNo,5]:
        if(i != 0):
            isAnyOpenPos = True
            self.isAnyOpenPos = isAnyOpenPos

            return
    self.isAnyOpenPos = isAnyOpenPos
def updateValues(self):
    try:
        if (self.isFirstOrderPunch):
            window = self.modifyW
        elif (self.isParameterSet):
            window = self.modifyW
        else:
            window = self.addW

        # getCEPEPrice(self)
        if (window.visibleRegion().isEmpty() == False):

            window.lb_ltp_cash.setText(str(window.cashPrice))
            window.lb_ltp_fo.setText(str(window.futurePrice))
            window.lb_atm.setText(str(window.ATM))

            window.ATM_CE_Token=getATM_CE_Token(self,window.ATM,window.ceTable)
            window.ATM_PE_Token=getATM_PE_Token(self,window.ATM,window.peTable)

            # pairTotal = window.atmPEPrice + window.atmCEPrice
            # window.lb_pTotal.setText('%.2f'%pairTotal)

            window.lbCEPrice.setText(str(window.atmCEPrice))
            window.lbPEPrice.setText(str(window.atmPEPrice))

    except:
        print(traceback.print_exc())

def getCEPEPrice(self):
    try:
        # print("(self.isFirstOrderPunch)",self.isFirstOrderPunch)
        # print("(self.isParameterSet)", self.isParameterSet)
        if (self.isFirstOrderPunch):
            window = self.modifyW
            a='modify'
        elif (self.isParameterSet):
            window = self.modifyW
            a='modify'

        else:
            window = self.addW
            a='add'

        if (window.visibleRegion().isEmpty() == False):
            # print(window,'llllll')
            # print(a)
            window.cashPrice = getPrice(self=self, token=window.cashToken, seg='NSECM', streamType=1501)['ltp']
            window.futurePrice = getPrice(self=self, token=window.futureToken, seg='NSEFO', streamType=1501)['ltp']
            window.ATM = getATM(self, window.cashPrice, window.strikeDiff)

            data = getQuote(self,window.ATM_CE_Token, 'NSEFO', 1501)
            window.atmCEPrice = data['LastTradedPrice']

            data1 = getQuote(self, window.ATM_PE_Token, 'NSEFO', 1501)
            window.atmPEPrice = data1['LastTradedPrice']
           # print('xyz2')
    except:
        print(traceback.print_exc())
def getATM(self,cashPrice,strikeDiff):
    ATM1 = (cashPrice / strikeDiff)
    frac = ATM1 % 1
    # ** NOTE  : need to chge below
    strikeDecisionPoint = 0.5 #float(self.addW.leLowerPoint.text())
    # print(frac)
    if(frac > strikeDecisionPoint):
        ATM = int(ATM1+1) * strikeDiff
    else:
        ATM= int(ATM1)  * strikeDiff
    # ATM1 = (cashPrice / strikeDiff) * strikeDiff
    return ATM

def getPrice(self, token, seg, streamType):

    data = getQuote(self, token, seg, streamType)
    ltp = data['LastTradedPrice']
    try:
        bid = data['AskInfo']['Price']
        ask = data['BidInfo']['Price']
    except:
        bid = 0.00
        ask = 0.00
    return {"bid": bid, "ask": ask, "ltp": ltp}
def getPrices(self):
    try:
        th = threading.Thread(target=getCEPEPrice,args=(self,))
        th.start()
    except:
        print(traceback.print_exc())

def setParametersModifyW(self):
    try:

        self.modifyW.SlAmount = float(self.addW.leSLAmount.text())
        self.modifyW.targetAmount = float(self.addW.leTargetAmount.text())
        self.modifyW.folioName = self.addW.leFolioName.text()

        self.modifyW.clientId = self.addW.cbClient.currentText()
        self.modifyW.symbol = self.addW.cbSymbol.currentText()
        self.modifyW.expiry = self.addW.cbExp.currentText()

        self.modifyW.cashToken = getCashToken(self, self.symbol)
        self.modifyW.futureToken = getFutureToken(self, self.symbol)
        self.modifyW.strikeDiff = getStrikeDiff(self, self.futureToken)
        self.modifyW.freezeQty = int(self.fo_contract[self.futureToken - 35000, 14])

        # print('freezeQty',self.freezeQty)

        self.modifyW.ceTable = getCETable(self, self.symbol, self.expiry)
        self.modifyW.peTable = getPETable(self, self.symbol, self.expiry)
        self.modifyW.cashPrice = getPrice(self, token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
        self.modifyW.futurePrice = getPrice(self, token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']

        self.modifyW.ATM = getATM(self, self.cashPrice, self.strikeDiff)
        # print("ATM:", self.ATM, self.cashPrice, self.strikeDiff)
        # print("ceTable:", self.ceTable)

        self.modifyW.ceToken = getATM_CE_Token(self, self.ATM, self.ceTable)
        self.modifyW.peToken = getATM_PE_Token(self, self.ATM, self.peTable)
        self.modifyW.ATM_PE_Token = self.modifyW.ceToken
        self.modifyW.ATM_CE_Token = self.modifyW.peToken
        ###################################


        self.modifyW.cbSymbol.addItem(self.symbol)
        self.modifyW.cbExp.addItem(self.expiry)
        self.modifyW.leFolioName.setText(self.folioName)
        self.modifyW.cbClient.addItem(self.clientId)
        self.modifyW.leQty.setText(str(self.baseQty))
        self.modifyW.leMaxQty.setText(str(self.maxQty))
        self.modifyW.leIncQty.setText(str(self.incrQty))
        self.modifyW.leSLAmount.setText(str(self.SlAmount))
        self.modifyW.leTargetAmount.setText(str(self.targetAmount))
        self.modifyW.lb_ltp_cash.setText(self.addW.lb_ltp_cash.text())
        self.modifyW.lb_ltp_fo.setText(self.addW.lb_ltp_fo.text())
        self.modifyW.lb_atm.setText(self.addW.lb_atm.text())
        # self.modifyW.lbCEPrice.setText(str(self.addW.CEPrice))
        # self.modifyW.lbPEPrice.setText(str(self.addW.PEPrice))
        # self.modifyW.lb_pTotal.setText(self.addW.lb_pTotal.text())
        self.modifyW.leAdjPts.setText( str(self.adjPts))
        self.modifyW.cbCEIndex.setCurrentIndex(self.ceStrikeIndex)
        self.modifyW.cbPEIndex.setCurrentIndex(self.peStrikeIndex)

        self.modifyW.leSLPoint.setText(str(self.slPts))
        self.modifyW.leTargetPts1.setText(str(self.targetPts1))
        self.modifyW.leTargetPts2.setText(str(self.targetPts2))
        self.modifyW.leTargetPts3.setText(str(self.targetPts3))
        self.modifyW.leLowerPoint.setText(str(self.strikeDecisionPoint))
        self.modifyW.lbBaseStrike.setText(str(self.baseStrike))
        self.modifyW.lbLastOrderPoint.setText(str(self.lastOrderPoint))

        # self.modifyW.lbPEPrice.setText(str(self.modifyW.atmPEPrice))
        # self.modifyW.lbCEPrice.setText(str(self.modifyW.atmCEPrice))
        print("modify adjPts:", self.adjPts)
        self.modifyW.leAdjPts.setText( str(self.adjPts))
        #self.modifyW.leRMTM.setText(str(self.))

    except:
        print(traceback.print_exc())
