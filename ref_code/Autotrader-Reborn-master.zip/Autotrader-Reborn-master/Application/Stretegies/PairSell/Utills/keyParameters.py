import json
import datetime
import os
import numpy as np
import traceback
from Application.Stretegies.PairSell.Utills.executionSupport import *

'''
To save key parameters to json file
'''
def saveJson(self,cf=False):
    getKeyParameterFile(self,self.folioName)
    createKeyParameterJson(self,cf)
    file = open(self.keyParameterFile, 'w')
    jInfo_new = json.dumps(self.keyParameterJson, indent=4)
    file.write(jInfo_new)
    file.close()

'''
create key parameters
'''
def createKeyParameterJson(self,cf):
    if (cf):

        open_pos =self.position[:self.lastSerialNo, :].tolist()
        OMS = self.OMS[:self.lastSerialNo, :].tolist()
        inactiveOMS = self.inactiveOMS[:self.lastSerialNo, :].tolist()
        DOI=self.DOI
    else:
        open_pos = [[]]
        DOI = datetime.datetime.today().strftime('%d%m%Y')
        # OMS = [[]]
        # inactiveOMS = [[]]
        # open_pos = self.position[:self.lastSerialNo, :].tolist()
        OMS = self.OMS[:self.lastSerialNo, :].tolist()
        inactiveOMS = self.inactiveOMS[:self.lastSerialNo, :].tolist()
    self.keyParameterJson = {
        "folioName": self.folioName,
        "stype": self.stype,
        "symbol": self.symbol,
        "expiry": self.expiry,
        'clientId' : self.clientId,
        'isFirstOrderPunch':self.isFirstOrderPunch,
        'isAnyOpenPos':self.isAnyOpenPos,

        "cashToken" : self.cashToken,
        "futureToken" : self.futureToken,
        "strikeDiff" : self.strikeDiff,
        "ceToken" : self.ceToken,
        "peToken" : self.peToken,
        "freezeQty" : self.freezeQty,
        "qty" : self.baseQty,
        "SlAmount" : self.SlAmount,
        "targetAmount" : self.targetAmount,
        "trend" : self.trend,
        "lastSerialNo" :  self.lastSerialNo,
        "adjPts" : self.adjPts,
        "ATM" : self.ATM,
        "ceStrikeIndex":self.ceStrikeIndex,
        "peStrikeIndex":self.peStrikeIndex,
        "slPts":self.slPts,
        "targetPts1":self.targetPts1,
        "targetPts2":self.targetPts2,
        "targetPts3":self.targetPts3,
        "maxQty":self.maxQty,
        "strikeDecisionPoint": self.strikeDecisionPoint,
        "incrQty" : self.incrQty,
        "baseStrike" : self.baseStrike,
        "lastOrderPoint": self.lastOrderPoint,
        "lhQty" : self.lhQty,
        "OMS" : OMS,
        "inactiveOMS" : inactiveOMS,
        'open_position': open_pos,
        'DateOfInitialization': DOI,
        "iomslastOrderSerialNo" : self.iomslastOrderSerialNo,
        "lastOrderSerialNo" : self.lastOrderSerialNo
    }
 
'''
fetch key parameters
'''
def getKeyParameterFile(self,folioName):
    todate = datetime.datetime.today().strftime('%Y%m%d')
    loc = os.getcwd().split('Application')
    self.keyParameterFile = os.path.join(loc[0], 'Application', 'DB', 'Stretegy_data', todate,
                                         '%s.json' % folioName)
'''
reload key parameters from file
'''
def reloadKeyParameter(self):
    try:
        # fetch json object from  file
        file = open(self.keyParameterFile)
        self.keyParameterJson = json.load(file)
        file.close()
        # assign parameters
        self.stype = self.keyParameterJson['stype']
        self.symbol = self.keyParameterJson['symbol']
        self.expiry = self.keyParameterJson['expiry']
        self.clientId = self.keyParameterJson['clientId']
        self.folioName = self.keyParameterJson['folioName']
        self.isFirstOrderPunch = self.keyParameterJson['isFirstOrderPunch']
        self.isAnyOpenPos = self.keyParameterJson['isAnyOpenPos']

        self.OMS = np.asarray(self.keyParameterJson['OMS'])
        self.inactiveOMS = np.asarray(self.keyParameterJson['inactiveOMS'])
        self.cashToken = self.keyParameterJson['cashToken']
        self.futureToken = self.keyParameterJson['futureToken']
        self.strikeDiff = self.keyParameterJson['strikeDiff']
        self.ceToken = self.keyParameterJson['ceToken']
        self.peToken = self.keyParameterJson['peToken']
        self.freezeQty = self.keyParameterJson['freezeQty']
        self.baseQty = self.keyParameterJson['qty']
        self.SlAmount = self.keyParameterJson['SlAmount']
        self.targetAmount = self.keyParameterJson['targetAmount']
        self.trend = self.keyParameterJson['trend']
        self.lastSerialNo = self.keyParameterJson['lastSerialNo']
        self.lastOrderSerialNo = self.keyParameterJson['lastOrderSerialNo']
        self.iomslastOrderSerialNo = self.keyParameterJson['iomslastOrderSerialNo']
        self.adjPts = self.keyParameterJson['adjPts']
        self.ATM = self.keyParameterJson['ATM']
        self.ceStrikeIndex = self.keyParameterJson['ceStrikeIndex']
        self.peStrikeIndex = self.keyParameterJson['peStrikeIndex']
        self.slPts = self.keyParameterJson['slPts']
        self.targetPts1 = self.keyParameterJson['targetPts1']
        self.targetPts2 = self.keyParameterJson['targetPts2']
        self.targetPts3 = self.keyParameterJson['targetPts3']
        self.strikeDecisionPoint = self.keyParameterJson['strikeDecisionPoint']
        self.maxQty = self.keyParameterJson['maxQty']
        self.incrQty = self.keyParameterJson['incrQty']
        self.baseStrike = self.keyParameterJson['baseStrike']
        self.lastOrderPoint = self.keyParameterJson['lastOrderPoint']
        self.DOI = self.keyParameterJson['DateOfInitialization']
        # assign Pairsell core variables
        self.cashToken = getCashToken(self, self.symbol)
        self.futureToken = getFutureToken(self, self.symbol)
        self.strikeDiff = getStrikeDiff(self, self.futureToken)
        self.freezeQty = int(self.fo_contract[self.futureToken - 35000, 14])
        print("self.symbol, self.expiry:",self.symbol, self.expiry)
        self.ceTable = getCETable(self, self.symbol, self.expiry)
        self.peTable = getPETable(self, self.symbol, self.expiry)

        self.ceStrike = self.ATM + ((self.ceStrikeIndex + 1) * self.strikeDiff)
        self.peStrike = self.ATM - ((self.peStrikeIndex + 1) * self.strikeDiff)
        print("strike:", self.ceStrike, self.peStrike)
        print("self.ceTable:", self.ceTable)
        self.ceToken = self.ceTable[np.where(self.ceTable[:, 12] == self.ceStrike), 2][0][0]
        self.peToken = self.peTable[np.where(self.peTable[:, 12] == self.peStrike), 2][0][0]
        self.cashPrice = getPrice(self, token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
        self.futurePrice = getPrice(self, token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']

        if (self.keyParameterJson['open_position'] != []):
            self.open_position = np.asarray(self.keyParameterJson['open_position'])
            updateOpenPos(self)

        setParametersModifyW(self)

    except:
        print(traceback.print_exc())


def updateOpenPos(self):

    for i in self.open_position:
        # print(i)
        # fltr = [i[1]]
        rowarray = np.where(self.position[:self.lastSerialNo, 1]== i[1])[0]




        if(rowarray.size!=0):

            rowNO=rowarray[0]

            filteredArray = self.position[np.where(self.position[:self.lastSerialNo, 1] == i[1])][0]

            openQty=i[5] + filteredArray[5]
            openamt=i[8] +filteredArray[8]

            editList=[5,8,11,12,13,14]
            self.position[rowNO, editList] = [openQty,openamt,openQty,openamt,0.0,0.0]

        else:
            self.position[self.lastSerialNo]=[i[0],i[1],i[2],i[3],i[4],i[5],i[6],i[7],i[8],i[9],i[10],i[5],i[8],0.0,0.0]
            self.lastSerialNo+=1

        checkIsAnyPosition(self)
        print("i[5]:", i[5], type(i[5]))
        if(i[5]>0):
            sellQ=i[5]
            buyQ=0
        else:
            sellQ = 0
            buyQ = i[5]
        data=[self.userID,self.clientId, self.stype,self.folioName,i[0],i[1],'stockname',i[2],self.expiry,i[3],i[4],i[5],0.0,
              i[5],i[8],0.0,buyQ,0.0,sellQ,0.0,0.0,0.0, self.lotsize,self.freezeQty,i[8],0,0.0]
        self.sgFolioOpenPos.emit(data)