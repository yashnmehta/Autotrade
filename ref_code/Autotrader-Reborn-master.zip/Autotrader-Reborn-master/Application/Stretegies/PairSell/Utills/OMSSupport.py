import numpy as np
def addOrderToOMS(self, appOrderIdList, token, qty, optionType,orderSide, strike,cpAppOrderIdList, orderTag, filledQty,pendingQty,status = "Placed"):
    print("-------addOrderToOMS------------")
    for j,appOrder in enumerate(appOrderIdList):
        fltr = np.asarray([appOrder])
        filteredArray = self.OMS[np.in1d(self.OMS[:, 1], fltr)]
        cpAOID = cpAppOrderIdList[j]
        print("filteredArray.size : ", filteredArray.size, filteredArray.size == 0, cpAOID, type(self.lastOrderSerialNo))
        if (filteredArray.size == 0):
            self.OMS[self.lastOrderSerialNo,[0,1,2,3,4,5,6,7,8,21,22]] = [self.lastOrderSerialNo,
                                  appOrder,orderTag,token,optionType,orderSide,
                                  strike,status,qty,cpAOID,'OPEN'
                                  ]
            self.lastOrderSerialNo +=1
        else:
            self.OMS[self.lastOrderSerialNo, [2,7,8,9, 21, 22]] = [orderTag, status,filledQty,pendingQty,cpAOID, 'OPEN' ]

        print("-------end * addOrderToOMS------------")
def addSLOrderToOMS(self, appOrderIdList, token, qty, optionType,orderSide, strike, orderTag, mainAppOrderId,slPrice,slTriggerPrice):

    for j,appOrder in enumerate(appOrderIdList):
        fltr = np.asarray([appOrder])
        filteredArray = self.OMS[np.in1d(self.OMS[:, 1], fltr)]
        if (filteredArray.size == 0):
            self.OMS[self.lastOrderSerialNo,[0,1,2,3,4,5,6,7,8,12,13,23]] = [self.lastOrderSerialNo,
                                  appOrder,orderTag,token,optionType,orderSide,
                                  strike,'Placed',qty,slPrice,slTriggerPrice,mainAppOrderId
                                  ]
            self.lastOrderSerialNo +=1
        else:
            self.OMS[self.lastOrderSerialNo, [8, 12, 13, 20]] = [qty, slPrice, slTriggerPrice, mainAppOrderId
                 ]

def addTargetOrderToOMS(self, appOrderIdList, token, qty, optionType,orderSide, strike, orderTag, mainAppOrderId,targetPrice, targetTriggerPrice,targetLeg):

    for j,appOrder in enumerate(appOrderIdList):
        fltr = np.asarray([appOrder])
        filteredArray = self.OMS[np.in1d(self.OMS[:, 1], fltr)]
        if (filteredArray.size == 0):
            self.OMS[self.lastOrderSerialNo,[0,1,2,3,4,5,6,7,8,13,14,17,18]] = [self.lastOrderSerialNo,
                                  appOrder,orderTag,token,optionType,orderSide,
                                  strike,'Placed',qty,targetPrice, targetTriggerPrice,mainAppOrderId,targetLeg
                                  ]
            self.lastOrderSerialNo +=1
        else:
            self.OMS[self.lastOrderSerialNo, [8, 13, 14,18, 20]] = [qty, targetPrice, targetTriggerPrice, targetLeg,mainAppOrderId
                 ]

def getOMSRecord(self, appOrderId):
    appOrderIdList = [appOrderId]
    filteredArray = []
    for j,appOrder in enumerate(appOrderIdList):
        fltr = np.asarray([appOrder])
        filteredArray = self.OMS[np.in1d(self.OMS[:, 1], fltr)]
    return filteredArray