# from Application.Utils.supMethods import *
# from Application.Stretegies.Utils.stretegySideOps import setStretegyParameters, newStretegyRecordUpdate
def addNew(self,main):
    self.createObject(main.fo_contract)
    folioName = str(main.Manager.lastSerialNo) + '_PairSell'
    print("folioName : ", folioName)
    self.addW.leFolioName.setText(folioName)
    self.addW.cbClient.addItems(main.client_list)
    self.modifyW.leFolioName.setText(folioName)
    self.modifyW.cbClient.addItems(main.client_list)
    self.getBaseInfo(self.addW)
    self.addW.show()

    # self.timerUpdateWindows.start()
    # self.timerGetPrices.start()

    self.sgMTM.connect(main.updateStMTM)
    self.sgAlert.connect(main.showMsgW)
    return folioName