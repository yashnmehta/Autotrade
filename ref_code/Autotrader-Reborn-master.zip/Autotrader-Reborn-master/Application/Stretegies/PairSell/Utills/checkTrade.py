
from Application.Stretegies.PairSell.Utills.keyParameters import reloadKeyParameter, getKeyParameterFile, saveJson
from Application.Stretegies.PairSell.Utills.positionSupport import *
from Application.Stretegies.PairSell.Utills.orderSupport import *
from Application.Stretegies.PairSell.Utills.executionSupport import *
from Application.Stretegies.PairSell.Utills.positionSupport import *
def checkTrade(self, priceFeed):
    if (self.isStart):
        priceToken = priceFeed['Token']
        if (self.cashToken == priceToken):
            # cashPrice = priceFeed['LTP']
            # self.cashPrice = cashPrice
            # print('cashPrice',cashPrice,'lastOrderPoint',self.lastOrderPoint)
            if (self.cashPrice >= (self.lastOrderPoint + self.strikeDiff)):
                # print('in if ')\
                # store last order point
                print("********Bullish********")
                self.ATM +=  self.strikeDiff
                print("Atm :", self.ATM)

                ceStrike = self.ATM + (self.strikeDiff * (self.ceStrikeIndex))
                peStrike = self.ATM + (self.strikeDiff * (self.peStrikeIndex))
                print("strike : ", ceStrike, peStrike)
                ceToken = fetchToken(self.ceTable,ceStrike)
                peToken = fetchToken(self.peTable,peStrike)
                # print("TOken : ", ceToken,peToken)
                # fetch position

                ceOrderQty = getOrderQty(self, ceToken)
                peOrderQty = getOrderQty(self, peToken)
                # print("existing : ", ceOrderQty, peOrderQty)
                if (ceOrderQty != 0):
                    makeOrder(self, ceToken, ceOrderQty, "Sell", )

                if (peOrderQty != 0):
                    makeOrder(self, peToken, peOrderQty, "Sell", )

                # self.lhQty = qtyToOrder
                self.lastOrderPoint = self.cashPrice
                saveJson(self)

                d = {'cashPrice': self.cashPrice, 'strikeDiff': self.strikeDiff, 'lastOrderPoint': self.lastOrderPoint}
                self.Slogger.info('checkTrade (cashPrice >= (lastOrderPoint + strikeDiff))....', d)
                print("****************")

            elif (self.cashPrice <= (self.lastOrderPoint - self.strikeDiff)):
                self.ATM -= self.strikeDiff
                print("*********Bearish*******")
                print("Atm :", self.ATM)
                ceStrike = self.ATM - (self.strikeDiff * (self.ceStrikeIndex))
                peStrike = self.ATM - (self.strikeDiff * (self.peStrikeIndex))
                print("strike : ", ceStrike, peStrike)
                ceToken = fetchToken(self.ceTable,ceStrike)
                peToken = fetchToken(self.peTable,peStrike)
                print("TOken : ", ceToken, peToken)
                # fetch position
                ceOrderQty = getOrderQty(self,ceToken)
                peOrderQty = getOrderQty(self,peToken)
                print("Order QTY : ", ceOrderQty, peOrderQty)
                if (ceOrderQty != 0):
                    makeOrder(self, ceToken, ceOrderQty, "Sell", )

                if (peOrderQty != 0):
                    makeOrder(self, peToken, peOrderQty, "Sell", )

                # self.lhQty = qtyToOrder
                self.lastOrderPoint = self.cashPrice
                saveJson(self)

                d = {'cashPrice': self.cashPrice, 'strikeDiff': self.strikeDiff, 'lastOrderPoint': self.lastOrderPoint}
                self.Slogger.info('checkTrade (cashPrice < (lastOrderPoint - strikeDiff))....', d)
                print("*******************")


def getOrderQty(self, token):
    ind = abs(self.baseStrike - self.ATM)/self.strikeDiff
    print("ind:", ind, "baseQty:", self.baseQty)
    initOQty = self.baseQty + (ind * self.incrQty)
    print("initOQty:", initOQty, "lhQty:", self.lhQty)
    if(initOQty>self.maxQty):
        initOQty = self.maxQty
    elif(initOQty<self.lhQty):
        initOQty = self.lhQty
    else:
        self.lhQty = initOQty

    # print("after init qty:", initOQty)

    existingQty = abs(fetchTokenQuantity(self, token))
    # print("existingQty:", existingQty)
    return  initOQty - existingQty