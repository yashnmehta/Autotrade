import traceback

import numpy as np
from PyQt5.QtCore import *
from Application.Stretegies.PairSell.Utills.keyParameters import reloadKeyParameter, getKeyParameterFile, saveJson
from Application.Stretegies.PairSell.Utills.executionSupport import *
from PyQt5.QtWidgets import *
def setParameters(self):
    try:
        self.baseQty = int(self.addW.leQty.text())
        self.maxQty = int(self.addW.leMaxQty.text())
        print("QTY :::::::::::", self.baseQty)
        if (self.baseQty <= 0 and self.maxQty <= 0):
            self.messageBox = QMessageBox()
            self.messageBox.setIcon(QMessageBox.Critical)
            self.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
            self.messageBox.setText('Quantity must be greater than zero!!')
            self.messageBox.show()
        else:
            # assign values
            self.folioName = self.addW.leFolioName.text()
            self.clientId = self.addW.cbClient.currentText()
            self.symbol = self.addW.cbSymbol.currentText()
            self.expiry = self.addW.cbExp.currentText()
        self.Base = self.addW.cbCF.currentText()
        # self.BaseToken = self.addW.BaseToken

        self.cashToken = getCashToken(self, self.symbol)
        self.futureToken = getFutureToken(self, self.symbol)
        self.strikeDiff = getStrikeDiff(self, self.futureToken)
        self.freezeQty = int(self.fo_contract[self.futureToken - 35000, 14])
        self.lotsize = int(self.fo_contract[self.futureToken - 35000, 11])

        self.cashPrice = getPrice(self, token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
        self.futurePrice = getPrice(self, token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']

        self.ceStrikeIndex = self.addW.cbCEIndex.currentIndex()
        self.peStrikeIndex = self.addW.cbPEIndex.currentIndex()
        self.incrQty = int(self.addW.leIncQty.text())
        self.slPts = float(self.addW.leSLPoint.text())
        self.targetPts1 = float(self.addW.leTargetPts1.text())
        self.targetPts2 = float(self.addW.leTargetPts2.text())
        self.targetPts3 = float(self.addW.leTargetPts3.text())
        self.strikeDecisionPoint = float(self.addW.leLowerPoint.text())
        self.lhQty = self.baseQty

        self.SlAmount = float(self.addW.leSLAmount.text())
        self.targetAmount = float(self.addW.leTargetAmount.text())

        getKeyParameterFile(self, self.folioName)
        # self.isExecuteOnTimer = self.addW.cxbPunchOnETime.isChecked()
        self.adjPts = float(self.addW.leAdjPts.text())
        #

        print("self.symbol, self.expiry:", self.symbol, self.expiry)
        self.ceTable = getCETable(self, self.symbol, self.expiry)
        self.peTable = getPETable(self, self.symbol, self.expiry)
        print(":", self.ceTable, self.peTable)
        self.ATM = getATM(self, self.cashPrice, self.strikeDiff)
        print("ATM:", self.ATM)
        self.ceStrike = self.ATM + ((self.ceStrikeIndex) * self.strikeDiff)
        self.peStrike = self.ATM - ((self.peStrikeIndex) * self.strikeDiff)
        print("strike:", self.ceStrike, self.peStrike)
        self.ceToken = self.ceTable[np.where(self.ceTable[:, 12] == self.ceStrike), 2][0][0]
        self.peToken = self.peTable[np.where(self.peTable[:, 12] == self.peStrike), 2][0][0]
        print("token:", self.ceToken, self.peToken)
        self.baseStrike = self.ATM
        self.heads = ['serialNo',
                      'appOrderId', 'orderTag','token','optionType', 'orderSide',
                      'strike','status','orderQty','fillQty', 'pendingQty',
                      'avgPrice','slPrice','tslPrice', 'targetPrice', 'slAOID',
                      'slStatus','targetAOID','targetLeg', 'targetStatus','targetQty',
                      'cpOrderId', 'cpStatus','primaryAOID'
                      ]
        # exchange
        self.lastOrderSerialNo = 0
        self.OMS = np.zeros((500, 24), dtype=object)

        #### Inactive OMS
        self.inactiveOMS = np.zeros((500, 23), dtype=object)
        self.iomslastOrderSerialNo = 0
        setParametersModifyW(self)
        # print("dfff:",self.keyParameterJson)
        saveJson(self)

        print(" -*******-**----------")
        print(self.clientId, self.folioName)
        print(" -*******-**----------")

        # self.cashPrice = self.getPrice(token=self.cashToken, seg='NSECM', streamType=1501)['ltp']
        # self.futurePrice = self.getPrice(token=self.futureToken, seg='NSEFO', streamType=1501)['ltp']
        # self.ATM = self.getATM(self.cashPrice, self.strikeDiff)

        self.sgParamSet.emit()
    except:
        print(traceback.print_exc())