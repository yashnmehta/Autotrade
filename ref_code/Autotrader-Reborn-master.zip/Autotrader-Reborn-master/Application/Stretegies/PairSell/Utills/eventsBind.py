'''
bind events
'''

def eventsBind(self):
    self.addW.pbApply.clicked.connect(self.setParameters)
    self.addW.pbGet.clicked.connect(lambda : self.getBaseInfo(self.addW))
    self.modifyW.pbApply.clicked.connect(self.modifyParameter)
    self.modifyW.pbGet.clicked.connect(lambda: self.getBaseInfo(self.modifyW))

    self.modifyW.pbSetLTP.clicked.connect(lambda : self.setLTP(self.modifyW))
