import logging
import sys
import traceback
from os import path, getcwd
import threading
import time
import requests
import json
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import uic
import qdarkstyle
import qtpy
from Application.Utils.configReader import *
from Application.Views.titlebar import tBar
from Theme.dt2 import  dt1
import platform

class modifyW(QMainWindow):
    def __init__(self, parent= None):
        super(modifyW, self).__init__(parent=None)
        self.setObjectName('addParameter')

        #####################################################################

        loc1 = getcwd().split('Application')
        # print(loc1)
        ui_login = os.path.join(loc1[0] ,'Application','Stretegies','PairSell','UI','modify.ui')
        uic.loadUi(ui_login, self)
        dark_stylesheet = qdarkstyle.load_stylesheet_pyqt5()


        self.setStyleSheet(dt1)
        QSizeGrip(self.irGrip)
        osType = platform.system()

        if (osType == 'Darwin'):
            flags = Qt.WindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        else:
            flags = Qt.WindowFlags(Qt.SubWindow | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setWindowFlags(flags)
        self.pbCancel.clicked.connect(self.hide)

        self.title = tBar('MODIFY PARAMETER')
        self.headerFrame.layout().addWidget(self.title, 0, 0)
        self.title.sgPoss.connect(self.movWin)
        self.updateValues()
        self.connectAllSlots()
        # self.movWin()
        self.createShortcuts()



    def updateValues(self):
        self.lb_ltp_cash.setText('')
        self.lb_ltp_fo.setText('')
        self.lb_atm.setText('')
        # self.lb_pTotal.setText('')



    def movWin(self, x, y):
        self.move(self.pos().x() + x, self.pos().y() + y)

    def connectAllSlots(self):
        self.bt_close.clicked.connect(self.hide)
        self.bt_min.clicked.connect(self.hide)

    def createShortcuts(self):
        self.quitSc = QShortcut(QKeySequence('Esc'), self)
        self.quitSc.activated.connect(self.hide)





if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = modifyW()
    form.show()
    sys.exit(app.exec_())
