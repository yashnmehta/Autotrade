import os
import threading
import traceback

import json
from PyQt5.QtCore import QObject,QTimer,pyqtSignal
from Application.Stretegies.PairSell.Views.addW import addW
from Application.Stretegies.PairSell.Views.modifyW import modifyW
import numpy as np
import datatable as dt
from Application.Services.Xts.Api.servicesIA import PlaceOrder
import datetime
import time
from Application.Services.Xts.Api.servicesMD import getQuote
from Application.Utils.configReader import refresh
from Application.Stretegies.PairSell.Utills.keyParameters import reloadKeyParameter, getKeyParameterFile, saveJson
from Application.Stretegies.PairSell.Utills.eventsBind import eventsBind
from Application.Stretegies.PairSell.Utills.timer import createTimer
from Application.Stretegies.PairSell.Utills.positionSupport import *
from Application.Stretegies.PairSell.Utills.orderSupport import *
from Application.Stretegies.PairSell.Utills.executionSupport import *
from Application.Stretegies.PairSell.Utills.checkTrade import *
from Application.Stretegies.PairSell.Utills.setParameters import *
from Application.Stretegies.PairSell.Utills.inactiveOMSSupport import *
from Application.Stretegies.PairSell.Utills.strategyOp import addNew

class logic(QObject):
    sgMTM = pyqtSignal(str,float)
    sgSL = pyqtSignal(str, float)
    sgAlert = pyqtSignal(str)
    sgParamSet = pyqtSignal()
    sgStart = pyqtSignal()
    sgActivate =pyqtSignal()
    sgStop = pyqtSignal()
    sgClose =pyqtSignal()
    sgFolioOpenPos = pyqtSignal(list)
    ################################# Intialization Here ##################################################
    def __init__(self):
        super(logic, self).__init__()

        self.position = np.zeros((100, 15), dtype=object)
        self.posHeads = ['exch',
                         'token', 'symbol', 'strike', 'c/p', 'netqty',
                         'requestedOrder', 'openOrder', 'netamt', 'ltp', 'mtm',
                         'OpenQty', 'OpenAmt', 'DQty', 'Damt']

        self.addW = addW(self)
        self.modifyW = modifyW(self)
        self.initVaribles()

    def flushTradeData(self):
        self.position = np.zeros((100,11),dtype=object)
    def initVaribles(self):

        self.stype = 'PairSell'
        self.isStart = False
        self.isClose = False
        self.isFirstOrderPunch = False
        self.isParameterSet = False
        self.executionRunning =False
        self.isAnyOpenPos = False
        self.lastSerialNo = 0

        self.lastOrderPoint = 0
        self.isSlHitOnce = False
        self.isAnyOpenPos = False
        self.cashPrice = 0.0
        self.futurePrice = 0.0
        self.ATM = 0.0
        self.baseStrike = 0.0
        self.strikeDiff = 0.0
        self.pairTotal = 0.0
        self.incrQty = 0
        self.baseQty = 0
        self.maxQty = 0
        self.tsl = 0.0
        self.baseStrike = 0
        self.SlAmount = 0
        self.targetAmt = 0
        self.trend = 'Nutural'
        self.lhQty = 0
        self.mtm = 0.0
        self.lastOrderSerialNo = 0
        self.iomslastOrderSerialNo = 0
        self.OMS = []
        self.inactiveOMS = []

        self.lotsize = 0
        self.DOI = datetime.datetime.today().strftime('%d%m%Y')

    def createTimer(self):
        createTimer(self)


    def createObject(self,fo_contract):
        try:
            self.fo_contract=fo_contract

            refresh(self)
            refresh(self.addW)
            refresh(self.modifyW)

            self.addW.getSymbolList(self.fo_contract)
            self.addW.cbSymbol.setCurrentText('BANKNIFTY')
            self.symbol = self.addW.cbSymbol.currentText()
            self.addW.getOptionExpiryList(self.fo_contract)
            eventsBind(self)
            self.createTimer()
        except:
            print(traceback.print_exc())

    def reloadKeyParameter(self):
        try:
            reloadKeyParameter(self)
        except:
            print(traceback.print_exc())


    def setParameters(self):
        setParameters(self)

    def setLTP(self, window):
        self.cashPrice = float(window.leLTP.text())
        print("cashPrice:", self.cashPrice, "lst order point:", self.lastOrderPoint)
    def modifyParameter(self):
        print("modifyParameter:")
        if (self.isFirstOrderPunch == False):
            print("modifyParameter:11111")
            print("aaa")
            self.setParameters()
            print("bbb")
        else:
            print("modifyParameter:11111")
            self.SlAmount = float(self.modifyW.leSLAmount.text())
            self.adjPts = float(self.modifyW.leAdjPts.text())
            self.sgSL.emit(self.folioName, self.SlAmount)
            self.targetAmount = float(self.modifyW.leTargetAmount.text())
            # self.sgTarget.emit(self.folioName, self.targetAmount)
            # self.modifyW.leSLAmount.setText('%.2f' % self.SlAmount)
            # self.modifyW.leTargetAmount.setText('%.2f' % self.targetAmount)
            # self.modifyW.leRSLAmount.setText('%.2f' % self.SlAmount)
            # self.modifyW.leRTargetAmount.setText('%.2f' % self.targetAmount)
            # self.modifyW.leAdjPts.setText()
            saveJson(self)
        print("DFDf")
        self.hideModifyW()

    def saveJson(self, cf = False):
        saveJson(self, cf)
    def getKeyParameterFile(self, folioName):
        getKeyParameterFile(self, folioName)

    def addNew(self, main):
        return addNew(self,main)

    def updateTrade(self, trade, source='on_trade'):

        # print('in update position stretegy,',trade)
        if (source == "on_trade"):
            trade1 = trade[0]
        else:
            trade1 = trade
        # print(" Pairsel  update trade:,",trade1)
        print(self.folioName, trade1)

        if (trade1[15] == self.folioName):

            exchange = trade1[20]
            token = trade1[2]
            fltr0 = np.asarray([token])
            filteredArray0 = self.position[np.in1d(self.position[:, 1], fltr0)]
            isRecordExist = False
            if (filteredArray0.size != 0):
                isRecordExist = True

            if (isRecordExist):
                array = self.position[np.where(self.position[:, 1] == token)]
                # print('in is record exist',array)
                prev_qty = array[0][5]
                prev_amt = array[0][8]

                Prev_Dqty = array[0][13]
                Prev_Damt = array[0][14]

                Dqty = Prev_Dqty + trade1[18]
                DAmt = Prev_Damt + trade1[19]

                newQty = prev_qty + trade1[18]
                newAmt = prev_amt + trade1[19]

                self.position[np.where(self.position[:, 1] == token), [5, 8, 13, 14]] = [newQty, newAmt, Dqty, DAmt]

                # print('updated position dekh lo',self.position)
            else:
                new = dt.Frame([[exchange],
                                [token], [trade1[4]], [float(trade1[6])], [trade1[7]], [trade1[18]],
                                [0], [0], [trade1[19]], [trade1[17]], [0.0],
                                [0.0], [0.0], [trade1[18]], [trade1[19]]
                                ]).to_numpy()

                # print('new position dekh lo',self.position,'\n\n\n\n',new,'\n\n\najsgd'
                #
                #       )

                self.position[self.lastSerialNo, :] = new
                self.lastSerialNo += 1
                # print('new position dekh lo',self.position)

                # # ************ put sl & Target order
                # token = trade1[2]
                # qty = trade1[11]
                # appOrderId = trade1[9]
                # optionType = trade1[7]
                # orderSide = trade1[8]
                # strike = trade1[6]
                # orderTag = trade1[15]
                # print("update trade:", appOrderId,optionType,orderSide,strike,orderTag)
                #
                # if (self.isStart):
                #     if(trade1[10]=='Market'):
                #         ########### Update SL on new CE / PE
                #
                #         tokenPrice = getPrice(self, token=token, seg='NSEFO', streamType=1501)['ltp']
                #         # calculate SL price (change to current LTP)
                #         # error : description': 'Gateway:Price should be multiple of Tick Size which is0.05for this contract'}
                #         print("")
                #         slPrice = int(tokenPrice * (self.slPts + 1))
                #         slTriggerPrice = int(tokenPrice * (self.slPts + 1 - 0.01))
                #
                #         # place sl order
                #         slorderIdList = makeOrder(self, token, qty, "Buy", 'StopLimit',
                #                                     slPrice, slTriggerPrice)
                #
                #         # sl order
                #         addSLOrderToOMS(self, slorderIdList, token, qty, optionType, "Buy",
                #                         strike, 'StopLimit',
                #                         appOrderId)
                #
                #         # update value
                #         self.OMS[self.lastOrderSerialNo, [12, 13, 15, 16]] = [slPrice, slTriggerPrice, appOrderId, 'Placed']
                #
                #     print("Is start =  false",self.iomslastOrderSerialNo)
                #         ##############
                ##############################
            self.modifyW.lbLastOrderPoint.setText(str(self.lastOrderPoint))
            checkIsAnyPosition(self)

            # res = {self.heads[i]: l[i] for i in range(len(heads))}

            # saveJson(self)





    def tradeVarification(self):
        pass

    def updateOrder(self,order, orderDict):
        updateOrder(self, orderDict)

    def orderVarification(self):
        pass


    def makeFirstOrder(self):
        makeFirstOrder(self)

    def checkTrade(self,priceFeed):
        checkTrade(self,priceFeed)


    def getPrice(self, token, seg, streamType):
        data = getQuote(self, token, seg, streamType)
        bid = data['AskInfo']['Price']
        ask = data['BidInfo']['Price']
        ltp = data['LastTradedPrice']
        return {"bid": bid, "ask": ask, "ltp": ltp}

    def updateMTM(self,data):
        if(self.isAnyOpenPos == True):
            if (self.position.size != 0):
                if (data['Token'] in self.position[:,1]):
                    fltr0 = np.asarray([data['Token']])
                    array = self.position[np.in1d(self.position[:, 1], fltr0)][0]
                    # print(array)
                    netAmt = array[8]
                    ltp = data['LTP']
                    qty = array[5]
                    mtm = netAmt + (qty * ltp)
                    self.position[np.in1d(self.position[:, 1], fltr0),[9,10]] = [ltp,mtm]
                    # print(self.position[np.in1d(self.position[:, 1], fltr0)][0])
                    total_mtm = np.sum(self.position[:,10])
                    self.mtm = total_mtm
                    self.sgMTM.emit(self.folioName,total_mtm)
                # print('emited')


    def getExecutionTime(self):
        now = datetime.datetime.today()
        date = now.strftime('%Y-%m-%d ')
        a915 = datetime.datetime.strptime(date + '09:15:00', '%Y-%m-%d %H:%M:%S')
        a920 = datetime.datetime.strptime(date + self.etime, '%Y-%m-%d %H:%M:%S')
        self.timeout1 = int(a920.timestamp()-time.time())*1000
        return self.timeout1




    def getFutureToken(self,symbol=''):
        futureToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 17]
        return futureToken

    def getCashToken(self,symbol=''):
        # print(self.fo_contract)
        assetToken = self.fo_contract[np.where(self.fo_contract[:, 3] == symbol)][0, 9]

        # print(symbol,self.symbol,'getCashToken',assetToken)
        return assetToken

    def getStrikeDiff(self,futureToken):
        # print(self.fo_contract[futureToken-35000,:])
        strikeDiff = self.fo_contract[futureToken-35000,36]
        return strikeDiff

    def getATM(self,cashPrice,strikeDiff):
        ATM1 = (cashPrice / strikeDiff)
        frac = ATM1 % 1

        strikeDecisionPoint = float(self.addW.leLowerPoint.text())
        # print(frac)
        if(frac > strikeDecisionPoint):
            ATM = int(ATM1+1) * strikeDiff
        else:
            ATM= int(ATM1)  * strikeDiff
        # ATM1 = (cashPrice / strikeDiff) * strikeDiff
        return ATM



    def hideAddW(self):
        try:
            self.timerUpdateWindows.stop()
            self.addW.hide()
        except:
            print(traceback)
    def hideModifyW(self):
        self.timerUpdateWindows.stop()
        self.modifyW.hide()




    def getCEPEPrice(self):
        try:
            # print('xyz1')
            data = getQuote(self,self.addW.ATM_CE_Token, 'NSEFO', 1501)
            self.addW.atmCEPrice = data['LastTradedPrice']

            data1 = getQuote(self, self.addW.ATM_PE_Token, 'NSEFO', 1501)
            self.addW.atmPEPrice = data1['LastTradedPrice']
            # print('xyz2')
        except:
            print(traceback.print_exc())




    def updateValues(self):
        try:

            # print('abc')

            self.addW.lb_ltp_cash.setText(str(self.addW.cashPrice))
            self.addW.lb_ltp_fo.setText(str(self.addW.futurePrice))
            self.addW.lb_atm.setText(str(self.addW.ATM))

            self.addW.ATM_CE_Token=self.getATM_CE_Token(self.addW.ATM,self.addW.ceTable)
            self.addW.ATM_PE_Token=self.getATM_PE_Token(self.addW.ATM,self.addW.peTable)

            pairTotal = self.addW.atmPEPrice + self.addW.atmCEPrice
            # self.addW.lb_pTotal.setText('%.2f'%pairTotal)



        except:
            print(traceback.print_exc())

    def getPrices(self):
        try:
            th = threading.Thread(target=self.getCEPEPrice,args=())
            th.start()
        except:
            print(traceback.print_exc())

    def getBaseInfo(self, window):
        getBaseInfo(self, window)
        # getBaseInfo(self)

    def getBasePrices(self):
        try:
            data = getQuote(self, self.addW.cashToken, 'NSECM', 1501)
            self.addW.cashPrice=data['LastTradedPrice']
            data = getQuote(self, self.addW.futureToken, 'NSEFO', 1501)
            self.addW.futurePrice=data['LastTradedPrice']

            self.addW.ATM = self.getATM(self.addW.cashPrice,self.addW.strikeDiff)

            self.addW.ceTable = self.getCETable(self.addW.symbol,self.addW.expiry)
            self.addW.peTable = self.getPETable(self.addW.symbol,self.addW.expiry)
            self.updateValues()
        except:
            print(traceback.print_exc())
    def flushTradeData(self):
        self.position = np.zeros((100,11),dtype=object)


    def checkShortPosExist(self,array):
        isPos =False
        # print('array',array)
        for i in array[0]:
            if(i < 0):
                isPos = True
                return isPos
        return isPos


    def squreOff(self):
        for i in self.position:
            token = i[1]
            exchange = i[0]
            quantity = i[5]

            if(quantity==0):
                pass
            elif quantity > 0:
                absQuantity = abs(quantity)
                while(absQuantity > self.freezeQty):
                    # print('if while')
                    PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Sell',
                               qty=self.freezeQty,
                               limitPrice=0.0,
                               validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                               productType='NRML')
                    time.sleep(0.1)
                    absQuantity -= self.freezeQty
                PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Sell',
                           qty=absQuantity,
                           limitPrice=0.0,
                           validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                           productType='NRML')
                time.sleep(0.1)
            else:

                absQuantity = abs(quantity)
                while (absQuantity > self.freezeQty):
                    print('else while')
                    PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Buy',
                               qty= self.freezeQty,
                               limitPrice=0.0,
                               validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                               productType='NRML')
                    time.sleep(0.1)
                    absQuantity -= self.freezeQty
                PlaceOrder(self, exchange=exchange, clientID=self.clientId, token=token, orderSide='Buy',
                           qty=absQuantity,
                           limitPrice=0.0,
                           validity='DAY', disQty=0, triggerPrice=0, uid=self.folioName, orderType='MARKET',
                           productType='NRML')


                time.sleep(0.1)