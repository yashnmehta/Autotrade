import os
import traceback

lisFinal = []



cwd = os.getcwd()
a=os.listdir(cwd)

print(a)

for i in a :
    if (i == '__pycache__'):
        pass

    elif(os.path.isdir(i)):

        try:
            newPath  = os.path.join(cwd,i)
            # print('newPath',newPath)
            newList = os.listdir(newPath)

            for ij in newList:
                newPath1 = os.path.join(newPath, ij)

                if(ij == '__pycache__'):
                    pass
                elif (os.path.isdir(newPath1)):
                    newList1 = os.listdir(newPath1)
                    for ix in newList1:
                        newPath2 = os.path.join(newPath1, ix)
                        if (ix == '__pycache__'):
                            pass

                        elif (os.path.isdir(newPath2)):
                            newList2 = os.listdir(newPath2)
                            for iz in newList2:


                                newPath3 = os.path.join(newPath2, iz)
                                if (iz == '__pycache__'):
                                    pass

                                elif (os.path.isdir(newPath3)):
                                    newList3 = os.listdir(newPath3)
                                    for iy in newList3:
                                        newPath4 = os.path.join(newPath3, iy)
                                        if (iy == '__pycache__'):
                                            pass
                                        elif (os.path.isdir(newPath4)):
                                            pass
                                        else:
                                            xx2 = newPath4.replace('D:\Autotrader-Reborn\\', '')
                                            if (xx2[-3:] == '.py'):
                                                lisFinal.append(newPath4.replace('D:\Autotrader-Reborn\\', ''))
                                else:
                                    xx2 = newPath3.replace('D:\Autotrader-Reborn\\', '')
                                    if (xx2[-3:] == '.py'):
                                        lisFinal.append(newPath3.replace('D:\Autotrader-Reborn\\', ''))

                        else:
                            xx1 = newPath2.replace('D:\Autotrader-Reborn\\', '')
                            if (xx1[-3:] == '.py'):
                                lisFinal.append(newPath2.replace('D:\Autotrader-Reborn\\', ''))

                else:
                    # print('else 2',newPath1)
                    xx = newPath1.replace('D:\Autotrader-Reborn\\','')
                    # print(xx[-3:])
                    if(xx[-3:]=='.py'):
                        lisFinal.append(newPath1.replace('D:\Autotrader-Reborn\\',''))


        except:
            print('error ',traceback.print_exc(),i)
        # x = os.listdir('d:/Autotrader-Reborn/Application')
    else:
        xx = i.replace('D:\Autotrader-Reborn\\', '')
        # print(xx[-3:])
        if (xx[-3:] == '.py'):
            print('tej',xx)
            lisFinal.append(xx)

print(lisFinal)