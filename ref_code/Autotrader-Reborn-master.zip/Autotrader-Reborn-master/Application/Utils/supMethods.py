import sqlite3
import sys
import logging
from PyQt5.Qt import *
import os
import datetime
from Application.Services.Xts.Api import servicesMD, servicesIA
from Application.Views.FolioPosition.support import filterData
from Application.Views import OptionChain
from Application.Stretegies.Utils.stretegySideOps import getPreviousActiveStretegies
from Application.Utils.configReader import refresh,read_broker
import traceback
import numpy as np
import json
# import mysql.connector




def showPendingW(main, a):
    main.CFrame.dockOP.raise_()
    main.PendingW.filterStr = a
    main.PendingW.smodelO.setFilterKeyColumn(2)
    main.PendingW.smodelO.setFilterFixedString(str(a))
    main.PendingW.tableView.setFocus()
    main.PendingW.tableView.selectRow(0)

def showFolioPosW(main, folio,client):

    print(client,folio)
    if(folio  != ''):
        if(main.FolioPos.isVisible()):
            main.FolioPos.hide()

    main.FolioPos.cbUID.setCurrentText(folio)
    main.FolioPos.cbClient.setCurrentText(client)


    main.FolioPos.filterStr = folio
    main.FolioPos.smodelFP.setFolioName(folio)
    main.FolioPos.smodelFP.setClientName(client)
    main.FolioPos.smodelFP.setFilterFixedString('')
    main.FolioPos.tableView.setFocus()
    main.FolioPos.show()




def showNetPosW(main):
    #if(a != ''):
    # print("1222")
    if(main.NetPos.isVisible()):
        main.NetPos.hide()


    main.NetPos.tableView.setFocus()
    main.NetPos.show()
def showTradeBookW(main, a):
    #if(a != ''):
    # print("1222")
    if(main.TradeW.isVisible()):
        main.TradeW.hide()

    main.TradeW.filterStr = a
    main.TradeW.smodelT.setFilterKeyColumn(2)
    main.TradeW.smodelT.setFilterFixedString(str(a))
    main.TradeW.tableView.setFocus()
    main.TradeW.show()
def showOrderBookW(main, a):
    if(a != ''):
        if(main.OrderBook.isVisible()):
            main.OrderBook.hide()

    main.OrderBook.filterStr = a
    main.OrderBook.smodelO.setFilterKeyColumn(2)
    main.OrderBook.smodelO.setFilterFixedString(str(a))
    main.OrderBook.tableView.setFocus()
    main.OrderBook.show()



def getLogPath(main):
    today =  datetime.datetime.today().strftime('%Y%m%d')
    loc1 = os.getcwd().split('Application')
    main.loc1 = loc1
    main.logDir = os.path.join(loc1[0] , 'Logs','%s'%today)
    # print('logDir',logDir)
    try:
        os.makedirs(main.logDir)
    except OSError as e:
        pass

    ls=os.listdir(main.logDir)
    attempt =1

    for i in ls:
        x=i.replace('.log','')
        y=x.split('_')
        # print(y,len(y))

        if len(y) > 1:
            if(len(y[0])==8):
                if( int(y[1]) >= attempt):
                    attempt=int(y[1])+1

    # print('attempt',attempt)
    api='API'
    order='Order'

    main.logPath= os.path.join(main.logDir, '%s_%s.log'%(today,attempt))

    main.APIlogPath= os.path.join(main.logDir, '%s.log'%(api))

    main.OrderlogPath= os.path.join(main.logDir, '%s.log'%(order))

    # print('main.logPath',xclass.logPath)
    logging.basicConfig(filename=main.logPath, filemode='a+', level=logging.INFO,
                        format='%(asctime)s    %(levelname)s    %(module)s  %(funcName)s   %(message)s',
                        datefmt='%m/%d/%Y %I:%M:%S %p')

    main.formatter = logging.Formatter('%(asctime)s    %(levelname)s    %(module)s  %(funcName)s   %(message)s',datefmt='%m/%d/%Y %I:%M:%S %p')
    # first file logger
    API_logger = logging.getLogger('API')
    hdlr_1 = logging.FileHandler(main.APIlogPath)
    hdlr_1.setFormatter(main.formatter)
    API_logger.setLevel(logging.DEBUG)
    API_logger.addHandler(hdlr_1)

    ORDER_logger = logging.getLogger('ORDER')
    hdlr_1 = logging.FileHandler(main.OrderlogPath)
    hdlr_1.setFormatter(main.formatter)
    ORDER_logger.setLevel(logging.DEBUG)
    ORDER_logger.addHandler(hdlr_1)

def effectWorking(main):
    shadow = QGraphicsDropShadowEffect()
    shadow.setBlurRadius(0.01)
    color = QColor(235, 235, 235,30)
    shadow.setColor(color)
    shadow.setXOffset(0)
    shadow.setYOffset(5)
    main.indexBar.setGraphicsEffect(shadow)


def PO4CT(self,Token,FDiffQty,AbsFDiffQty,freezQty,OrderType,Bid,Ask,Segment):

    if (FDiffQty > 0):  # buy

        LimitPrice = Ask + self.logicReplicate.differPoint
        while AbsFDiffQty > freezQty:
            self.PlaceOrder(Token, OrderType, "BUY", freezQty, LimitPrice, self.logicReplicate.FolioNo, 0.00,Segment)
            AbsFDiffQty = AbsFDiffQty - freezQty
        self.PlaceOrder(Token, "MARKET", "BUY", AbsFDiffQty, 1.0, self.logicReplicate.FolioNo, 0.00,Segment)
    else:  # sell
        while AbsFDiffQty > freezQty:
            LimitPrice = Bid - self.logicReplicate.differPoint

            self.PlaceOrder(Token, OrderType, "SELL", freezQty, LimitPrice, self.logicReplicate.FolioNo, 0.00,Segment)
            AbsFDiffQty = AbsFDiffQty - freezQty
        self.PlaceOrder(Token, OrderType, "SELL", AbsFDiffQty, LimitPrice, self.logicReplicate.FolioNo, 0.00,Segment)

def PO4CT1(self, Token, FDiffQty, AbsFDiffQty, freezQty, OrderType, LimitPrice,Segment):

    if (FDiffQty > 0):  # buy


        while AbsFDiffQty > freezQty:
            self.PlaceOrder(Token, OrderType, "BUY", freezQty, LimitPrice, self.logicReplicate.FolioNo, 0.00,Segment)
            AbsFDiffQty = AbsFDiffQty - freezQty
        self.PlaceOrder(Token, "MARKET", "BUY", AbsFDiffQty, 1.0, self.logicReplicate.FolioNo, 0.00,Segment)
    else:  # sell
        while AbsFDiffQty > freezQty:

            self.PlaceOrder(Token, OrderType, "SELL", freezQty, LimitPrice, self.logicReplicate.FolioNo, 0.00,Segment)
            AbsFDiffQty = AbsFDiffQty - freezQty
        self.PlaceOrder(Token, OrderType, "SELL", AbsFDiffQty, LimitPrice, self.logicReplicate.FolioNo, 0.00,Segment)


def changeIAS_connIcon(main,a):
    try:
        if(a==0):
            loc = os.path.join(main.loc1[0] , 'Resourses','icons','icons','red_icon.png')
            pixmap = QPixmap()
        else:
            loc = os.path.join(main.loc1[0], 'Resourses', 'icons', 'icons', 'green_icon.png')
            pixmap = QPixmap(loc)
        pixmap = pixmap.scaledToWidth(20)
        pixmap = pixmap.scaledToHeight(20)
        icon = QIcon()
        icon.addPixmap(pixmap)
        # main.Interactive_icon.setIcon(icon)
    except:
        print(traceback.print_exc())

def changeMD_connIcon(main,a):
    try:
        if (a == 0):
            pixmap = QPixmap(':/icon1/icons/green_icon.png')
        else:
            pixmap = QPixmap(':/icon1/icons/red_icon.png')
        icon = QIcon()
        icon.addPixmap(pixmap)
        # main.MData_icon.setIcon(icon)
        # print('f')

    except:
        print(traceback.print_exc())


def clearStatus(main):
    main.lbStatus.setText('')
    main.lbStatus.setStyleSheet('')
    main.timerChStatus.stop()


def showBuyWindow(self):
    pass
def showSellWindow(self):
    pass
# def ShowPending(self):
#     token = self.tableView.selectedIndexes()[0].data()
#     self.sgShowPending.emit(str(token))





# def addFolio(main,folio,clientId=''):
#     main.buyW.cbStretegyNo.addItem(folio)
#     main.sellW.cbStretegyNo.addItem(folio)
#     main.FolioPos.folioList.append(folio)
#     main.FolioPos.cbUID.addItem(folio)
#     main.multiOrders.cbFolio.addItem(folio)

def setclist(main,a):
    main.PreferanceW.cbCList.addItems(a)
    main.marketW.buyw.clist=a
    main.marketW.sellw.clist=a

# def setDefaultClient(main,a):
#     try:
#         main.DefaultClient = a
#         main.marketW.buyw.DefaultClient=main.DefaultClient
#         main.marketW.sellw.DefaultClient=main.DefaultClient
#         main.marketW.buyw.leClient.setText(main.DefaultClient)
#         main.marketW.sellw.leClient.setText(main.DefaultClient)
#     except:
#         logging.error(traceback.print_exc())



def SplashTimerWorking(main):
    main.Splash.close()
    main.login.show()
    #cb
    main.login.cbServer.setCurrentIndex(4)

    broker = read_broker(main)
    if(broker=='ARHAM_DIRECT'):
        pass
    main.timeSplash.stop()

###########################################################
def setMTM(main, a):
    main.lbMTM.setText(a)
    if (float(a) > 0):
        main.lbMTM.setStyleSheet(
            'QLabel {background-color: #1464A0;border: 1px solid #2d2d2d;color: #F0F0F0;border-radius: 4px;padding: 3px;outline: none;min-width: 10px;}')
    else:
        main.lbMTM.setStyleSheet(
            'QLabel {background-color: #c32051;border: 1px solid #2d2d2d;color: #F0F0F0;border-radius: 4px;padding: 3px;outline: none;min-width: 10px;}')



def proceed2login(self):
    servicesMD.login(self)
    getPreviousActiveStretegies(self)
    servicesIA.login(self)

def proceed2Main(main):
    try:

        main.login.hide()
        main.show()
        main.showMaximized()
        filterData(main.FolioPos)

        main.buyW.leClient.setText(main.defaultClient)
        main.sellW.leClient.setText(main.defaultClient)

        # getPreviousActiveStretegies(main)

        for i in main.Manager.All_stretegyList:
            refresh(i)
            refresh(i.addW)
            refresh(i.modifyW)

        for ixx in main.TradeW.ApiTrade:
            # print('fff',main.Manager.All_stretegyList)
            # print('ixx',ixx)

            for x in main.Manager.All_stretegyList:

                if (x.folioName == ixx[15]):
                    # print('ttt')
                    x.updateTrade(ixx,"get_Trade")
        # subscribeDefaultToken(main)
        # main.timerBalance.start()


        OptionChain.support.polpulateCbSymbol(main.OptionChain)
        OptionChain.support.populateCbExp(main.OptionChain)
        print('end')
    except:
        print(traceback.print_exc())


# def subscribeDefaultToken(main):
#

def createTimers(main):
    main.timernext = QTimer()
    main.timernext.setInterval(1000)
    main.timernext.timeout.connect(main.login.pbNext.show)



    main.timeSplash =QTimer()
    main.timeSplash.setInterval(1000)
    main.timeSplash.timeout.connect(lambda : SplashTimerWorking(main))


    main.timerMTM = QTimer()
    main.timerMTM.setInterval(500)
    main.timerMTM.timeout.connect(main.updateNetMTM)
    main.timerMTM.start()

    main.timerMTM_NP = QTimer()
    main.timerMTM_NP.setInterval(500)
    main.timerMTM_NP.timeout.connect(main.updateNetMTM_NP)
    main.timerMTM_NP.start()

    main.timerMTM_FP = QTimer()
    main.timerMTM_NP.setInterval(500)
    main.timerMTM_FP.timeout.connect(main.updateNetMTM_FP)
    main.timerMTM_FP.start()


    main.timerChStatus = QTimer()
    main.timerChStatus.setInterval(5000)
    main.timerChStatus.timeout.connect(lambda:clearStatus(main))
    main.timerChStatus.start()

    main.timerBalance = QTimer()
    main.timerBalance.setInterval(2000)
    main.timerBalance.setSingleShot(True)
    main.timerBalance.timeout.connect(lambda:servicesIA.get_balance(main))


    main.timerBalance = QTimer()
    main.timerBalance.setInterval(2000)
    main.timerBalance.setSingleShot(True)
    main.timerBalance.timeout.connect(lambda:servicesIA.get_balance(main))


def updateFolioOpenPos(main,i):
    # print(i)

    token = i[5]
    clientid = '*****' if ('PRO' in i[1]) else i[1]
    exchange = i[4]
    # check token
    ouid = i[3]

    if (clientid not in main.FolioPos.clientFolios.keys()):
        main.FolioPos.clientFolios[clientid] = []
    if (ouid not in main.FolioPos.clientFolios[clientid]):
        main.FolioPos.clientFolios[clientid].append(ouid)

    # print('####### self.clientFolios',self.clientF/olios)

    fltr0 = np.asarray([token])
    filteredArray0 = main.FolioPos.table[np.in1d(main.FolioPos.table[:, 5], fltr0)]

    isRecordExist = False
    # print(filteredArray0, token, type(token), main.FolioPos.table[:, 5])
    if (filteredArray0.size != 0):
        fltr = np.asarray([exchange])
        filteredArray1 = filteredArray0[np.in1d(filteredArray0[:, 4], fltr)]
        if (filteredArray1.size != 0):
            fltr = np.asarray([clientid])
            filteredArray2 = filteredArray1[np.in1d(filteredArray1[:, 1], fltr)]
            if (filteredArray2.size != 0):
                fltr = np.asarray([ouid])
                filteredArray21 = filteredArray2[np.in1d(filteredArray2[:, 3], fltr)]

                if (filteredArray21.size != 0):
                    isRecordExist = True

    if (isRecordExist == False):
        # print("enot exists:")
        # print("enot exists:")
        # print("-------------------")
        #
        # print(i[0],len(i[0]))
        try:

            # anm = dt.Frame([
            #     [i[0]],
            #     [clientid], ['Stretegy_type'], [i[15]], [i[20]], [i[2]],
            #     [i[3]], [i[4]], [i[5]], [i[6]], [i[7]],
            #     [0], [i[18]], [i[18]], [i[19]], [i[17]],
            #     [buyQ], [buyA], [sellQ], [sellA], [i[17]],
            #     [0.0], [i[21]], [i[22]], [0.0], [self.lastSerialNo],
            #     [i[19]]
            # ]).to_numpy()
            i[25] = main.FolioPos.lastSerialNo

            main.FolioPos.table[main.FolioPos.modelFP.lastSerialNo] = i
            main.FolioPos.modelFP.lastSerialNo += 1
            main.FolioPos.lastSerialNo += 1
            main.FolioPos.modelFP.insertRows()
            main.FolioPos.modelFP.rowCount()

            # ind = self.modelFP.index(0, 0)
            # ind1 = self.modelFP.index(0, 1)
            # self.modelFP.dataChanged.emit(ind, ind1)

            for i in range(27):
                ind = main.FolioPos.modelFP.index(main.FolioPos.modelFP.lastSerialNo, i)
                main.FolioPos.modelFP.dataChanged.emit(ind, ind)
            main.FolioPos.sgrecvfosubscribe.emit('FolioPosition', exchange, token)
            # main.recv_fo.subscribedlist("FolioPosition", exchange, token)
        except:
            print(traceback.print_exc())

    else:
        serialNo = filteredArray21[0][25]
        openValue = main.FolioPos.table[serialNo, 24]+i[14]
        openQty = main.FolioPos.table[serialNo, 11]+i[13]

        netQ = main.FolioPos.table[serialNo, 13] + i[13]
        netAmt = main.FolioPos.table[serialNo, 14] +i[14]




        netAvg = netAmt / netQ if netQ != 0 else 0
        # print("i[18]:", i, self.table[serialNo, 16] )
        if (i[13] > 0):
            buyQ = main.FolioPos.table[serialNo, 16] + i[13]
            sellQ = main.FolioPos.table[serialNo, 18]
            # buyAvg = ((main.FolioPos.table[serialNo, 17] * main.FolioPos.table[serialNo, 16]) + (-i[19])) / buyQ
            buyAvg = main.FolioPos.table[serialNo, 17]

            sellA = main.FolioPos.table[serialNo, 19]
        else:
            buyQ = main.FolioPos.table[serialNo, 16]
            sellQ = main.FolioPos.table[serialNo, 18] - i[13]
            buyAvg = main.FolioPos.table[serialNo, 17]
            # sellA = ((main.FolioPos.table[serialNo, 19] * main.FolioPos.table[serialNo, 18]) + (i[19])) / sellQ
            sellA = main.FolioPos.table[serialNo, 19]
            # print("sellA:", sellA)
            # print("sellA with minus:", (( self.table[serialNo, 19] * self.table[serialNo, 18] ) + (-i[19])) / sellQ)

        main.FolioPos.table[serialNo, [11, 13, 14, 15, 16, 17, 18, 19, 24]] = [openQty, netQ, netAmt, netAvg, buyQ, buyAvg, sellQ,
                                                                      sellA, openValue]

        # print('perv',self.table[serialNo,:],'\n',i,"\n",self.table[serialNo,:],'\n\n\n')

        for i in range(27):
            ind = main.FolioPos.modelFP.index(serialNo, i)
            main.FolioPos.modelFP.dataChanged.emit(ind, ind)

    # i[25]=main.FolioPos.lastSerialNo
    #
    # main.FolioPos.table[main.FolioPos.lastSerialNo]=i
    # main.FolioPos.modelFP.lastSerialNo += 1
    # main.FolioPos.lastSerialNo += 1
    # main.FolioPos.modelFP.insertRows()
    # main.FolioPos.modelFP.rowCount()
    #
    # ind = main.FolioPos.modelFP.index(0, 0)
    # ind1 = main.FolioPos.modelFP.index(0, 1)
    # main.FolioPos.modelFP.dataChanged.emit(ind, ind1)


def CFSPosition(main):
    selectedIndexes = main.Manager.tableView.selectedIndexes()
    folioName = selectedIndexes[3].data()

    for i in main.Manager.stretegyList:
        if (i.folioName == folioName):
            i.saveJson(cf=True)
            # i.copyJson_CF_data()
            try:

                main.Manager.table[np.where(main.Manager.table[:,3]==i.folioName),14]='CF'
            except:
                print(traceback.print_exc(),i.folioName)

    ind = main.Manager.model.index(0, 0)
    ind1 = main.Manager.model.index(0, 1)
    main.Manager.model.dataChanged.emit(ind, ind1)


def eodProcess(main):
    try:
        #################################################
        loc1 = os.getcwd().split('Application')
        main.StInfo_location = os.path.join(loc1[0], 'Application', 'DB', 'stretwgyList.json')
        with open(main.StInfo_location, "r") as f1:
            jInfo = json.load(f1)
        f1.close()
        #################################################

        # remove CF_data directory#################################################

        cf_dir_loc1 = os.getcwd().split('Application')
        try:
            path = os.path.join(cf_dir_loc1[0], 'Application', 'DB', 'CF_data')
            import shutil
            shutil.rmtree(path)
        except:
            print(traceback.print_exc())
        # create CF_data folder and generate file
        os.mkdir(path)
        #################################################

        #################################################
        jInfo['Previous']['Active'] = []
        #################################################

        cfList = []
        for i in main.Manager.table[:main.Manager.lastSerialNo,:]:
            print('55')
            status = i[14]
            folioName = i[3]
            if(status=='CF'):
                print('CF')
                for ij in jInfo['Today_list']['All']:
                    x = ij['FolioName']
                    if(x==folioName):
                        jInfo['Previous']['Active'].append(ij)
                        #################################################
                        cfList.append(folioName + '.json')
                        #################################################

        f2 = open(main.StInfo_location,'w')
        jInfo_new = json.dumps(jInfo,indent=4)
        f2.write(jInfo_new)
        f2.close()

        todayStr = datetime.datetime.today().strftime('%Y%m%d')

        # print('dd')

        backupCFstretegydir = os.path.join(loc1[0], 'Application', 'DB', 'BackUp_CF_data', todayStr)
        if (os.path.isdir(backupCFstretegydir) == False):
            os.mkdir(backupCFstretegydir)

        for ik in cfList:
            import shutil
            src_path = os.path.join(cf_dir_loc1[0], 'Application', 'DB', 'Stretegy_data',todayStr,ik)
            print("src_path:", src_path)
            dst_path = os.path.join(cf_dir_loc1[0], 'Application', 'DB', 'CF_data',ik)
            print("dst_path:", dst_path)
            shutil.copy(src_path, dst_path)

            dst_path1=os.path.join(loc1[0], 'Application', 'DB', 'BackUp_CF_data', todayStr,ik)
            shutil.copy(src_path, dst_path1)
            # print('Copied')


        print('eeee')
        # saveOrder2Database(main)
        # saveTradestoDatabase(main)



    except:
        print(traceback.print_exc())





def saveTradestoDatabase(self):
    try:
        tday = datetime.datetime.today().strftime('%Y-%m-%d')

        mydb = mysql.connector.connect(
            host="192.168.113.63",
            user="root",
            passwd="Admin@123",
            database="anvdb"
        )
        mycursor = mydb.cursor()


        loc=os.getcwd().split('Application')
        DBpath=os.path.join(loc[0],'Database','mainDB.db')
        conn = sqlite3.connect(DBpath)
    except:
        pass


    # conn.execute("INSERT INTO AllTrades (1, 'Paul', 32, 'California', 20000.00 )")
    for trade in self.TradeW.ApiTrade[:self.TradeW.lastSerialNo]:

        conn.execute("INSERT or IGNORE INTO AllTrades VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                     (tday,trade[9],trade[0],trade[1],trade[2],trade[3],trade[4],
                      trade[5], trade[6], trade[7], trade[8],
                      trade[10],trade[11],trade[12],trade[13],trade[14],
                      trade[15],trade[16],trade[17],trade[18],trade[19],
                       trade[20],trade[21],trade[22],trade[23]))

        mycursor.execute("INSERT IGNORE INTO AllTrades VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                     (tday,trade[9], trade[0], trade[1], trade[2], trade[3], trade[4],
                      trade[5], trade[6], trade[7], trade[8],
                      trade[10], trade[11], trade[12], trade[13], trade[14],
                      trade[15], trade[16], trade[17], trade[18], trade[19],
                      trade[20], trade[21], trade[22], trade[23]))

    for order in self.OrderBook.ApiOrder[:self.OrderBook.lastSerialNo]:
        conn.execute("INSERT or IGNORE INTO AllOrder VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                     (tday,order[0],order[25],order[1],order[2],order[3],order[4],
                      order[5], order[6], order[7], order[8], order[9],
                      order[10],order[11],order[12],order[13],order[14],
                      order[15],order[16],order[17],order[18],order[19],
                       order[20],order[21],order[22],order[23],order[24]))

        mycursor.execute("INSERT IGNORE INTO AllOrder VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                     (tday,order[0], order[25], order[1], order[2], order[3], order[4],
                      order[5], order[6], order[7], order[8], order[9],
                      order[10], order[11], order[12], order[13], order[14],
                      order[15], order[16], order[17], order[18], order[19],
                      order[20], order[21], order[22], order[23], order[24]))

    for st in self.Manager.table[:self.Manager.lastSerialNo]:
        conn.execute("INSERT or IGNORE INTO StretegySummary VALUES(?,?,?,?,?,?)",
                     (tday,st[3],st[1],st[2],st[5],st[6]
                      ))

        mycursor.execute("INSERT IGNORE INTO StretegySummary VALUES(%s,%s,%s,%s,%s,%s)",
                     (tday,st[3],st[1],st[2],st[5],st[6]))

    # for pos in self.NetPos.Apipos[:self.NetPos.lastSerialNo]:
    #     "IF NOT EXISTS(SELECT 1 FROM AllPosition WHERE UserID = %s AND )\
    #         INSERT INTO Payments(CustomerID,Amount)\
    #         VALUES('145300',12.33)"
    #
    #
    #     conn.execute("INSERT or IGNORE INTO AllPosition(UserID,ClientID,Segment,ExchangeInstrumentID,TradingSymbol,Symbol,Expiry,Strike,\
    #     OptionType,Qty,MTM,LTP,RealizedMTM,NetAmount,AvgPrice,lotsize,maxQ,AssetToken,OpenQty,OpenAmt,DayQ,DayAmt) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
    #                  (pos[0],pos[1],pos[2],pos[3],pos[4],
    #                   pos[5], pos[6], pos[7], pos[8], pos[9],
    #                   pos[10],pos[11],pos[12],pos[13],pos[14],
    #                   pos[15],pos[16],pos[17],pos[19],
    #                    pos[20],pos[21],pos[22]))
    #
    #     mycursor.execute("INSERT IGNORE INTO AllPosition(UserID,ClientID,Segment,ExchangeInstrumentID,TradingSymbol,Symbol,Expiry,Strike,\
    #     OptionType,Qty,MTM,LTP,RealizedMTM,NetAmount,AvgPrice,lotsize,maxQ,AssetToken,OpenQty,OpenAmt,DayQ,DayAmt) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
    #                  (pos[0], pos[1], pos[2], pos[3], pos[4],
    #                   pos[5], pos[6], pos[7], pos[8], pos[9],
    #                   pos[10], pos[11], pos[12], pos[13], pos[14],
    #                   pos[15], pos[16], pos[17], pos[19],
    #                   pos[20], pos[21], pos[22]))




    conn.commit()

    mydb.commit()

    conn.close()
    mydb.close()

def saveOrder2Database(self):
    loc=os.getcwd().split('Application')
    DBpath=os.path.join(loc[0],'Database','mainDB.db')
    conn = sqlite3.connect(DBpath)


    for order in self.OrderBook.ApiOrder[:self.OrderBook.lastSerialNo]:
        conn.execute("INSERT INTO AllOrder VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                     (order[0],order[25],order[1],order[2],order[3],order[4],
                      order[5], order[6], order[7], order[8], order[9],
                      order[10],order[11],order[12],order[13],order[14],
                      order[15],order[16],order[17],order[18],order[19],
                       order[20],order[21],order[22],order[23],order[24]))

    conn.commit()

    conn.close()

def checkIsAnyPosition(self):
    isAnyOpenPos = False
    for i in self.position[:self.lastSerialNo,5]:
        if(i != 0):
            isAnyOpenPos = True
            self.isAnyOpenPos = isAnyOpenPos

            return
    self.isAnyOpenPos = isAnyOpenPos





def SuareOffButtonClicked(main,button):
    # print(button)

    if( button.text()== 'SquareOff'):
        main.IsSquareOff=True
        messageBoxDeleteStretegy(main)


    else:
        pass

def messageBoxDeleteStretegy(main):
    main.messageBox1 = QMessageBox()
    main.messageBox1.setIcon(QMessageBox.Critical)
    main.messageBox1.setWindowFlags(Qt.WindowStaysOnTopHint)
    main.messageBox1.setText('Are you sure you want to SquareOff Position and permanently Delete Stretegy  ? ')
    main.messageBox1.setWindowTitle('Delete Stretegy')

    main.messageBox1.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
    main.messageBox1.setDefaultButton(QMessageBox.Ok)
    main.messageBox1.buttonClicked.connect(main.msgboxButtonClicked)
    main.messageBox1.exec()


def msgboxButtonClicked(main,button):
    # print('ttttttt',button.text())
    if (button.text() == '&Yes'):
        # print('yes',button)
        main.IsDelete=True

    else:
        pass

def squareOffStretegy(main):
    selectedIndexes = main.Manager.tableView.selectedIndexes()
    folioName = selectedIndexes[3].data()
    # print(folioName)
    for i in main.Manager.stretegyList:
        if (i.folioName == folioName):
            # print("Square off: ", folioName)
            i.squreOff()
            break

def updateStStatus(main,stretegy,status):
    for i in main.Manager.stretegyList:
        if(i.folioName == stretegy.folioName):
            main.Manager.table[np.where(main.Manager.table[:,3]==stretegy.folioName),4] = status

def changeStatusBarSettings(main):
    main.isUpdateStatusRejection = main.PreferanceW.cxbOrdSts.isChecked()
    main.isUpdateStatusTrade = main.PreferanceW.cxbTrdSts.isChecked()
    main.isUpdateStatusOrder = main.PreferanceW.cxbPOSts.isChecked()

    saveStatusBarSettings(main)

def saveStatusBarSettings(main):
    loc = os.getcwd().split('Application')[0]
    settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')

    main.statusBarSettingsJson['isUpdateStatusRejection'] = main.isUpdateStatusRejection
    main.statusBarSettingsJson['isUpdateStatusTrade'] = main.isUpdateStatusTrade
    main.statusBarSettingsJson['isUpdateStatusOrder'] = main.isUpdateStatusOrder
    # main.statusBarSettingsJson['isRejectionPopup'] = main.isRejectionPopup

    f1 = open(settingsFilePath)
    pathDetails = json.load(f1)
    pathDetails['StatusBar'] = main.statusBarSettingsJson
    f1.close()
    pathDetails_new = json.dumps(pathDetails, indent=4)

    f2 = open(settingsFilePath, 'w+')
    f2.write(pathDetails_new)
    # pathDetails= json.load(f1)
    f2.close()

def loadStatusBarSettings(main):
    loc = os.getcwd().split('Application')[0]
    settingsFilePath = os.path.join(loc, 'Resourses', 'Settings.json')

    f1 = open(settingsFilePath)
    main.statusBarSettingsJson = json.load(f1)['Statusbar']
    f1.close()

    main.isUpdateStatusRejection = main.statusBarSettingsJson['isUpdeStatusRejection']
    main.isUpdateStatusTrade = main.statusBarSettingsJson['isUpdateStatusTrade']
    main.isUpdateStatusOrder = main.statusBarSettingsJson['isUpdateStatusOrder']
    # main.isRejectionPopup = main.statusBarSettingsJson['isRejectionPopup']

def ShowTradeBook(main):
    loc = os.getcwd().split('Application')
    DBpath = os.path.join(loc[0], 'Database', 'mainDB.db')
    conn = sqlite3.connect(DBpath)
    temp=np.zeros_like(main.TradeW.ApiTrade[0:main.TradeW.modelT.lastSerialNo, :])

    main.TradeW.ApiTrade[0:main.TradeW.modelT.lastSerialNo, :]=temp

    main.TradeW.modelT.DelRows(0, main.TradeW.modelT.lastSerialNo)
    # main.TradeW.modelT.DelRows()
    main.TradeW.lastSerialNo=0
    main.TradeW.modelT.lastSerialNo =0
    main.TradeW.modelT.rowCount()

    ind = main.TradeW.modelT.index(0, 0)
    ind1 = main.TradeW.modelT.index(0, 1)
    main.TradeW.modelT.dataChanged.emit(ind, ind1)

    today = datetime.datetime.today().strftime('%Y-%m-%d')
    # qry='select * from AllTrades WHERE DateofTrade= '+ today
    # print(qry)
    data=conn.execute('select * from AllTrades WHERE DateofTrade= "'+today+'"')
    rows=data.fetchall()
    # print(rows)

    for trade in rows:
        # print(trade)
        try:
            main.TradeW.ApiTrade[main.TradeW.lastSerialNo, :] = [trade[2], trade[3], trade[4], trade[5], trade[6], trade[7],
                  trade[8], trade[9], trade[10],trade[1] ,trade[11],
                  trade[12], trade[13], trade[14], trade[15], trade[16],
                  trade[17], trade[18], trade[19],
                  trade[20], trade[21], trade[22], trade[23],trade[24]]

            main.TradeW.lastSerialNo += 1
            main.TradeW.modelT.lastSerialNo += 1
            main.TradeW.modelT.insertRows()
            main.TradeW.modelT.rowCount()

            # if (main.isVisible()):
            ind = main.TradeW.modelT.index(0, 0)
            ind1 = main.TradeW.modelT.index(0, 1)
            main.TradeW.modelT.dataChanged.emit(ind, ind1)
        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info())



def ShowOrderBook(main):
    loc = os.getcwd().split('Application')
    DBpath = os.path.join(loc[0], 'Database', 'mainDB.db')
    conn = sqlite3.connect(DBpath)

    temp=np.zeros_like(main.OrderBook.ApiOrder[0:main.OrderBook.modelO.lastSerialNo, :])

    main.OrderBook.ApiOrder[0:main.OrderBook.modelO.lastSerialNo, :]=temp

    main.OrderBook.modelO.DelRows(0, main.OrderBook.modelO.lastSerialNo)
    # main.OrderBook.modelO.DelRows()
    main.OrderBook.lastSerialNo=0
    main.OrderBook.modelO.lastSerialNo =0
    main.OrderBook.modelO.rowCount()

    ind = main.OrderBook.modelO.index(0, 0)
    ind1 = main.OrderBook.modelO.index(0, 1)
    main.OrderBook.modelO.dataChanged.emit(ind, ind1)

    today = datetime.datetime.today().strftime('%Y-%m-%d')
    # qry='select * from AllTrades WHERE DateofTrade= '+ today
    # print(qry)
    data = conn.execute('select * from AllOrder WHERE DateofOrder = "' + today + '"')
    rows=data.fetchall()

    for order in rows:
        # print(order)
        try:
            main.OrderBook.ApiOrder[main.OrderBook.lastSerialNo, :] = [order[1], order[3], order[4], order[5], order[6], order[7],
                  order[8], order[9], order[10],order[11] ,order[12],
                  order[13], order[14], order[15], order[16],
                  order[17], order[18], order[19],
                  order[20], order[21], order[22], order[23],order[24],order[25],order[26],order[2]]

            main.OrderBook.lastSerialNo += 1
            main.OrderBook.modelO.lastSerialNo += 1
            main.OrderBook.modelO.insertRows()
            main.OrderBook.modelO.rowCount()

            # if (main.isVisible()):
            ind = main.OrderBook.modelO.index(0, 0)
            ind1 = main.OrderBook.modelO.index(0, 1)
            main.OrderBook.modelO.dataChanged.emit(ind, ind1)
        except:
            print(traceback.print_exc())
            logging.error(sys.exc_info())



