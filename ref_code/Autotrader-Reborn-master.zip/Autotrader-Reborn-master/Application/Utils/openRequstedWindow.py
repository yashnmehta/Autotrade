import numpy as np
from Application.Views import BuyWindow
from Application.Views import SellWindow
from Application.Views import SellWindow
from Application.Views.OptionChain.optionChain import OptionChain
from Application.Views.multiModification import  Ui_MultiModification
import traceback
from Application.Utils.supMethods import  showNetPosW,showPendingW, showOrderBookW, showTradeBookW, showFolioPosW
from Application.Views import MultiOrders
from Application.Views.BuyWindow import support as buySupport
from Application.Views.SwapOrder import support
from Application.Views.SpreadOrder import support, spreadOrder
from Application.Views.SellWindow import support as sellSupport
from Application.Views import quickTrade
from Application.Views.OptionChain import optionSelection
from Application.Views import SwapOrder
from Application.Views import SpreadOrder
from Application.Views .quickTrade import quickTradeW
def quickOrderRequested(self,objectType):

    try:
        self.quickTradeW.hide()
        self.quickTradeW.show()
    except:
        print(traceback.print_exc())



def requestOC2BS(self,bs ):
    indexes = self.OptionChain.tableView.selectedIndexes()
    print(indexes,'indexes')
    self.OptionChain.optSelect.ceToken = int(indexes[0].data())
    self.OptionChain.optSelect.cePrice =indexes[12].data()

    self.OptionChain.optSelect.hide()
    self.OptionChain.optSelect.show()

    if(bs=='Buy'):
        self.OptionChain.optSelect.bs = 'Buy'
        self.OptionChain.optSelect.peToken =int(indexes[1].data())
        self.OptionChain.optSelect.pePrice =indexes[23].data()
    else:
        self.OptionChain.optSelect.bs = 'Sell'
        self.OptionChain.optSelect.peToken =int(indexes[1].data())
        self.OptionChain.optSelect.pePrice =indexes[23].data()

def requestBSWindowForOC(self):
    if(self.OptionChain.optSelect.optionType == 'CE'):
        token = self.OptionChain.optSelect.ceToken
        price = self.OptionChain.optSelect.cePrice
    else:
        token = self.OptionChain.optSelect.peToken
        price = self.OptionChain.optSelect.pePrice

    ins_details = self.fo_contract[token-35000]
    instrumentType = ins_details[5]
    # print('qqqq instrumentType',instrumentType)
    symbol = ins_details[3]
    exp = ins_details[6]
    strk = ins_details[7]
    opt = ins_details[8]
    tick = ins_details[10]
    lot = ins_details[11]
    max = ins_details[14]
    triggerPrice = '0.0'
    multiplier =1


    # print("inside buy window : 2")

    if(self.OptionChain.optSelect.bs == 'Buy'):
        BuyWindow.support.showWindow(self,'NSEFO',token,price,lot,symbol,instrumentType,exp,strk,opt,max,lot,tick, triggerPrice,multiplier)
    else:
        SellWindow.support.showWindow(self, 'NSEFO', token, price, lot, symbol, instrumentType, exp, strk, opt, max, lot,
                                     tick, triggerPrice,multiplier)


def swapOrderRequested(self,superClass):
    try:
        #
        SwapOrder.support.showWindow(self, superClass)
        # quickTrade.quickTradeW.hide(quickTradeW)

    except:
        print(traceback.print_exc())

def multiOrdersRequested(self,superClass):
    # print("multiOrdersRequested",superClass )

    try:
        MultiOrders.support.showWindow(self, superClass)
    except:
        print(traceback.print_exc())
#
def spreadOrderRequested(self, superClass):
    pass
    # print("spreadOrderRequested",superClass )

    try:
        SpreadOrder.support.showWindow(self,superClass)
    except:
        print(traceback.print_exc())


def orderBookRequested(self,superClass):
    print("Ordrbook inside",superClass )

    if (superClass == 'MarketWatch'):
        token = int(self.marketW.tableView.selectedIndexes()[0].data())
        exchange = self.marketW.tableView.selectedIndexes()[1].data()
    elif (superClass == 'MarketWatch_basic'):
        token = int(self.marketWB.tableView.selectedIndexes()[0].data())
        exchange = self.marketWB.tableView.selectedIndexes()[1].data()
    elif (superClass == 'PendingOrder'):
        token = int(self.PendingW.tableView.selectedIndexes()[2].data())
        exchange = self.PendingW.tableView.selectedIndexes()[19].data()

    elif (superClass == 'OrderBook'):
        token = ''
    elif (superClass == 'NetPosition'):
        indexes = self.NetPos.tableView.selectedIndexes()
        srNOIndex = 18
        for i in range(18):
            if (self.NetPos.tableView.horizontalHeader().isSectionHidden(i)):
                srNOIndex -= 1

        srNO = int(float(indexes[srNOIndex].data()))
        # tokenBuy = marketwatchSupportRef.getToken(marketwatchRef, srNO1)

        token = self.NetPos.Apipos[srNO, 3]
        exchange = self.NetPos.Apipos[srNO, 2]
    elif (superClass == 'FolioPosition'):
        indexes = self.FolioPos.tableView.selectedIndexes()
        srNOIndex = 25
        for i in range(25):
            if (self.FolioPos.tableView.horizontalHeader().isSectionHidden(i)):
                srNOIndex -= 1

        srNO = int(float(indexes[srNOIndex].data()))

        token = self.FolioPos.table[srNO, 5]

        # token = int(self.FolioPos.tableView.selectedIndexes()[5].data())
        exchange = self.FolioPos.tableView.selectedIndexes()[4].data()
    elif (superClass == 'SnapQuote'):
        token = self.snapW.Token
        exchange = self.snapW.exchange

    showOrderBookW(self, token)

def FolioPosRequested(self,superClass):
    # print("FolioPosRequested",superClass )

    if (superClass == 'Manager'):
        folio = (self.Manager.tableView.selectedIndexes()[3].data())
        client = self.Manager.tableView.selectedIndexes()[2].data()
        #exchange = self.snapW.exchange
    else:
        folio = ''
        client = ''

    showFolioPosW(self, folio,client)





def tradeBookRequested(self,superClass):
    print("Tradebook inside",superClass )
    try:
        if (superClass == 'MarketWatch'):
            token = int(self.marketW.tableView.selectedIndexes()[0].data())
            exchange = self.marketW.tableView.selectedIndexes()[1].data()
        elif (superClass == 'MarketWatch_basic'):
            token = int(self.marketWB.tableView.selectedIndexes()[0].data())
            exchange = self.marketWB.tableView.selectedIndexes()[1].data()
        elif (superClass == 'PendingOrder'):
            token = int(self.PendingW.tableView.selectedIndexes()[2].data())
            exchange = self.PendingW.tableView.selectedIndexes()[19].data()
        elif (superClass == 'OrderBook'):
            token = int(self.OrderBook.tableView.selectedIndexes()[2].data())
            exchange = self.OrderBook.tableView.selectedIndexes()[19].data()
        elif (superClass == 'TradeBook'):
            token = ''
        elif (superClass == 'NetPosition'):
            indexes = self.NetPos.tableView.selectedIndexes()
            srNOIndex = 18
            for i in range(18):
                if (self.NetPos.tableView.horizontalHeader().isSectionHidden(i)):
                    srNOIndex -= 1

            srNO = int(float(indexes[srNOIndex].data()))
            # tokenBuy = marketwatchSupportRef.getToken(marketwatchRef, srNO1)

            token = self.NetPos.Apipos[srNO, 3]
            exchange = self.NetPos.Apipos[srNO, 2]

        elif (superClass == 'FolioPosition'):
            indexes = self.FolioPos.tableView.selectedIndexes()
            srNOIndex = 25
            for i in range(25):
                if (self.FolioPos.tableView.horizontalHeader().isSectionHidden(i)):
                    srNOIndex -= 1

            srNO = int(float(indexes[srNOIndex].data()))

            token = self.FolioPos.table[srNO, 5]
            exchange = self.FolioPos.tableView.selectedIndexes()[4].data()
        elif (superClass == 'SnapQuote'):
            token = self.snapW.Token
            exchange = self.snapW.exchange
    except:
        token = ''
    showTradeBookW(self, token)

def netPosRequested(self,superClass):
    showNetPosW(self)

def pendingOrderRequested(self,superClass):
    try:
        if (superClass == 'MarketWatch'):
            token = int(self.marketW.tableView.selectedIndexes()[0].data())
            exchange = self.marketW.tableView.selectedIndexes()[1].data()
        elif (superClass == 'MarketWatch_basic'):
            token = int(self.marketWB.tableView.selectedIndexes()[0].data())
            exchange = self.marketWB.tableView.selectedIndexes()[1].data()
        elif (superClass == 'PendingOrder'):
            token = int(self.PendingW.tableView.selectedIndexes()[2].data())
            exchange = self.PendingW.tableView.selectedIndexes()[19].data()
        elif (superClass == 'NetPosition'):
            indexes = self.NetPos.tableView.selectedIndexes()
            srNOIndex = 18
            for i in range(18):
                if (self.NetPos.tableView.horizontalHeader().isSectionHidden(i)):
                    srNOIndex -= 1

            srNO = int(float(indexes[srNOIndex].data()))
            # tokenBuy = marketwatchSupportRef.getToken(marketwatchRef, srNO1)

            token = self.NetPos.Apipos[srNO, 3]
            exchange = self.NetPos.Apipos[srNO, 2]

        elif (superClass == 'FolioPosition'):

            indexes = self.FolioPos.tableView.selectedIndexes()
            srNOIndex = 25
            for i in range(25):
                if (self.FolioPos.tableView.horizontalHeader().isSectionHidden(i)):
                    srNOIndex -= 1

            srNO = int(float(indexes[srNOIndex].data()))

            token = self.FolioPos.table[srNO, 5]

            # token = int(self.FolioPos.tableView.selectedIndexes()[5].data())
            exchange = self.FolioPos.tableView.selectedIndexes()[4].data()
        elif (superClass == 'SnapQuote'):
            token = self.snapW.Token
            exchange = self.snapW.exchange
    except:
        token = ''

    showPendingW(self, token)

def snapQuoteRequested(self,superClass):


    if(self.snapW.isVisible()):
        self.snapW.hideWindow()

    if(superClass == 'MarketWatch'):
        token = int(self.marketW.tableView.selectedIndexes()[0].data())
        exchange = self.marketW.tableView.selectedIndexes()[1].data()
    elif(superClass=='MarketWatch_basic'):
        token = int(self.marketWB.tableView.selectedIndexes()[0].data())
        exchange = self.marketWB.tableView.selectedIndexes()[1].data()
    elif (superClass == 'PendingOrder'):
        token = int(self.PendingW.tableView.selectedIndexes()[2].data())
        exchange = self.PendingW.tableView.selectedIndexes()[19].data()
    elif (superClass == 'NetPosition'):
        indexes = self.NetPos.tableView.selectedIndexes()
        srNOIndex = 18
        for i in range(18):
            if (self.NetPos.tableView.horizontalHeader().isSectionHidden(i)):
                srNOIndex -= 1

        srNO = int(float(indexes[srNOIndex].data()))
        # tokenBuy = marketwatchSupportRef.getToken(marketwatchRef, srNO1)

        token = self.NetPos.Apipos[srNO, 3]
        exchange = self.NetPos.Apipos[srNO, 2]
    elif (superClass == 'FolioPosition'):
        try:
            print('infoliosnapQuote')
            indexes = self.FolioPos.tableView.selectedIndexes()
            srNOIndex = 25
            for i in range(25):
                if (self.FolioPos.tableView.horizontalHeader().isSectionHidden(i)):
                    srNOIndex -= 1

            srNO = int(float(indexes[srNOIndex].data()))

            token = self.FolioPos.table[srNO, 5]
            exchange = self.FolioPos.table[srNO, 4]
        except:
            print(traceback.print_exc())


    if(token!=self.snapW.Token):
        self.snapW.Token = token
        self.ins_details = self.fo_contract[token-35000]
        lua = self.ins_details
        # print("LUaa:::::", lua)
        self.snapW.cbEx.setCurrentText(lua[0])
        self.snapW.cbSg.setCurrentText(lua[1])
        self.snapW.cbIns.setCurrentText(lua[5])
        self.snapW.cbSym.setCurrentText(lua[3])
        self.snapW.cbExp.setCurrentText(lua[6])
        self.snapW.cbStrk.setCurrentText(lua[7])
        self.snapW.cbOtype.setCurrentText(lua[8])
        self.snapW.LeToken.setText(str(token))
    else:
        # print("----0.0")
        self.snapW.subscription_feed(self.snapW.Token,seg=exchange,streamType=1502)

    if(self.snapW.isVisible()):
        # print("----0")
        self.snapW.hideWindow()
    # print("----1")
    self.snapW.show()

def requestBuyModification(self,appOrderID, exchange, token, price, orderType, validity, productType,triggerPrice,qty,uid):

    try:
        if(exchange == 'NSEFO'):
            ins_details = self.fo_contract[token-35000]
        else:
            ins_details = self.fo_contract[token]

        instrumentType = ins_details[5]
        symbol = ins_details[3]
        exp = ins_details[6]
        strk = ins_details[7]
        opt = ins_details[8]
        tick = ins_details[10]
        lotSize = ins_details[11]
        max = ins_details[14]
        self.buyW.appOrderIdFprModification = appOrderID
        price = '%.2f' %price
        BuyWindow.support.showWindow(self,'PendingOrder',exchange,token,price,qty,symbol,instrumentType,exp,strk,opt,max,lotSize,tick, triggerPrice,uid,validity, productType, orderType,False)
        #self.buyW.show()
    except:
        print(traceback.print_exc())

def requestSellModification(self,appOrderID, exchange, token, price, orderType, validity, productType, triggerPrice, qty,uid):
    try:
        if (exchange == 'NSEFO'):
            ins_details = self.fo_contract[token - 35000]
        else:
            ins_details = self.fo_contract[token]

        instrumentType = ins_details[5]
        symbol = ins_details[3]
        exp = ins_details[6]
        strk = ins_details[7]
        opt = ins_details[8]
        tick = ins_details[10]
        lot = ins_details[11]
        max = ins_details[14]
        self.sellW.appOrderIdFprModification = appOrderID
        price = '%.2f' % price
        SellWindow.support.showWindow(self, 'PendingOrder',exchange, token, price, qty, symbol, instrumentType, exp, strk, opt, max,
                                     lot, tick, triggerPrice, uid, validity, productType, orderType, False)
        # self.buyW.show()
    except:
        print(traceback.print_exc())

def requestMultiModification(self, modifyArray):
    try:

        if (modifyArray[0][7] == 'NSEFO'):
            ins_details = self.fo_contract[modifyArray[0][2] - 35000]
        else:
            ins_details = self.fo_contract[modifyArray[0][2]]
        instrumentType = ins_details[5]
        self.multiModifyW.showWindow( modifyArray, instrumentType)
    except:
        print(traceback.print_exc())

def requestBuyWindow(self,sourceClass):
    # print("inside buy window")
    if(sourceClass == 'MarketWatch'):
        selectedIndexes = self.marketW.tableView.selectedIndexes()

        token = int(float(selectedIndexes[0].data()))
        exchange = selectedIndexes[1].data()
        price = selectedIndexes[8].data()

        if (exchange == 'NSEFO'):
            ins_details = self.fo_contract[token - 35000]
        elif (exchange == 'NSECM'):
            ins_details = self.eq_contract[token]
        elif (exchange == 'NSECD'):
            ins_details = self.cd_contract[token]

        instrumentType = ins_details[5]

        noOfLots = self.buyW.settings[exchange][instrumentType[0]]['Lots']
        multiplier = self.buyW.settings[exchange][instrumentType[0]]['Multiplier']

    elif(sourceClass == 'MarketWatch_basic'):
        selectedIndexes = self.marketWB.tableView.selectedIndexes()
        # print("selectedIndexes:",selectedIndexes[0].data())
        token = int(float(selectedIndexes[0].data()))
        exchange = selectedIndexes[1].data()
        price = selectedIndexes[8].data()
        if (exchange == 'NSEFO'):
            ins_details = self.fo_contract[token - 35000]
        elif (exchange == 'NSECM'):
            ins_details = self.eq_contract[token]
        elif (exchange == 'NSECD'):
            ins_details = self.cd_contract[token]
        instrumentType = ins_details[5]
        noOfLots = self.buyW.settings[exchange][instrumentType[0]]['Lots']
        multiplier = self.buyW.settings[exchange][instrumentType[0]]['Multiplier']

    elif(sourceClass == 'NetPosition'):
        # selectedIndexes = self.NetPos.tableView.selectedIndexes()
        # print("selectedIndexes:",selectedIndexes[0].data())
        indexes = self.NetPos.tableView.selectedIndexes()
        srNOIndex = 18
        for i in range(18):
            if (self.NetPos.tableView.horizontalHeader().isSectionHidden(i)):
                srNOIndex -= 1

        srNO = int(float(indexes[srNOIndex].data()))
        # tokenBuy = marketwatchSupportRef.getToken(marketwatchRef, srNO1)

        token = self.NetPos.Apipos[srNO,3]
        exchange = self.NetPos.Apipos[srNO,2]
        price =  '%.2f' % self.NetPos.Apipos[srNO,11]
        if (exchange == 'NSEFO'):
            ins_details = self.fo_contract[token - 35000]
        elif (exchange == 'NSECM'):
            ins_details = self.eq_contract[token]
        elif (exchange == 'NSECD'):
            ins_details = self.cd_contract[token]

        instrumentType = ins_details[5]

        noOfLots = 1
        multiplier = 1

    elif(sourceClass == 'SnapQuote'):

        token = self.snapW.Token
        exchange = self.snapW.exchange
        price = self.snapW.sp1.text()
        if (exchange == 'NSEFO'):
            ins_details = self.fo_contract[token - 35000]
        elif (exchange == 'NSECM'):
            ins_details = self.eq_contract[token]
        elif (exchange == 'NSECD'):
            ins_details = self.cd_contract[token]
        instrumentType = ins_details[5]
        noOfLots = self.buyW.settings[exchange][instrumentType[0]]['Lots']

        multiplier = self.buyW.settings[exchange][instrumentType[0]]['Multiplier']

    elif(sourceClass == 'FolioPosition'):
        print('shortcutfolio')

        indexes = self.FolioPos.tableView.selectedIndexes()
        srNOIndex = 25
        for i in range(25):
            if (self.FolioPos.tableView.horizontalHeader().isSectionHidden(i)):
                srNOIndex -= 1

        srNO = int(float(indexes[srNOIndex].data()))

        token = self.FolioPos.table[srNO, 5]
        exchange = self.FolioPos.table[srNO, 4]
        price = '%.2f' % self.FolioPos.table[srNO, 20]

        # self.sellW.cbStretegyNo.setCurrentText(self.FolioPos.cbUID.currentText())
        # self.buyW.cbStretegyNo.setCurrentText(self.FolioPos.cbUID.currentText())


        if (exchange == 'NSEFO'):
            ins_details = self.fo_contract[token - 35000]
        elif (exchange == 'NSECM'):
            ins_details = self.eq_contract[token]
        elif (exchange == 'NSECD'):
            ins_details = self.cd_contract[token]

        instrumentType = ins_details[5]
        noOfLots = 1
        multiplier = 1



    elif(sourceClass == 'SellW'):
        # print("inside buy window : 1.5")
        token = int(self.sellW.leToken.text())
        exchange = self.sellW.cbEx.currentText()
        price = (self.sellW.leRate.text())
        sellSupport.hideWindow( self.sellW)
        if (exchange == 'NSEFO'):
            ins_details = self.fo_contract[token - 35000]
        elif (exchange == 'NSECM'):
            ins_details = self.eq_contract[token]
        elif (exchange == 'NSECD'):
            ins_details = self.cd_contract[token]

        instrumentType = ins_details[5]

        noOfLots = self.buyW.settings[exchange][instrumentType[0]]['Lots']
        multiplier = self.buyW.settings[exchange][instrumentType[0]]['Multiplier']



    elif(sourceClass == 'BuyW'):
        # print("inside buy window : 1.5")
        token = int(self.buyW.leToken.text())
        exchange = self.buyW.cbEx.currentText()
        price = (self.buyW.leRate.text())
        buySupport.hideWindow( self.buyW)
        if (exchange == 'NSEFO'):
            ins_details = self.fo_contract[token - 35000]
        elif (exchange == 'NSECM'):
            ins_details = self.eq_contract[token]
        elif (exchange == 'NSECD'):
            ins_details = self.cd_contract[token]
        instrumentType = ins_details[5]
        noOfLots = self.buyW.settings[exchange][instrumentType[0]]['Lots']

        multiplier = self.buyW.settings[exchange][instrumentType[0]]['Multiplier']

    # elif(sourceClass == 'OptionChain'):
    #     exchange = 'NSEFO'
    #     selectedIndexes = self.optionChain.tableView.selectedIndexes()
    #     cetoken = int(selectedIndexes[0].data())
    #     petoken = int(selectedIndexes[1].data())
    #     # price = (self.buyW.leRate.text())
    #     buySupport.hideWindow( self.optionChain)

    symbol = ins_details[3]
    exp = ins_details[6]
    strk = ins_details[7]
    opt = ins_details[8]
    tick = ins_details[10]
    lot_size = ins_details[11]
    max = ins_details[14]
    triggerPrice = '0.0'
    qty = noOfLots*lot_size

    qty = max if qty >max else qty


    # Multiplier = multiplier

    print("inside buy window : 2")
    BuyWindow.support.showWindow(self,sourceClass,exchange,token,price,qty,symbol,instrumentType,exp,strk,opt,max,lot_size,tick, triggerPrice,multiplier)

    # spreadOrder.support.showWindow(self,symbol,exp,strk,opt)


def requestSellWindow(self,sourceClass):
    print('insell window')




    if(sourceClass == 'MarketWatch'):
        selectedIndexes = self.marketW.tableView.selectedIndexes()
        token = int(selectedIndexes[0].data())
        exchange = selectedIndexes[1].data()
        price =  selectedIndexes[7].data()

    elif(sourceClass == 'MarketWatch_basic'):
        selectedIndexes = self.marketWB.tableView.selectedIndexes()
        token = int(selectedIndexes[0].data())
        exchange = selectedIndexes[1].data()
        price =  selectedIndexes[7].data()

    elif(sourceClass == 'NetPosition'):
        indexes = self.NetPos.tableView.selectedIndexes()
        srNOIndex = 18
        for i in range(18):
            if (self.NetPos.tableView.horizontalHeader().isSectionHidden(i)):
                srNOIndex -= 1

        srNO = int(float(indexes[srNOIndex].data()))
        # tokenBuy = marketwatchSupportRef.getToken(marketwatchRef, srNO1)

        token = self.NetPos.Apipos[srNO, 3]
        exchange = self.NetPos.Apipos[srNO, 2]
        price = '%.2f' % self.NetPos.Apipos[srNO, 11]
    elif(sourceClass == 'SnapQuote'):
        token = self.snapW.Token
        exchange = self.snapW.exchange
        price = self.snapW.bp1.text()
    elif(sourceClass == 'BuyW'):
        token = int(self.buyW.leToken.text())
        exchange = self.buyW.cbEx.currentText()
        price = (self.buyW.leRate.text())
        buySupport.hideWindow( self.buyW)
    elif(sourceClass == 'SellW'):
        token = int(self.sellW.leToken.text())
        exchange = self.sellW.cbEx.currentText()
        price = (self.sellW.leRate.text())
        sellSupport.hideWindow( self.sellW)

    elif(sourceClass == 'FolioPosition'):
        indexes = self.FolioPos.tableView.selectedIndexes()
        srNOIndex = 25
        for i in range(25):
            if (self.FolioPos.tableView.horizontalHeader().isSectionHidden(i)):
                srNOIndex -= 1

        srNO = int(float(indexes[srNOIndex].data()))

        token = self.FolioPos.table[srNO, 5]
        exchange = self.FolioPos.table[srNO, 4]
        price = '%.2f' % self.FolioPos.table[srNO, 20]

        # self.sellW.cbStretegyNo.setCurrentText(self.FolioPos.cbUID.currentText())
        # self.buyW.cbStretegyNo.setCurrentText(self.FolioPos.cbUID.currentText())




        noOfLots = 1
        multiplier = 1



    if(exchange == 'NSEFO'):
        ins_details = self.fo_contract[token-35000]
    else:
        ins_details = self.fo_contract[token]

    instrumentType = ins_details[5]
    symbol = ins_details[3]
    exp = ins_details[6]
    strk = ins_details[7]
    opt = ins_details[8]
    tick = ins_details[10]
    lot = ins_details[11]
    max = ins_details[14]

    triggerPrice = '0.0'

    SellWindow.support.showWindow(self,sourceClass,exchange,token,price,lot,symbol,instrumentType,exp,strk,opt,max,lot,tick,triggerPrice)



# def folioRequested(self,superClass):
#     try:
#         if (superClass == 'MarketWatch'):
#             token = int(self.marketW.tableView.selectedIndexes()[0].data())
#             exchange = self.marketW.tableView.selectedIndexes()[1].data()
#         elif (superClass == 'MarketWatch_basic'):
#             token = int(self.marketWB.tableView.selectedIndexes()[0].data())
#             exchange = self.marketWB.tableView.selectedIndexes()[1].data()
#         elif (superClass == 'PendingOrder'):
#             token = int(self.PendingW.tableView.selectedIndexes()[2].data())
#             exchange = self.PendingW.tableView.selectedIndexes()[19].data()
#         elif (superClass == 'NetPosition'):
#             token = int(self.NetPos.tableView.selectedIndexes()[3].data())
#             exchange = self.NetPos.tableView.selectedIndexes()[2].data()
#         elif (superClass == 'FolioPosition'):
#             token = int(self.FolioPos.tableView.selectedIndexes()[5].data())
#             exchange = self.FolioPos.tableView.selectedIndexes()[4].data()
#         elif (superClass == 'SnapQuote'):
#             token = self.snapW.Token
#             exchange = self.snapW.exchange
#
#         elif (superClass == 'TradeBook'):
#             token = self.tra.Token
#         exchange = self.snapW.exchange
#
#     except:
#         token = ''
#     showPendingW(self, token)

