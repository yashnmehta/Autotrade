from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import *

def res_max(self):
    if (self.isMaximized() == False):
        self.showMaximized()
        self.CFrame.resizeDocks([self.CFrame.dockOP, self.CFrame.dockMW], [700, 500], Qt.Vertical)
    else:
        self.showNormal()
        self.CFrame.resizeDocks([self.CFrame.dockOP, self.CFrame.dockMW], [500, 500], Qt.Vertical)



def closeApp(main):
    print("exit")

    main.messageBox = QMessageBox()
    main.messageBox.setIcon(QMessageBox.Critical)
    main.messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
    main.messageBox.setText('Do you really want to quit..?')
    # main.messageBox.setInformativeText("Do you want to SquareOff Postion?")
    main.messageBox.setWindowTitle('Save Data')
    main.messageBox.addButton(QPushButton('Yes'), QMessageBox.YesRole)
    main.messageBox.addButton(QPushButton('No'), QMessageBox.RejectRole)
    main.messageBox.buttonClicked.connect(main.CloseButtonClicked)
    main.messageBox.exec()



def CloseButtonClicked(main,button):
    if (button.text() == 'Yes'):
        main.messageBox1 = QMessageBox()
        main.messageBox1.setIcon(QMessageBox.Critical)
        main.messageBox1.setWindowFlags(Qt.WindowStaysOnTopHint)
        main.messageBox1.setText('Do you want to Save data to Database.. ?')
        # main.messageBox.setInformativeText("Do you want to SquareOff Postion?")
        main.messageBox1.setWindowTitle('Save Data')
        main.messageBox1.addButton(QPushButton('Yes'), QMessageBox.YesRole)
        main.messageBox1.addButton(QPushButton('No'), QMessageBox.RejectRole)
        main.messageBox1.buttonClicked.connect(main.QuitButtonClicked)
        main.messageBox1.exec()
        main.close()

    else:
        pass

def QuitButtonClicked(main,button):
    if (button.text() == 'Yes'):
        pass
        # main.saveTradestoDatabase()
    else:
        pass

        # sys.exit()