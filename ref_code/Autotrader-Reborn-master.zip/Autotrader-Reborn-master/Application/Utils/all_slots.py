
from Application.Utils.scriptSearch import scriptBarSlots
import  sys

from Application.Utils.openRequstedWindow import showPendingW,showFolioPosW,showOrderBookW,showTradeBookW
from Application.Utils.animations import *
from Application.Utils.feedHandler import FeedHandler
from Application.Utils.supMethods import *
from Application.Utils.configReader import refresh
from Application.Utils.updation import *
from Application.Utils.basicWinOps import res_max,closeApp


from Application.Utils.basicWinOps import res_max

from Application.Utils.animations import *

from Application.Utils.supMethods import createTimers, proceed2login, proceed2Main
from Application.Stretegies.Utils.stretegyMainOps import activateStretegy,resumeStretegy, stopStretegy, deleteStretegy
from Application.Stretegies.Utils.stretegySideOps import showStretegyModificationWindow

from Application.Stretegies import TSpecial
from Application.Views.FeedManager.support import showFeedManagerWindow, connectFeed
from Application.Views.OptionChain import  support
from Application.Views.Prerferences import  support
from Application.Views import Prerferences
from Application.Views import OptionChain


def createSlots_main(main, tray=None):
    try:
        scriptBarSlots(main)
        main.pbFolioPos.clicked.connect(main.FolioPos.hide)
        main.pbFolioPos.clicked.connect(main.FolioPos.show)

        main.pbNetPos.clicked.connect(main.NetPos.hide)
        main.pbNetPos.clicked.connect(main.NetPos.show)
        main.pbTradeB.clicked.connect(main.TradeW.hide)
        main.pbTradeB.clicked.connect(main.TradeW.show)
        main.pbTradeB.clicked.connect(lambda :ShowTradeBook(main))
        main.pbOrderB.clicked.connect(main.OrderBook.hide)
        main.pbOrderB.clicked.connect(main.OrderBook.show)
        main.pbOrderB.clicked.connect(lambda :ShowOrderBook(main))
        main.pbShortcutInfo.clicked.connect(main.shortcutInfoW.hide)
        main.pbShortcutInfo.clicked.connect(main.shortcutInfoW.show)

        main.pbOpChain.clicked.connect(main.OptionChain.hide)
        main.pbOpChain.clicked.connect(main.OptionChain.show)
        main.pbOpChain.clicked.connect(lambda: OptionChain.support.updateTokenList(main))

        main.OptionChain.bt_close.clicked.connect(lambda: OptionChain.support.updateTokenListCloseW(main))



        main.pbPreferences.clicked.connect(main.PreferanceW.show)
        main.PreferanceW.pbApply.clicked.connect(lambda: main.setDefaultClient)

        ################################## Trade Setting Slot  ##########################################

        ################################# Login Class Slota ####################################

        main.login.pbLogin.clicked.connect(lambda : proceed2login(main))
        main.login.pbNext.clicked.connect(lambda : proceed2Main(main))
        main.login.pbCancel.clicked.connect(sys.exit)

        main.IAS.sgSocketConn.connect(main.LiveFeed.start_socket)
        main.IAS.sgSocketConn.connect(lambda: changeIAS_connIcon(main, 0))
        main.IAS.sgSocketConn.connect(lambda: main.login.label.append('Interactive socket is connected'))

        main.LiveFeed.sgSocketConn.connect(lambda: changeMD_connIcon(main, 0))
        main.LiveFeed.sgSocketConn.connect(lambda: main.login.label.append('Marketdata socket is connected'))
        main.LiveFeed.sgSocketConn.connect(main.timernext.start)

        ###############################################################################3
        # main.marketW.buyw.sgAppOrderID.connect(main.inPoreccessOrderIds.append)
        # main.marketW.sellw.sgAppOrderID.connect(main.inPoreccessOrderIds.append)
        #########################################################################################3
        # main.IAS.sgGetAPIpos.connect(lambda: updateGetPosition(main))
        main.IAS.sgOpenPos.connect(lambda: updateOpenPosition(main))

        main.IAS.sgAPIpos.connect(main.updateOnPosition)
        main.IAS.sgTrdSoc.connect(main.updateOnTrade)
        main.IAS.sgPendSoc.connect(main.updateOderSocket)


        ######################################################################
        # both getOrderbook process is done directly from Api call methos only
        # main.IAS.sgGetOrder.connect(main.updateGetorderBook)
        # main.IAS.sgGetPOrder.connect(main.updateGetPendinOrderBook)
        # main.IAS.sgGetTrd.connect(main.on_get_tradeBook)

        ######################################################################

        ############################################################################################
        main.LiveFeed.sgindexfd.connect(main.on_new_feed_Index)

        main.LiveFeed.sgNPFrec.connect(main.on_new_feed_1501)

        main.LiveFeed.sgNPFSub.connect(main.on_new_feed_sub_1501)
       # main.broadcastReader.sgNPF.connect(main.on_new_Feed_broadcaster)
        main.LiveFeed.sgNSQrec.connect(main.on_new_feed_1502)

        # main.recv_fo.sgData7202.connect(main.on_new_feed_7202)

        main.recv_fo.sgData7202.connect(main.on_new_feed_7202_OC)
        main.recv_fo.sgDataIV_LTP.connect(main.on_new_feed_ltp_iv)
        main.recv_fo.sgDataIV_BA.connect(main.on_new_feed_ba_iv)
        main.recv_fo.sgDataGreeks.connect(main.on_new_feed_greeks)

        # main.recv_fo.sgData7208.connect(main.on_new_feed_7208)
        main.recv_fo.sgData7208.connect(main.on_new_feed_7208_OC)

        #########################################################################################3
        main.IAS.sgStatusUp.connect(main.updateStatusLable)
        #########################################################################################3
        # main.PositionW.sgTMTM.connect(main.setMTM)
        # main.bt_close.clicked.connect(main.close)
        main.bt_close.clicked.connect(lambda: closeApp(main))
        main.bt_min.clicked.connect(main.showMinimized)
        main.bt_max.clicked.connect(lambda: res_max(main))
        main.title.sgPoss.connect(main.movWin)
        # main.pbMenu.clicked.connect(main.openSideBar)
        # main.pbDPosition.clicked.connect(lambda:showDetailPos(main.marketW.DetailPos))

        # main.pbBanned.clicked.connect(main.Banned.show)

        # main.Splash.sgFin.connect(lambda: splashWork(main))
        main.cbMrglvl.currentIndexChanged.connect(main.setMrgLvl)
        main.btnIB.clicked.connect(lambda: showIndexBar(main))
        main.btnSB.clicked.connect(lambda: showScriptBar(main))
        main.btnMV.clicked.connect(lambda: showMarginBar(main))
        main.btnSttn.clicked.connect(lambda: showSettingMenu(main))
        main.title.sgDClick.connect(lambda: res_max(main))
        main.marketW.sgShowPending.connect(lambda: showPendingW(main))

        main.OptionChain.pbGet.clicked.connect(lambda: OptionChain.support.changeOptionChain(main))
        main.OptionChain.pbGet.clicked.connect(lambda :OptionChain.support.getClosingOI(main))
        main.OptionChain.pbApply.clicked.connect(lambda: OptionChain.support.changeOptionChainwithNoofstrike(main))
        # self.pbApply.clicked.connect(lambda: changeOptionChainwithNoofstrike(self))


        # main.Banned.pbAddBSym.clicked.connect(lambda: addBannedSymbol(main))
        # main.Banned.pbAddBIns.clicked.connect(lambda: addBannedInstrument(main))
        # main.Banned.pbRemBSym.clicked.connect(lambda: remBannedSymbol(main))
        # main.Banned.pbRemBIns.clicked.connect(lambda: remBannedInstrument(main))



        main.Manager.pbAdd.clicked.connect(main.addNewStretegy)
        main.Manager.pbActivate.clicked.connect(lambda:activateStretegy(main))
        main.Manager.pbEOD.clicked.connect(lambda:eodProcess(main))
        main.Manager.pbCFP.clicked.connect(lambda:CFSPosition(main))
        main.Manager.pbResume.clicked.connect(lambda:resumeStretegy(main))
        main.Manager.pbDelete.clicked.connect(lambda:deleteStretegy(main))
        main.Manager.pbStop.clicked.connect(lambda:stopStretegy(main))
        main.Manager.pbModify.clicked.connect(lambda:showStretegyModificationWindow(main))


        main.Manager.pbSquareOff.clicked.connect(lambda : squareOffStretegy(main))
        # Feed
        main.pbFeedManager.clicked.connect(lambda : showFeedManagerWindow(main))
        main.feedManager.pbConnect.clicked.connect(lambda: connectFeed(main))
        #StatusbarSetting#######################################################################
        main.FolioPos.sgrecvfosubscribe.connect(main.subscribeRecvFO)
        main.PreferanceW.pbSttsApply.clicked.connect(lambda : changeStatusBarSettings(main))
        main.PreferanceW.pbConnect.clicked.connect(lambda :Prerferences.support.connect2selectedFeeds(main))
        main.PreferanceW.pbDisconnect.clicked.connect(lambda :Prerferences.support.disconnect2selectedFeeds(main))

    except:
        print(traceback.print_exc())


