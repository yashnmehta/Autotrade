import sys
import traceback

from PyQt5.QtWidgets import QMenu
from PyQt5.QtCore import  pyqtSlot
from Application.Utils.openRequstedWindow import multiOrdersRequested
from Application.Utils.openRequstedWindow import swapOrderRequested
from Application.Utils.openRequstedWindow import spreadOrderRequested

# #
# def headerRightClickMenu_mw(self, position):
#     try:
#         menu = QMenu()
#         saveColumnProfile = menu.addAction("save col profile")
#         restoreColumnProfile = menu.addAction("open Col Profile")
#         hideColumn = menu.addAction("hide")
#         reset = menu.addAction("reset")
#
#         # cancelAction = menu.addAction("Cancel")
#         action = menu.exec_(self.tableView.horizontalHeader().mapToGlobal(position))
#         if action == saveColumnProfile:
#             self.saveColumnProfile()
#         elif (action == restoreColumnProfile):
#             self.openColumnProfile()
#         elif (action == hideColumn):
#
#             x = (self.tableView.horizontalHeader().logicalIndexAt(position))
#             self.tableView.horizontalHeader().hideSection(x)
#         elif (action == reset):
#             self.updateDefaultColumnProfile()
#     except:
#         print(sys.exc_info()[1])
#
@pyqtSlot(tuple,object)
def tableRightClickMenu_mw(main,position ):
    try:
        # a=(self.tableView.selectedIndexes()[0].data())
        Menu = QMenu()
        # QuickT = Menu.addAction("QuickT")
        # action = self.Menu.exec_(self.tableView.mapToGlobal(position))

        SubMenu = QMenu(Menu)
        SubMenu.setTitle('Quick-Trade')
        Multi = SubMenu.addAction('Multi Order')
        Swap = SubMenu.addAction('Swap Order')
        Spread = SubMenu.addAction('Spread Order')
        Menu.addMenu(SubMenu)
        action = Menu.exec_(main.marketW.tableView.mapToGlobal(position))
        if action == Multi:
            multiOrdersRequested(main, 'MarketWatch')
        elif action == Swap:
            swapOrderRequested(main,'MarketWatch')

        elif action == Spread:
            spreadOrderRequested(main,'MarketWatch')


    except:
        print(traceback.print_exc())
# # def tableRightClickMenu_mw_Basic(main,position ):
# #     try:
# #         # a=(self.tableView.selectedIndexes()[0].data())
# #         Menu = QMenu()
# #         # QuickT = Menu.addAction("QuickT")
# #         # action = self.Menu.exec_(self.tableView.mapToGlobal(position))
# #
# #         SubMenu = QMenu(Menu)
# #         SubMenu.setTitle('Quick-Trade')
# #         Multi = SubMenu.addAction('Multi Order')
# #         Swap = SubMenu.addAction('Swap Order')
# #         Spread = SubMenu.addAction('Spread Order')
# #         Menu.addMenu(SubMenu)
# #         action = Menu.exec_(main.marketWB.tableView.mapToGlobal(position))
# #         if action == Multi:
# #             multiOrdersRequested(main, 'MarketWatch')
# #         elif action == Swap:
# #             swapOrderRequested(main,'MarketWatch')
# #
# #         elif action == Spread:
# #             spreadOrderRequested(main,'MarketWatch')
# #
# #
# #     except:
# #         print(traceback.print_exc())
# #
# #
# #
