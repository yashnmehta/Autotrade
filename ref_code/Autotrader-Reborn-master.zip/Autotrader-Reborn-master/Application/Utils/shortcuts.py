from PyQt5.QtWidgets import QShortcut,QPushButton
from PyQt5.QtGui import QIcon, QKeySequence
from PyQt5.QtCore import Qt
from Application.Utils.openRequstedWindow import *
from Application.Utils.scriptSearch import *
from Application.Views import BuyWindow
from Application.Views import SellWindow
from Application.Views import PendingOrder
from Application.Views import basicMWatch
from Application.Views import MultiOrders
from Application.Utils.animations import showSettingMenu
from Application.Views import SwapOrder
from Application.Views.OptionChain.optionSelection import *
from Application.Views.OptionChain import optionSelection
from Application.Views import quickTrade

#from Application.Views.basicMWatch.mWatch import MarketW_basic

# from Application
def setWindowShortcuts(self):
    self.quitSc = QShortcut(QKeySequence('Esc'), self)
    self.quitSc.activated.connect(self.hide)



#this methon belongs to main class only
def setShortcuts(self):
    ###############################################################
    # setWindowShortcuts(self)
    ###############################################################

    self.selExch = QShortcut(QKeySequence('Ctrl+S'), self)
    self.selExch.activated.connect(lambda:selExchange(self))


    self.scriptBar.addScript = QShortcut(QKeySequence('Enter'), self.scriptBar)
    self.scriptBar.addScript.setContext(Qt.WidgetWithChildrenShortcut)
    self.scriptBar.addScript.activated.connect(lambda:addscript(self))

    self.scriptBar.addScript = QShortcut(QKeySequence('Return'), self.scriptBar)
    self.scriptBar.addScript.setContext(Qt.WidgetWithChildrenShortcut)
    self.scriptBar.addScript.activated.connect(lambda:addscript(self))








    ########################################################################################################################

    self.callNetPos = QShortcut(QKeySequence('Alt+F6'), self)
    self.callNetPos.activated.connect(lambda: netPosRequested(self, ''))

    settingsMenu_shortcut(self)

    # self.sellW.callBuyW1 = QShortcut(QKeySequence('Esc'), self.sellW)
    # self.sellW.callBuyW1.setContext(Qt.WidgetWithChildrenShortcut)
    # self.sellW.callBuyW1.activated.connect(lambda: requestBuyWindow(self, 'SellW'))




    ############################@#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@##################################################################################################3


    # multi modification
    self.buyW.PlaceOrdSc1 = QShortcut(QKeySequence('Return'), self.buyW)
    self.buyW.PlaceOrdSc1.activated.connect(lambda:BuyWindow.support.validateAndPunch(self))
    self.buyW.PlaceOrdSc2 = QShortcut(QKeySequence('Enter'), self.buyW)
    self.buyW.PlaceOrdSc2.activated.connect(lambda:BuyWindow.support.validateAndPunch(self))
    self.buyW.pbSubmit.clicked.connect(lambda:BuyWindow.support.placeOrd(self))

    # self.buyW.PlaceOrdSc1 = QShortcut(QKeySequence('Return'), self.buyW)
    # self.buyW.PlaceOrdSc1.activated.connect(lambda:BuyWindow.support.placeOrd(self))
    # self.buyW.PlaceOrdSc2 = QShortcut(QKeySequence('Enter'), self.buyW)
    # self.buyW.PlaceOrdSc2.activated.connect(lambda:BuyWindow.support.placeOrd(self))
    # self.buyW.pbSubmit.clicked.connect(lambda:BuyWindow.support.placeOrd(self))
    #


    self.sellW.PlaceOrdSc1 = QShortcut(QKeySequence('Return'), self.sellW)
    self.sellW.PlaceOrdSc1.activated.connect(lambda:SellWindow.support.validateAndPunch(self))
    self.sellW.PlaceOrdSc2 = QShortcut(QKeySequence('Enter'), self.sellW)
    self.sellW.PlaceOrdSc2.activated.connect(lambda:SellWindow.support.validateAndPunch(self))
    self.sellW.pbSubmit.clicked.connect(lambda:SellWindow.support.placeOrd(self))


    self.multiModifyW.PlaceOrdSc1 = QShortcut(QKeySequence('Return'), self.multiModifyW)
    self.multiModifyW.PlaceOrdSc1.activated.connect(self.multiModifyW.modifyMultipleOrders)
    self.multiModifyW.PlaceOrdSc2 = QShortcut(QKeySequence('Enter'), self.multiModifyW)
    self.multiModifyW.PlaceOrdSc2.activated.connect(self.multiModifyW.modifyMultipleOrders)

    ##############################################################################################
    self.sellW.callBuyW = QShortcut(QKeySequence('+'), self.sellW)
    self.sellW.callBuyW.setContext(Qt.WidgetWithChildrenShortcut)
    self.sellW.callBuyW.activated.connect(lambda: requestBuyWindow(self, 'SellW'))

    self.sellW.callSellW = QShortcut(QKeySequence('-'), self.sellW)
    self.sellW.callSellW.setContext(Qt.WidgetWithChildrenShortcut)
    self.sellW.callSellW.activated.connect(lambda: requestSellWindow(self, 'SellW'))

    self.sellW.callBuyW1 = QShortcut(QKeySequence('F1'), self.sellW)
    self.sellW.callBuyW1.setContext(Qt.WidgetWithChildrenShortcut)
    self.sellW.callBuyW1.activated.connect(lambda: requestBuyWindow(self, 'SellW'))

    self.buyW.callSellW = QShortcut(QKeySequence('-'), self.buyW)
    self.buyW.callSellW.setContext(Qt.WidgetWithChildrenShortcut)
    self.buyW.callSellW.activated.connect(lambda: requestSellWindow(self, 'BuyW'))

    self.buyW.callBuyW = QShortcut(QKeySequence('+'), self.buyW)
    self.buyW.callBuyW.setContext(Qt.WidgetWithChildrenShortcut)
    self.buyW.callBuyW.activated.connect(lambda: requestBuyWindow(self, 'BuyW'))

    self.buyW.callSellW1 = QShortcut(QKeySequence('F2'), self.buyW)
    self.buyW.callSellW1.setContext(Qt.WidgetWithChildrenShortcut)
    self.buyW.callSellW1.activated.connect(lambda: requestSellWindow(self, 'BuyW'))

    ##############################################################################################

    ############# Multi Orders
    self.multiOrders.executeOrdersReturnBtn = QShortcut(QKeySequence('Return'), self.multiOrders)
    self.multiOrders.executeOrdersReturnBtn.activated.connect(lambda : MultiOrders.support.executeMultipleOrders(self))
    self.multiOrders.executeOrdersEnterBtn = QShortcut(QKeySequence('Enter'), self.multiOrders)
    self.multiOrders.executeOrdersEnterBtn.activated.connect(lambda : MultiOrders.support.executeMultipleOrders(self))
    self.multiOrders.pbSubmit.clicked.connect(lambda: MultiOrders.support.executeMultipleOrders(self))



    ####################Swap Orders
    self.swapOrder.executeOrdersReturnBtn = QShortcut(QKeySequence('Return'), self.swapOrder)
    self.swapOrder.executeOrdersReturnBtn.activated.connect(lambda : SwapOrder.support.executeSwapOrders(self))
    self.swapOrder.executeOrdersEnterBtn = QShortcut(QKeySequence('Enter'), self.swapOrder)
    self.swapOrder.executeOrdersEnterBtn.activated.connect(lambda : SwapOrder.support.executeSwapOrders(self))
    self.swapOrder.pbApply.clicked.connect(lambda: SwapOrder.support.executeSwapOrders(self))


    ####################Spread Orders
    self.spreadOrder.executeOrdersReturnBtn = QShortcut(QKeySequence('Return'), self.spreadOrder)
    self.spreadOrder.executeOrdersReturnBtn.activated.connect(lambda : SpreadOrder.support.executeSpreadOrders(self))
    self.spreadOrder.executeOrdersEnterBtn = QShortcut(QKeySequence('Enter'), self.spreadOrder)
    self.spreadOrder.executeOrdersEnterBtn.activated.connect(lambda : SpreadOrder.support.executeSpreadOrders(self))
    self.spreadOrder.pbApply.clicked.connect(lambda: SpreadOrder.support.executeSpreadOrders(self))



    sManger_shortcut(self)
    MWatch_Shortcut(self)
    MWBasic_shortcut(self)

    FolioPos_shortcut(self)
    NetPos_shortcut(self)
    tradebook_shortcut(self)
    OrderBook_shortcut(self)
    PendingBook_shortcut(self)
    snapW_shortcut(self)


def sManger_shortcut(self):


    self.focusSt = QShortcut(QKeySequence('Z'), self)
    self.focusSt.activated.connect(lambda:self.Manager.pbCustomSt.setFocus(True))

    self.Manager.tableView.scFolioPos = QShortcut(QKeySequence('F11'), self.Manager)
    self.Manager.tableView.scFolioPos.setContext(Qt.WidgetWithChildrenShortcut)
    self.Manager.tableView.scFolioPos.activated.connect(lambda: FolioPosRequested(self, 'Manager'))

    self.Manager.scAddCustom = QShortcut(QKeySequence('C,A'), self.Manager)
    self.Manager.scAddCustom.setContext(Qt.WidgetWithChildrenShortcut)
    self.Manager.scAddCustom.activated.connect(self.Manager.pbCustomSt.click)
    self.Manager.scAddCustom.activated.connect(self.Manager.pbAdd.click)

    self.Manager.scAddTSpecial = QShortcut(QKeySequence('T,A'), self.Manager)
    self.Manager.scAddTSpecial.setContext(Qt.WidgetWithChildrenShortcut)
    self.Manager.scAddTSpecial.activated.connect(self.Manager.pbTSpecial.click)
    self.Manager.scAddTSpecial.activated.connect(self.Manager.pbAdd.click)

    self.Manager.scAddMomentum = QShortcut(QKeySequence('M,A'), self.Manager)
    self.Manager.scAddMomentum.setContext(Qt.WidgetWithChildrenShortcut)
    self.Manager.scAddMomentum.activated.connect(self.Manager.pbMomentum.click)
    self.Manager.scAddMomentum.activated.connect(self.Manager.pbAdd.click)

    self.Manager.scAddPyramid = QShortcut(QKeySequence('P,A'), self.Manager)
    self.Manager.scAddPyramid.setContext(Qt.WidgetWithChildrenShortcut)
    self.Manager.scAddPyramid.activated.connect(self.Manager.pbPyramid.click)
    self.Manager.scAddPyramid.activated.connect(self.Manager.pbAdd.click)


    self.Manager.scjodiATM = QShortcut(QKeySequence('J,A'), self.Manager)
    self.Manager.scjodiATM.setContext(Qt.WidgetWithChildrenShortcut)
    self.Manager.scjodiATM.activated.connect(self.Manager.pbJodiATM.click)
    self.Manager.scjodiATM.activated.connect(self.Manager.pbAdd.click)

    self.Manager.scJTiger = QShortcut(QKeySequence('G,A'), self.Manager)
    self.Manager.scJTiger.setContext(Qt.WidgetWithChildrenShortcut)
    self.Manager.scJTiger.activated.connect(self.Manager.pbJTiger.click)
    self.Manager.scJTiger.activated.connect(self.Manager.pbAdd.click)

    self.Manager.scPairSell = QShortcut(QKeySequence('S,A'), self.Manager)
    self.Manager.scPairSell.setContext(Qt.WidgetWithChildrenShortcut)
    self.Manager.scPairSell.activated.connect(self.Manager.pbPairSell.click)
    self.Manager.scPairSell.activated.connect(self.Manager.pbAdd.click)



    self.Manager.settingsMenu.scAddFolio = QShortcut(QKeySequence('A'), self.Manager.settingsMenu)
    self.Manager.settingsMenu.scAddFolio.setContext(Qt.WidgetWithChildrenShortcut)
    self.Manager.settingsMenu.scAddFolio.activated.connect(self.Manager.pbAdd.click)

    self.Manager.scFocusHandler = QShortcut(QKeySequence('H'), self.Manager)
    self.Manager.scFocusHandler.setContext(Qt.WidgetWithChildrenShortcut)
    self.Manager.scFocusHandler.activated.connect(lambda:self.Manager.pbAdd.setFocus(True))

    self.Manager.scFocusHandler = QShortcut(QKeySequence('Q'), self.Manager)
    self.Manager.scFocusHandler.setContext(Qt.WidgetWithChildrenShortcut)
    self.Manager.scFocusHandler.activated.connect(lambda:self.Manager.pbFAll.setFocus(True))

    self.Manager.scFocusHandler = QShortcut(QKeySequence('F'), self.Manager.settingsMenu)
    self.Manager.scFocusHandler.setContext(Qt.WidgetWithChildrenShortcut)
    self.Manager.scFocusHandler.activated.connect(lambda:print('please filter manager table'))

    self.Manager.scFocusHandler = QShortcut(QKeySequence('Esc'), self.Manager)
    self.Manager.scFocusHandler.setContext(Qt.WidgetWithChildrenShortcut)
    self.Manager.scFocusHandler.activated.connect(lambda:self.Manager.tableView.setFocus(True))
    self.Manager.scFocusHandler.activated.connect(lambda:self.Manager.tableView.selectRow(0))



    # for i in self.Manager.scrollArea.findChildren(QPushButton):
    #     i.selectPB = QShortcut(QKeySequence('Return'), i)
    #     i.selectPB.setContext(Qt.WidgetWithChildrenShortcut)
    #     i.selectPB.activated.connect(i.click)

    # for i in self.Manager.scrollArea.findChildren(QPushButton):
    #     i.selectPB = QShortcut(QKeySequence('Return'), i)
    #     i.selectPB.setContext(Qt.WidgetWithChildrenShortcut)
    #     i.selectPB.activated.connect(i.click)
    #





def MWatch_Shortcut(self):
    try:
        self.focusMW = QShortcut(QKeySequence('F4'), self)
        self.focusMW.activated.connect(self.marketW.tableView.setFocus)
        self.focusMW.activated.connect(self.CFrame.dockMW.raise_)

        self.focusMW = QShortcut(QKeySequence('Ctrl+F4'), self)
        self.focusMW.activated.connect(self.marketWB.tableView.setFocus)
        self.focusMW.activated.connect(self.CFrame.dockMW_basic.raise_)

        ##################################################################################################3
        self.marketW.tableView.shortcut_buy = QShortcut(QKeySequence('F1'), self.marketW.tableView)
        self.marketW.tableView.shortcut_buy.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketW.tableView.shortcut_buy.activated.connect(lambda: requestBuyWindow(self, 'MarketWatch'))

        self.marketW.tableView.shortcut_buy1 = QShortcut(QKeySequence('+'), self.marketW.tableView)
        self.marketW.tableView.shortcut_buy1.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketW.tableView.shortcut_buy1.activated.connect(lambda: requestBuyWindow(self, 'MarketWatch'))

        self.marketW.tableView.shortcut_sell = QShortcut(QKeySequence('-'), self.marketW.tableView)
        self.marketW.tableView.shortcut_sell.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketW.tableView.shortcut_sell.activated.connect(lambda: requestSellWindow(self, 'MarketWatch'))

        self.marketW.tableView.shortcut_sell1 = QShortcut(QKeySequence('F2'), self.marketW.tableView)
        self.marketW.tableView.shortcut_sell1.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketW.tableView.shortcut_sell1.activated.connect(lambda: requestSellWindow(self, 'MarketWatch'))

        # self.marketW.tableView.scMultiOrders = QShortcut(QKeySequence('F12'), self.marketW)
        # self.marketW.tableView.scMultiOrders.setContext(Qt.WidgetWithChildrenShortcut)
        # self.marketW.tableView.scMultiOrders.activated.connect(lambda: multiOrdersRequested(self, 'MarketWatch'))

        self.marketW.scPendingOrderW = QShortcut(QKeySequence('F3'), self.marketW)
        self.marketW.scPendingOrderW.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketW.scPendingOrderW.activated.connect(lambda: pendingOrderRequested(self, 'MarketWatch'))

        self.marketW.tableView.scOrderBook = QShortcut(QKeySequence('Ctrl+F3'), self.marketW)
        self.marketW.tableView.scOrderBook.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketW.tableView.scOrderBook.activated.connect(lambda: orderBookRequested(self, 'MarketWatch'))

        self.marketW.tableView.shortcut_snapQuote = QShortcut(QKeySequence('F5'), self.marketW.tableView)
        self.marketW.tableView.shortcut_snapQuote.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketW.tableView.shortcut_snapQuote.activated.connect(lambda: snapQuoteRequested(self, 'MarketWatch'))

        self.marketW.tableView.scTradeBook = QShortcut(QKeySequence('F8'), self.marketW)
        self.marketW.tableView.scTradeBook.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketW.tableView.scTradeBook.activated.connect(lambda: tradeBookRequested(self, 'MarketWatch'))

        self.marketW.tableView.scFolioPos = QShortcut(QKeySequence('F11'), self.marketW)
        self.marketW.tableView.scFolioPos.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketW.tableView.scFolioPos.activated.connect(lambda: FolioPosRequested(self, 'MarketWatch'))

        self.marketW.tableView.callSwapOrder = QShortcut(QKeySequence('S'), self.marketW)
        self.marketW.tableView.callSwapOrder.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketW.tableView.callSwapOrder.activated.connect(lambda: swapOrderRequested(self, 'MarketWatch'))

        # self.marketW.tableView.scMultiOrders = QShortcut(QKeySequence('1'), self.marketW)
        # self.marketW.tableView.scMultiOrders.setContext(Qt.WidgetWithChildrenShortcut)
        # self.marketW.tableView.scMultiOrders.activated.connect(lambda: multiOrdersRequested(self, 'MarketWatch'))

##########################################################################################################################################################################################################################

        self.marketW.tableView.scquickOrder = QShortcut(QKeySequence('Alt+Q'), self.marketW)
        self.marketW.tableView.scquickOrder.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketW.tableView.scquickOrder.activated.connect(lambda : quickOrderRequested(self, 'MarketWatch'))


        self.quickTradeW.scMultiOrders = QShortcut(QKeySequence('1'), self.quickTradeW)
        self.quickTradeW.scMultiOrders.setContext(Qt.WidgetWithChildrenShortcut)
        self.quickTradeW.scMultiOrders.activated.connect(lambda: multiOrdersRequested(self, 'MarketWatch'))
        self.quickTradeW.scMultiOrders.activated.connect(self.quickTradeW.hide)


        self.quickTradeW.pbMulti.clicked.connect(lambda: multiOrdersRequested(self, 'MarketWatch'))
        self.quickTradeW.pbMulti.clicked.connect(self.swapOrder.hide)
        self.quickTradeW.pbMulti.clicked.connect(self.spreadOrder.hide)


        self.quickTradeW.pbSwap.clicked.connect(lambda: swapOrderRequested(self, 'MarketWatch'))
        self.quickTradeW.pbSwap.clicked.connect(self.multiOrders.hide)
        self.quickTradeW.pbSwap.clicked.connect(self.spreadOrder.hide)


        self.quickTradeW.pbSpread.clicked.connect(lambda: spreadOrderRequested(self, 'MarketWatch'))
        self.quickTradeW.pbSpread.clicked.connect(self.multiOrders.hide)
        self.quickTradeW.pbSpread.clicked.connect(self.swapOrder.hide)

        self.quickTradeW.callSwapOrder = QShortcut(QKeySequence('2'), self.quickTradeW)
        self.quickTradeW.callSwapOrder.setContext(Qt.WidgetWithChildrenShortcut)
        self.quickTradeW.callSwapOrder.activated.connect(lambda: swapOrderRequested(self, 'MarketWatch'))
        self.quickTradeW.callSwapOrder.activated.connect(self.quickTradeW.hide)

        self.quickTradeW.scSpreadOrder = QShortcut(QKeySequence('3'), self.quickTradeW)
        self.quickTradeW.scSpreadOrder.setContext(Qt.WidgetWithChildrenShortcut)
        self.quickTradeW.scSpreadOrder.activated.connect(lambda: spreadOrderRequested(self, 'MarketWatch'))
        self.quickTradeW.scSpreadOrder.activated.connect(self.quickTradeW.hide)


    except:
        print(traceback.print_exc())

###############################################################################################################################################################################################################
def MWBasic_shortcut(self):
    try:

        self.marketWB.tableView.shortcut_buy = QShortcut(QKeySequence('F1'), self.marketWB.tableView)
        self.marketWB.tableView.shortcut_buy.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketWB.tableView.shortcut_buy.activated.connect(lambda:requestBuyWindow(self,'MarketWatch_basic'))

        self.marketWB.tableView.shortcut_buy1 = QShortcut(QKeySequence('+'), self.marketWB.tableView)
        self.marketWB.tableView.shortcut_buy1.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketWB.tableView.shortcut_buy1.activated.connect(lambda:requestBuyWindow(self,'MarketWatch_basic'))

        self.marketWB.tableView.shortcut_sell = QShortcut(QKeySequence('-'), self.marketWB.tableView)
        self.marketWB.tableView.shortcut_sell.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketWB.tableView.shortcut_sell.activated.connect(lambda:requestSellWindow(self,'MarketWatch_basic'))

        self.marketWB.tableView.shortcut_sell1 = QShortcut(QKeySequence('F2'), self.marketWB.tableView)
        self.marketWB.tableView.shortcut_sell1.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketWB.tableView.shortcut_sell1.activated.connect(lambda:requestSellWindow(self,'MarketWatch_basic'))

        self.marketWB.scPendingOrderW = QShortcut(QKeySequence('F3'), self.marketWB)
        self.marketWB.scPendingOrderW.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketWB.scPendingOrderW.activated.connect(lambda:pendingOrderRequested(self,'MarketWatch_basic'))



        self.marketWB.tableView.scFolioPos = QShortcut(QKeySequence('F11'), self.marketWB)
        self.marketWB.tableView.scFolioPos.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketWB.tableView.scFolioPos.activated.connect(lambda: FolioPosRequested(self, 'MarketWatch_basic'))

        self.marketWB.tableView.scOrderBook = QShortcut(QKeySequence('Ctrl+F3'), self.marketWB)
        self.marketWB.tableView.scOrderBook.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketWB.tableView.scOrderBook.activated.connect(lambda: orderBookRequested(self, 'MarketWatch_basic'))

        self.marketWB.tableView.scTradeBook = QShortcut(QKeySequence('F7'), self.marketWB)
        self.marketWB.tableView.scTradeBook.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketWB.tableView.scTradeBook.activated.connect(lambda: tradeBookRequested(self, 'MarketWatch_basic'))

        self.marketWB.tableView.scMultiOrders = QShortcut(QKeySequence('F12'), self.marketWB)
        self.marketWB.tableView.scMultiOrders.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketWB.tableView.scMultiOrders.activated.connect(lambda: multiOrdersRequested(self, 'MarketWatch_basic'))

        self.marketWB.tableView.shortcut_snapQuote = QShortcut(QKeySequence('F5'), self.marketWB.tableView)
        self.marketWB.tableView.shortcut_snapQuote.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketWB.tableView.shortcut_snapQuote.activated.connect(lambda:snapQuoteRequested(self,'MarketWatch_basic'))

        self.marketWB.tableView.callSwapOrder = QShortcut(QKeySequence('S'), self.marketWB)
        self.marketWB.tableView.callSwapOrder.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketWB.tableView.callSwapOrder.activated.connect(lambda: swapOrderRequested(self, 'MarketWatch_basic'))

        self.marketWB.tableView.delt = QShortcut(QKeySequence('Del'), self.marketWB.tableView)
        self.marketWB.tableView.delt.setContext(Qt.WidgetWithChildrenShortcut)

        self.marketWB.tableView.delt.activated.connect(lambda: basicMWatch.support.delScript(self.marketWB))
        self.marketWB.tableView.delt.activated.connect(lambda: basicMWatch.support.unsubscribeToken(self))

        self.marketWB.tableView.scquickOrder = QShortcut(QKeySequence('Alt+Q'), self.marketWB)
        self.marketWB.tableView.scquickOrder.setContext(Qt.WidgetWithChildrenShortcut)
        self.marketWB.tableView.scquickOrder.activated.connect(lambda : quickOrderRequested(self, 'MarketWatch_basic'))

    except:
        print(traceback.print_exc())


def OrderBook_shortcut(self):
    try:
        self.OrderBook.tableView.scOrderBook = QShortcut(QKeySequence('Ctrl+F3'), self.OrderBook)
        self.OrderBook.tableView.scOrderBook.setContext(Qt.WidgetWithChildrenShortcut)
        self.OrderBook.tableView.scOrderBook.activated.connect(lambda: orderBookRequested(self, 'OrderBook'))

        self.OrderBook.tableView.scFolioPos = QShortcut(QKeySequence('F11'), self.OrderBook)
        self.OrderBook.tableView.scFolioPos.setContext(Qt.WidgetWithChildrenShortcut)
        self.OrderBook.tableView.scFolioPos.activated.connect(lambda: FolioPosRequested(self, 'OrderBook'))

        self.OrderBook.tableView.scTradeBook = QShortcut(QKeySequence('F8'), self.OrderBook)
        self.OrderBook.tableView.scTradeBook.setContext(Qt.WidgetWithChildrenShortcut)
        self.OrderBook.tableView.scTradeBook.activated.connect(lambda: tradeBookRequested(self, 'OrderBook'))

        self.OrderBook.tableView.scSnapQ = QShortcut(QKeySequence('F5'), self.OrderBook)
        self.OrderBook.tableView.scSnapQ.setContext(Qt.WidgetWithChildrenShortcut)
        self.OrderBook.tableView.scSnapQ.activated.connect(lambda: snapQuoteRequested(self, 'OrderBook'))
    except:
        print(traceback.print_exc())


def PendingBook_shortcut(self):
    try:

        self.PendingW.tableView.shortcut_modify = QShortcut(QKeySequence('Shift+F2'), self.PendingW.tableView)
        self.PendingW.tableView.shortcut_modify.setContext(Qt.WidgetWithChildrenShortcut)
        self.PendingW.tableView.shortcut_modify.activated.connect(lambda: PendingOrder.support.ModifyOrder(self))

        self.PendingW.tableView.delt = QShortcut(QKeySequence('Del'), self.PendingW.tableView)
        self.PendingW.tableView.delt.setContext(Qt.WidgetWithChildrenShortcut)
        self.PendingW.tableView.delt.activated.connect(lambda:PendingOrder.support.CancleOrder(self.PendingW))

        self.PendingW.tableView.scOrderBook = QShortcut(QKeySequence('Ctrl+F3'), self.PendingW)
        self.PendingW.tableView.scOrderBook.setContext(Qt.WidgetWithChildrenShortcut)
        self.PendingW.tableView.scOrderBook.activated.connect(lambda: orderBookRequested(self, 'PendingOrder'))

        self.PendingW.tableView.scPendingOrderW = QShortcut(QKeySequence('F3'), self.PendingW)
        self.PendingW.tableView.scPendingOrderW.setContext(Qt.WidgetWithChildrenShortcut)
        self.PendingW.tableView.scPendingOrderW.activated.connect(lambda: pendingOrderRequested(self,'PendingOrder'))

        self.PendingW.tableView.scSnapQ = QShortcut(QKeySequence('F5'), self.PendingW)
        self.PendingW.tableView.scSnapQ.setContext(Qt.WidgetWithChildrenShortcut)
        self.PendingW.tableView.scSnapQ.activated.connect(lambda: snapQuoteRequested(self,'PendingOrder'))

        self.PendingW.tableView.scTradeBook = QShortcut(QKeySequence('F8'), self.PendingW)
        self.PendingW.tableView.scTradeBook.setContext(Qt.WidgetWithChildrenShortcut)
        self.PendingW.tableView.scTradeBook.activated.connect(lambda: tradeBookRequested(self, 'PendingOrder'))

        self.PendingW.tableView.shortcut_modify = QShortcut(QKeySequence(''), self.PendingW)
        self.PendingW.tableView.shortcut_modify.setContext(Qt.WidgetWithChildrenShortcut)
        self.PendingW.tableView.shortcut_modify.activated.connect(lambda: PendingOrder.support.ModifyOrder(self))

    except:
        print(traceback.print_exc())

def FolioPos_shortcut(self):
    try:
        self.FolioPos.tableView.shortcut_buy = QShortcut(QKeySequence('F1'), self.FolioPos)
        self.FolioPos.tableView.shortcut_buy.setContext(Qt.WidgetWithChildrenShortcut)
        self.FolioPos.tableView.shortcut_buy.activated.connect(lambda:requestBuyWindow(self,'FolioPosition'))

        self.FolioPos.tableView.shortcut_buy1 = QShortcut(QKeySequence('+'), self.FolioPos)
        self.FolioPos.tableView.shortcut_buy1.setContext(Qt.WidgetWithChildrenShortcut)
        self.FolioPos.tableView.shortcut_buy1.activated.connect(lambda:requestBuyWindow(self,'FolioPosition'))

        self.FolioPos.tableView.shortcut_sell = QShortcut(QKeySequence('-'), self.FolioPos)
        self.FolioPos.tableView.shortcut_sell.setContext(Qt.WidgetWithChildrenShortcut)
        self.FolioPos.tableView.shortcut_sell.activated.connect(lambda:requestSellWindow(self,'FolioPosition'))


        self.FolioPos.tableView.shortcut_sell1 = QShortcut(QKeySequence('F2'),self.FolioPos)
        self.FolioPos.tableView.shortcut_sell1.setContext(Qt.WidgetWithChildrenShortcut)
        self.FolioPos.tableView.shortcut_sell1.activated.connect(lambda:requestSellWindow(self,'FolioPosition'))

        self.FolioPos.tableView.scPendingOrderW = QShortcut(QKeySequence('F3'), self.FolioPos)
        self.FolioPos.tableView.scPendingOrderW.setContext(Qt.WidgetWithChildrenShortcut)
        self.FolioPos.tableView.scPendingOrderW.activated.connect(lambda: pendingOrderRequested(self,'FolioPosition'))

        self.FolioPos.tableView.scOrderBook = QShortcut(QKeySequence('Ctrl+F3'), self.FolioPos)
        self.FolioPos.tableView.scOrderBook.setContext(Qt.WidgetWithChildrenShortcut)
        self.FolioPos.tableView.scOrderBook.activated.connect(lambda: orderBookRequested(self, 'FolioPosition'))

        self.FolioPos.tableView.scSnapQ = QShortcut(QKeySequence('F5'), self.FolioPos)
        self.FolioPos.tableView.scSnapQ.setContext(Qt.WidgetWithChildrenShortcut)
        self.FolioPos.tableView.scSnapQ.activated.connect(lambda: snapQuoteRequested(self, 'FolioPosition'))

        self.FolioPos.tableView.scTradeBook = QShortcut(QKeySequence('F8'), self.FolioPos)
        self.FolioPos.tableView.scTradeBook.setContext(Qt.WidgetWithChildrenShortcut)
        self.FolioPos.tableView.scTradeBook.activated.connect(lambda: tradeBookRequested(self, 'FolioPosition'))

        self.FolioPos.tableView.scFolioPos = QShortcut(QKeySequence('F11'), self.FolioPos)
        self.FolioPos.tableView.scFolioPos.setContext(Qt.WidgetWithChildrenShortcut)
        self.FolioPos.tableView.scFolioPos.activated.connect(lambda: FolioPosRequested(self, 'FolioPosition'))
    except:
        print(traceback.print_exc())

def NetPos_shortcut(self):
    try:
        self.NetPos.tableView.shortcut_buy1 = QShortcut(QKeySequence('+'), self.NetPos.tableView)
        self.NetPos.tableView.shortcut_buy1.setContext(Qt.WidgetWithChildrenShortcut)
        self.NetPos.tableView.shortcut_buy1.activated.connect(lambda: requestBuyWindow(self, 'NetPosition'))

        self.NetPos.tableView.shortcut_buy = QShortcut(QKeySequence('F1'), self.NetPos.tableView)
        self.NetPos.tableView.shortcut_buy.setContext(Qt.WidgetWithChildrenShortcut)
        self.NetPos.tableView.shortcut_buy.activated.connect(lambda: requestBuyWindow(self, 'NetPosition'))

        self.NetPos.tableView.shortcut_sell1 = QShortcut(QKeySequence('-'), self.NetPos.tableView)
        self.NetPos.tableView.shortcut_sell1.setContext(Qt.WidgetWithChildrenShortcut)
        self.NetPos.tableView.shortcut_sell1.activated.connect(lambda: requestSellWindow(self, 'NetPosition'))

        self.NetPos.tableView.shortcut_sell = QShortcut(QKeySequence('F2'), self.NetPos.tableView)
        self.NetPos.tableView.shortcut_sell.setContext(Qt.WidgetWithChildrenShortcut)
        self.NetPos.tableView.shortcut_sell.activated.connect(lambda: requestSellWindow(self, 'NetPosition'))

        self.NetPos.tableView.scOrderBook = QShortcut(QKeySequence('Ctrl+F3'), self.NetPos)
        self.NetPos.tableView.scOrderBook.setContext(Qt.WidgetWithChildrenShortcut)
        self.NetPos.tableView.scOrderBook.activated.connect(lambda: orderBookRequested(self, 'NetPosition'))

        self.NetPos.tableView.scPendingOrderW = QShortcut(QKeySequence('F3'), self.NetPos)
        self.NetPos.tableView.scPendingOrderW.setContext(Qt.WidgetWithChildrenShortcut)
        self.NetPos.tableView.scPendingOrderW.activated.connect(lambda:pendingOrderRequested(self,'NetPosition'))

        self.NetPos.tableView.scSnapQ = QShortcut(QKeySequence('F5'), self.NetPos)
        self.NetPos.tableView.scSnapQ.setContext(Qt.WidgetWithChildrenShortcut)
        self.NetPos.tableView.scSnapQ.activated.connect(lambda:snapQuoteRequested(self,'NetPosition'))


        self.NetPos.tableView.scTradeBook = QShortcut(QKeySequence('F8'), self.NetPos)
        self.NetPos.tableView.scTradeBook.setContext(Qt.WidgetWithChildrenShortcut)
        self.NetPos.tableView.scTradeBook.activated.connect(lambda: tradeBookRequested(self, 'NetPosition'))




    except:
        print(traceback.print_exc())

def snapW_shortcut(self):
    try:
        self.snapW.shortcut_buy = QShortcut(QKeySequence('F1'), self.snapW)
        self.snapW.shortcut_buy.setContext(Qt.WidgetWithChildrenShortcut)
        self.snapW.shortcut_buy.activated.connect(lambda:requestBuyWindow(self,'SnapQuote'))

        self.snapW.shortcut_buy1 = QShortcut(QKeySequence('+'), self.snapW)
        self.snapW.shortcut_buy1.setContext(Qt.WidgetWithChildrenShortcut)
        self.snapW.shortcut_buy1.activated.connect(lambda:requestBuyWindow(self,'SnapQuote'))

        self.snapW.shortcut_sell = QShortcut(QKeySequence('-'), self.snapW)
        self.snapW.shortcut_sell.setContext(Qt.WidgetWithChildrenShortcut)
        self.snapW.shortcut_sell.activated.connect(lambda:requestSellWindow(self,'SnapQuote'))

        self.snapW.shortcut_sell1 = QShortcut(QKeySequence('F2'), self.snapW)
        self.snapW.shortcut_sell1.setContext(Qt.WidgetWithChildrenShortcut)
        self.snapW.shortcut_sell1.activated.connect(lambda:requestSellWindow(self,'SnapQuote'))

        self.snapW.scOrderBook = QShortcut(QKeySequence('Ctrl+F3'), self.snapW)
        self.snapW.scOrderBook.setContext(Qt.WidgetWithChildrenShortcut)
        self.snapW.scOrderBook.activated.connect(lambda: orderBookRequested(self, 'SnapQuote'))

        self.snapW.scPendingOrderW = QShortcut(QKeySequence('F3'), self.snapW)
        self.snapW.scPendingOrderW.setContext(Qt.WidgetWithChildrenShortcut)
        self.snapW.scPendingOrderW.activated.connect(lambda: pendingOrderRequested(self, 'SnapQuote'))

        self.snapW.scTradeBook = QShortcut(QKeySequence('F8'), self.snapW)
        self.snapW.scTradeBook.setContext(Qt.WidgetWithChildrenShortcut)
        self.snapW.scTradeBook.activated.connect(lambda: tradeBookRequested(self, 'SnapQuote'))

        self.snapW.scFolioPos = QShortcut(QKeySequence('F11'), self.snapW)
        self.snapW.scFolioPos.setContext(Qt.WidgetWithChildrenShortcut)
        self.snapW.scFolioPos.activated.connect(lambda: FolioPosRequested(self, 'SnapQuote'))

    except:
        print(traceback.print_exc())



def tradebook_shortcut(self):
    self.TradeW.tableView.scFolioPos = QShortcut(QKeySequence('F11'), self.PendingW)
    self.TradeW.tableView.scFolioPos.setContext(Qt.WidgetWithChildrenShortcut)
    self.TradeW.tableView.scFolioPos.activated.connect(lambda: FolioPosRequested(self, 'TradeBook'))

    self.TradeW.tableView.scTradeBook = QShortcut(QKeySequence('F8'), self.PendingW)
    self.TradeW.tableView.scTradeBook.setContext(Qt.WidgetWithChildrenShortcut)
    self.TradeW.tableView.scTradeBook.activated.connect(lambda: tradeBookRequested(self, 'TradeBook'))

    self.TradeW.tableView.scSnapQ = QShortcut(QKeySequence('F5'), self.PendingW)
    self.TradeW.tableView.scSnapQ.setContext(Qt.WidgetWithChildrenShortcut)
    self.TradeW.tableView.scSnapQ.activated.connect(lambda: snapQuoteRequested(self, 'TradeBook'))



def settingsMenu_shortcut(self):

    self.scSettingsMenu = QShortcut(QKeySequence('Alt+H'), self)
    self.scSettingsMenu.activated.connect(self.btnSttn.click)
    self.scSettingsMenu.activated.connect(lambda: self.pbHome.setFocus(True))


    self.settingsMenu.scHide = QShortcut(QKeySequence('Esc'), self.settingsMenu)
    self.settingsMenu.scHide.setContext(Qt.WidgetWithChildrenShortcut)
    self.settingsMenu.scHide.activated.connect(lambda:showSettingMenu(self))

    self.settingsMenu.scNetPos = QShortcut(QKeySequence('N'), self.settingsMenu)
    self.settingsMenu.scNetPos.setContext(Qt.WidgetWithChildrenShortcut)
    self.settingsMenu.scNetPos.activated.connect(self.pbNetPos.click)

    self.settingsMenu.scFolioPOs = QShortcut(QKeySequence('F'), self.settingsMenu)
    self.settingsMenu.scFolioPOs.setContext(Qt.WidgetWithChildrenShortcut)
    self.settingsMenu.scFolioPOs.activated.connect(self.pbFolioPos .click)

    self.settingsMenu.scTB = QShortcut(QKeySequence('T'), self.settingsMenu)
    self.settingsMenu.scTB.setContext(Qt.WidgetWithChildrenShortcut)
    self.settingsMenu.scTB.activated.connect(self.pbTradeB .click)

    self.settingsMenu.scOB = QShortcut(QKeySequence('O'), self.settingsMenu)
    self.settingsMenu.scOB.setContext(Qt.WidgetWithChildrenShortcut)
    self.settingsMenu.scOB.activated.connect(self.pbOrderB .click)

    self.settingsMenu.scOChain = QShortcut(QKeySequence('C'), self.settingsMenu)
    self.settingsMenu.scOChain.setContext(Qt.WidgetWithChildrenShortcut)
    self.settingsMenu.scOChain.activated.connect(self.pbOpChain.click)





    ##################################################################################################3
    # self.OptionChain.tableView.shortcut_buy = QShortcut(QKeySequence('F1'), self.OptionChain.tableView)
    # self.OptionChain.tableView.shortcut_buy.setContext(Qt.WidgetWithChildrenShortcut)
    # self.OptionChain.tableView.shortcut_buy.activated.connect(lambda: requestBuyWindow(self, 'optionChain'))
    #
    # self.OptionChain.tableView.shortcut_buy1 = QShortcut(QKeySequence('+'), self.OptionChain.tableView)
    # self.OptionChain.tableView.shortcut_buy1.setContext(Qt.WidgetWithChildrenShortcut)
    # self.OptionChain.tableView.shortcut_buy1.activated.connect(lambda: requestBuyWindow(self, 'optionChain'))
    #
    # self.OptionChain.tableView.shortcut_sell = QShortcut(QKeySequence('-'), self.marketW.tableView)
    # self.OptionChain.tableView.shortcut_sell.setContext(Qt.WidgetWithChildrenShortcut)
    # self.OptionChain.tableView.shortcut_sell.activated.connect(lambda: requestSellWindow(self, 'optionChain'))
    #
    # self.OptionChain.tableView.shortcut_sell1 = QShortcut(QKeySequence('F2'), self.OptionChain.tableView)
    # self.OptionChain.tableView.shortcut_sell1.setContext(Qt.WidgetWithChildrenShortcut)
    # self.OptionChain.tableView.shortcut_sell1.activated.connect(lambda: requestSellWindow(self, 'optionChain'))
    #

    self.OptionChain.scOptSelectWindow = QShortcut(QKeySequence('F1'), self.OptionChain)
    self.OptionChain.scOptSelectWindow.setContext(Qt.WidgetWithChildrenShortcut)
    self.OptionChain.scOptSelectWindow.activated.connect(lambda: requestOC2BS(self, 'Buy'))

    self.OptionChain.scOptSelectWindow = QShortcut(QKeySequence('F2'), self.OptionChain)
    self.OptionChain.scOptSelectWindow.setContext(Qt.WidgetWithChildrenShortcut)
    self.OptionChain.scOptSelectWindow.activated.connect(lambda: requestOC2BS(self, 'Sell'))


    self.OptionChain.optSelect.scoptSelect = QShortcut(QKeySequence('1'), self.OptionChain.optSelect)
    self.OptionChain.optSelect.scoptSelect.setContext(Qt.WidgetWithChildrenShortcut)
    self.OptionChain.optSelect.scoptSelect.activated.connect(lambda: self.OptionChain.optSelect.setOptionType('CE'))
    self.OptionChain.optSelect.scoptSelect.activated.connect(lambda: requestBSWindowForOC(self))



    self.OptionChain.optSelect.scoptSelect1= QShortcut(QKeySequence('2'), self.OptionChain.optSelect)
    self.OptionChain.optSelect.scoptSelect1.setContext(Qt.WidgetWithChildrenShortcut)
    self.OptionChain.optSelect.scoptSelect1.activated.connect(lambda: self.OptionChain.optSelect.setOptionType('PE'))
    self.OptionChain.optSelect.scoptSelect1.activated. connect(lambda: requestBSWindowForOC(self))



    self.OptionChain.optSelect.pbCE.clicked.connect(lambda: self.OptionChain.optSelect.setOptionType('CE'))
    self.OptionChain.optSelect.pbCE.clicked.connect(lambda: requestBSWindowForOC(self))
    self.OptionChain.optSelect.pbPE.clicked.connect(lambda: self.OptionChain.optSelect.setOptionType('PE'))
    self.OptionChain.optSelect.pbPE.clicked.connect(lambda: requestBSWindowForOC(self))







    # self.OptionChain.optSelect.scoptSelect2 = QShortcut(QKeySequence('Enter'), self.OptionChain.optSelect)
    # self.OptionChain.optSelect.scoptSelect2.activated.connect(lambda: OptionChain.support.  changeOptionChain(self))




