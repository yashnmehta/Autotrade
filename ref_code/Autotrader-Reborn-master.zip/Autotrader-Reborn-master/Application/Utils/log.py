import csv
import os
import logging
from datetime import datetime

from PyQt5.QtGui import QStandardItemModel, QStandardItem
from PyQt5.QtWidgets import QHeaderView


def createLogfile(main,newStretegy,folioName):

    today = datetime.today().strftime('%Y%m%d')
    main.logDir = os.path.join(main.loc1[0], 'Application', 'DB','Stretegy_data','%s' % today)
    newStretegy.Slogger = logging.getLogger(folioName)
    newStretegy.logFilePath = os.path.join(main.logDir, '%s.log' % (folioName))

    hdlr_1 = logging.FileHandler(newStretegy.logFilePath)
    hdlr_1.setFormatter(main.formatter)
    newStretegy.Slogger.setLevel(logging.DEBUG)
    newStretegy.Slogger.addHandler(hdlr_1)

def createLogCsvfile(main,newStretegy,folioName):
    today = datetime.today().strftime('%Y%m%d')
    main.logDir = os.path.join(main.loc1[0], 'Application', 'DB','Stretegy_data','%s' % today)
    newStretegy.logCsvFilePath = os.path.join(main.logDir, '%s.csv' % (folioName))
    with open(newStretegy.logCsvFilePath, "w", newline=""):
        pass
        # writer = csv.writer(file)
        # # Write an empty row to the CSV file
        # writer.writerow([])

def createLogTableModel(self):
    self.model = QStandardItemModel(0, self.logTableheadsLen, self)
    self.model.setHorizontalHeaderLabels(self.logTableheads)
    self.tableViewLogs.setModel(self.model)
    self.tableViewLogs.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)

def insertLogRow(self, Qty, token,orderSide):
    Time = datetime.now().strftime("%H:%M:%S")
    strike, CP = self.getStrikeOT(token)
    if CP == 'CE':
        LTP = self.cePrice
    else:
        LTP = self.pePrice

    if self.stype == 'EMASpecial':
        row = [Time, self.symbol, self.expiry, strike, CP, Qty, LTP, orderSide, self.ema, self.finalEmaAdjPts]
    elif self.stype == 'LevelSpecial':
        row = [Time, self.symbol, self.expiry, strike, CP, Qty, LTP, orderSide, self.changePoint]
    else:
        row = [Time,self.symbol,self.expiry,strike,CP,Qty,LTP,orderSide]

    item_list = [QStandardItem(str(value)) for value in row]
    self.modifyW.model.appendRow(item_list)
    writeLogstoCsv(self,row)

def writeLogstoCsv(self,row):
    with open(self.logCsvFilePath, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(row)

def loadLogTable(self):
    getLogCsvFilePath(self)
    with open(self.logCsvFilePath, 'r') as file:
        reader = csv.reader(file)
        data = list(reader)

    self.modifyW.model.clear()
    self.modifyW.model.setHorizontalHeaderLabels(self.modifyW.logTableheads)

    for row in data:
        item_list = [QStandardItem(str(value)) for value in row]
        self.modifyW.model.appendRow(item_list)

def getLogCsvFilePath(self):
    todate = datetime.today().strftime('%Y%m%d')
    loc = os.getcwd().split('Application')
    self.logCsvFilePath = os.path.join(loc[0], 'Application', 'DB', 'Stretegy_data', todate,
                                         '%s.csv' % self.folioName)