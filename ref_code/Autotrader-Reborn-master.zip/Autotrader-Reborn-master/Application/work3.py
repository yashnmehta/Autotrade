# #####      "E:\Autotrader-Reborn\Application\DB\Stretegy_data\20220812"
#
# import json
# import os
# import datetime
# folioName= '1_TSpecial'
# todate = datetime.datetime.today().strftime('%Y%m%d')
# loc = os.getcwd().split('Application')
# parameteFile= os.path.join(loc[0] , 'Application' ,'DB' ,'Stretegy_data', todate,'%s.json'%folioName )
#
# f1 = open(parameteFile)
# jPara = json.load(f1)
# print(jPara)
# f1.close()
