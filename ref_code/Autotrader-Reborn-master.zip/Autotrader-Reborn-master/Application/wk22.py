import os
import traceback

lisFinal = []



cwd = os.getcwd()
aa = os.path.join(cwd,'Services','UDP')
a=os.listdir(aa)

print(a)

for i in a :
    z= os.path.join(aa,i)
    print('z',z)
    if (i == '__pycache__'):
        pass
    elif(os.path.isdir(z)):
        newPath  = os.path.join(aa,i)

        newList = os.listdir(newPath)


        for ij in newList:
            newPath1 = os.path.join(newPath, ij)
            # print('newPath1', newPath1)

            if(ij == '__pycache__'):
                pass
            elif (os.path.isdir(newPath1)):
                newList1 = os.listdir(newPath1)

                for ix in newList1:
                    newPath2 = os.path.join(newPath1, ix)
                    # print('newPath2', newPath2)
                    if (ix == '__pycache__'):
                        pass
                    elif (os.path.isdir(newPath2)):
                        newList2 = os.listdir(newPath2)
                    else:
                        # print('else 2', newPath2)
                        xx = newPath2.replace('D:\Autotrader-Reborn\\', '')
                        # print(xx[-3:])
                        if (xx[-3:] == '.py'):
                            lisFinal.append(newPath2.replace('D:\Autotrader-Reborn\\', ''))

                #
                else:
                    # print('else 2',newPath1)
                    xx = newPath1.replace('D:\Autotrader-Reborn\\','')
                    # print(xx[-3:])
                    if(xx[-3:]=='.py'):
                        lisFinal.append(newPath1.replace('D:\Autotrader-Reborn\\',''))
#
            print('error ',traceback.print_exc(),i)
    else:
        xx = i.replace('D:\Autotrader-Reborn\\', '')
        # print(xx[-3:])
        if (xx[-3:] == '.py'):
            print('tej',xx)
            lisFinal.append(xx)

print(lisFinal)