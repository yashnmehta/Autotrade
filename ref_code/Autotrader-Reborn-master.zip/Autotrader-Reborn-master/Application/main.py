import time

from Application.Stretegies.JCat import JCat
from Application.Stretegies.Momentum import Momentum
from Application.Stretegies.Pyramid import Pyramid
from Application.Stretegies.LevelSpecial import LevelSpecial
from Application.Views.OptionChain.optionSelection import Ui_OptSelect
from Theme.dt2 import dt1
import pyautogui
from Application.Utils.basicWinOps import CloseButtonClicked,QuitButtonClicked
import platform

from Application.Utils.animations import *
from Application.Utils.feedHandler import FeedHandler
from Application.Utils.supMethods import getLogPath, effectWorking, createTimers, updateFolioOpenPos,SuareOffButtonClicked, msgboxButtonClicked, updateStStatus, showFolioPosW, saveTradestoDatabase
from Application.Stretegies.Utils.stretegySideOps import setStretegyParameters,newStretegyRecordUpdate, popTempStretegy

from Application.Utils.log import createLogfile, createLogCsvfile
from Application.Utils.configReader import refresh
from Application.Utils.updation import *
from Application.Views.OptionChain.optionChain import OptionChain

from Application.Services.Xts.Sockets.Trade.interactiveApi import Interactive
from Application.Services.Xts.Sockets.Feeds.marketData import MarketFeeds
from Application.Views.OptionChain.optionSelection import *
from Application.Views.SManager.sManager import Manager
from Application.Views.SManager.support import *
from Application.Views.PendingOrder.pendingOrder import PendingOrder
from Application.Views.Banned.bannedScript import Ui_Banned
from Application.Views.OrderBook.orderBook import OrderBook
from Application.Views.TradeBook.tradeBook import TradeBook
from Application.Views.Prerferences.prefereances import Ui_Preferences
from Application.Views.MarketWatch.mWatch import MarketW
from Application.Views.basicMWatch.mWatch import MarketW_basic
from Application.Views.Login.login import Ui_Login
from Application.Views.cframe import  Ui_CFrame
from Application.Views.splashScreen import Ui_Splash
from Application.Views.titlebar import tBar
from Application.Views.BuyWindow.buyWindow import Ui_BuyW
from Application.Views.SellWindow.sellWindow import Ui_SellW
from Application.Views.SnapQuote.snapQuote import Ui_snapQ
from Application.Views.FolioPosition.folioPosition  import FolioPosition
from Application.Views.NetPosition.netPosition  import NetPosition
from Application.Views.MultiOrders.multiOrders import Ui_MultiOrders
from Application.Views.SwapOrder.swapOrders import Ui_SwapOrder
from Application.Views.SpreadOrder.spreadOrder import Ui_SpreadOrder
from Application.Views.shortcutinfo import shortcutInfo
from Application.Views.FeedManager.FeedManager import Ui_FeedManager
from Application.Views.quickTrade import quickTradeW

from Application.Utils.createTables import tables_details_mw, tables_details_mw_basic, tables_details_mo ,tables_details_np
from Application.Services.UDP.UDPSock import Receiver
from Application.Services.Rebroadcaster.broadcastReader import Receiver as broadcastreader
# from PyQt5 import QHeaderView
from Application.Utils.configReader import get_udp_port
from Application.Utils.shortcuts import setShortcuts
from Application.Views.multiModification import Ui_MultiModification
from PyQt5 import uic

from Application.Utils.animations import createAnimations
from Application.Utils.all_slots import createSlots_main

from Application.Utils.getMasters import getMaster,shareContract
from Application.Stretegies import TSpecial
from Application.Stretegies.VixMonkey import VixMonkey
from Application.Stretegies.ValSpread import ValSpread
import Application.Stretegies.PairSell.PairSell as PairSellS
from Application.Stretegies.Custom import Custom
from Application.Utils.createContextMenus import *
import Application.Stretegies.JodiATM.JodiATM as JATM
import Application.Stretegies.JTiger.JTiger as JTiger
import Application.Stretegies.OCheetah.OCheetah as OCheetah
import Application.Stretegies.EMASpecial.EMASpecial as EMAS
from Application.Stretegies.JodiSt import JodiST
import os

class Ui_Main(QMainWindow):
    ################################# Intialization Here ##################################################
    def __init__(self):
        try:
            super(Ui_Main, self).__init__()
            self.osType = platform.system()
            #########################################################
            getLogPath(self)
            ########################################################


            #########################################################
            loc1 = os.getcwd().split('Application')
            ui_login = os.path.join(loc1[0],'Resourses','UI','Main.ui')
            uic.loadUi(ui_login, self)
            osType = platform.system()
            if (osType == 'Darwin'):
                flags = Qt.WindowFlags(Qt.FramelessWindowHint  )
            else:
                flags = Qt.WindowFlags(Qt.FramelessWindowHint  )


            self.setWindowFlags(flags)


            self.title = tBar('ANV TRADER')
            self.headerFrame.layout().addWidget(self.title,0,1)
            self.title.setStyleSheet(
                'QFrame {\n  background-color: #000a14\n;\n\n  border-radius: 4px;\n  border: 0px solid transparent;\n\n  /* No frame */\n  /* HLine */\n  /* HLine */\n}\n\n.QFrame[frameShape="0"] {\n  border-radius: 4px;\n  border: 1px transparent #2d2d2d;\n}\n\n.QFrame[frameShape="4"] {\n  max-height: 2px;\n  border: none;\n  background-color: #2d2d2d;\n}\n\n.QFrame[frameShape="5"] {\n  max-width: 2px;\n  border: none;\n  background-color: #2d2d2d;\n}\n\n\n')
            # self.titleFrame.layout.addWidget(self.lbName)

            # self.title.setStyleSheet('/* QFrame -----------------------------------------------------------------\n\nhttps://doc.qt.io/qt-5/stylesheet-examples.html#customizing-qframe\nhttps://doc.qt.io/qt-5/qframe.html#-prop\nhttps://doc.qt.io/qt-5/qframe.html#details\nhttps://stackoverflow.com/questions/14581498/qt-stylesheet-for-hline-vline-color\n\n--------------------------------------------------------------------------- */\n/* (dot) .QFrame  fix #141, #126, #123 */\n.QFrame {\n  background-color: #000a14\n;\n\n  border-radius: 4px;\n  border: 0px solid transparent;\n\n  /* No frame */\n  /* HLine */\n  /* HLine */\n}\n\n.QFrame[frameShape="0"] {\n  border-radius: 4px;\n  border: 1px transparent #2d2d2d;\n}\n\n.QFrame[frameShape="4"] {\n  max-height: 2px;\n  border: none;\n  background-color: #2d2d2d;\n}\n\n.QFrame[frameShape="5"] {\n  max-width: 2px;\n  border: none;\n  background-color: #2d2d2d;\n}\n\n\n')
            QSizeGrip(self.frame_5)
            self.setStyleSheet(dt1)

            width, height = pyautogui.size()


            #########################################################
            self.fo_contract, self.eq_contract, self.cd_contract, self.contract_heads = getMaster(self,False)

            #########################################################
            self.objectCreation()
            # self.msg = messageBox()
            self.initVariables()
            setShortcuts(self)
            createAnimations(self)


            createSlots_main(self)

            shareContract(self)
            # getPreviousActiveStretegies(self)



            # print('parth parth')
            effectWorking(self)



            # self.MarginBar.layout().addWidget(self.lbUDP,0,10)
            # self.MarginBar.layout().addWidget(self.lbUDP,0,10)
            # self.MarginBar.layout().addWidget(self.toggleUDP,0,11)
            refresh(self)


            # addFolio(self,'abc')
            # addFolio(self,'parth')
            # print(width)
            self.setMaximumWidth(width)
        except:
            # pass
            # print("2222")
            print(traceback.print_exc(),'dddd',sys.exc_info())

        # self.gridLayout_2.QHeaderView.logicalIndexAt()

    def objectCreation(self):
        try:
            self.Splash = Ui_Splash()
            self.multiModifyW = Ui_MultiModification()
            self.buyW = Ui_BuyW(self)
            self.sellW = Ui_SellW(self)
            self.snapW = Ui_snapQ(self)
            get_udp_port(self)
            # print('fofofofo',self.port_fo)
            self.recv_fo = Receiver(self.port_fo)
            self.recv_fo.fo_contract = self.fo_contract
            self.recv_fo.join_grp()

            self.thread1 =QThread()
            self.recv_fo.moveToThread(self.thread1)
            self.thread1.start()


            self.recv_cash = Receiver(self.port_cash)
            self.broadcastReader = broadcastreader()

            self.thread2 =QThread()
            self.broadcastReader.moveToThread(self.thread2)
            self.thread2.start()


            # #self.ecodedUDP_cash = decodedUDPReceiver(self.port_cash)
            # self.thread1 =QThread()
            # self.recv_fo.moveToThread(self.thread1)
            # self.thread1.start()

            #
            # self.recv_cash = Receiver(self.port_cash)
            # self.broadcastReader = broadcastreader()
            #
            # self.thread2 =QThread()
            # self.broadcastReader.moveToThread(self.thread2)
            # self.thread2.start()


            #self.ecodedUDP_cash = decodedUDPReceiver(self.port_cash)
            self.CFrame = Ui_CFrame()
            self.LiveFeed = MarketFeeds()
            self.thread3 =QThread()
            self.LiveFeed.moveToThread(self.thread3)
            self.thread3.start()

            self.IAS = Interactive()
            self.thread4 =QThread()
            self.IAS.moveToThread(self.thread4)
            self.thread4.start()

            self.marketW = MarketW()
            self.quickTradeW = quickTradeW()
            self.marketWB = MarketW_basic()
            # self.marketW.buyw = Ui_BuyW()
            # self.marketW.sellw = Ui_SellW()
            tables_details_mw(self)
            tables_details_mw_basic(self)
            # tables_details_np(self)
            self.FolioPos = FolioPosition(self)
            self.NetPos = NetPosition(self)
            self.Manager = Manager()

            self.OptionChain = OptionChain()
            self.optSelect = Ui_OptSelect()
            self.multiOrders = Ui_MultiOrders()
            self.feedManager = Ui_FeedManager()
            self.swapOrder = Ui_SwapOrder()
            self.spreadOrder = Ui_SpreadOrder()
            # self.payOffW = payOffChart()
            tables_details_mo(self)
            self.PendingW = PendingOrder()
            self.OrderBook =OrderBook(self)
            self.TradeW = TradeBook(self)
            self.PreferanceW = Ui_Preferences(self)
            self.Banned = Ui_Banned()
            self.mainFrame.layout().addWidget(self.CFrame,0,1)
            self.CFrame.dockOP.setWidget(self.PendingW)
            self.CFrame.dockMGR.setWidget(self.Manager)
            self.CFrame.dockMW.setWidget(self.marketW)
            self.CFrame.dockMW_basic.setWidget(self.marketWB)
            self.CFrame.resizeDocks([self.CFrame.dockOP,self.CFrame.dockMW],[500,500],Qt.Vertical)
            self.CFrame.resizeDocks([self.CFrame.dockOP],[500],Qt.Horizontal)
            self.login = Ui_Login()
            self.FeedHandler = FeedHandler()
            self.PendingW.FeedHandler = self.FeedHandler
            self.shortcutInfoW = shortcutInfo()


            createTimers(self)
            self.requestContextMenus()

        except:
            print(traceback.print_exc())

    @pyqtSlot(str,str,int)
    def subscribeRecvFO(self,classname,exch,token):
        self.recv_fo.subscribedlist(classname,exch,token)

    def cancelAllMDAPIConnction(self):
        self.LiveFeed.sgNPFrec.disconnect(self.on_new_feed_1501)

        self.LiveFeed.sgNPFrec.connect(self.on_new_feed_7202)


    def initVariables(self):
        self.inPoreccessOrderIds = []
        self.Mrglvl = 0
        ################### as part of window animation ############

        self.isUpdateStatusRejection = True
        self.isUpdateStatusTrade = True
        self.isUpdateStatusOrder = True
        self.isRejectionPopup = True

        self.statusBarSettingsJson = {}

        self.sl = 0.0

        self.isIndexBarOpen =True
        self.isSTBarOpen =True
        self.AllowOnlyIndex = False
        self.isScriptBarOpen =True
        self.isMarginBarOpen =True
        self.isSidebarOpen =False
        self.isMenuOpen = False
        self.isMrgWOpen = False
        self.isMMWOpen = False
        self.jobbinMode = False
        self.Mrglvl = 0
        self.listBannedSymbol = []
        self.listBannedIns = []
        self.isOverOTRFIndex = True  #check its use
        self.openPosDict ={}


    def movWin(self, x, y):
        self.move(self.pos().x() + x, self.pos().y() + y)


    #################################################################
    def updateOnPosition(self,position,dayNey):
        # print("update on position",position)
        update_Position_Socket_NP(self, position)
        update_Position_socket_MW(self,position)

    def updateOderSocket(self,order, orderDict):
        # updateSocketOB(self.OrderBook,order)
        updateOrderSocket_OB_INDB(self,order)
        updateSocketPOB(self.PendingW,order)
        # self.timerBalance.stop()
        self.timerBalance.start()
        #stretegy
        for i in self.Manager.stretegyList:
            if(i.folioName == order[0][15]):
                i.updateOrder(order,orderDict)



    def updateOnTrade(self,trade):
        updateTradeSocket_TB_INDB(self,trade)
        updateGetTrade_FP(self.FolioPos,trade)
        for i in self.Manager.stretegyList:
            if(i.folioName == trade[0][15]):
                i.updateTrade(trade)


    ##################################################################
    # currently not in us
    def updateGetorderBook(self,order,rowNo):
        updateGetOrder_OB(self,order,rowNo)

    def updateGetPendinOrderBook(self,order,rowNo):
        updateGetOrder_POB(order,rowNo)

    def on_get_tradeBook(self,tradeBook):
        updateGetTradeApi(self.TradeW,tradeBook)
        updateGetTrade_FP(self.FolioPos,tradeBook)


    ##################################################################

    ##################################################################
    @pyqtSlot(list)
    def updateFolioOpenPos(self,data):
        updateFolioOpenPos(self,data)

    def on_new_Feed_broadcaster(self,data):
        # print('from rebroadcaster')

        if(data['Token']==82222):
            print('rb',time.time(),data['LTP'],data['VOLUME'])
        UpdateLTP_MW(self, data)
        UpdateLTP_MW_basic(self, data)


    def on_new_feed_1501(self,data):
        UpdateLTP_MW(self,data)
        UpdateLTP_MW_basic(self, data)
        UpdateLTP_NP(self,data)
        UpdateLTP_FP(self,data)
        updateSwapOrder(self,data)
        updateSpreadOrder(self,data)
        if(data['Exch'] == 'NSEFO'):
            self.fo_contract[data['Token'] - 35000,18 ] = data['LTP']


        # print(self.Manager.stretegyList,self.Manager.stretegyList_temp)
        for i in self.Manager.stretegyList:
            if i.isStart:
                i.checkTrade(data)
                i.updateMTM(data)

        for i in self.Manager.stretegyList_temp:
            # print(self.Manager.stretegyList, self.Manager.stretegyList_temp)
            i.updateWindows(data,i.addW)
            # i.updateWindows(data)

    def on_new_feed_sub_1501(self,data):
        UpdateLTP_MW(self,data)
        UpdateLTP_MW_basic(self, data)
        UpdateLTP_NP(self,data)
        UpdateLTP_FP(self,data)
        updateSwapOrder(self,data)
        updateSpreadOrder(self,data)

        if(data['Exch'] == 'NSEFO'):
            self.fo_contract[data['Token'] - 35000,18 ] = data['LTP']
        if(data['Exch'] == 'NSEFO'):
            self.fo_contract[data['Token'] - 35000,18 ] = data['LTP']

        for i in self.Manager.stretegyList:
            if i.isStart:
                i.checkTrade(data)
                i.updateMTM(data)

    def SuareOffButtonClicked(self, i):
        SuareOffButtonClicked(self, i)

    def msgboxButtonClicked(self, i):
        msgboxButtonClicked(self, i)


    def on_new_feed_ltp_iv(self,data):
        self.OptionChain.updateValues(data)
    def on_new_feed_ba_iv(self,data):
        self.OptionChain.updateValues(data)
    def on_new_feed_greeks(self,data):
        self.OptionChain.updateValues(data)

    def on_new_feed_7202_OC(self,data):
        self.OptionChain.updateValues(data)

    def on_new_feed_7202(self,data):
        # self.OptionChain.updateValues(data)
        UpdateLTP_MW(self,data,7202)
        UpdateLTP_MW_basic(self,data,7202)
        UpdateLTP_NP(self, data)
        UpdateLTP_FP(self, data)


    def on_new_feed_7208(self,data):
        # self.OptionChain.updateValues(data)
        print('ddddd')
        UpdateLTP_MW(self,data,7208)
        UpdateLTP_MW_basic(self,data,7208)
        UpdateLTP_NP(self, data)
        UpdateLTP_FP(self, data)

    def on_new_feed_7208_OC(self,data):
        self.OptionChain.updateValues(data)



    def on_new_feed_1502(self,data):
        sock1502(self.snapW,data)

    def on_new_feed_Index(self,data):
        updateCashIndex(self,data)

    def addNewStretegy(self):

        if (self.Manager.lastSerialNo in self.Manager.SerialInUse):
            self.Manager.lastSerialNo += 1

        if(self.Manager.lastSelectedStretegy == self.Manager.pbTSpecial):
            newStretegy = TSpecial.TSpecial.logic()
            newStretegy.createObject(self.fo_contract)
            folioName = str(self.Manager.lastSerialNo) +'_TSpecial'
            refresh(newStretegy)
            # print("folioName : ", folioName)
            newStretegy.addW.leFolioName.setText(folioName)
            newStretegy.addW.cbClient.addItems(self.client_list)
            newStretegy.modifyW.leFolioName.setText(folioName)
            newStretegy.modifyW.cbClient.addItems(self.client_list)
            newStretegy.getBaseInfo(newStretegy.addW)

            self.Manager.stretegyList_temp.append(newStretegy)


            # newStretegy.connect2slots()
            newStretegy.sgMTM.connect(self.updateStMTM)
            newStretegy.sgSL.connect(self.updateStSL)
            newStretegy.sgTarget.connect(self.updateStTarget)

            newStretegy.addW.show()
            #
            # newStretegy.timerUpdateWindows.start()
            # newStretegy.timerGetPrices.start()

            newStretegy.sgMTM.connect(self.updateStMTM)
            newStretegy.sgAlert.connect(self.showMsgW)
            newStretegy.sgStart.connect(lambda:updateStStatus(self,newStretegy,'Started'))
            newStretegy.sgParamSet.connect(lambda:setStretegyParameters(self,newStretegy))
            newStretegy.sgParamSet.connect(lambda:newStretegyRecordUpdate(self,newStretegy,newStretegy.symbol))


        elif(self.Manager.lastSelectedStretegy == self.Manager.pbCustomSt):
            newStretegy = Custom.logic()
            newStretegy.createObject(self.fo_contract)
            folioName = str(self.Manager.lastSerialNo) +'_Custom'
            refresh(newStretegy)
            # print("folioName : ", folioName)
            newStretegy.addW.leFolioName.setText(folioName)
            newStretegy.addW.cbClient.addItems(self.client_list)
            newStretegy.modifyW.leFolioName.setText(folioName)
            newStretegy.modifyW.cbClient.addItems(self.client_list)
            newStretegy.addW.show()
            newStretegy.sgMTM.connect(self.updateStMTM)
            newStretegy.sgSL.connect(self.updateStSL)
            newStretegy.sgTSL.connect(self.updateStTSL)
            newStretegy.sgTarget.connect(self.updateStTarget)
            newStretegy.sgAlert.connect(self.showMsgW)
            newStretegy.sgParamSet.connect(lambda:setStretegyParameters(self,newStretegy))
            newStretegy.sgParamSet.connect(lambda:newStretegyRecordUpdate(self,newStretegy,''))

        elif(self.Manager.lastSelectedStretegy == self.Manager.pbPairSell):
            newStretegy = PairSellS.logic()
            folioName = newStretegy.addNew(self)
            refresh(newStretegy)
            newStretegy.addW.leFolioName.setText(folioName)
            newStretegy.addW.cbClient.addItems(self.client_list)
            newStretegy.modifyW.leFolioName.setText(folioName)
            newStretegy.modifyW.cbClient.addItems(self.client_list)
            newStretegy.addW.show()
            newStretegy.sgMTM.connect(self.updateStMTM)
            newStretegy.sgSL.connect(self.updateStSL)
            newStretegy.sgTSL.connect(self.updateStTSL)
            newStretegy.sgTarget.connect(self.updateStTarget)
            newStretegy.sgAlert.connect(self.showMsgW)
            self.sgStart.connect(lambda: updateStStatus(self, newStretegy, 'Started'))
            self.sgParamSet.connect(lambda: setStretegyParameters(self, newStretegy))
            self.sgParamSet.connect(lambda: newStretegyRecordUpdate(self, newStretegy, newStretegy.symbol))

            # self.Manager.stretegyList_temp.append(newStretegy)

        elif (self.Manager.lastSelectedStretegy == self.Manager.pbMomentum):
            newStretegy = Momentum.logic()
            newStretegy.createObject(self.fo_contract)
            folioName = str(self.Manager.lastSerialNo) +'_Momentum'
            refresh(newStretegy)
            # print("folioName : ", folioName)
            newStretegy.addW.leFolioName.setText(folioName)
            newStretegy.addW.cbClient.addItems(self.client_list)
            newStretegy.modifyW.leFolioName.setText(folioName)
            newStretegy.modifyW.cbClient.addItems(self.client_list)
            # print("parth golakiya")
            newStretegy.addW.show()

            # newStretegy.timerUpdateWindows.start()
            # newStretegy.timerGetPrices.start()

            # newStretegy.sgMTM.connect(self.updateStMTM)
            # newStretegy.sgAlert.connect(self.showMsgW)
            newStretegy.sgStart.connect(lambda:updateStStatus(self,newStretegy,'Started'))
            newStretegy.sgParamSet.connect(lambda:setStretegyParameters(self,newStretegy))
            newStretegy.sgParamSet.connect(lambda:newStretegyRecordUpdate(self,newStretegy,newStretegy.symbol))

        elif (self.Manager.lastSelectedStretegy == self.Manager.pbPyramid):
            newStretegy = Pyramid.logic()
            newStretegy.createObject(self.fo_contract)
            folioName = str(self.Manager.lastSerialNo) +'_Pyramid'
            refresh(newStretegy)
            # print("folioName : ", folioName)
            newStretegy.addW.leFolioName.setText(folioName)
            newStretegy.addW.cbClient.addItems(self.client_list)

            newStretegy.modifyW.leFolioName.setText(folioName)
            newStretegy.modifyW.cbClient.addItems(self.client_list)
            # print("parth golakiya")

            newStretegy.addW.show()

            # newStretegy.timerUpdateWindows.start()
            # newStretegy.timerGetPrices.start()

            newStretegy.sgMTM.connect(self.updateStMTM)
            newStretegy.sgAlert.connect(self.showMsgW)
            newStretegy.sgStart.connect(lambda:updateStStatus(self,newStretegy,'Started'))
            newStretegy.sgParamSet.connect(lambda:setStretegyParameters(self,newStretegy))
            newStretegy.sgParamSet.connect(lambda:newStretegyRecordUpdate(self,newStretegy,newStretegy.symbol))

        elif (self.Manager.lastSelectedStretegy == self.Manager.pbJodiATM):
            try:
                newStretegy = JATM.logic()
                newStretegy.createObject(self.fo_contract)
                folioName = str(self.Manager.lastSerialNo) + '_JodiAtm'
                # print(folioName)
                refresh(newStretegy)
                # print("folioName : ", folioName)

                newStretegy.addW.leFolioName.setText(folioName)
                newStretegy.addW.cbClient.addItems(self.client_list)

                newStretegy.modifyW.leFolioName.setText(folioName)
                newStretegy.modifyW.cbClient.addItems(self.client_list)
                newStretegy.getBaseInfo(newStretegy.addW)

                newStretegy.addW.show()

                newStretegy.timerUpdateWindows.start()
                newStretegy.timerGetPrices.start()
                newStretegy.sgMTM.connect(self.updateStMTM)
                newStretegy.sgSL.connect(self.updateStSL)
                #newStretegy.sgTSL.connect(self.updateStTSL)
                newStretegy.sgAlert.connect(self.showMsgW)
                newStretegy.sgStart.connect(lambda: updateStStatus(self, newStretegy, 'Started'))
                # print("22222")
                newStretegy.sgParamSet.connect(lambda: setStretegyParameters(self, newStretegy))
                # print("33333")
                newStretegy.sgParamSet.connect(lambda: newStretegyRecordUpdate(self, newStretegy, newStretegy.symbol))
                self.Manager.stretegyList_temp.append(newStretegy)
                createLogfile(self, newStretegy, folioName)
                createLogCsvfile(self, newStretegy, folioName)

            except:
                print(traceback.print_exc())

        elif (self.Manager.lastSelectedStretegy == self.Manager.pbJTiger):
            newStretegy = JTiger.logic()
            newStretegy.createObject(self.fo_contract)
            folioName = str(self.Manager.lastSerialNo) + '_JTiger'
            # print(folioName)
            refresh(newStretegy)
            # print("folioName : ", folioName)
            newStretegy.addW.leFolioName.setText(folioName)
            newStretegy.addW.cbClient.addItems(self.client_list)

            newStretegy.modifyW.leFolioName.setText(folioName)
            newStretegy.modifyW.cbClient.addItems(self.client_list)
            newStretegy.getBaseInfo(newStretegy.addW)
            self.Manager.stretegyList_temp.append(newStretegy)

            newStretegy.sgMTM.connect(self.updateStMTM)
            newStretegy.sgSL.connect(self.updateStSL)
            newStretegy.sgTarget.connect(self.updateStTarget)
            newStretegy.addW.show()

            # newStretegy.timerUpdateWindows.start()
            # newStretegy.timerGetPrices.start()

            #newStretegy.sgTSL.connect(self.updateStTSL)
            newStretegy.sgAlert.connect(self.showMsgW)
            newStretegy.sgStart.connect(lambda: updateStStatus(self, newStretegy, 'Started'))
            # print("22222")
            newStretegy.sgParamSet.connect(lambda: setStretegyParameters(self, newStretegy))
            # print("33333_parth ",self.Manager.stretegyList_temp)
            newStretegy.sgParamSet.connect(lambda: newStretegyRecordUpdate(self, newStretegy, newStretegy.symbol))
            self.Manager.stretegyList_temp.append(newStretegy)
            createLogfile(self, newStretegy, folioName)


        elif (self.Manager.lastSelectedStretegy == self.Manager.pbValSp):
            newStretegy = ValSpread.logic()
            newStretegy.createObject(self.fo_contract)
            folioName = str(self.Manager.lastSerialNo) + '_ValSpread'
            refresh(newStretegy)


            newStretegy.addW.leFolioName.setText(folioName)
            newStretegy.addW.cbClient.addItems(self.client_list)
            newStretegy.getBaseInfo(newStretegy.addW)
            newStretegy.connect2slots()

            newStretegy.modifyW.leFolioName.setText(folioName)
            newStretegy.modifyW.cbClient.addItems(self.client_list)
            newStretegy.sgMTM.connect(self.updateStMTM)
            newStretegy.sgTarget.connect(self.updateStTarget)

            newStretegy.sgSL.connect(self.updateStSL)
            newStretegy.sgAlert.connect(self.showMsgW)
            newStretegy.sgStart.connect(lambda: updateStStatus(self, newStretegy, 'Started'))
            newStretegy.sgParamSet.connect(lambda: setStretegyParameters(self, newStretegy))
            newStretegy.sgParamSet.connect(lambda: newStretegyRecordUpdate(self, newStretegy, newStretegy.symbol))
            # add in temp list
            self.Manager.stretegyList_temp.append(newStretegy)

            newStretegy.addW.show()

            newStretegy.addW.bt_close.clicked.connect(lambda:popTempStretegy(self,newStretegy))
            newStretegy.addW.bt_min.clicked.connect(lambda:popTempStretegy(self,newStretegy))
            newStretegy.addW.quitSc = QShortcut(QKeySequence('Esc'), newStretegy.addW)
            newStretegy.addW.quitSc.activated.connect(newStretegy.addW.hide)
            newStretegy.addW.quitSc.activated.connect(lambda:popTempStretegy(self,newStretegy))
            newStretegy.modifyW.sgGetFolioBook.connect(self.stFolioBook)

            # newStretegy.timerUpdateWinodws.start()
            # newStretegy.timerGetPrices.start()

        elif (self.Manager.lastSelectedStretegy == self.Manager.pbVixMonkey):
            newStretegy = VixMonkey.logic()
            newStretegy.createObject(self.fo_contract)
            folioName = str(self.Manager.lastSerialNo) + '_VixMonkey'
            # print(folioName)
            refresh(newStretegy)
            # print("folioName : ", folioName)
            newStretegy.addW.leFolioName.setText(folioName)
            newStretegy.addW.cbClient.addItems(self.client_list)
            newStretegy.getBaseInfo(newStretegy.addW)
            newStretegy.connect2slots()

            newStretegy.modifyW.leFolioName.setText(folioName)
            newStretegy.modifyW.cbClient.addItems(self.client_list)

            newStretegy.sgMTM.connect(self.updateStMTM)
            newStretegy.sgSL.connect(self.updateStSL)
            newStretegy.sgTarget.connect(self.updateStTarget)

            newStretegy.sgAlert.connect(self.showMsgW)
            newStretegy.sgStart.connect(lambda: updateStStatus(self, newStretegy, 'Started'))
            newStretegy.sgParamSet.connect(lambda: setStretegyParameters(self, newStretegy))
            newStretegy.sgParamSet.connect(lambda: newStretegyRecordUpdate(self, newStretegy, newStretegy.symbol))
            # add in temp list
            self.Manager.stretegyList_temp.append(newStretegy)

            newStretegy.addW.show()

            newStretegy.addW.bt_close.clicked.connect(lambda:popTempStretegy(self,newStretegy))
            newStretegy.addW.bt_min.clicked.connect(lambda:popTempStretegy(self,newStretegy))
            newStretegy.addW.quitSc = QShortcut(QKeySequence('Esc'), newStretegy.addW)
            newStretegy.addW.quitSc.activated.connect(newStretegy.addW.hide)
            newStretegy.addW.quitSc.activated.connect(lambda:popTempStretegy(self,newStretegy))

        elif (self.Manager.lastSelectedStretegy == self.Manager.pbOCheetah):
            newStretegy = OCheetah.logic()
            newStretegy.createObject(self.fo_contract)
            folioName = str(self.Manager.lastSerialNo) + '_OCheetah'
            # print(folioName)
            refresh(newStretegy)
            # print("folioName : ", folioName)
            newStretegy.addW.leFolioName.setText(folioName)
            newStretegy.addW.cbClient.addItems(self.client_list)

            newStretegy.modifyW.leFolioName.setText(folioName)
            newStretegy.modifyW.cbClient.addItems(self.client_list)
            newStretegy.getBaseInfo(newStretegy.addW)
            self.Manager.stretegyList_temp.append(newStretegy)

            newStretegy.sgMTM.connect(self.updateStMTM)
            newStretegy.sgSL.connect(self.updateStSL)
            newStretegy.sgTarget.connect(self.updateStTarget)
            newStretegy.addW.show()

            # newStretegy.timerUpdateWindows.start()
            # newStretegy.timerGetPrices.start()

            #newStretegy.sgTSL.connect(self.updateStTSL)
            newStretegy.sgAlert.connect(self.showMsgW)
            newStretegy.sgStart.connect(lambda: updateStStatus(self, newStretegy, 'Started'))
            # print("22222")
            newStretegy.sgParamSet.connect(lambda: setStretegyParameters(self, newStretegy))
            # print("33333_parth ",self.Manager.stretegyList_temp)
            newStretegy.sgParamSet.connect(lambda: newStretegyRecordUpdate(self, newStretegy, newStretegy.symbol))
            self.Manager.stretegyList_temp.append(newStretegy)
            createLogfile(self, newStretegy, folioName)
            createLogCsvfile(self, newStretegy, folioName)


        elif (self.Manager.lastSelectedStretegy == self.Manager.pbEMASpecial):
            newStretegy = EMAS.logic()
            newStretegy.createObject(self.fo_contract)
            folioName = str(self.Manager.lastSerialNo) + '_EMASpecial'
            # print(folioName)
            refresh(newStretegy)
            # print("folioName : ", folioName)

            newStretegy.addW.leFolioName.setText(folioName)
            newStretegy.addW.cbClient.addItems(self.client_list)

            newStretegy.modifyW.leFolioName.setText(folioName)
            newStretegy.modifyW.cbClient.addItems(self.client_list)
            newStretegy.getBaseInfo(newStretegy.addW)

            newStretegy.addW.show()

            newStretegy.timerUpdateWindows.start()
            newStretegy.timerGetPrices.start()
            newStretegy.sgMTM.connect(self.updateStMTM)
            newStretegy.sgSL.connect(self.updateStSL)
            # newStretegy.sgTSL.connect(self.updateStTSL)
            newStretegy.sgAlert.connect(self.showMsgW)
            newStretegy.sgStart.connect(lambda: updateStStatus(self, newStretegy, 'Started'))
            # print("22222")
            newStretegy.sgParamSet.connect(lambda: setStretegyParameters(self, newStretegy))
            # print("33333")
            newStretegy.sgParamSet.connect(lambda: newStretegyRecordUpdate(self, newStretegy, newStretegy.symbol))
            self.Manager.stretegyList_temp.append(newStretegy)
            createLogfile(self, newStretegy, folioName)
            createLogCsvfile(self, newStretegy, folioName)

        elif (self.Manager.lastSelectedStretegy == self.Manager.pbJodiST):
            try:
                newStretegy = JodiST.logic()
                newStretegy.createObject(self.fo_contract)
                folioName = str(self.Manager.lastSerialNo) + '_Jodi-ST'
                refresh(newStretegy)

                newStretegy.addW.leFolioName.setText(folioName)
                newStretegy.addW.cbClient.addItems(self.client_list)

                newStretegy.modifyW.leFolioName.setText(folioName)
                newStretegy.modifyW.cbClient.addItems(self.client_list)
                newStretegy.getBaseInfo(newStretegy.addW)
                # newStretegy.connect2slots()

                newStretegy.addW.show()
                # newStretegy.modifyW.sgGetFolioBook.connect(self.stFolioBook)

                # newStretegy.timerUpdateWinodws.start()
                # newStretegy.timerGetPrices.start()
                newStretegy.sgMTM.connect(self.updateStMTM)
                newStretegy.sgTarget.connect(self.updateStTarget)

                newStretegy.sgSL.connect(self.updateStSL)
                newStretegy.sgAlert.connect(self.showMsgW)
                newStretegy.sgStart.connect(lambda: updateStStatus(self, newStretegy, 'Started'))
                newStretegy.sgParamSet.connect(lambda: setStretegyParameters(self, newStretegy))
                newStretegy.sgParamSet.connect(lambda: newStretegyRecordUpdate(self, newStretegy, newStretegy.symbol))
                # add in temp list


                newStretegy.addW.bt_close.clicked.connect(lambda: popTempStretegy(self, newStretegy))
                newStretegy.addW.bt_min.clicked.connect(lambda: popTempStretegy(self, newStretegy))
                newStretegy.addW.quitSc = QShortcut(QKeySequence('Esc'), newStretegy.addW)
                newStretegy.addW.quitSc.activated.connect(newStretegy.addW.hide)
                newStretegy.addW.quitSc.activated.connect(lambda: popTempStretegy(self, newStretegy))
                self.Manager.stretegyList_temp.append(newStretegy)
                createLogfile(self, newStretegy, folioName)
                createLogCsvfile(self, newStretegy, folioName)
            except:
                print(traceback.print_exc())

        elif (self.Manager.lastSelectedStretegy == self.Manager.pbJCat):
            try:
                newStretegy = JCat.logic()
                newStretegy.createObject(self.fo_contract)
                folioName = str(self.Manager.lastSerialNo) + '_JCat'
                refresh(newStretegy)

                newStretegy.addW.leFolioName.setText(folioName)
                newStretegy.addW.cbClient.addItems(self.client_list)

                newStretegy.modifyW.leFolioName.setText(folioName)
                newStretegy.modifyW.cbClient.addItems(self.client_list)
                newStretegy.getBaseInfo(newStretegy.addW)
                # newStretegy.connect2slots()

                newStretegy.addW.show()
                # newStretegy.modifyW.sgGetFolioBook.connect(self.stFolioBook)

                # newStretegy.timerUpdateWinodws.start()
                # newStretegy.timerGetPrices.start()
                newStretegy.sgMTM.connect(self.updateStMTM)
                newStretegy.sgTarget.connect(self.updateStTarget)

                newStretegy.sgSL.connect(self.updateStSL)
                newStretegy.sgAlert.connect(self.showMsgW)
                newStretegy.sgStart.connect(lambda: updateStStatus(self, newStretegy, 'Started'))
                newStretegy.sgParamSet.connect(lambda: setStretegyParameters(self, newStretegy))
                newStretegy.sgParamSet.connect(lambda: newStretegyRecordUpdate(self, newStretegy, newStretegy.symbol))
                # add in temp list


                newStretegy.addW.bt_close.clicked.connect(lambda: popTempStretegy(self, newStretegy))
                newStretegy.addW.bt_min.clicked.connect(lambda: popTempStretegy(self, newStretegy))
                newStretegy.addW.quitSc = QShortcut(QKeySequence('Esc'), newStretegy.addW)
                newStretegy.addW.quitSc.activated.connect(newStretegy.addW.hide)
                newStretegy.addW.quitSc.activated.connect(lambda: popTempStretegy(self, newStretegy))
                self.Manager.stretegyList_temp.append(newStretegy)
                createLogfile(self, newStretegy, folioName)
            except:
                print(traceback.print_exc())

        elif (self.Manager.lastSelectedStretegy == self.Manager.pbLevelSpecial):
            try:
                newStretegy = LevelSpecial.logic()
                newStretegy.createObject(self.fo_contract)
                folioName = str(self.Manager.lastSerialNo) + '_LevelSpecial'
                refresh(newStretegy)

                newStretegy.addW.leFolioName.setText(folioName)
                newStretegy.addW.cbClient.addItems(self.client_list)

                newStretegy.modifyW.leFolioName.setText(folioName)
                newStretegy.modifyW.cbClient.addItems(self.client_list)
                newStretegy.getBaseInfo(newStretegy.addW)
                # newStretegy.connect2slots()

                newStretegy.addW.show()
                # newStretegy.modifyW.sgGetFolioBook.connect(self.stFolioBook)

                # newStretegy.timerUpdateWinodws.start()
                # newStretegy.timerGetPrices.start()
                newStretegy.sgMTM.connect(self.updateStMTM)
                newStretegy.sgSL.connect(self.updateStSL)
                newStretegy.sgTarget.connect(self.updateStTarget)

                newStretegy.sgAlert.connect(self.showMsgW)
                newStretegy.sgStart.connect(lambda: updateStStatus(self, newStretegy, 'Started'))
                newStretegy.sgParamSet.connect(lambda: setStretegyParameters(self, newStretegy))
                newStretegy.sgParamSet.connect(lambda: newStretegyRecordUpdate(self, newStretegy, newStretegy.symbol))
                # add in temp list


                newStretegy.addW.bt_close.clicked.connect(lambda: popTempStretegy(self, newStretegy))
                newStretegy.addW.bt_min.clicked.connect(lambda: popTempStretegy(self, newStretegy))
                newStretegy.addW.quitSc = QShortcut(QKeySequence('Esc'), newStretegy.addW)
                newStretegy.addW.quitSc.activated.connect(newStretegy.addW.hide)
                newStretegy.addW.quitSc.activated.connect(lambda: popTempStretegy(self, newStretegy))
                self.Manager.stretegyList_temp.append(newStretegy)
                createLogfile(self, newStretegy, folioName)
                createLogCsvfile(self, newStretegy, folioName)
            except:
                print(traceback.print_exc())









    @pyqtSlot(str,str)
    def stFolioBook(self,folioName,clientId):
        # print('xyz')
        showFolioPosW(self,folioName,clientId)

    def showMsgW(self,data):
        pass
        # self.msg.setText(data)

        # self.msg.show()

    def updateStMTM(self, folio, mtm):
        # print('------mtm----',mtm,folio)
        rowIndex = np.where(self.Manager.table[:, 3] == folio)[0][0]
        # print('updateStMTM rowindex',rowIndex)
        self.Manager.table[rowIndex, 5] = mtm
        ind1 = self.Manager.model.index(rowIndex, 5)
        self.Manager.model.dataChanged.emit(ind1, ind1)

    def updateStSL(self, folio, sl):
        # print("Updated SL",folio,sl)
        rowIndex = np.where(self.Manager.table[:, 3] == folio)[0][0]
        # print('updateStSL rowindex',rowIndex)
        self.Manager.table[rowIndex, 6] = sl
        # print("SSSSllllll",sl)
        ind1 = self.Manager.model.index(rowIndex, 6)
        self.Manager.model.dataChanged.emit(ind1, ind1)

    def updateStTSL(self, folio, tsl):
        rowIndex = np.where(self.Manager.table[:, 3] == folio)[0][0]
        self.Manager.table[rowIndex, 7] = tsl
        # print('tsl rowindex',self.tsl)
        ind1 = self.Manager.model.index(rowIndex,7)
        self.Manager.model.dataChanged.emit(ind1, ind1)

    def updateStTarget(self, folio, target):
        rowIndex = np.where(self.Manager.table[:, 3] == folio)[0][0]
        self.Manager.table[rowIndex, 8] = target
        ind1 = self.Manager.model.index(rowIndex,8)
        self.Manager.model.dataChanged.emit(ind1, ind1)


    def addFolio(self,folio,clientId=''):
        # print('folio',folio,'clientId',clientId)
        self.buyW.cbStretegyNo.addItem(folio)
        self.sellW.cbStretegyNo.addItem(folio)
        self.FolioPos.folioList.append(folio)
        self.FolioPos.cbUID.addItem(folio)
        try:
            self.swapOrder.cbFolio.addItem(folio)
            self.spreadOrder.cbFolio.addItem(folio)
        except:
            print(traceback.print_exc())



        if(clientId not in self.FolioPos.clientFolios.keys()):
            self.FolioPos.clientFolios[clientId] = []
        self.FolioPos.clientFolios[clientId].append(folio)
        rc= (self.FolioPos.cbUID.model().rowCount())
        for i in range(rc):
            pass
            # print(self.FolioPos.cbUID.model().index(i,0).data())

        # a=QComboBox()
        # a.
        # self.FolioPos.clientFolios.app

    def deleteFolio(self,folio,clientId):
        # print('folio',folio,'clientId',clientId)
        # print(self.Manager.stretegyList)

        index=self.buyW.cbStretegyNo.findText(folio)
        self.buyW.cbStretegyNo.removeItem(index)
        self.sellW.cbStretegyNo.removeItem(index)


        # self.FolioPos.folioList.remove(folio)
        #
        # try:
        #     self.swapOrder.cbFolio.removeItem(index)
        #     self.spreadOrder.cbFolio.removeItem(index)
        # except:
        #     print(traceback.print_exc())




    def setMrgLvl(self,a):
        # print('setMrgLvl',a)
        self.Mrglvl = a


    def showNotificationMessage(self , tray:QSystemTrayIcon):
        notificationTitel = self.notification_title.text()
        notificationMessage = self.notification_message.toPlainText()
        icon = QIcon(u":/Application/Resourses/icons/info.svg")
        duration = 3* 1000

        if len(notificationTitel) == 0 or len(notificationMessage) == 0:
            tray.showMessage("Input Somthing","Entrer your notification" ,icon, duration)
        else:
            tray.showMessage(notificationTitel,notificationMessage,icon,duration)


    def requestContextMenus(self):
        self.marketW.tableView.customContextMenuRequested.connect(self.tableRightClickMenu_mw1)
    def tableRightClickMenu_mw1(self,pos):
        tableRightClickMenu_mw(self,pos)
        # tableRightClickMenu_mw_Basic(self,pos)

    def updateStatusLable(main, data , tag):

        if(tag=='Rejection' and main.isUpdateStatusRejection==True ):
            main.lbStatus.setStyleSheet('background-color: rgb(220, 41, 56)')

            main.lbStatus.setText(tag + '     ' + data)
            main.timerChStatus.stop()
            main.timerChStatus.setInterval(5000)
            main.timerChStatus.start()

            if(main.isRejectionPopup):
                messageBox = QMessageBox()
                messageBox.setIcon(QMessageBox.Critical)
                messageBox.setWindowFlags(Qt.WindowStaysOnTopHint)
                messageBox.setText('Your Order Is Rejected!!!')
                messageBox.show()

        elif(tag=='Trade' and main.isUpdateStatusTrade==True):

            main.lbStatus.setText(tag + '     '+data)
            main.timerChStatus.stop()
            main.timerChStatus.setInterval(5000)
            main.timerChStatus.start()

    def updateNetMTM(self):
        totalmtm=np.sum(self.marketW.table[:,15])
        self.label.setText('%.2f'% totalmtm)
    #
    def updateNetMTM_NP(self):
        totalmtm=np.sum(self.NetPos.Apipos[:,10])
        self.NetPos.lbMTM.setText('%.2f'% totalmtm)

    def updateNetMTM_FP(self):
        totalmtm=np.sum(self.FolioPos.table[:,21])
        self.FolioPos.lbMTM.setText('%.2f'% totalmtm)


    def CloseButtonClicked(self,i):
        CloseButtonClicked(self,i)

    def QuitButtonClicked(self,i):
        QuitButtonClicked(self,i)

    def saveTradestoDatabase(self):
        saveTradestoDatabase(self)


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = Ui_Main()
    showSplashScreen(form)
    sys.exit(app.exec_())
