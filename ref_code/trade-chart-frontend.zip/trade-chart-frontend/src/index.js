// import * as ReactDOMClient from "react-dom/client";
// import App from "./App";
// import "./index.css";

// const container = document.getElementById("root");
// const root = ReactDOMClient.createRoot(container);
// root.render(<App />);

import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import App from "./App";

const Main = () => {
  return (
    <Router>
      <Routes>
        <Route path="/chart" element={<App />} />
      </Routes>
    </Router>
  );
};

ReactDOM.render(<Main />, document.getElementById("root"));
