import React from "react";

export async function getAllSymbols(userInput) {
  try {
    const response = await fetch(
      `${process.env.REACT_APP_URL}/api/v1/tradingview/stock-list/fetch?search=${userInput}`,
      {
        method: "GET", // Specify HTTP method (optional; default is "GET")
        headers: {
          Authorization: "token",
        },
      }
    );

    const data = await response.json();
    console.log("data", data);
    return data.data;
  } catch (err) {
    console.error(err);
  }

  let allSymbols = [];

  // for (const exchange of configurationData.exchanges) {
  //     const pairs = data.Data[exchange.value].pairs;

  //     for (const leftPairPart of Object.keys(pairs)) {
  //         const symbols = pairs[leftPairPart].map(rightPairPart => {
  //             const symbol = generateSymbol(exchange.value, leftPairPart, rightPairPart);
  //             return {
  //                 symbol: symbol.short,
  //                 ticker: symbol.short,
  //                 description: symbol.short,
  //                 exchange: exchange.value,
  //                 type: 'crypto',
  //             };
  //         });
  //         allSymbols = [...allSymbols, ...symbols];
  //     }
  // }
  // return allSymbols;
}

export function formatDate(date) {
  const months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];
  const d = new Date(date);
  const month = months[d.getMonth()];
  const day = String(d.getDate()).padStart(2, "0");
  const year = d.getFullYear();
  const hours = String(d.getHours()).padStart(2, "0");
  const minutes = String(d.getMinutes()).padStart(2, "0");
  const seconds = String(d.getSeconds()).padStart(2, "0");

  return `${month} ${day} ${year} ${hours}${minutes}${seconds}`;
}
