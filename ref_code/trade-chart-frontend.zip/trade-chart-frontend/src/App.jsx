import { TVChartContainer } from "./components/TVChartContainer";
import { version } from "./charting_library";

const App = () => {
  return <TVChartContainer />;
};

export default App;
