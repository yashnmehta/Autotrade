import io from "socket.io-client";
import { getQueryParam } from "./datafeed";

const channelToSubscription = new Map();

console.log("channelToSubscription", channelToSubscription);

function getNextDailyBarTime(barTime) {
  const date = new Date(barTime * 1000);
  date.setDate(date.getDate() + 1);
  return date.getTime() / 1000;
}

const userID = "A0031";
const socket = io("http://192.168.102.9:3000/", {
  path: "/apimarketdata/socket.io",
  transports: ["websocket"],
  query: {
    token: getQueryParam("authToken"),
    userID,
    publishFormat: "JSON",
    broadcastMode: "Full",
    apiType: "APIMARKETDATA",
  },
  forceNew: true,
});

const IST_OFFSET = 5 * 60 * 60 * 1000 + 30 * 60 * 1000;

socket.on("connect", () => {
  console.log("[socket] Connected");
});

socket.on("disconnect", (reason) => {
  console.log("[socket] Disconnected:", reason);
});       

socket.on("connect_error", (error) => {
  console.error("[socket] Connection error:", error);
});

socket.on("error", (error) => {
  console.error("[socket] Error:", error);
});

// Listen for messages
socket.on("message", (data) => {
  console.log("[socket] Message received:", data);
});

// Example of subscribing to a custom event (if applicable)
socket.on("customEvent", (data) => {
  console.log("[socket] Custom event received:", data);
});

const tenYearsInMs = 10 * 365.25 * 24 * 60 * 60 * 1000;

const handleLiveData = (data) => {
  const tradePrice = parseFloat(data.Touchline?.LastTradedPrice).toFixed(2);
  const tradeTime =
    Number(data.ExchangeTimeStamp) * 1000 +
    tenYearsInMs -
    IST_OFFSET -
    43200000;

  // 0~NSE~NIFTY~INR
  const channelString = `0~NSE~${getQueryParam("symbol")}~INR`;
  console.log("channelString", channelString);
  let subscriptionItem = channelToSubscription.get(channelString);

  if (!subscriptionItem) {
    const timeDate = new Date(tradeTime);
    subscriptionItem = {
      lastDailyBar: {
        time: timeDate, // Initialize time with current tradeTime
        open: tradePrice,
        high: tradePrice,
        low: tradePrice,
        close: tradePrice,
      },
      handlers: [], // Initialize with an empty handlers array
    };
    channelToSubscription.set(channelString, subscriptionItem);
    subscriptionItem.handlers.forEach((handler) =>
      handler.callback(subscriptionItem.lastDailyBar)
    );
    return;
  }

  const lastBar = subscriptionItem?.lastDailyBar;

  let bar;
  const nextBarTime = new Date(lastBar?.time).getTime();
  // const nextBarTime = getNextBarTime(new Date(lastBar?.time).getTime());
  const istTime = new Date(lastBar?.time);
  if (!lastBar || tradeTime > nextBarTime) {
    bar = {
      time: new Date(tradeTime),
      open: tradePrice,
      high: tradePrice,
      low: tradePrice,
      close: tradePrice,
    };
    console.log("[Live] New bar created:", bar);
  } else {
    // Update the existing bar
    bar = {
      ...lastBar,
      high: Math.max(lastBar.high, tradePrice).toFixed(2),
      low: Math.min(lastBar.low, tradePrice).toFixed(2),
      close: tradePrice,
    };
    console.log("[Live] Updated bar:", bar);
  }
  subscriptionItem.lastDailyBar = bar;
  subscriptionItem.handlers.forEach((handler) => handler.callback(bar));
};

const handleOneMinuteCandle = (data) => {
  const timestampMillis = parseInt(data.BarTime, 10) * 1000;
  const utcTime = new Date(timestampMillis);
  const IST_OFFSET = 5 * 60 * 60 * 1000 + 30 * 60 * 1000;
  const istTime = new Date(utcTime.getTime() - IST_OFFSET);
  const bar = {
    time: istTime,
    open: data.Open,
    high: data.High,
    low: data.Low,
    close: data.Close,
  };

  const channelString = `0~NSE~${getQueryParam("symbol")}~INR`;
  const subscriptionItem = channelToSubscription.get(channelString);

  if (!subscriptionItem) return;

  const lastBar = subscriptionItem.lastDailyBar;

  if (!lastBar) {
    subscriptionItem.lastDailyBar = bar;
    subscriptionItem.handlers.forEach((handler) => handler.callback(bar));
    return;
  }

  const barTimeInMSEC = new Date(istTime).getTime();
  const lastbarTimeInMSEC = new Date(lastBar?.time).getTime();

  if (barTimeInMSEC > lastbarTimeInMSEC) {
    // Only create a new bar if this is a new minute
    subscriptionItem.lastDailyBar = bar;
    console.log("[Candle] New bar received:", bar);
  }

  // if (barTimeInMSEC > lastBar.time) {
  //   console.log("[Candle] New bar received:", bar);
  //   subscriptionItem.lastDailyBar = bar;
  // } else {
  //   console.log("[Candle] Updating bar with 1-min data:", bar);
  //   subscriptionItem.lastDailyBar = {
  //     ...lastBar,
  //     high: Math.max(lastBar.high, bar.high),
  //     low: Math.min(lastBar.low, bar.low),
  //     close: bar.close,
  //   };
  // }
  subscriptionItem.handlers.forEach((handler) => handler.callback(bar));
};

// Event Listeners
// socket.addEventListener("1501-json-full", (event) => {
//   const data = JSON.parse(event);
//   handleLiveData(data);
// });

// socket.addEventListener("1505-json-full", (event) => {
//   const data = JSON.parse(event);
//   handleOneMinuteCandle(data);
// });

// Helper to calculate the next bar time
const getNextBarTime = (currentBarTime) => {
  const oneMinute = 60 * 1000; // 1 min in ms
  return currentBarTime + oneMinute;
};

export function subscribeOnStream(
  symbolInfo,
  resolution,
  onRealtimeCallback,
  subscriberUID,
  onResetCacheNeededCallback,
  lastDailyBar
) {
  // const parsedSymbol = parseFullSymbol(symbolInfo.full_name);
  const parsedSymbol = {
    exchange: "NSE",
    fromSymbol: getQueryParam("symbol"),
    toSymbol: "INR",
  };
  const channelString = `0~${parsedSymbol.exchange}~${parsedSymbol.fromSymbol}~${parsedSymbol.toSymbol}`;

  const handler = {
    id: subscriberUID,
    callback: onRealtimeCallback,
  };

  let subscriptionItem = channelToSubscription.get(channelString);

  if (subscriptionItem) {
    // Already subscribed to the channel, use the existing subscription
    subscriptionItem.handlers.push(handler);
    return;
  }

  subscriptionItem = {
    subscriberUID,
    resolution,
    lastDailyBar,
    handlers: [handler],
  };

  channelToSubscription.set(channelString, subscriptionItem);
  console.log(
    "[subscribeBars]: Subscribe to streaming. Channel:",
    channelString
  );

  const subRequest = {
    action: "SubAdd",
    subs: [channelString],
  };
  socket.send(JSON.stringify(subRequest));
}

export function unsubscribeFromStream(subscriberUID) {
  for (const channelString of channelToSubscription.keys()) {
    const subscriptionItem = channelToSubscription.get(channelString);
    const handlerIndex = subscriptionItem.handlers.findIndex(
      (handler) => handler.id === subscriberUID
    );

    if (handlerIndex !== -1) {
      // Remove from handlers
      subscriptionItem.handlers.splice(handlerIndex, 1);

      if (subscriptionItem.handlers.length === 0) {
        // Unsubscribe from the channel if it was the last handler
        console.log(
          "[unsubscribeBars]: Unsubscribe from streaming. Channel:",
          channelString
        );
        const subRequest = {
          action: "SubRemove",
          subs: [channelString],
        };
        socket.send(JSON.stringify(subRequest));
        channelToSubscription.delete(channelString);
        break;
      }
    }
  }
}
