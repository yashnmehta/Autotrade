import { formatDate, getAllSymbols } from "../utils/ApiHelper";
import { subscribeOnStream } from "./streaming";

const userID = "A0031";
const Exchange = window.Exchange;
let socket;

const lastBarsCache = new Map();

export function getQueryParam(param) {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get(param);
}
const configurationData = {
  supports_search: true,
  supports_group_request: false,
  supports_marks: true,
  supports_timescale_marks: true,
  supports_time: true,
  exchanges: [
    { value: "", name: "All Exchanges", desc: "" },
    { value: "NasdaqNM", name: "NasdaqNM", desc: "NasdaqNM" },
    { value: "NYSE", name: "NYSE", desc: "NYSE" },
  ],
  symbols_types: [
    { name: "All types", value: "" },
    { name: "Stock", value: "stock" },
    { name: "Index", value: "index" },
  ],
  supported_resolutions: ["1", "5", "15", "30", "60", "1D", "1W"],
};
export default {
  onReady: (callback) => {
    setTimeout(() => callback(configurationData));
  },

  searchSymbols: async (
    userInput,
    exchange,
    symbolType,
    onResultReadyCallback
  ) => {
    const symbols = await getAllSymbols(userInput);

    console.log("symbols", symbols);
    // const newSymbols = symbols?.data?.filter((symbol) => {
    //   const isExchangeValid = exchange === "" || symbol.exchange === "NSE";
    //   const fullName = `${symbol.exchange}:${symbol.ticker}`;
    //   const isFullSymbolContainsInput =
    //     fullName.toLowerCase().indexOf(userInput.toLowerCase()) !== -1;
    //   return isExchangeValid && isFullSymbolContainsInput;
    // });
    // console.log("newSymbols", newSymbols);
    onResultReadyCallback(symbols);
  },

  resolveSymbol: async (
    symbolName,
    onSymbolResolvedCallback,
    onResolveErrorCallback
  ) => {
    console.log("hiiii", symbolName);

    const Exchange = window.Exchange;
    const symbols = await getAllSymbols();
    const symbol = getQueryParam("symbol");
    if (!symbol) {
      onResolveErrorCallback("unknown_symbol");
    } else {
      const symbolInfo = {
        ticker: symbol,
        name: symbol,
        type: "stock",
        session: "0915-1530",
        timezone: "Asia/Kolkata",
        exchange: Exchange || "NSE",
        minmov: 1,
        pricescale: 100,
        has_intraday: true,
        has_daily: true,
        has_weekly_and_monthly: true,
        visible_plots_set: "ohlcv",
        supported_resolutions: [
          "1", // 1 minute*-
          "5", // 5 minutes
          "15", // 15 minutes
          "30", // 30 minutes
          "60", // 1 hour
          "1D", // 1 day
        ],
        data_status: "streaming",
      };

      if (!symbolInfo.supported_resolutions.includes("1D")) {
        console.log(
          "1D resolution is not supported. Removing from the available resolutions."
        );
      }
      setTimeout(() => onSymbolResolvedCallback(symbolInfo), 0);
    }
  },

  // getBars: async (
  //   symbolInfo,
  //   resolution,
  //   periodParams,
  //   onHistoryCallback,
  //   onErrorCallback = (error) => console.error("Error fetching bars:", error)
  // ) => {
  //   const authToken = getQueryParam("authToken");
  //   const symbol = getQueryParam("symbol");

  //   console.log("resolution", resolution);

  //   console.log("periodParams", periodParams);

  //   if (!authToken || !symbol) {
  //     console.error("Missing authToken or symbol in URL parameters.");
  //     return onErrorCallback("Missing authToken or symbol");
  //   }

  //   const exchangeInstrumentID = getQueryParam("exchangeInstrumentID");
  //   const exchange = getQueryParam("exchange");

  //   // Build the API URL dynamically
  //   const url = `http://192.168.102.9:3000/apimarketdata/instruments/ohlc?exchangeSegment=${exchange}&exchangeInstrumentID=${exchangeInstrumentID}&startTime=Feb%2001%202024%20091500&endTime=Dec%2031%202024%20235322&compressionValue=60`;

  //   try {
  //     const response = await fetch(url, {
  //       headers: {
  //         Authorization: authToken,
  //       },
  //     });

  //     if (response.status === 200) {
  //       const jsonResponse = await response.json();
  //       const dataResponse = jsonResponse.result.dataReponse;

  //       if (!dataResponse) {
  //         console.error("No data received from the API.");
  //         return onHistoryCallback([], { noData: true });
  //       }

  //       const rawData = dataResponse.split(",");
  //       const bars = rawData.map((item) => {
  //         const [timestamp, open, high, low, close, volume] = item.split("|");
  //         const timestampMillis = parseInt(timestamp, 10) * 1000;
  //         const utcTime = new Date(timestampMillis);
  //         const IST_OFFSET = 5 * 60 * 60 * 1000 + 30 * 60 * 1000;
  //         const istTime = new Date(utcTime.getTime() - IST_OFFSET);

  //         return {
  //           time: istTime,
  //           open: parseFloat(open).toFixed(2),
  //           high: parseFloat(high).toFixed(2),
  //           low: parseFloat(low).toFixed(2),
  //           close: parseFloat(close).toFixed(2),
  //           volume: parseInt(volume, 10),
  //         };
  //       });
  //       console.log("bar", bars);
  //       if (bars.length > 0) {
  //         onHistoryCallback(bars, { noData: false });
  //       } else {
  //         onHistoryCallback([], { noData: true });
  //       }
  //     } else {
  //       console.error(
  //         "Error response from API:",
  //         response.status,
  //         response.statusText
  //       );
  //       onHistoryCallback([], { noData: true });
  //     }
  //   } catch (error) {
  //     console.error("[getBars] Error:", error);

  //     if (typeof onErrorCallback === "function") {
  //       onErrorCallback(error);
  //     }
  //   }
  // },

  getBars: async (
    symbolInfo,
    resolution,
    periodParams,
    onHistoryCallback,
    onErrorCallback = (error) => console.error("Error fetching bars:", error)
  ) => {
    const authToken = getQueryParam("authToken");
    const symbol = getQueryParam("symbol");

    console.log("resolution", resolution);
    console.log("periodParams", periodParams);

    if (!authToken || !symbol) {
      console.error("Missing authToken or symbol in URL parameters.");
      return onErrorCallback("Missing authToken or symbol");
    }

    const exchangeInstrumentID = getQueryParam("exchangeInstrumentID");
    const exchange = getQueryParam("exchange");

    // Extract periodParams values (from, to, etc.)

    const { from, to, countBack, firstDataRequest } = periodParams;
    const startTime = formatDate(from * 1000);
    const endTime = formatDate(to * 1000);

    const url = `http://192.168.102.9:3000/apimarketdata/instruments/ohlc?exchangeSegment=${exchange}&exchangeInstrumentID=${exchangeInstrumentID}&startTime=${startTime}&endTime=${endTime}&compressionValue=60`;

    try {
      const response = await fetch(url, {
        headers: {
          Authorization: authToken,
        },
      });

      if (response.status === 200) {
        const jsonResponse = await response.json();
        const dataResponse = jsonResponse.result.dataReponse;

        if (!dataResponse) {
          console.error("No data received from the API.");
          return onHistoryCallback([], { noData: false });
        }

        const rawData = dataResponse.split(",");
        const bars = rawData.map((item) => {
          const [timestamp, open, high, low, close, volume] = item.split("|");
          const timestampMillis = parseInt(timestamp, 10) * 1000;
          const utcTime = new Date(timestampMillis);
          const IST_OFFSET = 5 * 60 * 60 * 1000 + 30 * 60 * 1000;
          const istTime = new Date(utcTime.getTime() - IST_OFFSET);

          return {
            time: istTime,
            open: parseFloat(open).toFixed(2),
            high: parseFloat(high).toFixed(2),
            low: parseFloat(low).toFixed(2),
            close: parseFloat(close).toFixed(2),
            volume: parseInt(volume, 10),
          };
        });

        console.log("bar", bars);
        if (bars.length > 0) {
          onHistoryCallback(bars, { noData: false });
        } else {
          console.log("error while getting bars");
          onHistoryCallback([], { noData: false });
        }
      } else {
        console.error(
          "Error response from API:",
          response.status,
          response.statusText
        );
        onHistoryCallback([], { noData: false });
      }
    } catch (error) {
      console.error("[getBars] Error:", error);

      if (typeof onErrorCallback === "function") {
        onErrorCallback(error);
      }
    }
  },

  subscribeBars: (
    symbolInfo,
    resolution,
    onRealtimeCallback,
    subscriberUID,
    onResetCacheNeededCallback
  ) => {
    subscribeOnStream(
      symbolInfo,
      resolution,
      onRealtimeCallback,
      subscriberUID,
      onResetCacheNeededCallback,
      lastBarsCache.get(symbolInfo.full_name)
    );
  },

  unsubscribeBars: (subscriberUID) => {},
};
