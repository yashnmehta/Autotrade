import { getQueryParam } from "./datafeed";
import axios from "axios";
// Your CryptoCompare API key
export const apiKey = "<api-key>";

// Makes requests to CryptoCompare API
export async function makeApiRequest(path) {
  try {
    const url = new URL(`https://min-api.cryptocompare.com/${path}`);
    url.searchParams.append("api_key", apiKey);
    const response = await fetch(url.toString());
    return response.json();
  } catch (error) {
    throw new Error(`CryptoCompare request error: ${error.status}`);
  }
}

// {
//   "Response": "Success",
//   "Data": [
//       {
//           "time": 1638316800,
//           "close": 1242.85,
//           "high": 1250.00,
//           "low": 1200.00,
//           "open": 1210.00,
//           "volumefrom": 150000,
//           "volumeto": 185000000
//       },
//       ...
//   ]
// }

// Generates a symbol ID from a pair of the coins
export function generateSymbol(exchange, fromSymbol, toSymbol) {
  const short = `${fromSymbol}/${toSymbol}`;
  return {
    short,
  };
}
// {
//   "short": "RELIANCE/INR"
// }

// Returns all parts of the symbol
export function parseFullSymbol(fullSymbol) {
  const match = fullSymbol.match(/^(\w+):(\w+)\/(\w+)$/);
  if (!match) {
    return null;
  }
  return { exchange: match[1], fromSymbol: match[2], toSymbol: match[3] };
}

// {
//   "exchange": "NSE",
//   "fromSymbol": "RELIANCE",
//   "toSymbol": "INR"
// }

const url = "http://192.168.102.9:3000/apimarketdata/instruments/subscription";

const headers = {
  Authorization: getQueryParam("authToken"), // Replace YOUR_TOKEN_HERE with your actual token
  "Content-Type": "application/json",
};

export function subscribeToMarketData(i, exchangeInstrumentID, method = "POST") {
  const body = [
    {
      instruments: [
        {
          exchangeSegment: 1,
          exchangeInstrumentID: exchangeInstrumentID, // Set externally
        },
      ],
      xtsMessageCode: 1501,
    },
    {
      instruments: [
        {
          exchangeSegment: 1,
          exchangeInstrumentID: exchangeInstrumentID, // Set externally
        },
      ],
      xtsMessageCode: 1505,
    },
  ];

  const requestConfig = {
    method,
    url,
    headers,
  };

  if (method === "POST" || method === "PUT") {
    requestConfig.data = body[i];
  }

  axios(requestConfig)
    .then((response) => {
      console.log("Response:", response.data);
    })
    .catch((error) => {
      console.error(
        "Error:",
        error.response ? error.response.data : error.message
      );
    });
}
