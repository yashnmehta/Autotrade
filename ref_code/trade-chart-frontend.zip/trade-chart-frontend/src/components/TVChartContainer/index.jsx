import React, { useEffect, useRef } from "react";
import "./index.css";
import { widget } from "../../charting_library";
import DataFeed, { getQueryParam } from "../datafeed";
import { subscribeToMarketData } from "../helper";

function getLanguageFromURL() {
  const regex = new RegExp("[\\?&]lang=([^&#]*)");
  const results = regex.exec(window.location.search);
  return results === null
    ? null
    : decodeURIComponent(results[1].replace(/\+/g, " "));
}

export const TVChartContainer = () => {
  const chartContainerRef = useRef();

  // symbol: 'AAPL',
  // 	interval: 'D',
  // 	datafeedUrl: 'https://demo_feed.tradingview.com',
  // 	libraryPath: '/charting_library/',
  // 	chartsStorageUrl: 'https://saveload.tradingview.com',
  // 	chartsStorageApiVersion: '1.1',
  // 	clientId: 'tradingview.com',
  // 	userId: 'public_user_id',
  // 	fullscreen: false,
  // 	autosize: true,
  // 	studiesOverrides: {},

  useEffect(() => {
    const defaultProps = {
      interval: "1",
      datafeed: DataFeed,
      libraryPath: "/charting_library/",
      chartsStorageUrl: "http://192.168.119.185:3008/api/v1",
      chartsStorageApiVersion: "tradingview",
      clientId: "abc",
      userId: "xyz",
      fullscreen: false,
      timezone: "Asia/Kolkata",
      autosize: true,
      studiesOverrides: {},
    };

    const widgetOptions = {
      symbol: getQueryParam("symbol") || "RELIANCE",
      interval: defaultProps.interval,
      container: chartContainerRef.current,
      library_path: defaultProps.libraryPath,
      datafeed: defaultProps.datafeed,
      // locale: getLanguageFromURL() || "en",
      disabled_features: [
        // "header_symbol_search",
        // "hide_left_toolbar_by_default",
        // "header_compare",
      ],
      // enabled_features: ["study_templates"],
      charts_storage_url: defaultProps.chartsStorageUrl,
      charts_storage_api_version: defaultProps.chartsStorageApiVersion,
      client_id: defaultProps.clientId,
      user_id: defaultProps.userId,
      fullscreen: defaultProps.fullscreen,
      autosize: defaultProps.autosize,
      studies_overrides: defaultProps.studiesOverrides,
      timezone: defaultProps.timezone,
      full_name: getQueryParam("symbol") || "RELIANCE",
      allow_symbol_change: true,
    };

    const tvWidget = new widget(widgetOptions);
    tvWidget.onChartReady(() => {
      tvWidget.headerReady().then(() => {
        const button = tvWidget.createButton();
        button.setAttribute("title", "Click to show a notification popup");
        button.classList.add("apply-common-tooltip");
        button.addEventListener("click", () =>
          tvWidget.showNoticeDialog({
            title: "Notification",
            body: "TradingView Charting Library API works correctly",
            callback: () => {
              console.log("Noticed!");
            },
          })
        );
        button.innerHTML = "Check API";
      });

      // widget.chart().createStudy("Supertrend", false, false, [2, 7]);
      // tvWidget.subscribe("event", (event) => {
      //   console.log("hi");
      //   console.log("Symbol changed to:", event);
      // });

      // tvWidget.saveChartToServer(() => {
      //   console.log("Chart saved");
      // });

      console.log("Chart is ready and event subscription is set.");
    });
    return () => {
      tvWidget.remove();
    };
  }, []);

  useEffect(() => {
    subscribeToMarketData(0, getQueryParam("exchangeInstrumentID"), "POST");
    // subscribeToMarketData(1);
  }, [getQueryParam("authToken")]);

  return <div ref={chartContainerRef} className={"TVChartContainer"} />;
};
